/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\n#editToolbarExt {\r\n\tdisplay: inline-block;\r\n}\r\n\r\n#editToolbarDiv {\r\n\tposition: relative;\r\n\tfloat: left;\r\n\tz-index: 10;\r\n}\r\n\r\n#editToolbarDiv:hover .editToolbarMenu0 {\r\n\tdisplay: block;\r\n}\r\n\r\n#editToolbarButton {\r\n\tcursor: pointer;\r\n\tborder: 1px solid #aaa;\r\n\tborder-radius: 3px;\r\n\tpadding: 2px;\r\n\tmargin: 1px;\r\n\tbackground-color: #eee;\r\n}\r\n\r\n.editToolbarMenu2 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu2>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu2>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* second level of menus */\r\n.editToolbarMenu1 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu1>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu1>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* first level of menus */\r\n.editToolbarMenu0 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tleft: 0px;\r\n\tlist-style: none;\r\n\tpadding: 1px;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n\tz-index: 10;\r\n}\r\n\r\n.editToolbarMenu0>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmin-width: 160px;\r\n\tmargin-bottom: 1px;\r\n\tfloat: left;\r\n\tz-index: 11;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n\ttext-align: left;\r\n\ttext-decoration: none;\r\n\tcursor: pointer;\r\n}\r\n\r\n.editToolbarMenu0>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* On hover, display the next level's menu */\r\n.editToolbarMenu0 li:hover>ul {\r\n\tdisplay: inline;\r\n}\r\n\r\n/* Menu Link Styles - Apply to all links inside the multi-level menu */\r\n.editToolbarMenu0 a {\r\n\tfont: normal 11px verdana, arial, sans-serif;\r\n\tcolor: #000000;\r\n\ttext-decoration: none !important;\r\n\tpadding: 0px 5px;\r\n\r\n\t/* Make the link cover the entire list item-container */\r\n\tdisplay: block;\r\n\tline-height: 24px;\r\n}\r\n\r\n.editToolbarMenu0 a:link {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:hover {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:visited {\r\n\tcolor: #000000 !important;\r\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 811:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "menu#appsSubMenu {\r\n\tdisplay:none;\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tbackground-color:white !important;\t\r\n\toverflow:visible;\r\n}\r\nmenu#appsSubMenu a{\r\n\tmargin-left:-19.1em;\r\n\tbackground-color:white !important;\r\n\tborder:1px solid #ccc;\r\n\twidth:18em;\r\n\tdisplay:block;\r\n\tpadding:5px;\r\n\tfloat:none;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu a{\r\n\tmargin-left:-22.8em;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu {\r\n\tbackground-color:transparent !important;\r\n}\r\nmenu#appsSubMenu a:hover{\r\n\tbackground-color:#ffe270 !important;\r\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 243:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "button.wikitreeturbo {\r\n    padding: 2px 10px;\r\n    font-family: monospace;\r\n    background-color: #eee;\r\n    color: #333;\r\n\tposition:absolute !important;\r\n\tmargin-left:-2.85em;\r\n\tmargin-top: -0.25em;\r\n}\r\nbutton.wikitreeturbo, button.wikitreeturbo:active {\r\n\ttop:auto !important;\r\n}\r\n#descendantsContainer li.collapse {\r\n\tposition:relative;\r\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 931:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "body.darkMode *,\r\nbody.darkMode html body,\r\nbody.darkMode .wrapper,\r\nbody.darkMode a,\r\nbody.darkMode a:link,\r\nbody.darkMode a:visited,\r\nbody.darkMode .SMALL,\r\nbody.darkMode .small,\r\nbody.darkMode .pureCssMenum,\r\nbody.darkMode .home,\r\nbody.darkMode .person,\r\nbody.darkMode .add,\r\nbody.darkMode .find,\r\nbody.darkMode .help,\r\nbody.darkMode strong,\r\nbody.darkMode a.viewsi,\r\nbody.darkMode ul.views a,\r\nbody.darkMode ul.pure-css-menu,\r\nbody.darkMode a:link.activeProfile,\r\nbody.darkMode a:hover.activeProfile,\r\nbody.darkMode a:visited.activeProfile a:active.activeProfile,\r\nbody.darkMode iframe.cke_wysiwyg_frame,\r\nbody.darkMode #cke_61_contents,\r\nbody.darkMode body.blackLinks strong,\r\nbody.darkMode menu#appsSubMenu a,\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode {\r\n  font-weight: 400;\r\n  background-color: #36393f !important;\r\n  color: #dcddde !important;\r\n}\r\nbody.darkMode .button,\r\nbody.darkMode div.pad form button,\r\nbody.darkMode input.button.green.search {\r\n  padding: 12px 12px !important;\r\n}\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode span#showHideDescendants {\r\n  padding: 6px !important;\r\n}\r\nbody.darkMode .qa-vote-buttons input {\r\n  padding: 0 !important;\r\n}\r\nbody.darkMode .large,\r\nbody.darkMode ul,\r\nbody.darkMode li {\r\n  background: none !important;\r\n}\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode div.stripes,\r\nbody.darkMode div.getstarted {\r\n  background-image: none !important;\r\n}\r\nbody.darkMode menu#appsSubMenu a:hover {\r\n  background: navy !important;\r\n}\r\nbody.darkMode ul.profile-tabs li,\r\nbody.darkMode {\r\n  font-weight: bold;\r\n  border: 1px solid white;\r\n}\r\nbody.darkMode ul.pureCssMenu ul li a:hover {\r\n  background-color: navy !important;\r\n}\r\nbody.darkMode .yourConnection,\r\nbody.darkMode #yourConnection {\r\n  background: white !important;\r\n}\r\nbody.darkMode #yourConnection {\r\n  margin-right: 4px;\r\n}\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode button,\r\nbody.darkMode input[type=\"button\"],\r\nbody.darkMode a.button,\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode span#showHideDescendants {\r\n  border: 1px solid white !important;\r\n}\r\nbody.darkMode button.copyWidget,\r\nbody.darkMode div.comment-actions button.button,\r\nbody.darkMode span.commentContainerToggle button,\r\nbody.darkMode div.qa-vote-buttons input,\r\nbody.darkMode input.qa-favorite-button,\r\nbody.darkMode #wtIDgo_go,\r\nbody.darkMode input.qa-form-light-button-reshow,\r\nbody.darkMode input.qa-form-light-button-hide,\r\nbody.darkMode input.qa-form-light-button-edit,\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  background: url(\"https://www.wikitree.com/images/icons/search-submit-icon.png\")\r\n    white !important;\r\n  font-size: 0;\r\n  top: -5px !important;\r\n}\r\nbody.darkMode input.qa-a-select-button {\r\n  background-image: url(\"https://www.wikitree.com/g2g/qa-theme/WikiTree/select-star.png\")\r\n    no-repeat !important;\r\n  border: 0 !important;\r\n  background-color: white !important;\r\n}\r\nbody.darkMode input.qa-form-light-button.qa-form-light-button-flag,\r\nbody.darkMode div.qa-vote-buttons qa-vote-buttons-net input {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode #header,\r\nbody.darkMode #footer {\r\n  background: #36393f;\r\n}\r\nbody.darkMode div.copyWidgetContainer,\r\nbody.darkMode div.copyWidgetContainerInner,\r\nbody.darkMode div.copyWidgetContainerInner button {\r\n  background: none !important;\r\n}\r\nbody.darkMode li.GREEN-ARROW {\r\n  background-blend-mode: color;\r\n}\r\nbody.darkMode div.qa-q-item-title a:link .checkmark,\r\nbody.darkMode span.qa-q-item-meta a.qa-q-item-what:link .checkmark {\r\n  color: #36393f !important;\r\n}\r\nbody.darkMode div.qa-nav-main a:hover,\r\nbody.darkMode div.qa-footer a:hover,\r\nbody.darkMode div.qa-nav-main a:visited:hover,\r\nbody.darkMode div.qa-footer a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:hover {\r\n  color: #36393f !important;\r\n  background: #dcddde !important;\r\n}\r\nbody.darkMode a[href*=\"wiki/Privacy\"] img,\r\nbody.darkMode img[src*=\"images/icons/privacy\"] {\r\n  background-color: #9196a1 !important;\r\n  border-radius: 50%;\r\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 751:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#distanceFromYou {\r\n  font-size: 0.5em;\r\n  font-weight: bold;\r\n  padding: 0.2em;\r\n  border: 2px solid forestgreen;\r\n  border-radius: 50%;\r\n  width: 3em;\r\n  text-align: center;\r\n  background: white;\r\n  opacity: 0.8;\r\n  z-index: 1;\r\n  cursor:default;\r\n}\r\nbutton.copyWidget {\r\n  z-index: 10;\r\n}\r\n\r\n#yourRelationshipText {\r\n  display: inline-block;\r\n  border: 1px solid green;\r\n  border-bottom: 2px solid forestgreen;\r\n  border-right: 2px solid forestgreen;\r\n  padding: 0.5em;\r\n  border-radius: 0.5em;\r\n  margin: 0.1em 1em 1em;\r\n  font-weight: bold;\r\n}\r\n#yourCommonAncestor {\r\n  margin: auto;\r\n  padding: 0;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li {\r\n  display: block;\r\n  margin: auto;\r\n  padding: auto;\r\n  list-style: none;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li:nth-child(n + 3) {\r\n  display: none;\r\n}\r\n#yourRelationshipText {\r\n  position: relative;\r\n  background: whitesmoke;\r\n}\r\n#showMoreAncestors {\r\n  position: absolute;\r\n  font-size: 0.8em;\r\n  padding: 0.5em;\r\n  top: -0.5em;\r\n  right: -0.5em;\r\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 262:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#myDrafts {\r\n\tposition: absolute;\r\n\ttop: 100px;\r\n\tleft: 50%;\r\n\tz-index: 11000;\r\n\tbackground: white;\r\n\tborder: 2px solid forestgreen;\r\n\tborder-radius: 1em;\r\n\tbox-shadow: 0.1em 0.1em 0.1em 0.1em lightgreen;\r\n\tpadding: 1em;\r\n\tdisplay: none;\r\n\ttext-align: left;\r\n}\r\n\r\n#myDrafts x {\r\n\tfont-weight: bold;\r\n\tposition: absolute;\r\n\ttop: 0;\r\n\tright: 0.2em;\r\n\tcursor: pointer;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tmargin: 0.5em;\r\n}\r\n\r\n#myDrafts table td {\r\n\tpadding: 0.5em;\r\n\tlist-style: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n#myDrafts a {\r\n\tmargin: 0.2em 0.5em;\r\n}\r\n\r\n#myDrafts a.button:active {\r\n\tcolor: gold;\r\n\tbackground: rgb(0, 100, 0);\r\n}\r\n\r\n#myDrafts p {\r\n\ttext-align: center;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tpadding: 0.5em;\r\n}\r\n\r\nbody.qa-body-js-on .button.small {\r\n\tpadding: 7px 15px;\r\n\tbackground: #25422d;\r\n\tborder: 0;\r\n\toutline: none;\r\n\tcursor: pointer;\r\n\ttext-align: center;\r\n\ttext-transform: uppercase;\r\n\tborder-radius: 5px;\r\n\tcolor: #fff;\r\n\tfont-weight: normal;\r\n\ttext-decoration: none !important;\r\n\tcursor: pointer;\r\n\tline-height: normal;\r\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 161:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#timeline.wrap,\r\n.familySheet.wrap {\r\n  width: 80%;\r\n  white-space: normal;\r\n}\r\n#timeline,\r\n.familySheet {\r\n  white-space: nowrap;\r\n  height: auto;\r\n  position: absolute;\r\n  width: auto;\r\n  left: 10%;\r\n  z-index: 4000;\r\n  background: white;\r\n  border: 3px solid forestgreen;\r\n  border-radius: 1em;\r\n  box-shadow: 1em 1em 1em #ccc;\r\n  padding: 0.3em;\r\n  display: none;\r\n  cursor: move;\r\n}\r\n#timelineTable td {\r\n  padding: 0.3em;\r\n}\r\n#timelineTable caption {\r\n  font-size: 1.5em;\r\n  font-weight: bold;\r\n}\r\n.tlAge,\r\n.tlBioAge {\r\n  text-align: center;\r\n}\r\nth.tlBioAge {\r\n  text-align: center;\r\n}\r\n.tlEventName {\r\n  text-align: center;\r\n}\r\n.tlDate {\r\n  white-space: nowrap;\r\n}\r\n#timeline x,\r\n.familySheet x {\r\n  position: absolute;\r\n  top: 0;\r\n  right: 0.5em;\r\n  font-weight: bold;\r\n  cursor: pointer;\r\n}\r\n#timeline w {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0.5em;\r\n  font-weight: bold;\r\n  cursor: pointer;\r\n}\r\n#timeline .BioPerson,\r\n#timeline .marriage {\r\n  font-weight: bold;\r\n}\r\n#timeline tr.BioPerson.Birth {\r\n  border-top: 1px solid forestgreen;\r\n}\r\n#timeline tr.BioPerson.Death {\r\n  border-bottom: 1px solid forestgreen;\r\n}\r\n#timelineTable {\r\n  width: 98%;\r\n  margin: auto;\r\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 834:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".wrongPeriod {\r\n\tbackground: #ffe6ea;\r\n}\r\n\r\n.familyLoc.rightPeriod {\r\n\tbackground: #DAF7A6;\r\n}\r\n\r\n.familyLoc2.rightPeriod {\r\n\tbackground: lightgreen;\r\n}\r\n\r\n.autocomplete-suggestions div.currentSelectedLocation {\r\n\tbackground: #DCDCDC !important;\r\n}\r\n\r\ninput[name='mMarriageLocation'] {\r\n\twidth: 100%;\r\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 604:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\ntr.trSelect:hover { \r\n  background: #ffe270;; \r\n}\r\n\r\ntr.trSelected { \r\n  background: #CCCCCC !important; \r\n}\r\n\r\n::placeholder {\r\n  color:    #bbb;\r\n}\r\n\r\n/* dialog formatting  */\r\n\r\ndialog {\r\n  max-width: 600px;\r\n}  \r\n\r\ndialog input[type=\"text\"] {\r\n  min-width: 350px;\r\n  padding: 4px 4px;\r\n  margin: 2px;\r\n}\r\ndialog button, dialog .button{\r\n  padding: 8px 20px;\r\n  margin: 5px;\r\n}\r\ntd button{\r\n  padding: 5px 5px;\r\n  margin: 3px;\r\n  font-size: 14px;\r\n}\r\ndialog select{\r\n  overflow: auto;\r\n  background: unset;  \r\n}\r\ndialog textarea{\r\n  width: 100%;\r\n  margin: 5px;\r\n}\r\n\r\n.wtPlusRequired {\r\n  background-color: palevioletred;\r\n}\r\n.wtPlusPreferred {\r\n  background-color: palegreen;\r\n}\r\n.wtPlusOptional {\r\n  background-color: palegoldenrod;\r\n}\r\n.wtPlusDeprecated{\r\n  background-color:  lightgrey;\r\n  text-decoration-line: line-through;\r\n}\r\n\r\n.wtPlusLegend{\r\n  display: none;\r\n  background: white;\r\n  color: black;\r\n  text-align: left;\r\n  font-size: 14px;\r\n  text-transform: none;\r\n  position: absolute;\r\n  bottom: 65px;\r\n  left: 25px;\r\n  padding: 10px;\r\n  border: 1px solid black;\r\n  line-height: 35px;\r\n}\r\n\r\n#wtPlusLegendBtn:hover .wtPlusLegend{\r\n  display: block;\r\n}\r\n\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 89:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// EXTERNAL MODULE: ./node_modules/jquery/dist/jquery.js
var jquery = __webpack_require__(755);
var jquery_default = /*#__PURE__*/__webpack_require__.n(jquery);
;// CONCATENATED MODULE: ./src/core/common.js


let pageProfile = false;
let pageHelp = false;
let pageSpecial = false;
let pageCategory = false;
let pageTemplate = false;
let pageSpace = false;
let pageG2G = false;

if (
    window.location.pathname.match(/(\/wiki\/)\w[^:]*-[0-9]*/g) ||
    window.location.href.match(/\?title\=\w[^:]+-[0-9]+/g)
  ) {
      // Is a Profile Page
	pageProfile = true;
} else if (window.location.pathname.match(/(\/wiki\/)Help:*/g)) {
	// Is a Help Page
	pageHelp = true;
} else if (window.location.pathname.match(/(\/wiki\/)Special:*/g)) {
	// Is a Special Page
	pageSpecial = true;
} else if (window.location.pathname.match(/(\/wiki\/)Category:*/g)) {
	// Is a Category Page
	pageCategory = true;
} else if (window.location.pathname.match(/(\/wiki\/)Template:*/g)) {
	// Is a Template Page
	pageTemplate = true;
} else if (window.location.pathname.match(/(\/wiki\/)Space:*/g)) {
	// Is a Space Page
	pageSpace = true;
} else if (window.location.pathname.match(/\/g2g\//g)) {
	// Is a G2G page
	pageG2G = true;
}

// Add wte class to body to let WikiTree BEE know not to add the same functions
document.querySelector("body").classList.add("wte");

/**
 * Creates a new menu item in the Apps dropdown menu.
 *
 */
function createTopMenuItem(options) {
  let title = options.title;
  let name = options.name;
  let id = options.id;
  let url = options.url;

  jquery_default()("#wte-topMenu").append(`<li>
        <a id="${id}" class="pureCssMenui" title="${title}">${name}</a>
    </li>`);
}

// Add a link to the short list of links below the tabs
function createProfileSubmenuLink(options) {
  jquery_default()("ul.views.viewsm")
    .eq(0)
    .append(
      jquery_default()(
        `<li class='viewsi'><a title='${options.title}' href='${options.url}' id='${options.id}'>${options.text}</a></li>`
      )
    );
  let links = jquery_default()("ul.views.viewsm:first li");
  // Re-sort the links into alphabetical order
  links.sort(function (a, b) {
    return jquery_default()(a).text().localeCompare(jquery_default()(b).text());
  });
  jquery_default()("ul.views.viewsm").eq(0).append(links);
}

function createTopMenu() {
  const newUL = jquery_default()("<ul class='pureCssMenu' id='wte-topMenuUL'></ul>");
  jquery_default()("ul.pureCssMenu").eq(0).after(newUL);
  newUL.append(`<li>
        <a class="pureCssMenui0">
            <span>App Features</span>
        </a>
        <ul class="pureCssMenum" id="wte-topMenu"></ul>
    </li>`);
}

// Used in familyTimeline, familyGroup, locationsHelper
async function getRelatives(id, fields = "*") {
  try {
    const result = await jquery_default().ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: {
        action: "getRelatives",
        keys: id,
        fields: fields,
        getParents: 1,
        getSiblings: 1,
        getSpouses: 1,
        getChildren: 1,
      },
    });
    return result[0].items[0].person;
  } catch (error) {
    console.error(error);
  }
}

// Used in familyTimeline, familyGroup, locationsHelper
// Make the family member arrays easier to handle
function extractRelatives(rel, theRelation = false) {
  let people = [];
  if (typeof rel == undefined || rel == null) {
    return false;
  }
  const pKeys = Object.keys(rel);
  pKeys.forEach(function (pKey) {
    var aPerson = rel[pKey];
    if (theRelation != false) {
      aPerson.Relation = theRelation;
    }
    people.push(aPerson);
  });
  return people;
}

// Used in familyTimeline, familyGroup, locationsHelper
function familyArray(person) {
  // This is a person from getRelatives()
  const rels = ["Parents", "Siblings", "Spouses", "Children"];
  let familyArr = [person];
  rels.forEach(function (rel) {
    const relation = rel.replace(/s$/, "").replace(/ren$/, "");
    familyArr = familyArr.concat(extractRelatives(person[rel], relation));
  });
  return familyArr;
}

function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

// Check that a value is OK
// Used in familyTimeline and familyGroup
function isOK(thing) {
  const excludeValues = [
    "",
    null,
    "null",
    "0000-00-00",
    "unknown",
    "Unknown",
    "undefined",
    undefined,
    "0000",
    "0",
    0,
  ];
  if (!excludeValues.includes(thing)) {
    if (isNumeric(thing)) {
      return true;
    } else {
      if (jquery_default().type(thing) === "string") {
        const nanMatch = thing.match(/NaN/);
        if (nanMatch == null) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  } else {
    return false;
  }
}

;// CONCATENATED MODULE: ./src/features/akaNameLinks/akaNameLinks.js



async function akaNames(){
// Make AKA last names clickable
    if (jquery_default()("body.profile").length){
        const nameBit = jquery_default()(".VITALS").eq(0).find(".large");
        const nameText = nameBit.text();
        if (nameText.match("aka ")){
            const strongs = nameBit.find("strong");
            const lastStrong = strongs.eq(strongs.length-1);
            const akaText = lastStrong.text();
            const oAkaNames = akaText.split(",");
            lastStrong.text("");
            oAkaNames.forEach(function(akaName,i){
                jquery_default()("<a href='https://www.wikitree.com/genealogy/"+akaName.trim()+"'>"+akaName.trim()+"</a>").appendTo(lastStrong);
                if (i+1<oAkaNames.length){
                    jquery_default()("<span>, </span>").appendTo(lastStrong);
                }
            })
        }
    }
}

chrome.storage.sync.get('akaNameLinks', (result) => {
	if (result.akaNameLinks && pageProfile == true) { 
        akaNames();
    }
})
// EXTERNAL MODULE: ./node_modules/js-cookie/dist/js.cookie.mjs
var js_cookie = __webpack_require__(955);
// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(379);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(795);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(569);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(565);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(216);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(589);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css
var appsMenu = __webpack_require__(811);
;// CONCATENATED MODULE: ./src/features/appsMenu/appsMenu.css

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());

      options.insert = insertBySelector_default().bind(null, "head");
    
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(appsMenu/* default */.Z, options);




       /* harmony default export */ const appsMenu_appsMenu = (appsMenu/* default */.Z && appsMenu/* default.locals */.Z.locals ? appsMenu/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/appsMenu/appsMenu.js




chrome.storage.sync.get('appsMenu', (result) => {
	if (result.appsMenu) {
		// Add a menu if WikiTree BEE hasn't already done so. 
		if (jquery_default()("#appsSubMenu").length==0){
            addAppsMenu();
        }
	}
});

async function getAppsMenu(){
	try{
		const result = await jquery_default().ajax({url: "https://wikitreebee.com/BEE.php?q=apps_menu", crossDomain: true, type: 'POST', dataType: 'json'})
		return result.apps_menu;
	} catch (error) {
		console.error(error);
	}
}

function attachAppsMenu(menu){
	const mWTID = js_cookie/* default.get */.Z.get("wikitree_wtb_UserName");
	const appsList = jquery_default()("<menu class='subMenu' id='appsSubMenu'></menu>");
	menu.forEach(function(app){
		const appsLi = jquery_default()("<a class='pureCssMenui' href='"+app.URL.replace(/mWTID/,mWTID)+"'>"+app.title+"</a>");
		appsLi.appendTo(appsList);
	})
	appsList.appendTo(jquery_default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").parent());
	const appsLink = jquery_default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").parent();
	jquery_default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").text("« Apps");
	appsLink.hover(function(){appsList.show();},function(){appsList.hide();})
}

function addAppsMenu(){	
	const d = new Date();
	let day = d.getUTCDate();
	let getMenu = false;
	// Store the date if it hasn't been stored
	if (!localStorage.appsMenuCheck){
		localStorage.setItem("appsMenuCheck",day);
	}
	// Store the date and update the menu if it's a new day.
	else if (day!=localStorage.appsMenuCheck){
		localStorage.setItem("appsMenuCheck",day);
		getMenu = true;
	}
	if (!localStorage.appsMenu || getMenu == true){
		getAppsMenu().then((menu)=>{
			attachAppsMenu(menu);
			// Store the menu.
			localStorage.setItem("appsMenu",JSON.stringify(menu));
		})
	} else {  // Or use the stored menu.
		attachAppsMenu(JSON.parse(localStorage.appsMenu));
	}
}
// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css
var collapsibleDescendantsTree = __webpack_require__(243);
;// CONCATENATED MODULE: ./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css

      
      
      
      
      
      
      
      
      

var collapsibleDescendantsTree_options = {};

collapsibleDescendantsTree_options.styleTagTransform = (styleTagTransform_default());
collapsibleDescendantsTree_options.setAttributes = (setAttributesWithoutAttributes_default());

      collapsibleDescendantsTree_options.insert = insertBySelector_default().bind(null, "head");
    
collapsibleDescendantsTree_options.domAPI = (styleDomAPI_default());
collapsibleDescendantsTree_options.insertStyleElement = (insertStyleElement_default());

var collapsibleDescendantsTree_update = injectStylesIntoStyleTag_default()(collapsibleDescendantsTree/* default */.Z, collapsibleDescendantsTree_options);




       /* harmony default export */ const collapsibleDescendantsTree_collapsibleDescendantsTree = (collapsibleDescendantsTree/* default */.Z && collapsibleDescendantsTree/* default.locals */.Z.locals ? collapsibleDescendantsTree/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js




chrome.storage.sync.get('collapsibleDescendantsTree', (result) => {
	if (result.collapsibleDescendantsTree && pageProfile == true) { 

    // Look out for the appearance of new list items in the descendantsContainer
    const descendantsObserver = new MutationObserver(function (mutations_list) {
      mutations_list.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (added_node) {
        if (added_node.tagName == "OL") {
        theLIS = jquery_default()(added_node).find("li");
        theLIS.each(function (index, thing) {
            setTimeout(function () {
            createDescendantsButton(index, thing);
              }, 10);
            })
          }
        });
      });
    });

    if (jquery_default()("#descendantsContainer").length) {
        descendantsObserver.observe(document.querySelector("#descendantsContainer"),
        { subtree: true, childList: true });
    }

    // Add buttons
    if (jquery_default()("body.page-Special_Descendants").length) {
      if (jquery_default()("ol").length) {
        jquery_default()("ol li").each(function (index, thing) {
          setTimeout(function () {
            createDescendantsButton(index, thing);
          }, 10);
        })
      }
    }

    async function createDescendantsButton(n, li) {
    // Attach class to avoid adding button more than once
      if (li.classList.contains('collapse')) {
        return;
      }
      if (!isNextSiblingDiv(li)) {
        return;
      }
      jquery_default()(li).addClass('collapse');
      const button = jquery_default()("<button class='wikitreeturbo'>-</button>");
      jquery_default()(button).click(toggleCollapse);
      jquery_default()(li).prepend(button);
    }

    function isNextSiblingDiv(el) {
      if(el.nextElementSibling) {
        if (el.nextElementSibling.tagName=="DIV") {
          return true;
        }
      }
      return false;
    }

    function toggleCollapse(e) {
      const s = jquery_default()(e.target).text();
      jquery_default()(e.target).text(s=='-' ? '+' : '-');
      jquery_default()(e.target.parentElement.nextElementSibling).toggle();
    }
    
  }
});

// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css
var darkMode = __webpack_require__(931);
;// CONCATENATED MODULE: ./src/features/darkMode/darkMode.css

      
      
      
      
      
      
      
      
      

var darkMode_options = {};

darkMode_options.styleTagTransform = (styleTagTransform_default());
darkMode_options.setAttributes = (setAttributesWithoutAttributes_default());

      darkMode_options.insert = insertBySelector_default().bind(null, "head");
    
darkMode_options.domAPI = (styleDomAPI_default());
darkMode_options.insertStyleElement = (insertStyleElement_default());

var darkMode_update = injectStylesIntoStyleTag_default()(darkMode/* default */.Z, darkMode_options);




       /* harmony default export */ const darkMode_darkMode = (darkMode/* default */.Z && darkMode/* default.locals */.Z.locals ? darkMode/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/darkMode/darkMode.js



chrome.storage.sync.get("darkMode", (result) => {
  if (result.darkMode) {
    jquery_default()("body").addClass("darkMode");
    jquery_default()("img[src*='wikitree-logo.png']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-white.png")
    );
    jquery_default()("img[src*='wikitree-small.png']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-small-white.png")
    );
    jquery_default()("img[src*='Wiki-Tree.gif']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-white-G2G.png")
    );
    jquery_default()("img[src*='G2G.gif']").attr(
      "src",
      chrome.runtime.getURL("images/G2G-transparent.png")
    );
    jquery_default()("h1:contains(Connection Finder)").parent().css("background-image", "");
    jquery_default()("body.darkMode.page-Main_Page div.sixteen.columns.top").css(
      "background-image",
      "url(" + chrome.runtime.getURL("images/tree-white.png") + ")"
    );

    // Add code to iframes on merging comparison page.
    if (window.location.href.match("Special:MergePerson")) {
      setTimeout(function () {
        var iframes = document.querySelectorAll("iframe");
        iframes.forEach(function (frame) {
          let linkEl = document.createElement("link");
          linkEl.rel = "stylesheet";
          linkEl.href = chrome.runtime.getURL("features/darkMode/darkMode.css");
          linkEl.type = "text/css";
          let oDocument = frame.contentWindow.document;
          let theHead = oDocument.getElementsByTagName("head")[0];
          theHead.appendChild(linkEl);
          oDocument.getElementsByTagName("body")[0].classList.add("darkMode");
          let logo = oDocument.querySelector("img[src*='wikitree-small.png']");
          if (logo) {
            logo.setAttribute(
              "src",
              chrome.runtime.getURL("images/wikitree-logo-small-white.png")
            );
          }
        });
      }, 700);
    }
  }
});

// EXTERNAL MODULE: ./node_modules/dexie/dist/modern/dexie.min.mjs
var dexie_min = __webpack_require__(520);
// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css
var distanceAndRelationship = __webpack_require__(751);
;// CONCATENATED MODULE: ./src/features/distanceAndRelationship/distanceAndRelationship.css

      
      
      
      
      
      
      
      
      

var distanceAndRelationship_options = {};

distanceAndRelationship_options.styleTagTransform = (styleTagTransform_default());
distanceAndRelationship_options.setAttributes = (setAttributesWithoutAttributes_default());

      distanceAndRelationship_options.insert = insertBySelector_default().bind(null, "head");
    
distanceAndRelationship_options.domAPI = (styleDomAPI_default());
distanceAndRelationship_options.insertStyleElement = (insertStyleElement_default());

var distanceAndRelationship_update = injectStylesIntoStyleTag_default()(distanceAndRelationship/* default */.Z, distanceAndRelationship_options);




       /* harmony default export */ const distanceAndRelationship_distanceAndRelationship = (distanceAndRelationship/* default */.Z && distanceAndRelationship/* default.locals */.Z.locals ? distanceAndRelationship/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/distanceAndRelationship/distanceAndRelationship.js





chrome.storage.sync.get("distanceAndRelationship", (result) => {
  if (
    result.distanceAndRelationship &&
    jquery_default()("body.BEE").length == 0 &&
    jquery_default()("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    const profileID = jquery_default()("a.pureCssMenui0 span.person").text();
    const userID = js_cookie/* default.get */.Z.get("wikitree_wtb_UserName");
    var db = new dexie_min/* default */.ZP("ConnectionFinderResults");
    db.version(1).stores({
      distance: "[userId+id]",
      connection: "[userId+id]",
    });
    db.open().then(function (db) {
      db.distance
        .get({ userId: userID, id: profileID })
        .then(function (result) {
          if (result == undefined) {
            initDistanceAndRelationship(userID, profileID);
          } else {
            if (jquery_default()("#distanceFromYou").length == 0) {
              const profileName = jquery_default()("h1 span[itemprop='name']").text();
              jquery_default()("h1").append(
                jquery_default()(
                  `<span id='distanceFromYou' title='${profileName} is ${result.distance} degrees from you. \nClick to refresh.'>${result.distance}°</span>`
                )
              );

              jquery_default()("#distanceFromYou").click(function (e) {
                e.preventDefault();
                jquery_default()(this).fadeOut("slow").remove();
                jquery_default()("#yourRelationshipText").fadeOut("slow").remove();
                initDistanceAndRelationship(userID, profileID);
              });

              var rdb = new dexie_min/* default */.ZP("RelationshipFinderResults");
              rdb.version(1).stores({
                relationship: "[userId+id]",
              });
              rdb.open().then(function (rdb) {
                rdb.relationship
                  .get({ userId: userID, id: profileID })
                  .then(function (result) {
                    if (result != undefined) {
                      if (result.relationship != "") {
                        if (
                          jquery_default()("#yourRelationshipText").length == 0 &&
                          jquery_default()(".ancestorTextText").length == 0 &&
                          jquery_default()("#ancestorListBox").length == 0
                        ) {
                          jquery_default()("#yourRelationshipText").remove();
                          addRelationshipText(
                            result.relationship,
                            result.commonAncestors
                          );
                        }
                      }
                    } else {
                      doRelationshipText(userID, profileID);
                    }
                  });
              });
            }
          }
        });
    });
  }
});

async function getProfile(id, fields = "*") {
  try {
    const result = await jquery_default().ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: { action: "getProfile", key: id, fields: fields },
    });
    return result[0].profile;
  } catch (error) {
    console.error(error);
  }
}

async function getConnectionFinderResult(id1, id2, relatives = 0) {
  try {
    const result = await jquery_default().ajax({
      url: "https://www.wikitree.com/index.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      data: {
        title: "Special:Connection",
        action: "connect",
        person1Name: id1,
        person2Name: id2,
        relation: relatives,
        ignoreIds: "",
      },
      type: "POST",
      dataType: "json",
      success: function (data) {},
      error: function (error) {
        console.log(error);
      },
    });
    return result;
  } catch (error) {
    console.error(error);
  }
}

async function getRelationshipFinderResult(id1, id2) {
  try {
    const result = await jquery_default().ajax({
      url: "https://www.wikitree.com/index.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      data: {
        title: "Special:Relationship",
        action: "getRelationship",
        person1_name: id1,
        person2_name: id2,
      },
      type: "POST",
      dataType: "json",
      success: function (data) {},
      error: function (error) {
        console.log(error);
      },
    });
    return result;
  } catch (error) {
    console.error(error);
  }
}

function addRelationshipText(oText, commonAncestors) {
  const commonAncestorTextOut = commonAncestorText(commonAncestors);
  const cousinText = jquery_default()(
    "<div id='yourRelationshipText' title='Click to refresh' class='relationshipFinder'>Your " +
      oText +
      "<ul id='yourCommonAncestor' style='white-space:nowrap'>" +
      commonAncestorTextOut +
      "</ul></div>"
  );
  jquery_default()("h1").after(cousinText);
  jquery_default()("#yourRelationshipText").click(function (e) {
    e.stopPropagation();
    let id1 = js_cookie/* default.get */.Z.get("wikitree_wtb_UserName");
    let id2 = jquery_default()("a.pureCssMenui0 span.person").text();
    initDistanceAndRelationship(id1, id2);
  });
  if (commonAncestors.length > 2) {
    jquery_default()("#yourRelationshipText").append(
      jquery_default()("<button class='small' id='showMoreAncestors'>More</button>")
    );
    jquery_default()("#showMoreAncestors").click(function (e) {
      e.preventDefault();
      e.stopPropagation();
      jquery_default()("#yourCommonAncestor li:nth-child(n+3)").toggle();
    });
  }
}

function commonAncestorText(commonAncestors) {
  let ancestorTextOut = "";
  const profileGender = jquery_default()("body")
    .find("meta[itemprop='gender']")
    .attr("content");
  let possessiveAdj = "their";
  if (profileGender == "male") {
    possessiveAdj = "his";
  }
  if (profileGender == "female") {
    possessiveAdj = "her";
  }
  commonAncestors.forEach(function (commonAncestor) {
    const thisAncestorType = ancestorType(
      commonAncestor.path2Length - 1,
      commonAncestor.ancestor.mGender
    ).toLowerCase();
    ancestorTextOut +=
      '<li>Your common ancestor, <a href="https://www.wikitree.com/wiki/' +
      commonAncestor.ancestor.mName +
      '">' +
      commonAncestor.ancestor.mDerived.LongNameWithDates +
      "</a>, is " +
      possessiveAdj +
      " " +
      thisAncestorType +
      ".</li>";
  });
  return ancestorTextOut;
}

function doRelationshipText(userID, profileID) {
  getRelationshipFinderResult(userID, profileID).then(function (data) {
    if (data) {
      let out = "";
      var aRelationship = true;
      const commonAncestors = [];
      let realOut = "";
      let dummy = jquery_default()("<html></html>");
      dummy.append(jquery_default()(data.html));
      if (dummy.find("h1").length) {
        if (dummy.find("h1").eq(0).text() == "No Relationship Found") {
          aRelationship = false;
          console.log("No Relationship Found");
        }
      }
      if (dummy.find("h2").length && aRelationship == true) {
        let oh2 = dummy
          .find("h2")
          .eq(0)
          .text()
          .replaceAll(/[\t\n]/g, "");
        if (data.commonAncestors.length == 0) {
          out = dummy.find("b").text();
        } else {
          const profileGender = jquery_default()("body")
            .find("meta[itemprop='gender']")
            .attr("content");
          if (oh2.match("is the")) {
            out = oh2.split("is the ")[1].split(" of")[0];
          } else if (oh2.match(" are ")) {
            out = oh2.split("are ")[1].replace(/cousins/, "cousin");
          }
          if (out.match(/nephew|niece/)) {
            if (profileGender == "male") {
              out = out.replace(/nephew|niece/, "uncle");
            }
            if (profileGender == "female") {
              out = out.replace(/nephew|niece/, "aunt");
            }
          }
        }
        let outSplit = out.split(" ");
        outSplit[0] = ordinalWordToNumberAndSuffix(outSplit[0]);
        out = outSplit.join(" ");
        if (
          jquery_default()("#yourRelationshipText").length == 0 &&
          jquery_default()(".ancestorTextText").length == 0 &&
          jquery_default()("#ancestorListBox").length == 0
        ) {
          jquery_default()("#yourRelationshipText").remove();
          addRelationshipText(out, data.commonAncestors);
        }
      }

      var rdb = new dexie_min/* default */.ZP("RelationshipFinderResults");
      rdb.version(1).stores({
        relationship: "[userId+id]",
      });
      rdb
        .open()
        .then(function (rdb) {
          rdb.relationship.put({
            userId: userID,
            id: profileID,
            relationship: out,
            commonAncestors: data.commonAncestors,
          });
          // Database opened successfully
        })
        .catch(function (err) {
          // Error occurred
        });
    }
  });
}

async function addDistance(data) {
  if (jquery_default()("#degreesFromYou").length == 0) {
    window.distance = data.path.length;
    const profileName = jquery_default()("h1 span[itemprop='name']").text();
    jquery_default()("h1").append(
      jquery_default()(
        `<span id='distanceFromYou' title='${profileName} is ${window.distance} degrees from you.'>${window.distance}°</span>`
      )
    );
    var db = new dexie_min/* default */.ZP("ConnectionFinderResults");
    db.version(1).stores({
      distance: "[userId+id]",
      connection: "[userId+id]",
    });
    db.open()
      .then(function (db) {
        db.distance.put({
          userId: js_cookie/* default.get */.Z.get("wikitree_wtb_UserName"),
          id: jquery_default()("a.pureCssMenui0 span.person").text(),
          distance: window.distance,
        });
        // Database opened successfully
      })
      .catch(function (err) {
        // Error occurred
      });
  }
}

async function getDistance() {
  const id1 = js_cookie/* default.get */.Z.get("wikitree_wtb_UserName");
  const id2 = jquery_default()("a.pureCssMenui0 span.person").text();
  const data = await getConnectionFinderResult(id1, id2);
  addDistance(data);
}

function ordinal(i) {
  var j = i % 10,
    k = i % 100;
  if (j == 1 && k != 11) {
    return i + "st";
  }
  if (j == 2 && k != 12) {
    return i + "nd";
  }
  if (j == 3 && k != 13) {
    return i + "rd";
  }
  return i + "th";
}

function ancestorType(generation, gender) {
  let relType;
  if (generation > 0 || generation == 0) {
    if (gender == "Female") {
      relType = "Mother";
    } else if (gender == "Male") {
      relType = "Father";
    } else {
      relType = "Parent";
    }
  }
  if (generation > 1) {
    relType = "Grand" + relType.toLowerCase();
  }
  if (generation > 2) {
    relType = "Great-" + relType.toLowerCase();
  }
  if (generation > 3) {
    relType = ordinal(generation - 2) + " " + relType;
  }
  return relType;
}

function ordinalWordToNumberAndSuffix(word) {
  const ordinalsArray = [
    ["first", "1st"],
    ["second", "2nd"],
    ["third", "3rd"],
    ["fourth", "4th"],
    ["fifth", "5th"],
    ["sixth", "6th"],
    ["seventh", "7th"],
    ["eigth", "8th"],
    ["ninth", "9th"],
    ["tenth", "10th"],
    ["eleventh", "11th"],
    ["twelfth", "12th"],
    ["thirteenth", "13th"],
    ["fourteenth", "14th"],
    ["fifteenth", "15th"],
    ["sixteenth", "16th"],
    ["seventeenth", "17th"],
    ["eighteenth", "18th"],
    ["nineteenth", "19th"],
    ["twentieth", "20th"],
    ["twenty-first", "21st"],
    ["twenty-second", "22nd"],
    ["twenty-third", "23rd"],
    ["twenty-fourth", "24th"],
    ["twenty-fifth", "25th"],
  ];
  ordinalsArray.forEach(function (arr) {
    if (word == arr[0]) {
      word = arr[1];
      return arr[1];
    }
  });
  return word;
}

function initDistanceAndRelationship(userID, profileID) {
  jquery_default()("#distanceFromYou").fadeOut().remove();
  jquery_default()("#yourRelationshipText").fadeOut().remove();
  getProfile(profileID).then((person) => {
    const nowTime = Date.parse(Date());
    const created = Date.parse(
      person.Created.substr(0, 8).replace(/(....)(..)(..)/, "$1-$2-$3")
    );
    const timeDifference = nowTime - created;
    const nineDays = 777600000;
    if (
      person.Privacy > 29 &&
      person.Connected == 1 &&
      timeDifference > nineDays
    ) {
      getDistance();
      doRelationshipText(userID, profileID);
    }
  });
}

// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css
var draftList = __webpack_require__(262);
;// CONCATENATED MODULE: ./src/features/draftList/draftList.css

      
      
      
      
      
      
      
      
      

var draftList_options = {};

draftList_options.styleTagTransform = (styleTagTransform_default());
draftList_options.setAttributes = (setAttributesWithoutAttributes_default());

      draftList_options.insert = insertBySelector_default().bind(null, "head");
    
draftList_options.domAPI = (styleDomAPI_default());
draftList_options.insertStyleElement = (insertStyleElement_default());

var draftList_update = injectStylesIntoStyleTag_default()(draftList/* default */.Z, draftList_options);




       /* harmony default export */ const draftList_draftList = (draftList/* default */.Z && draftList/* default.locals */.Z.locals ? draftList/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/draftList/draftList.js




chrome.storage.sync.get("draftList", (result) => {
  if (result.draftList) {
    // Check that WikiTree BEE hasn't added this already
    if (jquery_default()("a.drafts").length == 0) {
      addDraftsToFindMenu();
    }
    if (jquery_default()("body.page-Special_EditPerson").length && jquery_default()("a.drafts").length) {
      saveDraftList();
    }
  }
});

async function updateDraftList() {
  const profileWTID = jquery_default()("a.pureCssMenui0 span.person").text();
  let addDraft = false;
  let timeNow = Date.now();
  let lastWeek = timeNow - 604800000;
  let isEditPage = false;
  let theName = jquery_default()("h1")
    .text()
    .replace("Edit Profile of ", "")
    .replaceAll(/\//g, "")
    .replaceAll(/ID|LINK|URL/g, "");
  if (
    jquery_default()("#draftStatus:contains(saved),#status:contains(Starting with previous)")
      .length
  ) {
    addDraft = true;
  } else if (jquery_default()("body.page-Special_EditPerson").length) {
    isEditPage = true;
  }
  if (localStorage.drafts) {
    let draftsArr = [];
    let draftsArrIDs = [];
    let drafts = JSON.parse(localStorage.drafts);
    drafts.forEach(function (draft) {
      if (!draftsArrIDs.includes(draft[0])) {
        if (
          (addDraft == false || window.fullSave == true) &&
          draft[0] == profileWTID &&
          isEditPage == true
        ) {
        } else {
          if (draft[1] > lastWeek) {
            draftsArr.push(draft);
            draftsArrIDs.push(draft[0]);
          }
        }
      }
    });

    if (!draftsArrIDs.includes(profileWTID) && addDraft == true) {
      draftsArr.push([profileWTID, timeNow, theName]);
    }

    localStorage.setItem("drafts", JSON.stringify(draftsArr));
  } else {
    if (addDraft == true && window.fullSave != true) {
      localStorage.setItem(
        "drafts",
        JSON.stringify([[profileWTID, timeNow, theName]])
      );
    }
  }
  return true;
}

async function showDraftList() {
  if (localStorage.drafts) {
    await updateDraftList();
  }
  jquery_default()("#myDrafts").remove();
  jquery_default()("body").append(
    jquery_default()("<div id='myDrafts'><h2>My Drafts</h2><x>x</x><table></table></div>")
  );
  jquery_default()("#myDrafts").dblclick(function () {
    jquery_default()(this).slideUp();
  });
  jquery_default()("#myDrafts x").click(function () {
    jquery_default()(this).parent().slideUp();
  });
  jquery_default()("#myDrafts").draggable();

  if (localStorage.drafts != undefined && localStorage.drafts != "[]") {
    window.drafts = JSON.parse(localStorage.drafts);
    window.draftCalls = 0;
    window.tempDraftArr = [];
    window.drafts.forEach(function (draft, index) {
      const theWTID = draft[0];
      if (!isOK(theWTID)) {
        delete window.drafts[index];
        window.draftCalls++;
      } else {
        jquery_default().ajax({
          url:
            "https://www.wikitree.com/index.php?title=" +
            theWTID +
            "&displayDraft=1",
          type: "GET",
          dataType: "html", // added data type
          success: function (res) {
            window.draftCalls++;
            const dummy = jquery_default()(res);
            const aWTID = dummy.find("a.pureCssMenui0 span.person").text();
            if (
              dummy.find("div.status:contains('You have an uncommitted')")
                .length
            ) {
              window.tempDraftArr.push(aWTID);
              const useLink = dummy
                .find("a:contains(Use the Draft)")
                .attr("href");
              if (useLink != undefined) {
                const personID = useLink
                  .match(/&u=[0-9]+/)[0]
                  .replace("&u=", "");
                const draftID = useLink
                  .match(/&ud=[0-9]+/)[0]
                  .replace("&ud=", "");
                window.drafts.forEach(function (yDraft) {
                  if (yDraft[0] == aWTID) {
                    yDraft[3] = personID;
                    yDraft[4] = draftID;
                  }
                });
              }
            }
            if (window.draftCalls == window.drafts.length) {
              window.newDraftArr = [];
              window.drafts.forEach(function (aDraft) {
                if (
                  window.tempDraftArr.includes(aDraft[0]) &&
                  isOK(aDraft[0])
                ) {
                  window.newDraftArr.push(aDraft);
                }
              });

              newDraftArr.forEach(function (xDraft) {
                let dButtons = "<td></td><td></td>";
                if (xDraft[3] != undefined) {
                  dButtons =
                    "<td><a href='https://www.wikitree.com/index.php?title=Special:EditPerson&u=" +
                    xDraft[3] +
                    "&ud=" +
                    xDraft[4] +
                    "' class='small button'>USE</a></td><td><a href='https://www.wikitree.com/index.php?title=Special:EditPerson&u=" +
                    xDraft[3] +
                    "&dd=" +
                    xDraft[4] +
                    "' class='small button'>DISCARD</a></td>";
                }

                jquery_default()("#myDrafts table").append(
                  jquery_default()(
                    "<tr><td><a href='https://www.wikitree.com/index.php?title=" +
                      xDraft[0] +
                      "&displayDraft=1'>" +
                      xDraft[2] +
                      "</a></td>" +
                      dButtons +
                      "</tr>"
                  )
                );
              });
              jquery_default()("#myDrafts").slideDown();
              if (newDraftArr.length == 0) {
                jquery_default()("#myDrafts").append(jquery_default()("<p>No drafts!</p>"));
              }
              localStorage.setItem("drafts", JSON.stringify(newDraftArr));
            }
          },
          error: function (res) {},
        });
      }
    });
  } else {
    jquery_default()("#myDrafts").append(jquery_default()("<p>No drafts!</p>"));
    jquery_default()("#myDrafts").slideDown();
  }
}

function saveDraftList() {
  window.fullSave = false;
  jquery_default()("#wpSave").click(function () {
    window.fullSave = true;
  });
  window.addEventListener("beforeunload", (event) => {
    updateDraftList();
  });
  jquery_default()("#wpSaveDraft").click(function () {
    updateDraftList();
  });
  setInterval(updateDraftList, 60000);
}

function addDraftsToFindMenu() {
  const connectionLi = jquery_default()("li a.pureCssMenui[href='/wiki/Special:Connection']");
  const newLi = jquery_default()(
    "<li><a class='pureCssMenui drafts' id='draftsLink' title='See your uncommitted drafts'>Drafts</li>"
  );
  newLi.insertAfter(connectionLi.parent());
  jquery_default()("li a.drafts").click(function (e) {
    e.preventDefault();
    showDraftList();
  });
}

// EXTERNAL MODULE: ./node_modules/jquery-ui/ui/widgets/draggable.js
var draggable = __webpack_require__(285);
// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css
var familyTimeline = __webpack_require__(161);
;// CONCATENATED MODULE: ./src/features/familyTimeline/familyTimeline.css

      
      
      
      
      
      
      
      
      

var familyTimeline_options = {};

familyTimeline_options.styleTagTransform = (styleTagTransform_default());
familyTimeline_options.setAttributes = (setAttributesWithoutAttributes_default());

      familyTimeline_options.insert = insertBySelector_default().bind(null, "head");
    
familyTimeline_options.domAPI = (styleDomAPI_default());
familyTimeline_options.insertStyleElement = (insertStyleElement_default());

var familyTimeline_update = injectStylesIntoStyleTag_default()(familyTimeline/* default */.Z, familyTimeline_options);




       /* harmony default export */ const familyTimeline_familyTimeline = (familyTimeline/* default */.Z && familyTimeline/* default.locals */.Z.locals ? familyTimeline/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/familyGroup/familyGroup.js





chrome.storage.sync.get("familyGroup", (result) => {
  if (
    result.familyGroup &&
    jquery_default()("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    // Add a link to the short list of links below the tabs
    const options = {
      title: "Display family group dates and locations",
      id: "familyGroupButton",
      text: "Family Group",
      url: "#n",
    };
    createProfileSubmenuLink(options);
    jquery_default()("#" + options.id).click(function (e) {
      e.preventDefault();
      const profileID = jquery_default()("a.pureCssMenui0 span.person").text();
      showFamilySheet(jquery_default()(this)[0], profileID);
    });

    async function showFamilySheet(theClicked, profileID) {
      // If the table already exists toggle it.
      if (jquery_default()("#" + profileID.replace(" ", "_") + "_family").length) {
        jquery_default()("#" + profileID.replace(" ", "_") + "_family").fadeToggle();
      } else {
        // Make the table and do other things
        getRelatives(profileID).then((person) => {
          const uPeople = familyArray(person);
          // Make the table
          const familyTable = peopleToTable(uPeople);
          // Attach the table to the body, position it and make it draggable and toggleable
          familyTable.prependTo("body");
          familyTable.attr("id", profileID.replace(" ", "_") + "_family");
          familyTable.draggable();
          familyTable.fadeIn();
          familyTable.on("dblclick", function () {
            jquery_default()(this).fadeOut();
          });
          let theLeft = getOffset(jquery_default()("div.ten.columns")[0]).left;
          familyTable.css({
            top: getOffset(theClicked).top + 50,
            left: theLeft,
          });
          // Adjust the position of the table on window resize
          jquery_default()(window).resize(function () {
            if (familyTable.length) {
              theLeft = getOffset(jquery_default()("div.ten.columns")[0]).left;
              familyTable.css({
                top: getOffset(theClicked).top + 50,
                left: theLeft,
              });
            }
          });

          jquery_default()(".familySheet x").unbind();
          jquery_default()(".familySheet x").click(function () {
            jquery_default()(this).parent().fadeOut();
          });
          jquery_default()(".familySheet w").unbind();
          jquery_default()(".familySheet w").click(function () {
            jquery_default()(this).parent().toggleClass("wrap");
          });
        });
      }
    }

    // Put a group of people in a table
    function peopleToTable(kPeople) {
      const kTable = jquery_default()(
        "<div class='familySheet'><w>↔</w><x>x</x><table><caption></caption><thead><tr><th>Relation</th><th>Name</th><th>Birth Date</th><th>Birth Place</th><th>Death Date</th><th>Death Place</th></tr></thead><tbody></tbody></table></div>"
      );
      kPeople.forEach(function (kPers) {
        let rClass = "";
        let isDecades = false;
        kPers.RelationShow = kPers.Relation;
        if (kPers.Relation == undefined || kPers.Active) {
          kPers.Relation = "Sibling";
          kPers.RelationShow = "";
          rClass = "self";
        }

        let bDate;
        if (kPers.BirthDate) {
          bDate = kPers.BirthDate;
        } else if (kPers.BirthDateDecade) {
          bDate = kPers.BirthDateDecade.slice(0, -1) + "-00-00";
          isDecades = true;
        } else {
          bDate = "0000-00-00";
        }

        let dDate;
        if (kPers.DeathDate) {
          dDate = kPers.DeathDate;
        } else if (kPers.DeathDateDecade) {
          if (kPers.DeathDateDecade == "unknown") {
            dDate = "0000-00-00";
          } else {
            dDate = kPers.DeathDateDecade.slice(0, -1) + "-00-00";
          }
        } else {
          dDate = "0000-00-00";
        }

        if (kPers.BirthLocation == null || kPers.BirthLocation == undefined) {
          kPers.BirthLocation = "";
        }

        if (kPers.DeathLocation == null || kPers.DeathLocation == undefined) {
          kPers.DeathLocation = "";
        }

        if (kPers.MiddleName == null) {
          kPers.MiddleName = "";
        }
        const oName = displayName(kPers)[0];

        if (kPers.Relation) {
          // The relation is stored as "Parents", "Spouses", etc., so...
          kPers.Relation = kPers.Relation.replace(/s$/, "").replace(/ren$/, "");
          if (rClass != "self") {
            kPers.RelationShow = kPers.Relation;
          }
        }
        if (oName) {
          let oBDate = ymdFix(bDate);
          let oDDate = ymdFix(dDate);
          if (isDecades == true) {
            oBDate = kPers.BirthDateDecade;
            if (oDDate != "") {
              oDDate = kPers.DeathDateDecade;
            }
          }
          const aLine = jquery_default()(
            "<tr data-name='" +
              kPers.Name +
              "' data-birthdate='" +
              bDate.replaceAll(/\-/g, "") +
              "' data-relation='" +
              kPers.Relation +
              "' class='" +
              rClass +
              " " +
              kPers.Gender +
              "'><td>" +
              kPers.RelationShow +
              "</td><td><a href='https://www.wikitree.com/wiki/" +
              htmlEntities(kPers.Name) +
              "'>" +
              oName +
              "</td><td class='aDate'>" +
              oBDate +
              "</td><td>" +
              kPers.BirthLocation +
              "</td><td class='aDate'>" +
              oDDate +
              "</td><td>" +
              kPers.DeathLocation +
              "</td></tr>"
          );

          kTable.find("tbody").append(aLine);
        }

        if (kPers.Relation == "Spouse") {
          let marriageDeets = "m.";
          const dMdate = ymdFix(kPers.marriage_date);
          if (dMdate != "") {
            marriageDeets += " " + dMdate;
          }
          if (isOK(kPers.marriage_location)) {
            marriageDeets += " " + kPers.marriage_location;
          }
          if (marriageDeets != "m.") {
            let kGender;
            if (kPers.DataStatus.Gender == "blank") {
              kGender = "";
            } else {
              kGender = kPers.Gender;
            }
            const spouseLine = jquery_default()(
              "<tr class='marriageRow " +
                kGender +
                "' data-spouse='" +
                kPers.Name +
                "'><td>&nbsp;</td><td colspan='3'>" +
                marriageDeets +
                "</td><td></td><td></td></tr>"
            );
            kTable.find("tbody").append(spouseLine);
          }
        }
      });
      const rows = kTable.find("tbody tr");
      rows.sort((a, b) =>
        jquery_default()(b).data("birthdate") < jquery_default()(a).data("birthdate") ? 1 : -1
      );
      kTable.find("tbody").append(rows);

      const familyOrder = ["Parent", "Sibling", "Spouse", "Child"];
      familyOrder.forEach(function (relWord) {
        kTable.find("tr[data-relation='" + relWord + "']").each(function () {
          jquery_default()(this).appendTo(kTable.find("tbody"));
        });
      });

      kTable.find(".marriageRow").each(function () {
        jquery_default()(this).insertAfter(
          kTable.find("tr[data-name='" + jquery_default()(this).data("spouse") + "']")
        );
      });

      return kTable;
    }

    // Find good names to display (as the API doesn't return the same fields all profiles)
    function displayName(fPerson) {
      if (fPerson != undefined) {
        let fName1 = "";
        if (typeof fPerson["LongName"] != "undefined") {
          if (fPerson["LongName"] != "") {
            fName1 = fPerson["LongName"].replace(/\s\s/, " ");
          }
        }
        let fName2 = "";
        let fName4 = "";
        if (typeof fPerson["MiddleName"] != "undefined") {
          if (
            fPerson["MiddleName"] == "" &&
            typeof fPerson["LongNamePrivate"] != "undefined"
          ) {
            if (fPerson["LongNamePrivate"] != "") {
              fName2 = fPerson["LongNamePrivate"].replace(/\s\s/, " ");
            }
          }
        } else {
          if (typeof fPerson["LongNamePrivate"] != "undefined") {
            if (fPerson["LongNamePrivate"] != "") {
              fName4 = fPerson["LongNamePrivate"].replace(/\s\s/, " ");
            }
          }
        }

        let fName3 = "";
        const checks = [
          "Prefix",
          "FirstName",
          "RealName",
          "MiddleName",
          "LastNameAtBirth",
          "LastNameCurrent",
          "Suffix",
        ];
        checks.forEach(function (dCheck) {
          if (typeof fPerson["" + dCheck + ""] != "undefined") {
            if (
              fPerson["" + dCheck + ""] != "" &&
              fPerson["" + dCheck + ""] != null
            ) {
              if (dCheck == "LastNameAtBirth") {
                if (fPerson["LastNameAtBirth"] != fPerson.LastNameCurrent) {
                  fName3 += "(" + fPerson["LastNameAtBirth"] + ") ";
                }
              } else if (dCheck == "RealName") {
                if (typeof fPerson["FirstName"] != "undefined") {
                } else {
                  fName3 += fPerson["RealName"] + " ";
                }
              } else {
                fName3 += fPerson["" + dCheck + ""] + " ";
              }
            }
          }
        });

        const arr = [fName1, fName2, fName3, fName4];
        var longest = arr.reduce(function (a, b) {
          return a.length > b.length ? a : b;
        });

        const fName = longest;

        let sName;
        if (fPerson["ShortName"]) {
          sName = fPerson["ShortName"];
        } else {
          sName = fName;
        }
        // fName = full name; sName = short name
        return [fName.trim(), sName.trim()];
      }
    }

    // Convert dates to ISO format (YYYY-MM-DD)
    function ymdFix(date) {
      let outDate;
      if (date == undefined || date == "") {
        outDate = "";
      } else {
        const dateBits1 = date.split(" ");
        if (dateBits1[2]) {
          const sMonths = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ];
          const lMonths = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          const dMonth = date.match(/[A-z]+/i);
          let dMonthNum;
          if (dMonth != null) {
            sMonths.forEach(function (aSM, i) {
              if (
                dMonth[0].toLowerCase() == aSM.toLowerCase() ||
                dMonth[0].toLowerCase() == aSM + ".".toLowerCase()
              ) {
                dMonthNum = (i + 1).toString().padStart(2, "0");
              }
            });
          }
          const dDate = date.match(/\b[0-9]{1,2}\b/);
          const dDateNum = dDate[0];
          const dYear = date.match(/\b[0-9]{4}\b/);
          const dYearNum = dYear[0];
          return dYearNum + "-" + dMonthNum + "-" + dDateNum;
        } else {
          const dateBits = date.split("-");
          outDate = date;
          if (dateBits[1] == "00" && dateBits[2] == "00") {
            if (dateBits[0] == "0000") {
              outDate = "";
            } else {
              outDate = dateBits[0];
            }
          }
        }
      }
      return outDate;
    }

    // Replace certain characters with HTML entities
    function htmlEntities(str) {
      return String(str)
        .replaceAll(/&/g, "&amp;")
        .replaceAll(/</g, "&lt;")
        .replaceAll(/>/g, "&gt;")
        .replaceAll(/"/g, "&quot;")
        .replaceAll(/'/g, "&apos;");
    }

    // Get the position of an element
    function getOffset(el) {
      const rect = el.getBoundingClientRect();
      return {
        left: rect.left + window.scrollX,
        top: rect.top + window.scrollY,
      };
    }
  }
});

;// CONCATENATED MODULE: ./src/features/familyTimeline/familyTimeline.js





chrome.storage.sync.get("familyTimeline", (result) => {
  if (
    result.familyTimeline &&
    jquery("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    // Add a link to the short list of links below the tabs
    const options = {
      title: "Display a family timeline",
      id: "familyTimeLineButton",
      text: "Family Timeline",
      url: "#n",
    };
    createProfileSubmenuLink(options);
    jquery("#" + options.id).click(function (e) {
      e.preventDefault();
      timeline();
    });
  }
});

async function familyTimeline_getRelatives(id, fields = "*") {
  try {
    const result = await jquery.ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: {
        action: "getRelatives",
        keys: id,
        fields: fields,
        getParents: 1,
        getSiblings: 1,
        getSpouses: 1,
        getChildren: 1,
      },
    });
    return result[0].items[0].person;
  } catch (error) {
    console.error(error);
  }
}

// Make the family member arrays easier to handle
function getRels(rel, person, theRelation = false) {
  let people = [];
  if (typeof rel == undefined || rel == null) {
    return false;
  }
  const pKeys = Object.keys(rel);
  pKeys.forEach(function (pKey) {
    var aPerson = rel[pKey];
    if (theRelation != false) {
      aPerson.Relation = theRelation;
    }
    people.push(aPerson);
  });
  return people;
}

// Get a year from the person's data
function getTheYear(theDate, ev, person) {
  if (!isOK(theDate)) {
    if (ev == "Birth" || ev == "Death") {
      theDate = person[ev + "DateDecade"];
    }
  }
  const theDateM = theDate.match(/[0-9]{4}/);
  if (isOK(theDateM)) {
    return parseInt(theDateM[0]);
  } else {
    return false;
  }
}

// Convert a date to YYYY-MM-DD
function dateToYMD(enteredDate) {
  let enteredD;
  if (enteredDate.match(/[0-9]{3,4}\-[0-9]{2}\-[0-9]{2}/)) {
    enteredD = enteredDate;
  } else {
    let eDMonth = "00";
    let eDYear = enteredDate.match(/[0-9]{3,4}/);
    if (eDYear != null) {
      eDYear = eDYear[0];
    }
    let eDDate = enteredDate.match(/\b[0-9]{1,2}\b/);
    if (eDDate != null) {
      eDDate = eDDate[0].padStart(2, "0");
    }
    if (eDDate == null) {
      eDDate = "00";
    }
    if (enteredDate.match(/jan/i) != null) {
      eDMonth = "01";
    }
    if (enteredDate.match(/feb/i) != null) {
      eDMonth = "02";
    }
    if (enteredDate.match(/mar/i) != null) {
      eDMonth = "03";
    }
    if (enteredDate.match(/apr/i) != null) {
      eDMonth = "04";
    }
    if (enteredDate.match(/may/i) != null) {
      eDMonth = "05";
    }
    if (enteredDate.match(/jun/i) != null) {
      eDMonth = "06";
    }
    if (enteredDate.match(/jul/i) != null) {
      eDMonth = "07";
    }
    if (enteredDate.match(/aug/i) != null) {
      eDMonth = "08";
    }
    if (enteredDate.match(/sep/i) != null) {
      eDMonth = "09";
    }
    if (enteredDate.match(/oct/i) != null) {
      eDMonth = "10";
    }
    if (enteredDate.match(/nov/i) != null) {
      eDMonth = "11";
    }
    if (enteredDate.match(/dec/i) != null) {
      eDMonth = "12";
    }
    enteredD = eDYear + "-" + eDMonth + "-" + eDDate;
  }
  return enteredD;
}

// Use an approximate date instead of assuming that dates are Jan 1 or the 1st of a month
function getApproxDate(theDate) {
  let approx = false;
  let aDate;
  if (theDate.match(/0s$/) != null) {
    // Change a decade date to a year ending in '5'
    aDate = theDate.replace(/0s/, "5");
    approx = true;
  } else {
    // If we only have the year, assume the date to be July 2 (the midway date)
    const bits = theDate.split("-");
    if (theDate.match(/00\-00$/) != null) {
      aDate = bits[0] + "-07-02";
      approx = true;
    } else if (theDate.match(/-00$/) != null) {
      // If we have a month, but not a day/date, assume the date to be 16 (the midway date)
      aDate = bits[0] + "-" + bits[1] + "-" + "16";
      approx = true;
    } else {
      aDate = theDate;
    }
  }
  return { Date: aDate, Approx: approx };
}

function getAge(birth, death) {
  // must be date objects
  var age = death.getFullYear() - birth.getFullYear();
  var m = death.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && death.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

function capitalizeFirstLetter(string) {
  string = string.toLowerCase();
  const bits = string.split(" ");
  let out = "";
  bits.forEach(function (abit) {
    out += abit.charAt(0).toUpperCase() + abit.slice(1) + " ";
  });
  function replacer(match, p1) {
    return "-" + p1.toUpperCase();
  }
  out = out.replace(/\-([a-z])/, replacer);
  return out.trim();
}

function timeline() {
  jquery("#timeline").remove();
  const fields =
    "BirthDate,BirthLocation,BirthName,BirthDateDecade,DeathDate,DeathDateDecade,DeathLocation,IsLiving,Father,FirstName,Gender,Id,LastNameAtBirth,LastNameCurrent,Prefix,Suffix,LastNameOther,Derived.LongName,Derived.LongNamePrivate,Manager,MiddleName,Mother,Name,Photo,RealName,ShortName,Touched,DataStatus,Derived.BirthName,Bio";
  const id = jquery("a.pureCssMenui0 span.person").text();
  familyTimeline_getRelatives(id, fields).then((personData) => {
    var person = personData;
    const parents = extractRelatives(person.Parents, "Parent");
    const siblings = extractRelatives(person.Siblings, "Sibling");
    const spouses = extractRelatives(person.Spouses, "Spouse");
    const children = extractRelatives(person.Children, "Child");
    const family = [person];
    const familyArr = [parents, siblings, spouses, children];
    // Make an array of family members
    familyArr.forEach(function (anArr) {
      if (anArr) {
        if (anArr.length > 0) {
          family.push(...anArr);
        }
      }
    });
    let familyFacts = [];
    const startDate = getTheYear(person.BirthDate, "Birth", person);
    // Get all BMD events for each family member
    family.forEach(function (aPerson) {
      const events = ["Birth", "Death", "marriage"];
      events.forEach(function (ev) {
        let evDate = "";
        let evLocation;
        if (aPerson[ev + "Date"]) {
          evDate = aPerson[ev + "Date"];
          evLocation = aPerson[ev + "Location"];
        } else if (aPerson[ev + "DateDecade"]) {
          evDate = aPerson[ev + "DateDecade"];
          evLocation = aPerson[ev + "Location"];
        }
        if (ev == "marriage") {
          if (aPerson[ev + "_date"]) {
            evDate = aPerson[ev + "_date"];
            evLocation = aPerson[ev + "_location"];
          }
        }
        if (aPerson.Relation) {
          aPerson.Relation = aPerson.Relation.replace(/s$/, "").replace(
            /ren$/,
            ""
          );
        }
        if (evDate != "" && evDate != "0000" && isOK(evDate)) {
          let fName = aPerson.FirstName;
          if (!aPerson.FirstName) {
            fName = aPerson.RealName;
          }
          let bDate = aPerson.BirthDate;
          if (!aPerson.BirthDate) {
            bDate = aPerson.BirthDateDecade;
          }
          let mBio = aPerson.bio;
          if (!aPerson.bio) {
            mBio = "";
          }
          if (evLocation == undefined) {
            evLocation = "";
          }
          familyFacts.push([
            evDate,
            evLocation,
            fName,
            aPerson.LastNameAtBirth,
            aPerson.LastNameCurrent,
            bDate,
            aPerson.Relation,
            mBio,
            ev,
            aPerson.Name,
          ]);
        }
      });
      // Look for military events in bios
      if (aPerson.bio) {
        const tlTemplates = aPerson.bio.match(/\{\{[^]*?\}\}/gm);
        if (tlTemplates != null) {
          const warTemplates = [
            "The Great War",
            "Korean War",
            "Vietnam War",
            "World War II",
            "US Civil War",
            "War of 1812",
            "Mexican-American War",
            "French and Indian War",
            "Spanish-American War",
          ];
          tlTemplates.forEach(function (aTemp) {
            let evDate = "";
            let evLocation = "";
            let ev = "";
            let evDateStart = "";
            let evDateEnd = "";
            let evStart;
            let evEnd;
            aTemp = aTemp.replaceAll(/[{}]/g, "");
            const bits = aTemp.split("|");
            const templateTitle = bits[0].replaceAll(/\n/g, "").trim();
            bits.forEach(function (aBit) {
              const aBitBits = aBit.split("=");
              const aBitField = aBitBits[0].trim();
              if (aBitBits[1]) {
                const aBitFact = aBitBits[1].trim().replaceAll(/\n/g, "");
                if (warTemplates.includes(templateTitle) && isOK(aBitFact)) {
                  if (aBitField == "startdate") {
                    evDateStart = dateToYMD(aBitFact);
                    evStart = "Joined " + templateTitle;
                  }
                  if (aBitField == "enddate") {
                    evDateEnd = dateToYMD(aBitFact);
                    evEnd = "Left " + templateTitle;
                  }
                  if (aBitField == "enlisted") {
                    evDateStart = dateToYMD(aBitFact);
                    evStart =
                      "Enlisted for " +
                      templateTitle.replace("american", "American");
                  }
                  if (aBitField == "discharged") {
                    evDateEnd = dateToYMD(aBitFact);
                    evEnd =
                      "Discharged from " +
                      templateTitle.replace("american", "American");
                  }
                  if (aBitField == "branch") {
                    evLocation = aBitFact;
                  }
                }
              }
            });
            if (isOK(evDateStart)) {
              evDate = evDateStart;
              ev = evStart;
              familyFacts.push([
                evDate,
                evLocation,
                aPerson.FirstName,
                aPerson.LastNameAtBirth,
                aPerson.LastNameCurrent,
                aPerson.BirthDate,
                aPerson.Relation,
                aPerson.bio,
                ev,
                aPerson.Name,
              ]);
            }
            if (isOK(evDateEnd)) {
              evDate = evDateEnd;
              ev = evEnd;
              familyFacts.push([
                evDate,
                evLocation,
                aPerson.FirstName,
                aPerson.LastNameAtBirth,
                aPerson.LastNameCurrent,
                aPerson.BirthDate,
                aPerson.Relation,
                aPerson.bio,
                ev,
                aPerson.Name,
              ]);
            }
          });
        }
      }
    });
    // Sort the events
    familyFacts.sort();
    if (!person.FirstName) {
      person.FirstName = person.RealName;
    }
    // Make a table
    const timelineTable = jquery(
      `<div class='wrap' id='timeline' data-wtid='${person.Name}'><w>↔</w><x>x</x><table id='timelineTable'>` +
        `<caption>Events in the life of ${person.FirstName}'s family</caption><thead><th class='tlDate'>Date</th><th class='tlBioAge'>Age (${person.FirstName})</th>` +
        `<th class='tlRelation'>Relation</th><th class='tlName'>Name</th><th class='tlAge'>Age</th><th class='tlEventName'>Event</th><th class='tlEventLocation'>Location</th>` +
        `</thead></table></div>`
    );
    // Attach the table to the container div
    timelineTable.prependTo(jquery("div.container.full-width"));
    if (jquery("#connectionList").length) {
      timelineTable.prependTo(jquery("#content"));
      timelineTable.css({ top: window.pointerY - 30, left: 10 });
    }
    let bpDead = false;
    let bpDeadAge;

    familyFacts.forEach(function (aFact) {
      // Add events to the table
      const showDate = aFact[0].replace("-00-00", "").replace("-00", "");
      const tlDate = "<td class='tlDate'>" + showDate + "</td>";
      let aboutAge = "";
      let bpBdate = person.BirthDate;
      if (!person.BirthDate) {
        bpBdate = person.BirthDateDecade.replace(/0s/, "5");
      }
      let hasBdate = true;
      if (bpBdate == "0000-00-00") {
        hasBdate = false;
      }
      const bpBD = getApproxDate(bpBdate);
      const evDate = getApproxDate(aFact[0]);
      const aPersonBD = getApproxDate(aFact[5]);
      if (bpBD.Approx == true) {
        aboutAge = "~";
      }
      if (evDate.Approx == true) {
        aboutAge = "~";
      }
      let bpAge = getAge(new Date(bpBD.Date), new Date(evDate.Date));
      if (bpAge == 0) {
        bpAge = "";
      }
      if (bpDead == true) {
        const theDiff = parseInt(bpAge - bpDeadAge);
        bpAge = bpAge + " (" + bpDeadAge + " + " + theDiff + ")";
      }
      let theBPAge;
      if (aboutAge != "" && bpAge != "") {
        theBPAge = "(" + bpAge + ")";
      } else {
        theBPAge = bpAge;
      }
      if (hasBdate == false) {
        theBPAge = "";
      }
      const tlBioAge = "<td class='tlBioAge'>" + theBPAge + "</td>";
      if (aFact[6] == undefined || aFact[9] == person.Name) {
        aFact[6] = "";
      }
      const tlRelation =
        "<td class='tlRelation'>" + aFact[6].replace(/s$/, "") + "</td>";
      let fNames = aFact[2];
      if (aFact[8] == "marriage") {
        fNames = person.FirstName + " and " + aFact[2];
      }
      const tlFirstName =
        "<td class='tlFirstName'><a href='https://www.wikitree.com/wiki/" +
        aFact[9] +
        "'>" +
        fNames +
        "</a></td>";
      const tlEventName =
        "<td class='tlEventName'>" +
        capitalizeFirstLetter(aFact[8])
          .replaceAll(/Us\b/g, "US")
          .replaceAll(/Ii\b/g, "II") +
        "</td>";
      const tlEventLocation = "<td class='tlEventLocation'>" + aFact[1] + "</td>";

      if (aPersonBD.Approx == true) {
        aboutAge = "~";
      }
      let aPersonAge = getAge(new Date(aPersonBD.Date), new Date(evDate.Date));
      if (aPersonAge == 0 || aPersonBD.Date.match(/0000/) != null) {
        aPersonAge = "";
        aboutAge = "";
      }
      let theAge;
      if (aboutAge != "" && aPersonAge != "") {
        theAge = "(" + aPersonAge + ")";
      } else {
        theAge = aPersonAge;
      }
      const tlAge = "<td class='tlAge'>" + theAge + "</td>";
      let classText = "";
      if (aFact[9] == person.Name) {
        classText += "BioPerson ";
      }
      classText += aFact[8] + " ";
      const tlTR = jquery(
        "<tr class='" +
          classText +
          "'>" +
          tlDate +
          tlBioAge +
          tlRelation +
          tlFirstName +
          tlAge +
          tlEventName +
          tlEventLocation +
          "</tr>"
      );
      jquery("#timelineTable").append(tlTR);
      if (aFact[8] == "Death" && aFact[9] == person.Name) {
        bpDead = true;
        bpDeadAge = bpAge;
      }
    });

    jquery("#timeline").slideDown("slow");
    jquery("#timeline x").click(function () {
      jquery("#timeline").slideUp();
    });
    jquery("#timeline w").click(function () {
      jquery("#timeline").toggleClass("wrap");
    });
    // Use jquery-ui to make the table draggable
    jquery("#timeline").draggable();
    jquery("#timeline").dblclick(function () {
      jquery(this).slideUp("swing");
    });
  });
}

// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css
var locationsHelper = __webpack_require__(834);
;// CONCATENATED MODULE: ./src/features/locationsHelper/locationsHelper.css

      
      
      
      
      
      
      
      
      

var locationsHelper_options = {};

locationsHelper_options.styleTagTransform = (styleTagTransform_default());
locationsHelper_options.setAttributes = (setAttributesWithoutAttributes_default());

      locationsHelper_options.insert = insertBySelector_default().bind(null, "head");
    
locationsHelper_options.domAPI = (styleDomAPI_default());
locationsHelper_options.insertStyleElement = (insertStyleElement_default());

var locationsHelper_update = injectStylesIntoStyleTag_default()(locationsHelper/* default */.Z, locationsHelper_options);




       /* harmony default export */ const locationsHelper_locationsHelper = (locationsHelper/* default */.Z && locationsHelper/* default.locals */.Z.locals ? locationsHelper/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/locationsHelper/locationsHelper.js




chrome.storage.sync.get("locationsHelper", (result) => {
  if (
    result.locationsHelper &&
    jquery_default()("body.BEE").length == 0 &&
    (jquery_default()("body.page-Special_EditPerson").length ||
      jquery_default()("body.page-Special_EditFamily").length)
  ) {
    function addRelArraysToPerson(zPerson) {
      const zSpouses = extractRelatives(zPerson.Spouses, "Spouse");
      zPerson.Spouse = zSpouses;
      const zChildren = extractRelatives(zPerson.Children, "Child");
      zPerson.Child = zChildren;
      const zSiblings = extractRelatives(zPerson.Siblings, "Sibling");
      zPerson.Sibling = zSiblings;
      const zParents = extractRelatives(zPerson.Parents, "Parent");
      zPerson.Parent = zParents;
      return zPerson;
    }

    function editDistance(s1, s2) {
      s1 = s1.toLowerCase();
      s2 = s2.toLowerCase();
      let costs = new Array();
      for (var i = 0; i <= s1.length; i++) {
        var lastValue = i;
        for (var j = 0; j <= s2.length; j++) {
          if (i == 0) costs[j] = j;
          else {
            if (j > 0) {
              var newValue = costs[j - 1];
              if (s1.charAt(i - 1) != s2.charAt(j - 1))
                newValue =
                  Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
              costs[j - 1] = lastValue;
              lastValue = newValue;
            }
          }
        }
        if (i > 0) costs[s2.length] = lastValue;
      }
      return costs[s2.length];
    }

    function similarity(s1, s2) {
      s1 = s1.toLowerCase();
      s2 = s2.toLowerCase();
      var longer = s1;
      var shorter = s2;
      if (s1.length < s2.length) {
        longer = s2;
        shorter = s1;
      }
      var longerLength = longer.length;
      if (longerLength == 0) {
        return 1.0;
      }
      return (
        (longerLength - editDistance(longer, shorter)) /
        parseFloat(longerLength)
      );
    }

    async function locationsHelper() {
      let theID;
      if (jquery_default()("body.page-Special_EditFamily").length) {
        theID = jquery_default()("a.pureCssMenui0 span.person").text();
      } else {
        theID = jquery_default()("a.pureCssMenui:Contains(Edit)").attr("href").split("u=")[1];
      }
      getRelatives(theID).then((result) => {
        const thisFamily = familyArray(result);
        window.bdLocations = [];
        thisFamily.forEach(function (aPe) {
          if (aPe.BirthLocation) {
            window.bdLocations.push(aPe.BirthLocation);
          }
          if (aPe.DeathLocation) {
            window.bdLocations.push(aPe.DeathLocation);
          }
        });
      });

      const observer2 = new MutationObserver(function (mutations_list) {
        mutations_list.forEach(function (mutation) {
          mutation.addedNodes.forEach(function (added_node) {
            if (added_node.className == "autocomplete-suggestion-container") {
              let activeEl = document.activeElement;
              let whichLocation = "";
              if (activeEl.id == "mBirthLocation") {
                whichLocation = "Birth";
              }
              if (activeEl.id == "mDeathLocation") {
                whichLocation = "Death";
              }
              if (activeEl.name == "mMarriageLocation") {
                whichLocation = "Marriage";
              }
              let dText = added_node.textContent;
              let currentBirthYearMatch = null;
              let currentDeathYearMatch = null;
              let currentMarriageYearMatch = null;
              if (jquery_default()("#mBirthDate").length) {
                currentBirthYearMatch = jquery_default()("#mBirthDate")
                  .val()
                  .match(/[0-9]{3,4}/);
              }
              if (jquery_default()("#mDeathDate").length) {
                currentDeathYearMatch = jquery_default()("#mDeathDate")
                  .val()
                  .match(/[0-9]{3,4}/);
              }
              if (jquery_default()("#mMarriageDate").length) {
                currentMarriageYearMatch = jquery_default()("#mMarriageDate")
                  .val()
                  .match(/[0-9]{3,4}/);
              }
              let startYear = "";
              let endYear = "";
              let goodDate = false;
              let familyLoc = false;
              let familyLoc2 = false;
              const yearsMatch = dText.match(/\([^A-z]*[0-9]{3,4}.*\)/g);
              if (yearsMatch != null) {
                years = yearsMatch[0].replaceAll(/[()]/g, "").split("-");
                //console.log(years);
                if (years[0].trim() != "") {
                  startYear = years[0].trim();
                }
                if (years[1].trim() != "") {
                  endYear = years[1].trim();
                }
              } else {
                goodDate = true;
              }
              let myYear = "";
              if (currentBirthYearMatch != null && whichLocation == "Birth") {
                myYear = currentBirthYearMatch[0];
              } else if (
                currentDeathYearMatch != null &&
                whichLocation == "Death"
              ) {
                myYear = currentDeathYearMatch[0];
              } else if (
                currentMarriageYearMatch != null &&
                whichLocation == "Marriage"
              ) {
                myYear = currentMarriageYearMatch[0];
              }
              if (myYear != "") {
                if (startYear == "" && parseInt(myYear) < parseInt(endYear)) {
                  goodDate = true;
                } else if (
                  endYear == "" &&
                  parseInt(myYear) > parseInt(startYear)
                ) {
                  goodDate = true;
                } else if (
                  parseInt(myYear) > parseInt(startYear) &&
                  parseInt(myYear) < parseInt(endYear)
                ) {
                  goodDate = true;
                }
              } else {
                goodDate = true;
              }
              window.bdLocations.forEach(function (aLoc) {
                dText = dText.split("(")[0].trim();
                if (similarity(aLoc, dText) > 0.8) {
                  familyLoc = true;
                }
                if (similarity(aLoc, dText) > 0.95) {
                  familyLoc2 = true;
                }
              });
              const theContainer = jquery_default()(added_node).closest(
                ".autocomplete-suggestion-container"
              );
              if (goodDate == true) {
                theContainer.addClass("rightPeriod");
                if (familyLoc2 == true) {
                  theContainer
                    .addClass("familyLoc2")
                    .prependTo(jquery_default()(".autocomplete-suggestions"));
                } else if (familyLoc == true) {
                  theContainer
                    .addClass("familyLoc1")
                    .prependTo(jquery_default()(".autocomplete-suggestions"));
                }
              } else {
                theContainer
                  .addClass("wrongPeriod")
                  .appendTo(jquery_default()(".autocomplete-suggestions"));
              }
            }
          });
        });
      });

      setTimeout(function () {
        observer2.observe(jquery_default()(".autocomplete-suggestions").eq(0)[0], {
          subtree: false,
          childList: true,
        });
        if (jquery_default()("#mDeathLocation").length) {
          observer2.observe(jquery_default()(".autocomplete-suggestions").eq(1)[0], {
            subtree: false,
            childList: true,
          });
        }
      }, 3000);
    }
    locationsHelper();
  }
});

;// CONCATENATED MODULE: ./src/features/printerfriendly/printerfriendly.js



chrome.storage.sync.get('printerFriendly', (result) => {
	if (result.printerFriendly) {
		// create a top menu item
		createTopMenuItem({
			title: 'Changes the format to a printer-friendly one.',
			name: 'Printer Friendly Bio',
			id: 'wte-tm-printer-friendly'
		});

		jquery_default()(`#wte-tm-printer-friendly`).on('click', () => {
			printBio();
		});
	}
});

// modified code from Steven's WikiTree Toolkit
function printBio() {
	var pTitleClean = jquery_default()(document).attr('title');
	var pTitleCleaner = pTitleClean.replace(' | WikiTree FREE Family Tree', '');
	var pTitle = pTitleCleaner.replace(' - WikiTree Profile', '');
	var pImage = jquery_default()("img[src^='/photo.php/']").attr('src');
	var pTitleInsert = jquery_default()('h2').first();
	pTitleInsert.before(
		`<div>
			<img style="float:left;" src="https://www.wikitree.com${pImage}" width="75" height="75">
			<div style="font-size: 2.1429em; line-height: 1.4em; margin-bottom:50px; padding: 20px 100px;">
				${pTitle}
			</div>
		</div>`
	);

	jquery_default()("a[target='_Help']").parent().remove();
	jquery_default()("span[title*='for the profile and']").parent().remove();
	jquery_default()("div[style='background-color:#e1efbb;']").remove();
	jquery_default()("div[style='background-color:#eee;']").remove();
	jquery_default()("a[href^='/treewidget/']").remove();
	jquery_default()("a[href='/g2g/']").remove();
	jquery_default()("a[class='nohover']").remove();

	jquery_default()('div').removeClass('ten columns');
	jquery_default()('.VITALS').remove();
	jquery_default()('.star').remove();
	jquery_default()('.profile-tabs').remove();
	//$(".SMALL").remove();
	jquery_default()('.showhidetree').remove();
	jquery_default()('.row').remove();
	jquery_default()('.button').remove();
	jquery_default()('.large').remove();
	jquery_default()('.sixteen').remove();
	jquery_default()('.five').remove();
	jquery_default()('.editsection').remove();
	jquery_default()('.EDIT').remove();
	jquery_default()('.comment-absent').remove();
	jquery_default()('.box').remove();

	jquery_default()('#views-wrap').remove();
	jquery_default()('#footer').remove();
	jquery_default()('#commentPostDiv').remove();
	jquery_default()('#comments').remove();
	jquery_default()('#commentEditDiv').remove();
	jquery_default()('#commentG2GDiv').remove();
	jquery_default()('#header').remove();
	jquery_default()('#showHideDescendants').remove();

	window.print();
	location.reload();
}

;// CONCATENATED MODULE: ./src/features/randomProfile/randomProfile.js


chrome.storage.sync.get('randomProfile', (result) => {
	if (result.randomProfile && jquery_default()("body.BEE").length==0) {
        function getRandomProfile() {
            var randomProfileID = Math.floor(Math.random() * 36065988);
            var link = '';
            // check if exists
            jquery_default().getJSON('https://api.wikitree.com/api.php?action=getPerson&key=' + randomProfileID)
                .done(function (json) {
                    // check to see if the profile is Open
                    if (json[0]['status'] == 0 && 'Privacy_IsOpen' in json[0]['person'] && json[0]['person']['Privacy_IsOpen']) {
                        link = 'https://www.wikitree.com/wiki/' + randomProfileID;
                        window.location = link;
                    } else { // If it isn't open, find a new profile
                        getRandomProfile();
                    }
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.log('getJSON request failed! ' + textStatus + ' ' + errorThrown);
                    getRandomProfile();
                });
        }

        // add random option to 'Find'
        async function addRandomToFindMenu() {
            const relationshipLi = jquery_default()("li a.pureCssMenui[href='/wiki/Special:Relationship']");
            const newLi = jquery_default()("<li><a class='pureCssMenui randomProfile' title='Go to a random profile'>Random Profile</li>");
            newLi.insertBefore(relationshipLi.parent());
            jquery_default()(".randomProfile").click(function (e) {
                e.preventDefault();
                getRandomProfile()
            });
        }
    addRandomToFindMenu();
    }
})

;// CONCATENATED MODULE: ./src/features/sourcepreview/sourcepreview.js


chrome.storage.sync.get('sPreviews', function (result) {
    if (result.sPreviews == true) {
        sourcePreview();

        function sourcePreview() {
            if (jquery_default()('.reference').length) { // and only if inline citations are found
                jquery_default()('.reference').hover(function (e) { // jquery.hover() handlerIn (show sourcePreview)
                    var sourceID = this.id.replace('ref', 'note').replace(/(_[0-9]+$)/g, '');
                    var sPreview = document.createElement('div');
                    sPreview.setAttribute('id', 'sourcePreview');
                    sPreview.setAttribute('class', 'box rounded');
                    sPreview.setAttribute('style', 'z-index:999; width: 450px; position:absolute;');
                    document.getElementById(this.id).appendChild(sPreview);
                    document.getElementById('sourcePreview').innerHTML = document.getElementById(sourceID).innerHTML;
                },
                    // jqeury.hover() handlerOut (remove sourcePreview)
                    function () {
                        jquery_default()('#sourcePreview').remove();
                    }
                )
            }
        }
        const targetNode = document.getElementById('previewbox');
        const config = { childList: true };
        const callback = (mutationList, observer) => {
            for (const mutation of mutationList) {
                if (mutation.type === 'childList') {
                    sourcePreview();
                }
            }
        };
        const observer = new MutationObserver(callback);
        if (jquery_default()('#previewbox').length > 0) {
            observer.observe(targetNode, config);
        }
    }
})

;// CONCATENATED MODULE: ./src/thirdparty/jquery.hoverDelay.js


(jquery_default()).fn.hoverDelay = function (n) {
  var e = { delayIn: 300, delayOut: 300, handlerIn: function () {}, handlerOut: function () {} };
  return (
    (n = jquery_default().extend(e, n)),
    this.each(function () {
      var e,
        t,
        u = jquery_default()(this);
      u.hover(
        function () {
          t && clearTimeout(t),
            (e = setTimeout(function () {
              n.handlerIn(u);
            }, n.delayIn));
        },
        function () {
          e && clearTimeout(e),
            (t = setTimeout(function () {
              n.handlerOut(u);
            }, n.delayOut));
        }
      );
    })
  );
};

;// CONCATENATED MODULE: ./src/features/spacepreview/spacepreview.js



chrome.storage.sync.get("spacePreviews", function (result) {
  if (result.spacePreviews == true) {
    jquery_default()('.ten.columns a[href*="/wiki/Space:"], .sixteen.columns a[href*="/wiki/Space:"]').hoverDelay({
      delayIn: 1000,
      delayOut: 0,
      handlerIn: function ($element) {
        jquery_default()("#spacePreview").remove();
        jquery_default()("#spaceHover").attr("id", "");
        console.log($element[0].href);
        $element.attr("id", "spaceHover");
        var sPreview = document.createElement("div");
        sPreview.setAttribute("id", "spacePreview");
        sPreview.setAttribute("class", "box rounded");
        sPreview.setAttribute(
          "style",
          `z-index:9999; max-height:450px; overflow: scroll; position:absolute; padding: 10px; margin-top:-20px;`
        );
        document.getElementById("spaceHover").parentElement.appendChild(sPreview);
        jquery_default().ajax({
          url: $element[0].href,
          context: document.body,
        }).done(function (result) {
          var pageContent = jquery_default()(result).find(".ten.columns").html();
          try {
            document.getElementById(
              "spacePreview"
            ).innerHTML = `<span style="float:right; font-weight:700;">click outside to close</span>${pageContent}`;
          } catch {}
        });
      },
    });
  }
  jquery_default()(document).on("click", function (event) {
    if (jquery_default()(event.target).closest("#spacePreview").length === 0) {
      jquery_default()("#spacePreview").remove();
      jquery_default()("#spaceHover").attr("id", "");
    }
  });
});

// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css
var wtPlus = __webpack_require__(604);
;// CONCATENATED MODULE: ./src/features/wt+/wtPlus.css

      
      
      
      
      
      
      
      
      

var wtPlus_options = {};

wtPlus_options.styleTagTransform = (styleTagTransform_default());
wtPlus_options.setAttributes = (setAttributesWithoutAttributes_default());

      wtPlus_options.insert = insertBySelector_default().bind(null, "head");
    
wtPlus_options.domAPI = (styleDomAPI_default());
wtPlus_options.insertStyleElement = (insertStyleElement_default());

var wtPlus_update = injectStylesIntoStyleTag_default()(wtPlus/* default */.Z, wtPlus_options);




       /* harmony default export */ const wt_wtPlus = (wtPlus/* default */.Z && wtPlus/* default.locals */.Z.locals ? wtPlus/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/features/wt+/contentEdit.js


let tb = {};

function itemsFindByTemplate(name) {
	return tb.templates.filter(item => item.name.toUpperCase() === name.toUpperCase())[0]
}

function paramsCopy (templateName){
	tb.template = itemsFindByTemplate(templateName); 
	tb.templateitems = tb.template.prop.map(item => {        
		return {
			name: item.name,
			type: item.type,
			usage: item.usage,
			numbered: item.numbered,
			initial: item.initial,
			help: item.help,
			example: item.example,
			group: item.group,
			values: item.values || [], 
			value: ''
		}
	})
	tb.unknownParams = ''
}

function paramsFromSelection(){
	//finds menu item
//    var params = tb.textSelected.split(/.*?\|\s*([^{}[\]|]*?(?:\[\[[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\]\][^{}[\]|]*?|\{\{[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\}\}[^{}[\]|]*?)*?[^{}[\]|]*?)\s*(?:(?=\|)|}})/g).map(par => par.trim()).filter(par => par != '');
	var params = tb.textSelected.split(/\|\s*([^{}[\]|]*?(?:\[\[[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\]\][^{}[\]|]*?|\{\{[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\}\}[^{}[\]|]*?)*?[^{}[\]|]*?)\s*(?:(?=\|)|}})/g).map(par => par.trim()).filter(par => par != '');
	tb.textSelected = tb.textSelected.replace('{{', '').replace('}}', '');
	params[0] = params[0].replace('{{', '').replace('}}', '').replace('_', ' ')
	tb.template = itemsFindByTemplate(params[0]); 
	if (tb.template) {
		params.splice(0, 1);
		var paramsNumbered = params.filter(par => !(par.includes('=')));
		var paramsNamed = params.filter(par => par.includes('=')).map(item => item.split("=").map(par => par.trim()));
		tb.templateitems = tb.template.prop.map(item => {
			var x;
			if (item.numbered) {
				x = paramsNumbered[item.numbered-1]
			} else {
				x = paramsNamed.filter(par => par[0].toUpperCase() === item.name.toUpperCase()).map(par => par[1]).join('');
			};
			if (!x) {x = ''};
			return {
				name: item.name,
				type: item.type,
				usage: item.usage,
				numbered: item.numbered,
				initial: item.initial,
				help: item.help,
				example: item.example,
				group: item.group,                                
				values: item.values || [], 
				value: x.trim()
			}            
		})
		var unknownNamed = paramsNamed.filter(par => !Boolean(tb.templateitems.find(ti => ti.name.toUpperCase() === par[0].toUpperCase())))        
		var unknownNumbered = paramsNumbered.filter((par, i) => !Boolean(tb.templateitems.find(ti => ti.numbered === i+1)))
		tb.unknownParams = unknownNamed.map(i => '|' + i[0] + '= ' + i[1]).concat(unknownNumbered.map(i => '|' + i)).join('\n')
	} else {
		alert ('Template "' + params[0] + '" is not recognised by the extension')
	}   
};

function paramsInitialValues (){
	if (tb.templateitems && tb.templateitems.length) {
		for (let prop of tb.templateitems) {
			if (prop.value === '' && prop.initial) {
				if (prop.initial.startsWith("Title:")) {
					prop.value = document.title.replace(RegExp(prop.initial.substring(6)), '$1');
				}    
				if (prop.initial.startsWith("Category:") && (tb.categories)) {
					var r = RegExp(prop.initial.substring(9), 'mg')
					var a = tb.categories.match(r)
					prop.value = ((a) ? a.join('\n').replace(r, '$1') : '' )
				}    
			}
		}
	}
}

function reformatCoortoURL (s) {
	return 'https://www.openstreetmap.org/#map=18/' + s.replace (',', '/').replace ('%20', '')
}

function reformatURLtoCoor (s) {
	if (s.match ( /^ *[\d]* *° *[\d]* *[′'] *([\d.]* *[″”"])? *[NS][, ]*[\d]* *° *[\d]* *[′'] *([\d.]* *[″”"])? *[EW] *$/mgi)) {
		// 32°42'16.02"N, 17°8'0.67"W
		let s1 = s.replace(
			/^ *([\d]{1,2}) *° *([\d]{1,2}) *[′'] *(([\d.]{1,5}) *[″”"])? *([NS])[, ]*([\d]{1,3}) *° *([\d]{1,2}) *[′'] *(([\d.]{1,5}) *[″”"])? *([EW]) *$/mgi,
			'$1;$2;$4;$5;$6;$7;$9;$10')
		let arr = s1.split(';')
		var lon, lat
		lat = (arr[3] == 'S' ? -1 : 1) * (Number(arr[0]) + Number(arr[1]) / 60 + Number(arr[2]) / 3600)
		lon = (arr[7] == 'W' ? -1 : 1) * (Number(arr[4]) + Number(arr[5]) / 60 + Number(arr[6]) / 3600)
		return parseFloat(lat.toFixed(6)) + ', ' + parseFloat(lon.toFixed(6))
	} else if (s.match (/^https:\/\/www\.openstreetmap\.org\/#map=[\d]*\/[\d.-]*\/[\d.-]*$/mgi)) {
		// https://www.openstreetmap.org/#map=15/32.7051/-17.1220
		let s1 = s.replace(
			/^https:\/\/www\.openstreetmap\.org\/#map=[\d]{1,2}\/([\d.-]*)\/([\d.-]*)$/mgi,
			'$1, $2')
		return s1
	} else {  
		return s.replace ('/', ', ')
	}
}

function reformatTexttoWiki (s) {
	return s.replace (/ /g, '_');
}

function reformatWikitoText  (s) {
	return decodeURIComponent (s.replace (/_/g, ' '));
}

function getNumbertoSlash  (s) {
	return s.replace (/(\d*)\/.*/g, '$1');
}

const urlMappings = [
	{type: "", placeholder:"Undefined type"},
	{type: "typeText", placeholder:"Enter text"},
	{type: "typeNumber", placeholder:"Enter a number"},
	{type: "typeYear", placeholder:"Enter year"},
	{type: "typeYes", placeholder:"Enter yes"},
	{type: "typeNo", placeholder:"Enter no"},
	{type: "typeURL", placeholder:"Enter URL https://...", prefixURL:'', sufixURL:'', emptyURL:''},
	{type: "typeWikitreeID", placeholder:"Enter profile's WikitreeID", prefixURL:'https://www.wikitree.com/wiki/', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typePage", placeholder:"Enter Page name with Namespace", prefixURL:'https://www.wikitree.com/wiki/', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeCategory", placeholder:"Enter Category on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Category:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeProjectNeedsCategory", placeholder:"Enter Project Needs category", prefixURL:'', sufixURL:'', emptyURL:''},
	{type: "typeProject", placeholder:"Enter Project on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Project:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeTeam", placeholder:"Enter Team of the project on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Space:', sufixURL:' Team', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeSpace", placeholder:"Enter Space page on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Space:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeImage", placeholder:"Enter Image name", prefixURL:'https://www.wikitree.com/wiki/Image:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeG2G", placeholder:"Enter question ID", prefixURL:'https://www.wikitree.com/g2g/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeWikiTreeBlog", placeholder:"Enter blog name", prefixURL:'https://www.wikitree.com/blog/', sufixURL:'/', emptyURL:''},
	{type: "typeWikiData", placeholder:"Enter WikiData code", prefixURL:'https://www.wikidata.org/wiki/', sufixURL:''},
	{type: "typeYouTube", placeholder:"Enter YouTube code", prefixURL:'https://www.youtube.com/watch?v=', sufixURL:''},
	{type: "typeFAGID", placeholder:"Enter FindAGrave ID", prefixURL:'https://www.findagrave.com/memorial/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeFAGCemID", placeholder:"Enter FindAGrave Cemetery ID", prefixURL:'https://www.findagrave.com/cemetery/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeFAGLocID", placeholder:"Enter FindAGrave Location ID", prefixURL:'https://www.findagrave.com/cemetery/search?locationId='},
	{type: "typeBGID", placeholder:"Enter BillionGraves ID", prefixURL:'https://billiongraves.com/cemetery/Cemetery/', sufixURL:'', emptyURL:'https://billiongraves.com/'},
	{type: "typeCoor", placeholder:"Enter coordinate 15.123, -33.213", prefixURL:'', sufixURL:'', emptyURL:'https://www.openstreetmap.org/', toURL:reformatCoortoURL, fromURL:reformatURLtoCoor},
	{type: "typeTOC", placeholder:"Not enough prfiles"},
	{type: "typeReadOnly"},
];

/* Setting result */

function updateEdit (){
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}
	tb.elText.value = tb.textResult;
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}
	tb.elText.setSelectionRange(tb.selStart, tb.selEnd);

	if (tb.birthLocationResult) {
		tb.elBirthLocation.value = tb.birthLocationResult
	}
	if (tb.deathLocationResult) {
		tb.elDeathLocation.value = tb.deathLocationResult
	}

	if (tb.elSummary) {
		tb.elSummary.focus();
		var s = tb.elSummary.value;
		if (s) {
			if (s.indexOf(tb.addToSummary) == -1) {
				s += ', ' + tb.addToSummary
			}
		} else {
			s = tb.addToSummary
		};
		tb.elSummary.value = s;
	}
	tb.elText.focus();
	tb.addToSummary = ''

	// Let the page know that changes have been made so that the "Save Changes" button works
//    if ("createEvent" in document) {
	var evt = document.createEvent("HTMLEvents");
	evt.initEvent("change", false, true);
	tb.elText.dispatchEvent(evt);
//      } else {
//        textbox.fireEvent("onchange");
//      }
}


/**************************/
/* edit Template          */
/**************************/

function editTemplate (summaryPrefix){
	if (tb.template) {
		var group, groupExpanded 
		tb.elDlg.innerHTML = 
			'<h3 style="margin: 0 0 0 10px;">Editing ' + '<a href="/wiki/Template:' + tb.template.name + '" target="_blank">Template:' + tb.template.name + '</a></h3>' + 
			'<table style="margin-bottom: 10px;"><tr><td style="white-space: nowrap;padding-right: 10px;">' +
			(tb.template.type ? 'Type: <b>' + tb.template.type + '</b><br>' : '') + 
			(tb.template.group ? 'Group: <b>' + tb.template.group + '</b><br>' : '') + 
			(tb.template.subgroup ? 'SubGroup: <b>' + tb.template.subgroup + '</b>' : '') + 
			'</td><td>' + tb.template.help + '</td></tr></table>' + 
			'<div id="wtPlusDlgParams">'+
			'<table style="width: 100%;">' + 
			tb.templateitems.map((item, i) => {
				var itemDef = urlMappings.filter(a=>a.type == item.type)[0] 
				if (!itemDef) {
					console.log('Missing ' + item.type + ' type') 
					itemDef = urlMappings[0];
				};
				// Sets TOC parameter
				if (item.type === "typeTOC") {
					var has_link = [].some.call(document.links, function(link) {
						return link.innerHTML.endsWith(' 200');
					});
					item.value = (has_link) ? 'yes': ''
				}
				var x = ''
				// Group
				if (item.group !== group) {
					if (item.group) {
						groupExpanded = Boolean (tb.templateitems.find(a=> a.group == item.group && a.value)) 
						x += '<tr class="wtPlus' + item.group + '"><td colspan="2"><label>' + item.group + ':</label></td><td>' + 
							'<button id="groupBtn' + item.group + '" title="Expand/Collapse" class="dlgClick" data-op="onDlgEditTemplateExpCol" data-id="' + item.group + '">' + 
							(groupExpanded ? 'Collapse' : 'Expand') + '</button></td><td colspan="3"></td></tr>' 
					}
					group = item.group
				}
				x  += '<tr class="wtPlus' + item.usage + (item.group ? ' group' + item.group + '" ' + (groupExpanded ? '' : 'style="visibility: collapse;') : '' ) + '">';
				// Name
				x += '<td><label>' + item.name + ':</label></td>' 
				// Help
				x += '<td>' + (item.help ? 
					'<img src="/images/icons/help.gif" border="0" width="22" height="22" alt="Help" title="Usage: ' + item.usage + '\n' + item.help + (item.example ? '\nExample: ' + item.example : '' ) + '" />': '') + '</td>';
				// Input
				x += '<td><input type="text" name="wtparam' + i + '" class="dlgPaste' + /*((item.type === "typeCategory") ? ' dlgCat' : '' ) + */'" ' +
					 'data-op="onDlgEditTemplatePaste" data-id="' + i + '" value="' + item.value + '" ';
				x += 'placeholder="' + itemDef.placeholder + '" '
				x += 'list="wtPlusAutoComplete' + i + '" '
				if ((item.type === "typeReadOnly") || (item.type === "typeTOC")) {
					x += 'readonly '
				}
				if (i === 0) {
					x += 'autofocus '
				}
				x += '/><datalist id="wtPlusAutoComplete' + i + '">' 
				x += item.values.map(item => '<option value="' + item + '"/>' ).join('\n')
				x +='</datalist></td>';
				//Buttons
				x +='<td>' + ((item.type != "typeReadOnly") && (item.type != "typeTOC") ? 
					'<button title="Restore value" class="dlgClick" data-op="onDlgEditTemplateRestore" data-id="' + i + '" tabindex="-1">R</button>' : '') + '</td>' 
				x +='<td>' + ((item.initial) ? 
					'<button title="Auto value" class="dlgClick" data-op="onDlgEditTemplateInitial" data-id="' + i + '" tabindex="-1">A</button>' : '') + '</td>' 
				x +='<td>' + ((urlMappings.filter(a=>a.prefixURL !== undefined).map(a=>a.type).includes(item.type)) ? 
					'<button title="Open link" class="dlgClick" data-op="onDlgEditTemplateFollow" data-id="' + i + '" tabindex="-1">O</button>' : '') + '</td>' 
				x +='</tr>';
													
				return x
			}).join('') + 
			'</table>' +
			'</div>' +
			'<div style="display:flex">'+        
			//Legend
			'<button id="wtPlusLegendBtn" class="dlgClick" data-op="onDlgNone" tabindex="-1">Legend'+
			'<table class="wtPlusLegend">' + 
			'<tr><td colspan="2" class="wtPlusRequired">Required</td></tr>' +
			'<tr><td colspan="2" class="wtPlusPreferred">Preferred</td></tr>' +
			'<tr><td colspan="2" class="wtPlusOptional">Optional</td></tr>' +
			'<tr><td><img src="/images/icons/help.gif" border="0" width="22" height="22" alt="Help" /></td><td>Hower for hint</td></tr>' +
			'<tr><td><button title="Restore value" class="dlgClick" data-op="onDlgNone">R</button></td><td>Restore value</td></tr>' +
			'<tr><td><button title="Auto value" class="dlgClick" data-op="onDlgNone">A</button></td><td>Auto value</td></tr>' +
			'<tr><td><button title="Open link" class="dlgClick" data-op="onDlgNone">O</button></td><td>Open link</td></tr>' +
			'</table>' +
			'</button>' +
			'<div style="flex:1"></div>' +
			'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Edit_Template" target="_blank">Help</a>' +
			//OK, Cancel
			'<button style="text-align:right" class="dlgClick" data-op="onDlgEditTemplateBtn" data-id="0">Close</button>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgEditTemplateBtn" data-id="1" value="default">Update changes</button>' +
			'</div>' 

		tb.elDlgParams = document.getElementById("wtPlusDlgParams");
				  
		attachEvents('button.dlgClick', 'click')
		attachEvents('input.dlgPaste', 'paste')
		attachEvents('input.dlgPaste', 'keypress')
		
		tb.addToSummary = summaryPrefix + " Template:" + tb.template.name;
		if (tb.unknownParams) 
		  alert('Unrecognized parameters:\n' + tb.unknownParams + '\n\nThey will be removed, unless you cancel.')
		tb.elDlg.showModal();
	}    
};
/*

	if ($('#addCategoryInput').length) {
		$('#addCategoryInput').autoComplete({
			cache: false,
			source: function(term, suggest) {
				wtCategorySuggestion(term, suggest);
			},
			renderItem: function(category, search) {
				return wtCategorySuggestionItemRender(category, search);
			},
			onSelect: function(e, term, item) {
				changesMade = 1;
				var categoryText = "[[Category:" + term + "]]\n";
				categoryText = categoryText.replace(/_/g, ' ');
				if ((typeof coloredEditor !== 'undefined') && (coloredEditor)) {
					coloredEditor.setCursor(0, 0);
					var cursor = coloredEditor.getCursor();
					coloredEditor.replaceRange(categoryText, cursor, cursor);
					coloredEditor.focus();
				} else {
					var textArea = document.editform.wpTextbox1;
					var textScroll = textArea.scrollTop;
					textArea.value = categoryText + textArea.value;
					textArea.selectionStart = 0;
					textArea.selectionEnd = categoryText.length;
					textArea.scrollTop = textScroll;
					textArea.focus();
				}
				$('#addCategoryInput').val('').hide();
				e.preventDefault();
				return false;
			},
		});
	}
});
function wtCategorySuggestion(term, suggest) {
	var includeAll = 0;
	if ($('#categorySuggestionIncludeAll').length && $('#categorySuggestionIncludeAll').val()) {
		includeAll = 1;
	}
	sajax_do_call("Title::ajaxCategorySearch", [term, includeAll], function(result) {
		var suggestions = JSON.parse(result.responseText);
		suggest(suggestions);
	});
}
function wtCategorySuggestionItemRender(item, search) {
	search = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
	var re = new RegExp("(" + search.split(' ').join('|') + ")","gi");
	var html = '';
	html += '<div class="autocomplete-suggestion" data-val="' + item + '">';
	html += item.replace(re, "<b>$1</b>");
	html += '</div>';
	return html;
}

*/
function onDlgEditTemplateBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		var a = tb.elDlgParams.querySelectorAll('input');
		for (var i in tb.templateitems) {tb.templateitems[i].value = a[i].value.trim()};
		tb.inserttext = '';
		var line = '';
		if (tb.templateitems && tb.templateitems.length) {
			var line = '\n';
			for (let prop of tb.templateitems) {
				if (prop.numbered) {
					line = '';
					if (prop.value) {
						tb.inserttext += '|' + prop.value;
					} else {
						switch(prop.usage) {
						case "Required":
						case "Preferred":
						tb.inserttext += '|';
						break;
						} 
					}    
				} else {
					if (prop.value) {
						tb.inserttext += '\n|' + prop.name + '= ' + prop.value;
					} else {
						switch(prop.usage) {
							case "Required":
							case "Preferred":
							tb.inserttext += '\n|' + prop.name + '= ';
							break;
						} 
					}    
				}
			}
		}
		tb.inserttext = '{{' + tb.template.name + tb.inserttext + line + '}}' ;
		tb.inserttext += (tb.textAfter[0]==='\n') ? '': line;
		
		tb.textResult = tb.textBefore + tb.inserttext + tb.textAfter;
		tb.selStart = tb.textBefore.length
		tb.selEnd = tb.selStart +  tb.inserttext.length;
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		updateEdit();
	};
	tb.elDlg.innerHTML = '';
	tb.addToSummary = ''
	return false
};

//listener for paste event
function onDlgEditTemplatePaste(i, evt) {
	if (evt.type == 'keypress') {
		var key = evt.which || evt.keyCode;
		if (key === 13) { 
			onDlgEditTemplateBtn('1')
		} 
	} 
	if (evt.type == 'paste') {
		let clipdata = evt.clipboardData || window.clipboardData;
		var s = clipdata.getData('text/plain');
		s = decodeURIComponent (s);
		for(const j of urlMappings) {
			if (tb.templateitems[i].type === j.type) {
				if (s.startsWith(j.prefixURL)) {
					s = s.replace(j.prefixURL, '');
					if ((j.sufixURL!='') && (s.endsWith(j.sufixURL))) {
						s = s.replace(j.sufixURL, '');
					}    
					s = j.fromURL ? j.fromURL(s) : s
					document.execCommand("insertHTML", false, s);
					evt.preventDefault();
				}
			}
		}
	}
}

function onDlgEditTemplateFollow(i) {
	var item=tb.templateitems[i];
	var e=tb.elDlgParams.querySelectorAll('input')[i];
	var s = e.value;

	for(const i of urlMappings) {
		if (item.type === i.type) {
			if (s) {
				s = (i.prefixURL === '') ? encodeURI (s) : encodeURIComponent (s)
				s = i.toURL ? i.toURL(s) : s
				s = i.prefixURL + s + i.sufixURL
			} else {
				s = i.emptyURL !== undefined ? i.emptyURL : i.prefixURL
			}
		}
	}
   
	if (s.startsWith('http')) {
		window.open(s, '_blank');
	}
	return false
};

function onDlgEditTemplateInitial(i) {
	var item=tb.templateitems[i];
	var e=tb.elDlgParams.querySelectorAll('input')[i];
	if (item.initial.startsWith("Title:")) {
		e.value = document.title.replace(RegExp(item.initial.substring(6)), '$1');
	}    
	if (item.initial.startsWith("Category:") && (tb.categories)) {
		var r=RegExp(item.initial.substring(9), 'mg')
		e.value = tb.categories.match(r).join('\n').replace(r, '$1');
	}
	return false
};

function onDlgEditTemplateRestore(i) {
	var item=tb.templateitems[i];
	var e = tb.elDlgParams.querySelectorAll('input')[i];
	e.value = item.value;
	return false
};

function onDlgEditTemplateExpCol(gName) {
	var e = tb.elDlg.getElementsByClassName('group' + gName);
	var b = document.getElementById('groupBtn' + gName);
	if (b.innerHTML == 'Expand') {
		b.innerHTML = 'Collapse'
		for(var ei of e) {ei.style.visibility = 'visible';}
	} else {
		b.innerHTML = 'Expand'
		for(var ei of e) {ei.style.visibility = 'collapse';}
	}
	return false
};

function WikiTreeGetCategory (query, fixed){
	fetch("https://www.wikitree.com/index.php?action=ajax&rs=Title::ajaxCategorySearch&rsargs[]=" + query + "&rsargs[]=1")
	.then((resp) => resp.json())
	.then(jsonData => {
		console.log('cat: ' + jsonData);
		return (jsonData);
	})
};

/**************************/
/* Select template to add */
/**************************/
 
function selectTemplate (data) {
	tb.elDlg.innerHTML = 
		'<h3>Select template</h3>' + 
		'<input type="checkbox" class="cbFilter" id="cb1" name="cb1" data-op="onDlgSelectTemplateFlt" data-id="1" value="Project Box"' + (data=="Project Box" ? ' checked' : '') + '><label for="cb1"> Project Box</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb2" name="cb2" data-op="onDlgSelectTemplateFlt" data-id="2" value="Sticker"' + (data=="Sticker" ? ' checked' : '') + '><label for="cb2"> Sticker</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb3" name="cb3" data-op="onDlgSelectTemplateFlt" data-id="3" value="Profile Box"' + (data=="Profile Box" ? ' checked' : '') + '><label for="cb3"> Research Note</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb4" name="cb4" data-op="onDlgSelectTemplateFlt" data-id="4" value="External Link"' + (data=="External Link" ? ' checked' : '') + '><label for="cb4"> External Link</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb5" name="cb5" data-op="onDlgSelectTemplateFlt" data-id="5" value="CategoryInfoBox"' + (data=="CategoryInfoBox" ? ' checked' : '') + '><label for="cb5"> CategoryInfoBox</label><br>' +
		'<label for="flt1">Filter: </label><input type="text" class="cbFilter" id="flt1" name="flt1" data-op="onDlgSelectTemplateFlt" data-id="9"><br>' +
		'<div style="min-width: 600px;overflow-y:auto;height: 400px;"><table style="width: 100%;" id="tb">' +
		tb.templates.map(item => '<tr class="trSelect" data-op="onDlgSelectTemplateTrSel"><td>' + item.name + '</td><td>' + item.group + '</td><td>' + item.subgroup + '</td></tr>' ).join('\n') +
		'</table></div>' +
		'<div style="text-align:right">'+
		'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Add_Template" target="_blank">Help</a>' +
		//OK, Cancel
		'<button style="text-align:right" class="dlgClick" data-op="onDlgSelectTemplateBtn" data-id="0">Close</button>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgSelectTemplateBtn" data-id="1" value="default">Select</button>' +
		'</div>' 
	attachEvents('button.dlgClick', 'click')
	attachEvents('input.cbFilter', 'input')
	attachEvents('tr.trSelect', 'click')
	onDlgSelectTemplateFlt ()
	tb.elDlg.showModal();
};

function onDlgSelectTemplateFlt () {
	let lb = tb.elDlg.querySelector("#tb")
	var s0 = '';
	for (let i=1;i<=5;i++) {
		if (tb.elDlg.querySelector("#cb"+i).checked)
		  s0 += (s0=='' ? '' : '|') + tb.elDlg.querySelector("#cb"+i).value
	}
	var r0 = new RegExp('('+s0+')','i')
	
	var s1 = tb.elDlg.querySelector("#flt1").value
	var r1 = new RegExp(s1,'i')
	
	lb.innerHTML = tb.templates.filter(item=> 
		((s0==='') || item.type.match(r0)) && 
		((s1==='') || item.name.match(r1) || item.group.match(r1) || item.subgroup.match(r1))
//    ).map(item => '<option value="' + item.name + '">' + item.name + ' (' + item.group + ': ' + item.subgroup + ')</option>' ).join('\n') 
		).map(item => '<tr class="trSelect" data-op="onDlgSelectTemplateTrSel"><td>' + item.name + '</td><td>' + item.group + '</td><td>' + item.subgroup + '</td></tr>' ).join('\n') 
	attachEvents('tr.trSelect', 'click')
}

function onDlgSelectTemplateTrSel (tr) {
	removeClass ('tr.trSelect', 'trSelected')
	tr.classList.add("trSelected")
}

function onDlgSelectTemplateBtn(update) {
	if (update==='1') {
		if (tb.elDlg.querySelectorAll('.trSelected>td').length === 0) {
			alert ('No template selected: Select a template before closing the dialog')
			return false
		}
		tb.elDlg.close();
		//Add template 
		var templateName = tb.elDlg.querySelectorAll('.trSelected>td')[0].innerText
		paramsCopy (templateName)
		paramsInitialValues ();
		editTemplate ("Added");
	} else {
		tb.elDlg.close();
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};

/*********************************/
/* Automatic update like EditBOT */
/*********************************/

function AutoUpdate () {
	let s0 = ''
	let s1 = ''
	let s2 = ''
	for (var loc=0;loc<3;loc++) {
		let actArr = ''
		if (loc==0) {
			if (tb.birthLocation) {
				s0 = 'Birth Location'
				s1 = tb.birthLocation
				actArr = tb.locations
			}
		} else if (loc==1) {
			if (tb.deathLocation) {
				s0 = 'Death Location'
				s1 = tb.deathLocation
				actArr = tb.locations
			}
		} else if (loc==2) {
			if (tb.textAll) {
				s0 = 'Bio'
				s1 = tb.textAll
				actArr = tb.cleanup
			}
		}
		if (actArr) {
			for (var j=0;j<actArr.length;j++) {
				let clean = actArr[j]
				let s3 = ''
				for (var i=0;i<clean.actions.length;i++) {
					let s = s1
					let action = clean.actions[i]
					switch(action.action) {
						case "replaceRegEx": 
						let reg = RegExp(action.from, action.flags)
						s1 = s1.replace(reg, action.to)
						break;
						case "replace": 
						s1 = s1.replace(action.from, action.to)
						break;
							default: 
						alert ('Unknown action: ' + action.action + ' defined for source: ' + clean.name)
						s1 = ''
					}
					if (s1=='') break
					if ((s1!=='') && (s !== s1)) {
						s3 += (s3!=='' ? ', ' : '') + action.description
					}    
				}
				if (s3!=='') {
					s2 += '<input type="checkbox" class="cb' + loc + '_' + j + '" id="cb' + loc + '_' + j + '" name="cb' + loc + '_' + j + '" data-op="onDlgPasteSourceCB" data-id="1" value="' + loc + '_' + j + '" checked>' +
						'<label for="cb' + loc + '_' + j + '"> ' + s0 + ' ' + clean.description + ' ' + ' (' + s3 + ')</label><br>\n' 
				}
			}
		}
	}
	if (s2 == '') {
		alert ('Nothing to change.')
	} else {
		tb.elDlg.innerHTML = 
			'<h3>Automated cleanup</h3>' + 
			s2 +
			'<div style="text-align:right">'+
			//OK, Cancel
			'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Profile_Cleanup" target="_blank">Help</a>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgProfileCleanupBtn" data-id="0">Close</button>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgProfileCleanupBtn" data-id="1" value="default">Select</button>' +
			'</div>' 
		attachEvents('button.dlgClick', 'click')
		attachEvents('input.cbInline', 'input')
		tb.elDlg.showModal();
	}
};

function onDlgProfileCleanupBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		//Set updated text

		let s0 = ''
		let s1 = ''
		let s2 = ''
		let actArr = []
		for (var loc=0;loc<3;loc++) {
			if (loc==0) {
				s0 = 'Birth Location'
				s1 = tb.birthLocation
				actArr = tb.locations
			} else if (loc==1) {
				s0 = 'Death Location'
				s1 = tb.deathLocation
				actArr = tb.locations
			} else if (loc==2) {
				s0 = 'Bio'
				s1 = tb.textAll
				actArr = tb.cleanup
			}
			if (actArr) {
				for (var j=0;j<actArr.length;j++) {
					var cb = tb.elDlg.querySelectorAll('#cb'+loc+'_'+j)[0]
					if ((cb) && (cb.checked)) {
						let clean = actArr[j]

						let s = ''
						let s1 = ''
						let s3 = ''
						for (var i=0;i<clean.actions.length;i++) {
							s = s1
							let action = clean.actions[i]
							switch(action.action) {
								case "replaceRegEx": 
								let reg = RegExp(action.from, action.flags)
								s1 = s1.replace(reg, action.to)
								break;
								case "replace": 
								s1 = s1.replace(action.from, action.to)
								break;
								default: 
								s1 = ''
							}
							if (s1=='') break
							if ((s1!=='') && (s !== s1)) {
								s3 += (s3!=='' ? ', ' : '') + action.description
							}    
						}
						if (s3!=='') {
							s2 += (s2!=='' ? ', ' : '' ) + '+' + s0 + ' ' + clean.description + ' (' + s3 + ')' 
						}
					}
				}
			}
			if (loc==0) {
				tb.birthLocationResult = s1;
			} else if (loc==1) {
				tb.deathLocationResult = s1;
			} else if (loc==2) {
				tb.textResult = s1;
			}
		}
		tb.addToSummary = s2;
		updateEdit();
	} else {
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};


/**************************/
/* Paste source reformat  */
/**************************/

function pasteSource () {
	tb.elDlg.innerHTML = 
		'<h3>Paste source</h3>' + 
		'<label for="srcPaste">Clipboard:</label><br>' +
		'<textarea class="srcPaste" data-op="onDlgPasteSourcePaste" data-id="1" placeholder="Paste a source or URL here." rows="5" cols="80"></textarea><br>' +
		'<input type="checkbox" class="cbInline" id="cb1" name="cb1" data-op="onDlgPasteSourceCB" data-id="1" value="Inline" checked><label for="cb1"> Inline citation</label><br>' +
		'<label for="resultFld">Citation to add:</label><br>' +
		'<textarea class="resultFld" rows="5" cols="80"></textarea>' +
		'<div style="text-align:right">'+
		//OK, Cancel
		'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Paste_Sources" target="_blank">Help</a>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgPasteSourceBtn" data-id="0">Close</button>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgPasteSourceBtn" data-id="1" value="default">Select</button>' +
		'</div>' 
	attachEvents('button.dlgClick', 'click')
	attachEvents('input.cbInline', 'input')
	attachEvents('textarea.srcPaste', 'paste')
	tb.elDlg.showModal();
};

function onDlgPasteSourceBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		//Add template 
		tb.inserttext = tb.elDlg.querySelectorAll('.resultFld')[0].value;
		tb.inserttext += (tb.textAfter[0]==='\n') ? '': '\n';
		tb.textResult = tb.textBefore + tb.inserttext + tb.textAfter;
		tb.selStart = tb.textBefore.length
		tb.selEnd = tb.selStart +  tb.inserttext.length;
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		updateEdit();
	} else {
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};

function onDlgPasteSourceCB(i, evt) {
	var e = tb.elDlg.querySelectorAll('.resultFld')[0]
	let s = e.value.replace('<ref>', '').replace('</ref>', '').replace('* ', '')
	if (tb.elDlg.querySelectorAll('.cbInline')[0].checked) {
		e.value = '<ref>' + s + '</ref>'
	} else {
		e.value = '* ' + s
	}
}

//listener for paste event
function onDlgPasteSourcePaste(i, evt) {
	if (evt.type == 'keypress') {
		var key = evt.which || evt.keyCode;
		if (key === 13) { 
			onDlgPasteSourceBtn('1')
		} 
	} 
	if (evt.type == 'paste') {
		var clipdata = evt.clipboardData || window.clipboardData;
		var s = clipdata.getData('text/plain');
		var s1 = '';
		s = decodeURIComponent (s);

		if (tb.sources) {
			for (let source of tb.sources) {
				var b = false
				for (let condition of source.conditions) {
					switch(condition.action) {
						case "startsWith": 
						b = s.startsWith(condition.find)
						break;
						case "includes": 
						b = s.includes(condition.find)
						break;
						default: alert ('Unknown condition: ' + condition.action + ' defined for source: ' + source.name)
					}   
					if (b) break;
				}
				if (b) {
					s1 = s
					for (let action of source.actions) {
						switch(action.action) {
							case "replaceRegEx": 
							let reg = RegExp(action.from, 'mg')
							s1 = s1.replace(reg, action.to)
							break;
							case "replace": 
							s1 = s1.replace(action.from, action.to)
							break;
							default: 
							alert ('Unknown action: ' + action.action + ' defined for source: ' + source.name)
							s1 = ''
						}
						if (s1=='') break
					}
					if (s1!=='') {
						tb.addToSummary = 'Added ' + source.description
						break
					}
				}
			}
		}

		// Adding inline citation
		if (s1!=='') {
			if (tb.elDlg.querySelectorAll('.cbInline')[0].checked) {
				s1 = '<ref>' + s1 + '</ref>'
			} else {
				s1 = '* ' + s1
			} 
		}
		tb.elDlg.querySelectorAll('.resultFld')[0].value = s1
	}
}

/**************************/
/* Menu events            */
/**************************/

function posToOffset (txt, pos){
  const arr=txt.split("\n");
  var len=0;
  for (var i=0;i<pos.line;i++) 
	len+= length(arr[i]) + 1 ;
  return len+pos.ch ;
};

function contentEdit_wtPlus (params){
	if (tb.elText.style.display == "none") {
		alert('Enhanced editor is not supported.\n\nTurning it off to use the extension.');
		tb.elEnhanced.click();
	}

	//Sets all edit variables
	tb.elEnhancedActive = (tb.elText.style.display == "none");
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
			
			
//            alert ('Enhanced editor is not supported.<br>Turn it off to use WikiTree+ extension.');
/*
		if (window.coloredEditor) {
			tb.textAll = coloredEditor.getValue().replace(/\r\n|\n\r|\n|\r/g, '\n')
			tb.selStart = posToOffset (tb.textAll, coloredEditor.getCursor("from"))
			tb.selEnd = posToOffset (tb.textAll, coloredEditor.getCursor("to"))
*/
		}

	tb.selStart = tb.elText.selectionStart;
	tb.selEnd = tb.elText.selectionEnd;
	tb.textAll = tb.elText.value;
	if (tb.elBirthLocation) {
		tb.birthLocation = tb.elBirthLocation.value;
	}
	if (tb.elDeathLocation) {
		tb.deathLocation = tb.elDeathLocation.value;
	}
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}

	tb.textBefore = tb.textAll.substring(0,  tb.selStart);
	tb.textSelected = tb.selEnd == tb.selStart ? '' : tb.textAll.substring(tb.selStart, tb.selEnd);
	tb.textAfter = tb.textAll.substring(tb.selEnd);
	tb.categories = tb.textAll.match(/\[\[Category:.*?\]\]/mgi)
	if (tb.categories){
		tb.categories = tb.categories.join('\n').replace(/\[\[Category:\s*(.*?)\s*\]\]/mgi, '$1');
	}        
	tb.textResult = tb.textAll; 

	if (params.template) {
		//Add template 
		paramsCopy (params.template)
		paramsInitialValues ();
		editTemplate ("Added");
	} else {
		switch(params.action) {
			case "": break;
			case "EditTemplate": //Edit template
//            var expression = /{{[\s\S]*?}}/g
		var expression = /\{\{.*?(\[\[[^{}[\]]*?\]\][^{}[\]]*?|\[[^{}[\]]*?\][^{}[\]]*?|\{\{[^{}[\]]*?\}\}[^{}[\]]*?)*?[^{}[\]]*?\}\}/gms


		if (tb.selStart != tb.selEnd) {
			let tem = tb.textSelected.match(expression);
			if (tem && (tem.length == 1)) {
				var s = tb.textSelected.split(expression);
				tb.textBefore += s[0];
				tb.textSelected = tem[0];
				tb.textAfter = s[2] + tb.textAfter;
				tb.selStart = tb.textBefore.length
				tb.selEnd = tb.selStart + tb.textSelected.length;
				paramsFromSelection();
				editTemplate("Edited");
			} else {
				alert ('There is no template in selected text');
			}    
		} else {
			let tem = tb.textAll.match(expression);
			if (tem) {
				if (tem.length == 1) {
					var s = tb.textAll.split(expression);
					tb.textBefore = s[0];
					tb.textSelected = tem[0];
					tb.textAfter  = s[2];
					tb.selStart = tb.textBefore.length
					tb.selEnd = tb.selStart + tb.textSelected.length;
					paramsFromSelection();
					editTemplate("Edited");
				} else {
					let match = ''
					while (match = expression.exec(tb.textAll)) {
						if ((match.index < tb.selStart) && (expression.lastIndex > tb.selStart)) {
							tb.textBefore = tb.textAll.substring(0,  match.index);
							tb.textSelected = match[0];
							tb.textAfter  = tb.textAll.substring(expression.lastIndex);
							tb.selStart = tb.textBefore.length
							tb.selEnd = tb.selStart + tb.textSelected.length;
							paramsFromSelection();
							editTemplate("Edited");
							return;
						};
					};
					alert ('There is no template at cursor position.')
				}
			} else {
				alert ('There is no template on the page.')
			}
		}
		break;

		case "AutoFormat": //automatic formting
		tb.textResult = tb.textAll.replace(/^ *\| *([^ =|]*) *= */mg, "|$1= ")
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		tb.addToSummary = ''
		updateEdit ();
		break;

		case "AutoUpdate": //automatic corrections
		AutoUpdate ();
		break;   

		case "EditBOTConfirm": //EditBOT confirmation
		tb.textResult = tb.textAll.replace(/\|(Review|Manual)\}\}/mg, "|Confirmed}}")
		tb.textResult = tb.textResult.replace(/\s\s\}\}/mg, " ")
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		tb.addToSummary = "Confirmation for EditBOT"
		updateEdit ();
		break;
		
		case "AddTemplate": //add any template
		selectTemplate (params.data);
		break;

		case "PasteSource": //paste a source citation
		pasteSource ();
		break;
		

		default: alert ("Unknown event " + params.action)
		};
	};
	
};

/* Classes */

const attachClass = (selector, className) => {
	document.querySelectorAll(selector).forEach(i=>i.classList.add(className))
}

const removeClass = (selector, className) => {
	document.querySelectorAll(selector).forEach(i=>i.classList.remove(className))
}

/* Events */

const attachEvents = (selector, eventType) => {
	document.querySelectorAll(selector).forEach(i=>i.addEventListener(eventType, event=>mainEventLoop(event)))
}
function mainEventLoop (event) {

	if (tb.elText.style.display == "none") {
		alert ('Enhanced editor is not supported.\n\nTurning it off to use the extension.');
		tb.elEnhanced.click();
	}   

	let element = event.srcElement
	if (element.tagName == 'TD') {
		element = element.parentElement
	}
	const op = element.dataset.op
	const id = element.dataset.id
	if (op === 'wtPlus')    {event.preventDefault(); return contentEdit_wtPlus(id)}
	
	if (op === 'onDlgEditTemplateExpCol') {event.preventDefault(); return onDlgEditTemplateExpCol(id)}
	if (op === 'onDlgEditTemplateRestore')    {event.preventDefault(); return onDlgEditTemplateRestore(id)}
	if (op === 'onDlgEditTemplateInitial')    {event.preventDefault(); return onDlgEditTemplateInitial(id)}
	if (op === 'onDlgEditTemplateFollow') {event.preventDefault(); return onDlgEditTemplateFollow(id)}
	if (op === 'onDlgEditTemplateBtn')  {event.preventDefault(); return onDlgEditTemplateBtn(id)}
	if (op === 'onDlgEditTemplatePaste')  return onDlgEditTemplatePaste(id, event)

	if (op === 'onDlgPasteSourcePaste')  return onDlgPasteSourcePaste(id, event)
	if (op === 'onDlgPasteSourceCB')  return onDlgPasteSourceCB(id, event)    
	if (op === 'onDlgPasteSourceBtn') {event.preventDefault(); return onDlgPasteSourceBtn(id)}

	if (op === 'onDlgProfileCleanupBtn') {event.preventDefault(); return onDlgProfileCleanupBtn(id)}

	if (op === 'onDlgSelectTemplateFlt') return onDlgSelectTemplateFlt()
	if (op === 'onDlgSelectTemplateTrSel') return onDlgSelectTemplateTrSel(element)
	if (op === 'onDlgSelectTemplateBtn') {event.preventDefault(); return onDlgSelectTemplateBtn(id)}

	if (op === 'onDlgNone') {event.preventDefault(); return}
	
	console.error ('Missing data-op on ', element)
}

function isEditPage() {
	return (window.location.href.match(/\/index.php\?title=Special:EditPerson&.*/g) ||
	        window.location.href.match(/\/index.php\?title=.*&action=edit.*/g) ||
			window.location.href.match(/\/index.php\?title=.*&action=submit.*/g));
}

/* Initialization */
chrome.storage.sync.get('wtplus', (result) => {
	if (result.wtplus && isEditPage()) {
		tb.nameSpace = (document.title.startsWith('Edit Person ')) ? 'Profile' : ''
		let w = document.querySelector('h1 > .copyWidget')
		if (w) {
			tb.wikitreeID = w.getAttribute('data-copy-text');
		}
		tb.elText = document.getElementById("wpTextbox1");
		tb.elBirthLocation = document.getElementById("mBirthLocation");
		tb.elDeathLocation = document.getElementById("mDeathLocation");

		tb.elSummary = document.getElementById("wpSummary");
		tb.elEnhanced = document.getElementById("toggleMarkupColor");

		document.getElementById("toolbar").insertAdjacentHTML('beforeend', '<dialog id="wtPlusDlg"></dialog>')
		tb.elDlg = document.getElementById("wtPlusDlg");

		// Loading of template definition From Storage
		chrome.storage.local.get(['alltemplates'], function(a){
			if (a.alltemplates && a.alltemplates.version) {
				// Is in storage
				tb.templates = a.alltemplates.templates;
				tb.cleanup = a.alltemplates.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
				tb.locations = a.alltemplates.locations; if (!(tb.locations)) {tb.locations = []};
				tb.sources = a.alltemplates.sources; if (!(tb.sources)) {tb.sources = []};
				tb.dataVersion = new Date(a.alltemplates.version);
				console.log('Storage: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates' + ', ' +  tb.cleanup.length + ' cleanup' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
			} else {
				// Not in storage
				tb.dataVersion = new Date("2000-01-01T00:00:00+01:00");
			} 
			// Loading of template definition From Extension
			fetch(chrome.runtime.getURL("features/wt+/templatesExp.json"))
			.then((resp) => resp.json())
			.then(jsonData => {
				const d = new Date(jsonData.version)
				if (d.getTime () > tb.dataVersion.getTime ()) {
					// Extension definition is newer
					tb.templates = jsonData.templates;
					tb.cleanup = jsonData.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
					tb.locations = jsonData.locations; if (!(tb.locations)) {tb.locations = []};
					tb.sources = jsonData.sources; if (!(tb.sources)) {tb.sources = []};
					tb.dataVersion = d;
					console.log('Extension: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates.' + ', ' +  tb.cleanup.length + ' cleanup.' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
					chrome.storage.local.set({"alltemplates": jsonData});
				}
				if (tb.dataVersion.getTime () < new Date().getTime () - 6 * 3600 * 1000) {
					// Loading of template definition From Web
					fetch("https://wikitree.sdms.si/chrome/templatesExp.json")
					.then((resp) => resp.json())
					.then(jsonData => {
						const d = new Date(jsonData.version)
						if (d.getTime () > tb.dataVersion.getTime ()) {
							// Web definition is newer
							tb.templates = jsonData.templates;
							tb.cleanup = jsonData.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
							tb.locations = jsonData.locations; if (!(tb.locations)) {tb.locations = []};
							tb.sources = jsonData.sources; if (!(tb.sources)) {tb.sources = []};
							tb.dataVersion = d;
							console.log('Web: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates.' + ', ' +  tb.cleanup.length + ' cleanup.' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
							chrome.storage.local.set({"alltemplates": jsonData});
						}
					})
				}
			})
		});
	}
});

/*
Todo. Add spaces on edit comment.
1.0.4
  * Condensed template info in the dialog to occupy less space.
  * After switching off the enhanced editor the selected function is executed if possible.
  * AutoCorrection of location fields.
  * Added AutoCorrection to categories
  * Implemented case insensitive in template parameter names recognition
*/

;// CONCATENATED MODULE: ./src/features/bioCheck/SourceRules.js
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
* Rules for identifying sources in a biography that are not valid
* Intended to be a singleton and immutable
* and look like what could be read from database tables
*/
class SourceRules {

  // Valid text for biography heading
  biographyHeadings = [
    "biography",
    "biographie",
    "biografia",
    "biografie",
    "biografi",
    "elämäntarina",
    "Æviskrá",
    "bographie",
    "biografijo",
    "biografía",
  ];
  // Valid text for sources heading
  sourcesHeadings = [
    "sources",
    "quellen",
    "bronnen",
    "fuentes",
    "lähteet",
    "fonti",
    "kallor",
    "heimildir",
    "källor",
    "fontes",
    "kilder",
    "źródła",
    "izvor",
  ];
  // Valid text for research notes heading
  researchNotesHeadings = [
    "research notes",
    "notes de recherche",
    "onderzoeksnotities",
    "opmerkingen",
    "bemerkungen zur nachforschung",
    "forschungsnotizen",
    "notas de investigación",
    "note di ricerca",
    "forskningsanteckningar",
    "forskningsnotater",
    "notas de pesquisa",
    "forskningsnotater",
    "tutkimustiedot",
    "notatki badawcze",
    "raziskovalne opombe",
    "viittaukset",
    "rannsóknarnótur",
  ];
  // Valid text for acknowledgements heading
  acknowledgmentsHeadings = [
    "acknowledgements",
    "acknowledgments",
    "acknowledgement",
    "acknowledgment",
    "remerciements",
    "dankbetuiging",
    "anerkennung",
    "danksagungen",
    "agradecimientos",
    "ringraziamenti",
    "dankwoord",
    "erkännanden",
    "reconhecimentos",
    "riconoscimenti",
    "anerkendelser",
    "anerkjennelser",
    "bekräftelser",
    "tunnustukset",
    "podziękowanie",
    "priznanja",
  ];
  // strings that identify a census source
  // when used by itself or with nothing other than
  // date are not a valid source
  censusStrings = [
    "census",
    "recensement",
    "bevolkingsregister",
    "volkszählung",
    "censo",
    "censimento",
    "volkstelling",
    "folketælling",
    "telling",
    "folkräkning",
    "väestönlaskenta",
    "spis",
    "ludności",
    "popis",
    "väestönlaskenta",
    "manntal",
    "folketelling",
    "folkräkning",
    "us federal census",
    "united states federal census",
    "united states census",
    "us census",
    "u.s. census",
    "us census returns",
    "federal census",
    "swedish census",
    "canada census",
    "census of canada",
    "canadian census",
    "england census",
    "irish census",
    "ireland census",
    "census information",
    "new york state census",
    "iowa state census",
    "scotland census",
  ];

  /* order by length then alpha, but for efficiency
   * since most profiles are English, that is first
   * Note: logic checks for at least 15 characters so
   * shorter are commented out, but kept in case 
   * this is too aggressive
   * invalidSourceList are strings on a line by themselves
   */
  invalidSourceList = [
  /*
    ".",
    "*",
    "bmd",
    "---",
    "ibid",
    "----",
    "bible",
    "census",
    "family",
    "freebmd",
    "hinshaw",
    "ancestry",
    "footnote",
    "geneanet",
    "research",
    "see also",
    "footnotes",
    "see also:",
    "we relate",
    "findagrave",
    "footnotes:",
    "myheritage",
    "ancestrycom",
    "ancestry.uk",
    "ancestry.ca",
    "bdm records",
    "my heritage",
    "my research",
    "will follow",
    "ancestry.com",
    "familysearch",
    "family bible",
    "family trees",
    "find a grave",
    "find-a-grave",
    "find my past",
    "source list:",
    "ancestry.com:",
    "billiongraves",
    "family member",
    "family papers",
    "family search",
    "needs sources",
    ":source list:",
    "source needed",
    "we relate web",
    "ancestry.co.uk",
    "ancestrydotcom",
    "billion graves",
    "census records",
    "church records",
    "family history",
    "family records",
    "findagrave.com",
    "freebmd.org.uk",
    "internet files",
    "my family tree",
    "myheritage.com",
    "parish records",
    "passenger list",
    "'''see also'''",
    */
    "ancestry source",
    "census records.",
    "familysearchorg",
    "family accounts",
    "family research",
    "online research",
    "own family tree",
    "title: marriage",
    "'''see also:'''",
    "www.ancestry.ca",
    "www.bms2000.org",
    "familysearch.org",
    "family documents",
    "family knowledge",
    "findmypast.co.uk",
    "'''footnotes:'''",
    "internet records",
    "personal records",
    "research records",
    "www.ancestry.com",
    "acknowledgements:",
    "ancestry research",
    "familysearch tree",
    "family collection",
    "family tree files",
    "fellow researcher",
    "scotland's people",
    "wiki, family tree",
    ":'''footnotes:'''",
    "personal research",
    "private genealogy",
    "'''source list'''",
    ":'''source list'''",
    "'''source list:'''",
    "cemetery headstone",
    "citing this record",
    "family information",
    "newspaper obituary",
    "source information",
    "title: death index",
    "wwwfamilysearchorg",
    "www.ancestry.co.uk",
    "www.gencircles.com",
    "www.myheritage.com",
    "{{citation needed}}",
    "citing this record:",
    "familysearch search",
    "my heritage records",
    "my tree on ancestry",
    ":'''source list:'''",
    "real estate records",
    "ancestry family tree",
    "from family records.",
    "personal family tree",
    "personal information",
    "uk census; bmd index", 
    "www.familysearch.org",
    "ancestry family trees",
    "ancestry family site.",
    "family search records",
    "mormon church records",
    "replace this citation",
    "ancestry and documents",
    "scotlandspeople.gov.uk",
    "ancestry tree & sources",
    "family tree on ancestry",
    "personal family records",
    "no sources at this time",
    "family search family tree",
    "scotland's people website",
    "ancestry and family search",
    "www.scotlandspeople.gov.uk",
    "us census, public records.",
    "family tree on familysearch",
    "social security death index",
    "sources are on my family tree",
    "familysearch.org ancestry.com",
    "ancestry.com familysearch.org",
    "'''footnotes and citations:'''",
    ":'''footnotes and citations:'''",
    "family search files on internet",
    "online trees. will add sources.",
    "personal knowledge , census reports",
    "a source is still needed for this data.",
    "social security applications and claims",
    "a source for this information is needed",
    "a source for this information is needed.",
    "replace this citation if there is another source",
    "personal recollection, as told to me by their relative. notes and sources in their possession.",
    "michael lechner,",
    "virginia hanks",
    "teresa a. theodore",
    "michael eneriis",
    /*
    "spis",
    "censo",
    "popis",
    "badania",
    "ricerca",
    "se aven",
    "se även",
    "se også",
    "sukupuu",
    "telling",
    "zie ook",
    "ættartré",
    "ludności",
    "pesquisa",
    "se också",
    "stamboom",
    "tutkimus",
    "forschung",
    "forskning",
    "onderzoek",
    "recherche",
    "slægtstræ",
    "slektstre",
    "släktträd",
    "volgt nog",
    "bron nodig",
    "censimento",
    "familietre",
    "katso myös",
    "katso myös",
    "rannsóknir",
    "sjá einnig",
    "siehe auch",
    "voir aussi",
    "zobacz też",
    "familie træ",
    "folkräkning",
    "poglej tudi",
    "recensement",
    "veja também",
    "ver tambien",
    "familiebibel",
    "folketælling",
    "guarda anche",
    "källa behövs",
    "potreben vir",
    "raziskovanje",
    "volkszählung",
    "volkstelling",
    "bronnen nodig",
    "familienbibel",
    "familie bibel",
    "investigación",
    "nachforschung",
    "perheraamattu",
    "source requise",
    "voir également",
    "družinsko drevo",
    "drzewo rodzinne",
    "familiestamboom",
    "kilde nødvendig",
    "lähde tarvitaan",
    "tarvitaan lähde",
    "quelle benötigt",
    "väestönlaskenta",
    */
    "árbol de familia",
    "bible de famille",
    "fjölskyldubiblía",
    "fonte necessária",
    "fuente necesaria",
    "potrzebne źródło",
    "quelle notwendig",
    "familienstammbaum",
    "heimildar er þörf",
    "korvaa tämä viite",
    "source nécessaire",
    "albero genealogico",
    "arbre généalogique",
    "bevolkingsregister",
    "ersätt detta citat",
    "heimild nauðsynleg",
    "kilde er nødvendig",
    "nadomesti ta citat",
    "skiptið út heimild",
    "zastąpić ten cytat",
    "erstat henvisningen",
    "korvaa tämä lainaus",
    "udskift dette citat",
    "ersetze dieses zitat",
    "reemplazar esta cita",
    "vervang deze citatie",
    "erstatt dette sitatet",
    "substitua esta citação",
    "ersätt denna hänvisning",
    "remplacez cette citation",
    "erstatt denne henvisningen",
    "sostituire questa citazione",
  ];

  // anywhere in a line not a valid source
  invalidPartialSourceList = [
    "through the import of",
    "add sources here",
    "add [[sources]] here",
    "family tree maker",
    ".ftw",
    "replace this citation if there is another source",
    "replace this citation",
  ];

  // anywhere on a line is a valid source
  validPartialSourceList = [
    "sources are hidden to protect",
    "sources hidden to protect",
    "source hidden to protect"
  ];

  // on the start of a line not a valid source
  invalidStartPartialSourceList = [
    "entered by",
    "no sources.",
    "no repo record found",
    "source will be added by",
    "no sour record found",
    "no note record found",
  ];

  // on a line by itself
  // not a valid source for
  // profile born > 150 or died > 100
  tooOldToRememberSourceList = [
    "personal recollection of events witnessed by",
    "personal recollection of",
    "personal knowledge",
    "first hand knowledge",
    "firsthand knowledge",
    "førstehånds kendskab",
    "ensi käden tieto",
    "af fyrstu hendi",
    "førstehåndskjennskap",
    "förstahandskälla",
    "förstahands kännedom",
    "as remembered by",
    "selon la mémoire de",
    "zoals herinnerd door",
    "eigen kennis",
    "wie erinnert von",
    "wissen aus erster hand",
    "como lo recuerda",
    "como lembrado por",
    "come ricordato da",
    "wie erinnert",
    "comme rappelé par",
    "som husket av",
    "som minns av",
    "kuten muistaa",
    "jak zapamiętał",
    "kot se spominja",
    "som husket af",
    "kuten nn muistaa",
    "nnn mukaan",
    "samkvæmt minni",
    "husket av",
    "ihågkommet av",
  ];

  // anywhere in a line
  // not a valid source for
  // profile born > 150 or died > 100
  invalidPartialSourceListTooOld = [
    "first hand knowledge",
    "firsthand knowledge",
    "personal recollection",
    "as remembered by",
    "selon la mémoire de",
    "zoals herinnerd door",
    "eigen kennis",
    "wie erinnert von",
    "wissen aus erster hand",
    "como lo recuerda",
    "como lembrado por",
    "come ricordato da",
    "wie erinnert",
    "comme rappelé par",
    "som husket av",
    "som minns av",
    "kuten muistaa",
    "jak zapamiętał",
    "kot se spominja",
    "som husket af",
    "kuten nn muistaa",
    "nnn mukaan",
    "samkvæmt minni",
    "husket av",
    "first-hand information",
    "eigen kennis",
    "unsourced family tree handed down",
  ];

  // line by itself
  // not a valid source for Pre1700
  invalidSourceListPre1700 = [
    "birth certificate",
    "birth record",
    "marriage certificate",
    "marriage record",
    "death certificate",
    "death record",
    "igi",
    "family data",
    "certificat de naissance",
    "registre de naissance",
    "certificat de décès",
    "registre de décès",
    "registre de mariage",
    "geboorteakte",
    "geboorte akte",
    "overlijdensakte",
    "overlijdens acte",
    "overlijdens akte",
    "trouwakte",
    "trouwacte",
    "trouw oorkonde",
    "geburtsurkunde",
    "sterbeurkunde",
    "heiratsurkunde",
    "acta de nacimiento",
    "acte de naissance",
    "akt urodzenia",
    "certidão de nascimento",
    "certificado de nacimiento",
    "certificato di nascita",
    "födelsebevis",
    "födelsedokument",
    "fødselsattest",
    "fødselsrekord",
    "registro de nascimento",
    "rojstni list",
    "rojstni zapis",
    "syntymätiedot akt urodzenia",
    "syntymätodistus",
    "certidão de óbito",
    "certificado de defunción",
    "certificato di morte",
    "certyfikat śmierci",
    "døds sertifikat",
    "dødsattest",
    "dödscertifikat",
    "kuolintodistus",
    "mrliški list",
    "acta de defunción",
    "acte de décès",
    "akt zgonu",
    "dödsrekord",
    "kuolemantiedot",
    "registro de morte",
    "registro degli atti di morte",
    "smrtni zapis",
    "akt małżeństwa",
    "certidão de casamento",
    "certificado de matrimonio",
    "certificat de mariage",
    "certificato di matrimonio",
    "eheurkunde trauschein",
    "huwelijksakte",
    "poročni list",
    "vielsesattest",
    "vigselbevis",
    "vigselsattest",
    "vihkitodistus",
    "acte de mariage",
    "ægteskabsoptegnelse",
    "äktenskap rekord",
    "avioliitto ennätys",
    "ekteskapsrekord",
    "poročni zapis",
    "record di matrimonio",
    "registro de casamento",
    "registro de matrimonio",
    "dåbsattest",
    "dánarskrá",
    "dánarvottorð",
    "dödsattest",
    "dödsfallsintyg",
    "dödsnotis",
    "dødsregistrering",
    "dødsregistrering",
    "fæðingarskrá",
    "fæðingarvottorð",
    "födelsenotis",
    "fødselsregistrering",
    "hjúskaparskrá",
    "hjúskaparvottorð",
    "kuolinkirjaus",
    "kuolinmerkintä",
    "navneattest",
    "syntymäkirjaus",
    "syntymämerkintä",
    "vielselsattest el. vigselsattest",
    "vielseregistrering",
    "vigselnotis",
    "vihkimismerkintä",
  ];

  // anywhere on a line
  // not a valid source for Pre1700
  invalidPartialSourceListPre1700 = [
    "ancestry tree",
    "public member tree",
    "family tree",
    "arbre généalogique",
    "familienstammbaum",
    "stamboom",
    "árbol de familia",
    "družinsko drevo",
    "albero genealogico",
    "familiestamboom",
    "familie træ",
    "familietre",
    "släktträd",
    "sukupuu",
    "drzewo rodzinne",
    "family-tree",
    "familysearch.org/tree",
    "trees.ancestry.com",
    "geni tree",
    "ancestral file",
    "burke's peerage",
    "burke’s dormant and extinct peerages",
    "burke’s extinct and dormant baronetcies",
    "burke’s peerage and baronetage",
    "capedia",
    "dictionnaire universel de la noblesse de france",
    "fabpedigree.com",
    "family data collection",
    "genealogie.quebec",
    "genealogieonline",
    "genealogy of the wives of the american presidents",
    "geneanet tree",
    "historiske efterretninger om verfortiente danske adelsmaend",
    "https://kindred.stanford.edu",
    "international genealogical index",
    "jean-baptiste-pierre jullien de courcelles",
    "kindred britain",
    "millennium file",
    "myheritage tree",
    "nicolas viton de saint-allais",
    "nobiliaire universel de france",
    "nosorigines",
    "nos origines",
    "nos origines.",
    "our common ancestors",
    "our royal, titled, noble, and commoner ancestors",
    "our-royal-titled-noble-and-commoner-ancestors.com",
    "pedigree resource file",
    "roglo",
    "rootsweb tree",
    "stirnet.com",
    "the peerage",
    "thepeerage.com",
    "tudor place",
    "u.s. and international marriage records, 1560-1900",
    "us and international marriages Index",
    "vore fælles ahner",
    "www.genealogieonline.nl",
    "www.tudorplace.com.ar",
    "ancestry.com-oneworld tree",
    "one world tree",
    "family group sheet",
    "added by confirming a smart match",
    "world family tree",
    "derbund wft",
    "www.gencircles.com",
  ];

  sourceRulesList = [
    this.biographyHeadings,
    this.sourcesHeadings,
    this.researchNotesHeadings,
    this.acknowledgmentsHeadings,
    this.censusStrings,
    this.invalidSourceList,
    this.invalidPartialSourceList,
    this.validPartialSourceList,
    this.invalidStartPartialSourceList,
    this.tooOldToRememberSourceList,
    this.invalidPartialSourceListTooOld,
    this.invalidSourceListPre1700,
    this.invalidPartialSourceListPre1700
  ];

  constructor() {
  }
}

;// CONCATENATED MODULE: ./src/features/bioCheck/PersonDate.js
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * Contains information about a WikiTree Profile
 * only contains a subset of the complete set of data available
 */
class PersonDate {

  static TOO_OLD_TO_REMEMBER_DEATH = 100;
  static TOO_OLD_TO_REMEMBER_BIRTH = 150;

  personDate = {
    birthDate: null,                // birth date as Date
    deathDate: null,                // death date as Date
    birthDateString: "",            // birth date string as from server
    deathDateString: "",            // death date string as from server
    hasBirthDate: true,
    hasDeathDate: true,
    lastDateCheckedEmpty: false,   // HACK
    oneYearAgo: null,
    isPre1700: false,
    isPre1500: false,
    tooOldToRemember: false,
    personUndated: false,
  }

  /**
   * constructor
   */
  constructor() {
  }

  /**
   * Initialize person dates from null, 0000 or various forms
   * @param bDay birth date
   * @param dDay death date
   */
  initWithDates(bDay, dDay) {
    if (bDay != null) {
      this.personDate.birthDateString = bDay;
      this.personDate.birthDate = this.getDate(this.personDate.birthDateString);
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasBirthDate = false;
    }
    if (dDay != null) {
      this.personDate.deathDateString = dDay;
      this.personDate.deathDate = this.getDate(this.personDate.deathDateString);
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasDeathDate = false;
    }

    // Go ahead and see if pre1500, pre1700 or too old
    this.isPersonPre1500();
    this.isPersonPre1700();
    this.mustBeOpen();
  }

  /**
   * Initialize person dates
   * @param profileObj containing the profile
   */
  init(profileObj) {

    if (profileObj.BirthDate != null) {
      this.personDate.birthDateString = profileObj.BirthDate;
      this.personDate.birthDate = this.getDate(this.personDate.birthDateString);
    } else {
      if (profileObj.BirthDateDecade != null) {
        this.personDate.birthDateString = profileObj.BirthDateDecade.slice(0, -1);
        this.personDate.birthDate = this.getDate(this.personDate.birthDateString);
      }
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasBirthDate = false;
    }
    if (profileObj.DeathDate != null) {
      this.personDate.deathDateString = profileObj.DeathDate;
      this.personDate.deathDate = this.getDate(this.personDate.deathDateString);
    } else {
      if (profileObj.DeathDateDecade != null) {
        this.personDate.deathDateString = profileObj.DeathDateDecade.slice(0, -1);
        this.personDate.deathDate = this.getDate(this.personDate.deathDateString);
      }
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasDeathDate = false;
    }

    // Go ahead and see if pre1500, pre1700 or too old
    this.isPersonPre1500();
    this.isPersonPre1700();
    this.mustBeOpen();

  }

  /**
   * Convert date from form returned by server to a Date
   * The server may have 00 for any year, month, day
   * In that case, the value 1 is used
   * @param dateString as input from server in the form 0000-00-00
   * @return Date for the input string
   */
  getDate(dateString) {
    let year = 0;             // default in case of 0 values
    let month = 0;
    let day = 0;
    this.lastDateCheckedEmpty = false;    // hack hack
    let splitString = dateString.split("-");
    let len = splitString.length;
    if (len > 0) {
      year = splitString[0];
    }
    if (len > 1) {
      month = splitString[1];
    }
    if (len >= 2) {
      day = splitString[2];
    }
    if ((year + month + day) === 0) {
      this.lastDateCheckedEmpty = true;
    }
    if (year === 0) {
      year = 1;
    }
    if (month === 0) {
      month = 1;
    }
    if (day === 0) {
      day = 1;
    }
    return (new Date(year, month, day));
  }

  /**
   * Is the person before 1500
   * @return true if either birth or death date before 1500
   */
  isPersonPre1500() {
    let theYear1500 = new Date("1500-01-01");
    if (this.personDate.birthDate != null) {
      if (this.personDate.birthDate < theYear1500) {
        this.isPre1500 = true;
      }
    }
    if (this.personDate.deathDate != null) {
      if (this.personDate.deathDate < theYear1500) {
        this.isPre1500 = true;
      }
    }
    if (this.isPre1500) {
      this.isPre1500 = true;
      this.isPre1700 = true;
      this.tooOldToRemember = true;
    }
    return this.isPre1500;
  }

  /**
   * Is the person before 1700
   * @return true if either birth or death date before 1700
   */
  isPersonPre1700() {
    let theYear1700 = new Date("1700-01-01");
    if (this.personDate.birthDate != null) {
      if (this.personDate.birthDate < theYear1700) {
        this.isPre1700 = true;
      }
    }
    if (this.personDate.deathDate != null) {
      if (this.personDate.deathDate < theYear1700) {
        this.isPre1700 = true;
      }
    }
    if (this.isPre1700) {
      this.tooOldToRemember = true;
    }
    return this.isPre1700;
  }
  /**
   * Is the person born > 150 years ago or died > 100 years ago
   * @return true if born > 150 years ago or died > 100 years ago
   */
  mustBeOpen() {
    let today = new Date();
    let year = today.getFullYear();
    let month = today.getMonth();
    let day = today.getDate();
    let earliestMemoryBeforeDeath = new Date(year - this.TOO_OLD_TO_REMEMBER_DEATH, month, day);
    let earliestMemoryBeforeBirth = new Date(year - this.TOO_OLD_TO_REMEMBER_BIRTH, month, day);
    if (this.personDate.birthDate != null) {
      if (this.personDate.birthDate < earliestMemoryBeforeBirth) {
        this.tooOldToRemember = true;
      }
    }
    if (this.personDate.deathDate != null) {
      if (this.personDate.deathDate < earliestMemoryBeforeDeath) {
        this.tooOldToRemember = true;
      }
    }
    /*
     * Since you already have today, pick up the date to use for
     * a source will be entered by xxxx tests
    */
    this.personDate.oneYearAgo = new Date(year - 1, month, day);
    
    return this.tooOldToRemember;
  }

  /**
   * Does the profile lack dates
   * @return true if profile has neither birth nor death date
   */
  isUndated() {
    if (!this.personDate.hasBirthDate && !this.personDate.hasDeathDate) {
      this.isPre1500 = true;
      this.isPre1700 = true;
      this.tooOldToRemember = true;
      return true;
    } else {
      return false;
    }
  }

  /**
   * Get birth date
   * @return birth date as Date
  */
  getBirthDate() {
    return this.personDate.birthDate;
  }
  /**
   * Get death date
   * @return death date as Date
  */
  getDeathDate() {
    return this.personDate.deathDate;
  }

  /**
   * Convert date to a display format
   * @param true to get birth date, else death date
   * @return string in the form yyyy mon dd
   */
  getReportDate(isBirth) {

    // handle cases without any date. sigh.
    let dateString = "";
    let hasDate = this.personDate.hasDeathDate;
    if (isBirth) {
      hasDate = this.personDate.hasBirthDate;
      if (hasDate) {
        dateString = this.personDate.birthDateString;
      }
    } else {
      if (hasDate) {
        dateString = this.personDate.deathDateString;
      }
    }
    let displayDate = "";
    if (hasDate) {
      let year = 0;             // default in case of 0 values
      let month = 0;
      let day = 0;
      let splitString = dateString.split("-");
      let len = splitString.length;
      if (len > 0) {
        year = splitString[0];
      }
      if (len > 1) {
        month = splitString[1];
      }
      if (len >= 2) {
        day = splitString[2];
      }
      if (day > 0) {
        displayDate = day + " ";
      }
      if (month > 0) {
        let months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        let monthNumber = parseInt(month);
        let monthName = months[monthNumber-1];
        displayDate += monthName + " ";
      }
      if (year > 0) {
        displayDate += year;
      }
    }
    return displayDate;
  }

}

;// CONCATENATED MODULE: ./src/features/bioCheck/BiographyResults.js
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * Hold results for parse and validate a WikiTree biography
 */
class BiographyResults {

   bioResults = {

      stats: {
         bioIsEmpty: false,
         bioHasCategories: false,
         bioIsMarkedUnsourced: false,
         bioIsUncertainExistance: false,
         bioIsUndated: false,
         totalBioLines: 0,
         inlineReferencesCount: 0,      // number of <ref>
         possibleSourcesLineCount: 0   // number of lines that might contain sources
      },
      style: {
         bioHasNonCategoryTestBeforeBiographyHeading: false,
         bioHasStyleIssues: false,
         hasEndlessComment: false,
         bioIsMissingBiographyHeading: false,
         bioHeadingWithNoLinesFollowing: false,
         bioHasMultipleBioHeadings: false,
         bioHasRefWithoutEnd: false,
         bioHasSpanWithoutEndingSpan: false,
         bioIsMissingSourcesHeading: false,
         sourcesHeadingHasExtraEqual: false,
         bioHasMultipleSourceHeadings: false,
         misplacedLineCount: 0,      // between Sources and <references /> 
         bioIsMissingReferencesTag: false,
         bioHasMultipleReferencesTags: false,
         bioHasRefAfterReferences: false,
         acknowledgementsHeadingHasExtraEqual: false,
         bioHasAcknowledgementsBeforeSources: false,
         bioIsAutoGenerated: false
      },
      sources: {
         sourcesFound: false,

         // Invalid sources that were found - each an array
         // might not need/want these, depends on reporting
         invalidSource: [],
         //invalidStandAloneSource: [],
         //invalidPartialSource: [],
         //invalidStartPartialSource: [],
         //invalidSpanTargetSource: [],
         validSource: [],
      }
   };

   constructor() {
   }

   getResults() {
     return this.bioResults;
   }
}

;// CONCATENATED MODULE: ./src/features/bioCheck/Biography.js
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * Parse and validate a WikiTree biography
 * Gather information about style and the parts needed to validate
 * along with information about the bio and methods to parse and validate
 */

class Biography extends BiographyResults {

  sourceRules = null;             // rules for testing sources
  bioLines = ([]);                // lines in the biography
  bioHeadingsFound = [];          // biography headings found (multi lang)
  sourcesHeadingsFound = [];      // sources headings found (multi lang)
  invalidSpanTargetList = ([]);   // target of a span that are not valid
  refStringList = ([]);           // all the <ref> this </ref> lines
  namedRefStringList = ([]);      // all the <ref> with names

  bioInputString = "";            // input string may be modified by processing
  biographyIndex = -1;            // first line of biography
  acknowledgementsEndIndex = -1;  // next heading or end of bio
  sourcesIndex = -1;              // first line of sources
  referencesIndex = -1;           // index into vector for <references tag
  acknowledgementsIndex = -1;     // first line of acknowledgements
  researchNotesIndex = -1;        // first line of researchNotes
  researchNotesEndIndex = -1;     // last line of research notes is next heading

  isPre1700 = false;              // is this a pre1700 profile
  isPre1500 = false;              // is this a pre1500 profile
  tooOldToRemember = false;       // is this profile to old to remember
  treatAsPre1700 = false;         // treat all profiles as pre1700

  static START_OF_COMMENT = "<!--";
  static END_OF_COMMENT = "-->";
  static START_OF_BR = "<br";
  static REF_START = "<ref>";
  static REF_END = "</ref>";
  static END_BRACKET = ">";
  static REF_START_NAMED = "<ref name";
  static REF_END_NAMED = "/>";
  static HEADING_START = "==";
  static CATEGORY_START = "[[category";
  static REFERENCES_TAG = "<references";
  static UNSOURCED = "unsourced";
  static UNSOURCED_TAG = "{{unsourced";
  static UNSOURCED_TAG2 = "{{ unsourced";
  static QUESTIONABLE_TAG = "{{template:questionable";
  static UNCERTAIN_TAG = "{{uncertain existence";
  static DISPROVEN_TAG = "{{disproven existence";
  static DISPROVEN2_TAG = "{{disproven existence project";
  static AUTO_GENERATED = "auto-generated by a gedcom import";
  static SPAN_TARGET_START = "<span id=";
  static SPAN_TARGET_END = "</span>";
  static SPAN_REFERENCE_START = "[[#";
  static SPAN_REFERENCE_END = "]]";
  static MIN_SOURCE_LEN = 15;       // minimum length for valid source
  static SOURCE_START = "source:";

  /**
   * Constructor
   * @param sourceRules source rules for validating sources
   * @param bioResults container for BiographyResults
   */ 
  constructor(theSourceRules) {
    super();
     this.sourceRules = theSourceRules;
  }

  /**
   * Parse contents of the bio
   * @param inStr bio string as returned from server
   * @param isPre1500 true if profile is treated as Pre1500
   * @param isPre1700 true if profile is treated as Pre1700
   * @param mustBeOpen true if profile is treated as too old to remember
   * @param bioUndated true if profile has no dates
   * @param checkAutoGenerated true to report profiles with auto-generated * string
   * Side effects - set statistics and style
   */
  parse(inStr, isPre1500, isPre1700, mustBeOpen, bioUndated, checkAutoGenerated) {

    this.isPre1500 = isPre1500;
    this.isPre1700 = isPre1700;
    this.tooOldToRemember = mustBeOpen;
    this.bioResults.stats.bioIsUndated = bioUndated;

    this.bioInputString = inStr;
    // Check for empty bio
    if (this.bioInputString.length === 0) {
      this.bioResults.stats.bioIsEmpty = true;
      this.bioResults.style.bioHasStyleIssues = true;
      return;
    }
    // check for endless comment
    this.bioInputString = this.swallowComments(this.bioInputString);
    if (this.bioResults.style.hasEndlessComment) {
      this.bioResults.style.bioHasStyleIssues = true;
      return;
    }
    // assume no style issues
    this.bioResults.style.bioHasStyleIssues = false;

    // swallow any <br>
    this.bioInputString = this.swallowBr(this.bioInputString);

    // if auto generated from GEDCOM and testing this, report as style issue
    if (checkAutoGenerated) {
      let tmpLine = this.bioInputString.toLowerCase();
      if ((tmpLine.indexOf(Biography.AUTO_GENERATED)) > 0) {
        this.bioResults.style.bioHasStyleIssues = true;
        this.bioResults.style.bioIsAutoGenerated = true;
      }
    }

    // build a vector of each line in the bio then iterate
    this.getLines(this.bioInputString);
    let lineCount = this.bioLines.length;
    let currentIndex = 0;
    while (currentIndex < lineCount) {
      let line = this.bioLines[currentIndex].toLowerCase();
      // handle the case where there is no space before ending /
      // so it might start with a blank
      // TODO maybe report starting with a blank as a style issue?
      if (line.indexOf(Biography.REFERENCES_TAG) >= 0) {
        this.referencesIndex = currentIndex;
      } else {
        if (line.startsWith(Biography.CATEGORY_START)) {
          this.bioResults.stats.bioHasCategories = true;
          if (line.includes(Biography.UNSOURCED)) {
            this.bioResults.stats.bioIsMarkedUnsourced = true;
          }
        } else {
          if (line.startsWith(Biography.HEADING_START)) {
            this.evaluateHeadingLine(line, currentIndex);
          }       // end if a heading line
        }         // end if a category line
      }           // end if references tag
      currentIndex++;
    }
    // acknowlegements may go to end of bio
    if (this.acknowledgementsEndIndex < 0) {
      this.acknowledgementsEndIndex = lineCount;
    }
    let line = this.bioInputString.toLowerCase();
    if ((line.includes(Biography.UNSOURCED_TAG)) ||
          (line.includes(Biography.UNSOURCED_TAG2))) {
      this.bioResults.stats.bioIsMarkedUnsourced = true;
    }
    if (line.includes(Biography.QUESTIONABLE_TAG) ||
         (line.includes(Biography.UNCERTAIN_TAG)) ||
         (line.includes(Biography.DISPROVEN2_TAG)) ||
         (line.includes(Biography.DISPROVEN_TAG))) {
         this.bioResults.stats.bioIsUncertainExistance = true;
    }

    // Get the string that might contain <ref>xxx</ref> pairs
    let bioLineString = this.getBioLineString();
    this.findRef(bioLineString);
    this.findNamedRef(bioLineString);

    this.setBioStatisticsAndStyle();

    // Lose bio lines not considered to contain sources
    this.removeResearchNotes();
    this.removeAcknowledgements();

    if (this.bioResults.style.bioHasRefWithoutEnd) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
    return;
  }

  /**
   * Validate contents of bio
   * @return true if probably valid sources and no style issues, else false
   */
  validate() {

    let isValid = false;
    /*
     * Don't bother for empty bio, one already marked unsourced, uncertain existance
     * or the manager's own profile
     */
    if (!this.bioResults.stats.bioIsEmpty && 
        !this.bioResults.stats.bioIsMarkedUnsourced &&
        !this.bioResults.stats.bioIsUncertainExistance &&
        !this.bioResults.stats.bioIsUndated) {

      // Look for a partial string that makes it valid
      isValid = this.containsValidPartialSource(this.bioInputString.toLowerCase());

      /*
       * First validate strings after references. This will build a side effect of
       * a list of invalid span tags.
       * Next validate strings between Sources and <references />. This will update/build
       * a side effect list of invalid span tags.
       * Finally validate the references, looking at invalid span tags if needed.
       *
       * Strings after references and within named and unnamed ref tags are
       * validated to add those to the list of valid/invalid sources
       */
      if (!isValid) {
        isValid = this.validateReferenceStrings();
        if (this.validateRefStrings(this.refStringList)) {
          if (!isValid) {
            isValid = true;
          }
        }
        if (this.validateRefStrings(this.namedRefStringList)) {
          if (!isValid) {
            isValid = true;
          }
        }
        if (!isValid) {
          this.bioResults.sources.sourcesFound = false;
          isValid = false;
        }
      }
    }
    if (isValid) {
      this.bioResults.sources.sourcesFound = true;
    }
    return isValid;
  }

  /* *********************************************************************
   * ******************* PRIVATE METHODS *********************************
   * ******************* used by Parser **********************************
   * *********************************************************************
   */

  /*
   * Swallow comments
   * side effect set style if endless comment found
   * @param inStr
   * @return string with comments removed
  */
  swallowComments(inStr) {
    let outStr = "";
    /*
     * Find start of comment
     * Put everything before start in output string
     * Find end of comment, skip past the ending and start looking there
    */
    let pos = 0;               // starting position of the comment
    let endPos = 0;            // end position of the comment
    let len = inStr.length;    // length of input string
    pos = inStr.indexOf(Biography.START_OF_COMMENT);
    if (pos < 0) {
      outStr = inStr;         // no comments
    }
    while ((pos < len) && (pos >= 0)) {
      // get everything to start of comment unless comment is first line in bio
      if (pos > 0) {
        outStr = outStr + inStr.substring(endPos, pos - 1);
      }
      // Find end of comment
      endPos = inStr.indexOf(Biography.END_OF_COMMENT, pos);
      if (endPos > 0) {
        pos = endPos + 3;    // skip the --> and move starting position there
        if (pos <= len) {
          pos = inStr.indexOf(Biography.START_OF_COMMENT, pos);  // find next comment
          if (pos < 1) {
            outStr += inStr.substring(endPos + 3);
          }
        }
      } else {
        this.bioResults.style.hasEndlessComment = true;
        pos = inStr.length + 1;  // its an endless comment, just bail
      }
    }
    return outStr;
  }
  /* 
   * Swallow BR 
   * could be in the form <br> or <br/> or <br />
   * @param inStr
   * @return string with br removed
   */
  swallowBr(inStr) {
    let outStr = "";
    let pos = 0;
    let endPos = 0;
    let len = inStr.length;
    pos = inStr.indexOf(Biography.START_OF_BR);
    if (pos < 0) {
       outStr = inStr;         // no br
    } 
    while ((pos < len) && (pos >= 0)) {
      if (pos > 0) {
        outStr = outStr + inStr.substring(endPos, pos);
      }
      endPos = inStr.indexOf(Biography.END_BRACKET, pos);
      if (endPos > 0) {
        pos = endPos + 1;    // skip the /> and move starting position there
        if (pos <= len) {
          pos = inStr.indexOf(Biography.START_OF_BR, pos);  // find next comment
          if (pos < 1) {
            outStr += inStr.substring(endPos + 1);
          }
        }
      }
    }
    return outStr;
  }

  /*
   * Build an array of each line in the bio
   * lines are delimited by a newline
   * empty lines or those with only whitespace are eliminated
   * @param inStr bio string stripped of comments
   */
  getLines(inStr) {
    let splitString = inStr.split("\n");
    let line = "";
    let tmpString = "";
    let len = splitString.length;
    for (let i = 0; i < len; i++) {
      line = splitString[i];
      // line is nothing but ---- ignore it by replacing with spaces then
      // trimming
      tmpString = line.replace('-', ' ');
      tmpString = tmpString.trim();
      // Sanity check if the line with <references /> also has text following on same line
      if (tmpString.indexOf(Biography.REFERENCES_TAG) >= 0) {
        let endOfReferencesTag = tmpString.indexOf(Biography.END_BRACKET);
        if (endOfReferencesTag + 1 < tmpString.length) {
          // Oopsie. Add a line for references and another for the line
          // and report a style issue?
          let anotherLine = tmpString.substring(0, endOfReferencesTag + 1);
          this.bioLines.push(anotherLine);
          line = tmpString.substring(endOfReferencesTag + 2);
          if (!line.length === 0) {
            this.bioLines.push(tmpString);
          }
        } else {
          this.bioLines.push(tmpString);
        }
      } else {
        this.bioLines.push(line);
      }
    }
    return;
  }

  /* 
   * Process heading line to find Biography, Sources, Acknowledgements
   * set index to each section
   * Methods are used to find sections so that rules can specify 
   * alternate languages
   * @param inStr starting with ==
   * @param currentIndex into master list of strings
   */
  evaluateHeadingLine(inStr, currentIndex) {

    let headingText = "";
    let headingStartPos = 0;
    let headingLevel = 0;
    /*
     * the bioLineString should start with the larger of the start of the line
     * after the biography heading or 0
     * it should end with the smallest of the length of the bio string or
     * the first heading found after the biography heading
    */
    let len = inStr.length;
    while ((headingStartPos < len) && (headingLevel < 4)) {
      if (inStr.charAt(headingStartPos) === '=') {
        headingStartPos++;
        headingLevel++;                // number of =
      } else {
        // lose any leading ' for bold or italics
        let i = headingLevel;
        while ((i < len) && (inStr.charAt(i) === "'")) {
          i++;
        }
        headingText = (inStr.substring(i)).trim();
        headingStartPos = len + 1;       // break out of loop
      }
    }
    // Save index for this heading   
    if (this.isBiographyHeading(headingText)) {
      if (this.biographyIndex < 0) {
        this.biographyIndex = currentIndex;
      } else {
        if (this.researchNotesIndex > 0) {
          this.researchNotesEndIndex = currentIndex - 1;
        }
      }
    } else {
      if (this.isResearchNotesHeading(headingText)) {
            this.researchNotesIndex = currentIndex;
      } else {
        if (this.isSourcesHeading(headingText)) {
          if (headingLevel > 2) {
              this.bioResults.style.sourcesHeadingHasExtraEqual = true;
              this.bioResults.style.bioHasStyleIssues = true;
          }
          if (this.sourcesIndex < 0) {
            this.sourcesIndex = currentIndex;
            if (this.researchNotesIndex > 0) {
              this.researchNotesEndIndex = currentIndex - 1;
            }
            if (this.acknowledgementsIndex > 0) {
              this.acknowledgementsEndIndex = currentIndex - 1;
            }
          } else {
              //this.bioResults.style.bioHasMultipleSourceHeadings = true;
              //this.bioResults.style.bioHasStyleIssues = true;
          }
        } else {
          if (this.isAckHeading(headingText)) {
            if (headingLevel > 2) {
              this.bioResults.style.acknowledgementsHeadingHasExtraEqual = true;
              this.bioResults.style.bioHasStyleIssues = true;
            }
            if (this.sourcesIndex < 0) {
              this.bioResults.style.bioHasAcknowledgementsBeforeSources = true;
              this.bioResults.style.bioHasStyleIssues = true;
            }
            this.acknowledgementsIndex = currentIndex;
            if ((this.researchNotesIndex > 0) && (this.researchNotesEndIndex < 0)) {
               this.researchNotesEndIndex = currentIndex - 1;
            }
          } else {
            // TODO if this is before biography, add a style issue Heading
            // before Biography (aka biographyIndex < 0)
            // just a line
          } // endif Acknowledgements
        } // endif Sources
      } // endif Research Notes
    } // endif Biography
    return;
  }

  /*
   * Get string from bio to be searched for any inline <ref
   * the bioLineString should start with the beginning of the biography
   * or the line after the Biography heading whichever is last
   * it should end with the smallest of the length of the bio string or
   * the first heading found after the biography heading
   */
  getBioLineString() {

    let bioLinesString = "";
    let startIndex = 0;
    // Jump to the start of == Biography
    if (this.biographyIndex > 0 ) {
        startIndex = this.biographyIndex;
    }
    // assume it ends at end of bio then pick smallest
    // of Research Notes, Sources, references, acknowledgements
    // which is also after the start of the biography
    let endIndex = this.bioLines.length;
    if ((this.researchNotesIndex > 0) && (this.researchNotesIndex > startIndex)) {
      endIndex = this.researchNotesIndex;
    }
    if ((this.sourcesIndex > 0) && (this.sourcesIndex < endIndex)) {
      endIndex = this.sourcesIndex;
    }
    if ((this.referencesIndex > 0) &&
        (this.referencesIndex < endIndex)) {
      endIndex = this.referencesIndex;
    }
    if ((this.acknowledgementsIndex > 0) &&
        (this.acknowledgementsIndex < endIndex)) {
      endIndex = this.acknowledgementsIndex;
    }

    if (this.biographyIndex === endIndex) {
      this.bioResults.style.bioHeadingWithNoLinesFollowing = true;
      this.bioResults.style.bioHasStyleIssues = true;
    } else {
      if (endIndex >= 0) {
        while (startIndex < endIndex) {
          bioLinesString += this.bioLines[startIndex];
          startIndex++;
        }
      }
    }
    return bioLinesString;
  }

  /* 
   * Find <ref> </ref> pairs that don't have a name
   * @param bioLineString string to look in for pairs
   * adds contents of ref to refStringList
   */
  findRef(bioLineString) {

    let startOfRef = bioLineString.indexOf(Biography.REF_START);
    let endOfRef = bioLineString.indexOf(Biography.REF_END, startOfRef);     
    while ((startOfRef >= 0) && (!this.bioResults.style.bioHasRefWithoutEnd)) {
      if (endOfRef < 0) {
        // Oopsie, starting <ref> without an ending >
        this.bioResults.style.bioHasRefWithoutEnd = true;
        this.bioResults.style.bioHasStyleIssues = true;
      } else {
        // Now we should have the whole ref lose the <ref> and move past it
        if ((startOfRef + 5) < endOfRef) {
          startOfRef = startOfRef + 5;
        }
        let line = bioLineString.substring(startOfRef, endOfRef);
        this.refStringList.push(line);
        endOfRef++;
        if (endOfRef < bioLineString.length) {
          startOfRef = bioLineString.indexOf(Biography.REF_START, endOfRef);
          if (startOfRef > 0) {
            endOfRef = bioLineString.indexOf(Biography.REF_END, startOfRef);
          }
        }
      }
    }
    return;
  }

  /* 
   * Find named ref
   * which are pairs in the form <ref name= ></ref>
   * or in the form <ref name=xxxx />
   * @param bioLineString string to look in for pairs
   * adds contents of ref to namedRefStringList
   */
  findNamedRef(bioLineString) {

    let endOfRefNamed = -1;
    let endOfRef = -1;
    let end = -1;
    let bioLength = bioLineString.length;
    let startOfRef = bioLineString.indexOf(Biography.REF_START_NAMED);
    while (startOfRef >= 0) {
      endOfRef = bioLineString.indexOf(Biography.REF_END, startOfRef);
      endOfRefNamed = bioLineString.indexOf(Biography.REF_END_NAMED, startOfRef);
      if (endOfRef < 0) {
        endOfRef = bioLength;
      }
      if (endOfRefNamed < 0) {
        endOfRefNamed = bioLength;
      }
      // lose the <ref> portion and use first ending found
      if ((startOfRef + 5) < endOfRef) {
        startOfRef = startOfRef + 5;
      }
      end = endOfRef;
      if (endOfRef > endOfRefNamed) {
        end = endOfRefNamed;
      }
      // save just the part of the line after the name
      let line = bioLineString.substring(startOfRef, end);
      let refStart = line.indexOf(Biography.END_BRACKET);
      if (refStart > 0) {
        refStart++;
        this.namedRefStringList.push(line.substring(refStart));
      }

      // move past the ref
      end++;
      endOfRef++;
      if (end <= bioLength) {
        startOfRef = bioLineString.indexOf(Biography.REF_START_NAMED, end);
      } else {
        if (end > bioLength) {
          startOfRef = -1;        // we are done
        }
      }
    }
  }

  /*
   * Gather bio statistics and style issues
   * only examines items not considered in the parsing
   * Basic checks for the headings and content expected in the biography
   * Update results style
   */
  setBioStatisticsAndStyle() {
    this.bioResults.stats.totalBioLines = this.bioLines.length;
    if ((this.biographyIndex > 1) && !this.bioResults.stats.bioHasCategories) {
      this.bioResults.style.bioHasNonCategoryTestBeforeBiographyHeading = true;      // NOT a style issue
    }
    if (this.biographyIndex < 0) {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioIsMissingBiographyHeading = true;
    }
    if (this.sourcesIndex < 0) {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioIsMissingSourcesHeading = true;
    }
    if (this.referencesIndex < 0) {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioIsMissingReferencesTag = true;
    }
    if (this.bioResults.style.bioHasMultipleReferencesTags) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
    if (this.bioResults.style.misplacedLineCount < 0) {
      this.bioResults.style.misplacedLineCount = 0;
    }
    if (this.bioResults.style.misplacedLineCount > 0) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
    this.bioResults.stats.inlineReferencesCount =
         this.refStringList.length + this.namedRefStringList.length;

    this.bioResults.stats.possibleSourcesLineCount = this.acknowledgementsIndex - 1;
    if (this.bioResults.stats.possibleSourcesLineCount < 0) {
      this.bioResults.stats.possibleSourcesLineCount = this.bioLines.length;
    }
    this.bioResults.stats.possibleSourcesLineCount = this.bioResults.stats.possibleSourcesLineCount -
    this.referencesIndex + 1 + this.bioResults.style.misplacedLineCount;
    if (this.bioResults.style.bioHasAcknowledgementsBeforeSources) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
  }

  /*
   * Determine if Biography heading
   * Uses rules to check for multiple languages
   * Adds bio headings to array of bio headings found
   * @param line to test
   * @return true if biography heading else false
   */
  isBiographyHeading(line) {
    let isBioHeading = false;
    let i = 0;
    while ((!isBioHeading) && (i < this.sourceRules.biographyHeadings.length)) {
      if (line.startsWith(this.sourceRules.biographyHeadings[i])) {
        isBioHeading = true;
        if (this.bioHeadingsFound.includes(line)) {
          this.bioResults.style.bioHasStyleIssues = true;
          this.bioResults.style.bioHasMultipleBioHeadings = true;
        } else {
          this.bioHeadingsFound.push(line);
        }
      }
      i++;
    }
    return isBioHeading;
  }
  /*
   * Determine if Research Notes heading
   * Uses rules to check for multiple languages
   * @param line to test
   * @return true if research notes heading else false
   */
  isResearchNotesHeading(line) {
    let isResearchNotesHeading = false;
    let i = 0;
    while ((!isResearchNotesHeading) && (i < this.sourceRules.researchNotesHeadings.length)) {
      if (line.startsWith(this.sourceRules.researchNotesHeadings[i])) {
        isResearchNotesHeading = true;
      }
      i++;
    }
    return isResearchNotesHeading;
  }

  /*
   * Determine if Sources heading
   * Uses rules to check for multiple languages
   * Adds sources headings to array of sources headings found
   * @param line to test
   * @return true if sources heading else false
   */
  isSourcesHeading(line) {
    let isSourcesHeading = false;
    let i = 0;
    while ((!isSourcesHeading) && (i < this.sourceRules.sourcesHeadings.length)) {
      if (line.startsWith(this.sourceRules.sourcesHeadings[i])) {
        isSourcesHeading = true;
        if (this.sourcesHeadingsFound.includes(line)) {
          this.bioResults.style.bioHasStyleIssues = true;
          this.bioResults.style.bioHasMultipleSourceHeadings = true;
        } else {
          this.sourcesHeadingsFound.push(line);
        }
      }
      i++;
    }
    return isSourcesHeading;
  }

  /*
   * Determine if Acknowledgements heading
   * Uses rules to check for multiple languages
   * @param line to test
   * @return true if acknowledgements heading else false
   */
  isAckHeading(line) {
    let isAckHeading = false;
    let i = 0;
    while ((!isAckHeading) && (i < this.sourceRules.acknowledgmentsHeadings.length)) {
      if (line.startsWith(this.sourceRules.acknowledgmentsHeadings[i])) {
        isAckHeading = true;
      }
      i++;
    }
    return isAckHeading;
  }

  /*
   * Remove Research Notes from bio lines
   * Remove lines between start of Research Notes
   * and end of Research Notes
   * Any content of Research Notes is not considered
   * as a source
   * Research Notes end when a Biography heading is found
   * or at the first Sources or Acknowledgements heading
   */
  removeResearchNotes() {
    let i = this.researchNotesIndex;
    let endIndex = this.researchNotesEndIndex;
    if (endIndex < 0) {
      endIndex = this.bioLines.length;
    }
    if (i > 0) {
      while (i <= endIndex) {
        this.bioLines[i] = "";
        i++;
      }
    }
  }

  /*
   * Remove acknowledgements from bio lines
   * Remove lines between start of Acknowledgements
   * and end of Acknowledgements
   * Any content of Acknowledgements is not considered
   * as a source
   * Acknowledgements end when a heading is found
   * or at the end of the biography
   */
  removeAcknowledgements() {
    let i = this.acknowledgementsIndex;
    let endIndex = this.acknowledgementsEndIndex;
    if (endIndex < 0) {
         endIndex = this.bioLines.length;
    }
    if (i > 0) {
      while (i <= endIndex) {
        this.bioLines[i] = "";
        i++;
      }
    }
  }


  /* *********************************************************************
   * ******************* PRIVATE METHODS *********************************
   * ******************* used by Validator *******************************
   * *********************************************************************
   */

  /*
   * Examine a single line to see if it is a valid source
   * Adds line to array of valid or invalid sources
   * @param mixedCaseLine line to test (and report)
   * @return true if valid else false
   */
  isValidSource(mixedCaseLine) {

    let isValid = false;                          // assume guilty 

    // just ignore starting *
    if (mixedCaseLine.startsWith("*")) {
         mixedCaseLine = mixedCaseLine.substring(1);
    }
    mixedCaseLine = mixedCaseLine.trim();
    
    // perform tests on lower case line
    let line = mixedCaseLine.toLowerCase().trim();
   
    // ignore starting source:
    if ((line.length > 0) && (line.startsWith(Biography.SOURCE_START))) {
        line = line.substring(7);
        line = line.trim();
    }
    // It takes a minimum number of characters to be valid
    if (line.length >= Biography.MIN_SOURCE_LEN) {

      if (!this.isInvalidStandAloneSource(line)) {
        line = line.trim();
        // FindAGrave citations may have partial strings that
        // would otherwise show up as invalid
        if (this.isFindAGraveCitation(line)) {
          isValid = true;
        } else {

          // Does line contain a phrase on the invalid partial source list?
          let invalidSourceString = this.onPartialSourceList(line);
          if (invalidSourceString.length > 0) {
            isValid = false;
          } else {
            // Check for line that starts with something on the invalid start partial list
            let partialSourceLine = "";
            let found = false;
            let max = this.sourceRules.invalidStartPartialSourceList.length;
            let i = 0;
            while (!found && (i < max)) {
              partialSourceLine = this.sourceRules.invalidStartPartialSourceList[i];
              if (line.startsWith(partialSourceLine)) {
                found = true;
              }
              i++;
            }
            if (found) {
              isValid = false;
            } else {

              // TODO can you refactor so this uses a plugin architecture?

              // Some other things to check
              if (!this.isJustCensus(line)) {
                if (!this.invalidFamilyTree(line)) {
                  if (!this.isJustRepository(line)) {
                    if (!this.isJustGedcomCrud(line)) {
                      // TODO add more logic to eliminate sources as valid
                      // TODO is the manager's name a valid source (this is hard)
                      // TODO add logic to check for just the name followed by grave
                      isValid = true;
                    }
                  }
                }
              }
            }     // endif starts with invalid phrase
          }       // endif contains a phrase on invalid partial source list
        }         // endif a findagrave citation
      }           // endif on the list of invalid sources
    }             // endif too short when stripped of whitespace

    // Save line for reporting
    if (isValid) { 
      this.bioResults.sources.validSource.push(mixedCaseLine);
    } else {
      this.bioResults.sources.invalidSource.push(mixedCaseLine);
    }
    return isValid;
  }

  /*
   * Determine if valid standalone source
   * @param line input source string
   * @return true if on the standalone list of invalid sources
   */
  isInvalidStandAloneSource(line) {

// TODO reverse this backward logic to check isValidStandAloneSource

    let isInvalidStandAloneSource = false;
    if (this.sourceRules.invalidSourceList.includes(line)) {
      isInvalidStandAloneSource = true;
    } else {
      if (this.tooOldToRemember && !isInvalidStandAloneSource) {
        if (this.sourceRules.tooOldToRememberSourceList.includes(line)) {
          isInvalidStandAloneSource = true;
        }
      }
      if ((this.isPre1700 || this.treatAsPre1700)
           && !isInvalidStandAloneSource) {
        if (this.sourceRules.invalidSourceListPre1700.includes(line)) {
          isInvalidStandAloneSource = true;
        }
      }
      if (this.bioResults.isPre1500 && !isInvalidStandAloneSource) {
        // TODO add more pre1500 validation
      }
    }
    return isInvalidStandAloneSource;
  }

  /*
   * Determine if found on partial source list
   * @param line input source string
   * @return string if on the partial source list
   */
  onPartialSourceList(line) {

    let foundOnPartialSourceList = false;
    let invalidSourceString = "";
    let partialSourceLine = "";
    let i = 0;
    while (!foundOnPartialSourceList && (i < this.sourceRules.invalidPartialSourceList.length)) {
      partialSourceLine = this.sourceRules.invalidPartialSourceList[i];
      if (line.includes(partialSourceLine)) {
        foundOnPartialSourceList = true;
        invalidSourceString = partialSourceLine;
      }
      i++;
    }
    if (this.tooOldToRemember && !foundOnPartialSourceList) {
      i = 0;
      while (!foundOnPartialSourceList && (i < this.sourceRules.invalidPartialSourceListTooOld.length)) {
        partialSourceLine = this.sourceRules.invalidPartialSourceListTooOld[i];
        if (line.includes(partialSourceLine)) {
          foundOnPartialSourceList = true;
          invalidSourceString = partialSourceLine;
        }
        i++;
      }
    }
    if ((this.isPre1700 || this.treatAsPre1700)
         && !foundOnPartialSourceList) {
      i = 0;
      while (!foundOnPartialSourceList && (i < this.sourceRules.invalidPartialSourceListPre1700.length)) {
        partialSourceLine = this.sourceRules.invalidPartialSourceListPre1700[i];
        if (line.includes(partialSourceLine)) {
          foundOnPartialSourceList = true;
          invalidSourceString = partialSourceLine;
        }
        i++;
      }
    }
    return invalidSourceString;
  }

  /*
   * Does string contain a phrase on the valid partial source list
   * This is a test case for strings that if found mean the profile is sourced
   * (thanks to David S for the test case)
   * @param str string to evaluate
   * @return true if string found, else false
   */
  containsValidPartialSource(str) {
    let found = false;
    let partialSourceLine = "";
    let i = 0;
    while (!found && (i < this.sourceRules.validPartialSourceList.length)) {
      partialSourceLine = this.sourceRules.validPartialSourceList[i];
      if (str.includes(partialSourceLine)) {
        found = true;
      }
      i++;
    }
    return found;
  }

  /* 
   * Validate content in <ref> tags
   * invalidSpanTargetList is used if line contains a span reference
   * @param refStrings array of string found within ref tag
   * @return true if at least one is valid else false
   */
  validateRefStrings(refStrings) {

    let isValid = false;                  // guilty until proven innnocent
    let line = "";
    let i = 0;
    while (i < refStrings.length) {
      line = refStrings[i];
      if (line.length > 0) {

        // Check span target if ref contains a span reference
        let startPos = line.indexOf(Biography.SPAN_REFERENCE_START);
        if (startPos >= 0) {
          startPos = startPos + 3;
          let endPos = line.indexOf("|");
          if (endPos < 0) {
            endPos = line.indexOf(Biography.SPAN_REFERENCE_END);
          }
          if ((endPos > 0) && (startPos < endPos)) {
            let spanId = line.substring(startPos, endPos);
            if (!this.invalidSpanTargetList.includes(spanId)) {
              isValid = true;
            }
          }
        } else {
          if (this.isValidSource(line)) {
            if (!isValid) {          // first one found?
              isValid = true;
            }
          }
        }
      }
      i++;
    }
    return isValid;
  }

  /* 
   * Validate all the strings after the == Sources heading
   * but before Acknowledgements or the end of the biography
   * @return true if at lease one valid else false
   */
  validateReferenceStrings() {
    let isValid = false;

    // start at the first of Sources or <references /> if neither, nothing to do
    // assume it is so messed up nothing to process
    let index = this.sourcesIndex + 1;
    if (index <= 0) {
      index = this.referencesIndex + 1;
    }
    if (index <= 0) {
      index = this.bioLines.length;
    }
    let lastIndex = this.bioLines.length;
    let line = "";
    let nextIndex = index + 1;
    while (index < lastIndex) {
      let mixedCaseLine = this.bioLines[index];
      line = mixedCaseLine.toLowerCase();
      // if line nothing but --- ignore it
      let tmpString = line.replaceAll('-', ' ');
      tmpString = tmpString.trim();
      if (tmpString.length <= 0) {
          line = tmpString;
      }
      nextIndex = index + 1;
      // Skip the <references line and any heading line or empty line
      if ((!line.startsWith(Biography.REFERENCES_TAG)) &&
          (!line.startsWith(Biography.HEADING_START)) &&
          (line.length > 0)) {

        // Now gather all lines from this line until an empty line
        // or a line that starts with * to test as the source
        let combinedLine = mixedCaseLine;
        let foundEndOfSource = false;
        while ((!foundEndOfSource) && (nextIndex < lastIndex)) {
          if (nextIndex < lastIndex) {
            // check next line
            let nextLine = this.bioLines[nextIndex];
            if (nextLine.length === 0) {
              foundEndOfSource = true;
            } else {
              if ((nextLine.startsWith("*")) || (nextLine.startsWith("--")) ||
                  (nextLine.startsWith("#")) ||
                  (nextLine.startsWith(Biography.REFERENCES_TAG)) ||
                  (nextLine.startsWith(Biography.HEADING_START))) {
                foundEndOfSource = true;
              } else {
                combinedLine = combinedLine + " " + nextLine;
                nextIndex++;
              }
            }
          }
        }
        mixedCaseLine = combinedLine;

        // At this point, the line should not contain an inline <ref
        // Unless all the ref are between Sources and references
        if ((line.indexOf("<ref") >= 0) && (index > this.referencesIndex)) {
          this.bioResults.style.bioHasStyleIssues = true;
          this.bioResults.style.bioHasRefAfterReferences = true;
        }
        if ((index < this.referencesIndex) || 
            (this.referencesIndex < 0)) {
          this.bioResults.style.misplacedLineCount++;
        }
        let spanTargetStartPos = mixedCaseLine.indexOf(Biography.SPAN_TARGET_START);
        if (spanTargetStartPos < 0) {
          if (this.isValidSource(mixedCaseLine)) {
            if (!isValid) {
              isValid = true;       // first one found
            }
          }
        } else {
          if (this.isValidSpanTarget(mixedCaseLine)) {
            if (!isValid) {
              isValid = true;       // first one found
            }
          }
        }
      }
      index = nextIndex;
    }
    return isValid;
  }

  /*
   * Validate string that is a span target
   * Side effect: add to invalidSpanTargetList for invalid target
   * @param line line to be evaluated
   * @param startPos starting position in line
   * @return true if valid else false
   */
  isValidSpanTarget(mixedCaseLine) {
    let isValid = false;
    let spanTargetStartPos = mixedCaseLine.indexOf(Biography.SPAN_TARGET_START);
    let beforeSpan = mixedCaseLine.substring(0, spanTargetStartPos - 1);

    // extract target id found here <span id='ID'>
    let pos = mixedCaseLine.indexOf("=");
    pos++; // skip the =
    pos++; // skip the '
    let endPos = mixedCaseLine.indexOf("'", pos);
    let spanId = mixedCaseLine.substring(pos, endPos);

    // Process the line starting after the end of the span target
    // but it might have source or repository before the <span>
    pos = mixedCaseLine.indexOf(Biography.SPAN_TARGET_END);
    if (pos > 0) {
      pos = pos + Biography.SPAN_TARGET_END.length;
    } else {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioHasSpanWithoutEndingSpan = true;
      pos = mixedCaseLine.length;
    }
    if (pos < mixedCaseLine.length) {
      // something after ending span
      mixedCaseLine = beforeSpan + " " + mixedCaseLine.substring(pos).trim();
      isValid = this.isValidSource(mixedCaseLine);
    }
    if (!isValid) {
        this.invalidSpanTargetList.push(spanId);
    }
    return isValid;
  }

  /*
   * Check for a line that is just
   * some collection of numbers and digits then census
   * @param line to check
   * @return true if just a census line else false
   */
  isJustCensus(line) {

    let isCensus = false;
    line = line.replace(/[^a-z ]/g, "");
    line = line.trim();
    if (this.sourceRules.censusStrings.includes(line)) {
      isCensus = true;
    } else {
      // get the census string portion of the line
      let theStr = this.hasCensusString(line);
      if (theStr.length > 0) {
        // lose census, at, on and everything not an alpha char
        line = line.replace(theStr, "");
        line = line.replace(/at/g, "");
        line = line.replace(/on/g, "");
        line = line.replace(/[^a-z]/g, "");
        line = line.trim();
        if (line.length === 0) {
          isCensus = true;
        } else {
          // lose things like ancestry, familysearch by themselves
          if (this.sourceRules.invalidSourceList.includes(line)) {
            isCensus = true;
          }
        }
      }
    }
    if (isCensus) {
      return true;
    } else {
      return false;
    }
  }
  /*
  * Does line contain a census
  * @param line line to test
  * @return census string if line contains census string
  */
  hasCensusString(line) {
    let theStr = "";
    let isCensusString = false;
    let i = 0;
    while ((!isCensusString) && (i < this.sourceRules.censusStrings.length)) {
      if (line.includes(this.sourceRules.censusStrings[i])) {
        isCensusString = true;
        theStr = this.sourceRules.censusStrings[i];
      }
      i++;
    }
    return theStr;
  }

  /*
   * Check for a line that contains both findagrave and created by
   * created by is an invalid partial source string UNLESS part of a findagrave
   * citation
   * @param line to test
   * @return true if line contains both findagrave and created by
   */
  isFindAGraveCitation(line) {
    if (((line.indexOf("findagrave")) >= 0) && 
        ((line.indexOf("created by")) >=0)) {
      return true;
    } else {
      return false;
    }
  }

  /*
   * Check for Ancestry Family Trees without a tree id 
   * or a tree id less than 4 characters, such as 0
   * @param line to test
   * @return true if Ancestry tree seems to have an id
   */
  invalidFamilyTree(line) {
    let isInvalidFamilyTree = false;
    let startPos = line.indexOf("ancestry family tree");
    if (startPos < 0) {
      startPos = line.indexOf("public member tree");
      if (startPos < 0) {
        startPos = line.indexOf("ancestry member family tree");
      }
      if (startPos < 0) {
        startPos = line.indexOf("{{ancestry tree");
      }
    }
    if (startPos >= 0) {
      line = line.substring(startPos);
      let hasId = false;
      let matches = line.match(/(\d+)/g);
      if (matches) {
        for (let i = 0; i < matches.length; i++) {
          if (matches[i].length > 4) {
            hasId = true;
          }
        }
      }
      if (!hasId) {
        isInvalidFamilyTree = true;
      }
    }
    return isInvalidFamilyTree;
  }

  /*
   * Check for just a repository
   * @param line to test
   * @return true if this is just a repository line
   */
  isJustRepository(line) {
    let isRepository = false;
    if (line.includes("repository")) {
      let repositoryStrings = [
        "ancestry",
        "com",
        "name",
        "address",
        "http",
        "www",
        "the church of jesus christ of latter-day saints",
        "note",
        "family history library",
        "n west temple street",
        "salt lake city",
        "utah",
        "usa",
        "360 west 4800 north",
        "provo",
        "ut",
        "city",
        "country", 
        "not given",
        "e-mail",
        "phone number",
        "internet",
        "cont",
        "unknown",
      ];
      for (let i = 0; i < repositoryStrings.length; i++) {
        let str = repositoryStrings[i];
        line = line.replaceAll(str, "");
      }
      line = line.replace(/r-/g, "");
      line = line.replace(/#r/g, "");
      line = line.replace(/[^a-z]/g, "");
      line = line.trim();
      if (line.length > 0) {
        if (line === "repository") {
          isRepository = true;
        }
      }
    }
    return isRepository;
  }

  /*
   * check for GEDCOM crud see Suggestion 853
   * in most cases this is in the Bio not sources, 
   * so you don't see it
   * @param line line to test
   * @return true if line contains GEDCOM crud and nothing else
   */
  isJustGedcomCrud(line) {
    let isGedcomCrud = false;
    let crudStrings = [
      "user id",
      "data changed",
      "lds endowment",
      "lds baptism",
      "record file number",
      "submitter",
      "object",
      "color",
      "upd",
      "ppexclude",
    ];
    if (line.startsWith(":")) {
      line = line.substring(1);
    }
    line = line.trim();
    let i = 0;
    while ((i < crudStrings.length) && (!isGedcomCrud)) {
      if (line.startsWith(crudStrings[i])) {
        isGedcomCrud = true;
      }
      i++;
    }
    return isGedcomCrud;
  }

}

;// CONCATENATED MODULE: ./src/features/bioCheck/bioCheck.js




chrome.storage.sync.get('bioCheck', (result) => {
	if (result.bioCheck) {

    // want to check on start, on draft save, and
    // on a scheduled interval

    // Only do this if on the edit page for a person
    // And ASSUME that if there is a mBirthDate it's a person edit page
    // previous code tried if ($("body.page-Special_EditPerson").length) {
    if (document.getElementById("mBirthDate")) {
      let theSourceRules = new SourceRules();
      checkBio(theSourceRules);


      let saveDraftButton = document.getElementById("wpSaveDraft");
      saveDraftButton.onclick = function(){checkBio(theSourceRules)};

      // and also once a minute
      setInterval(checkAtInterval, 60000, theSourceRules);

    }
  }
});

// Check at an interval
function checkAtInterval(theSourceRules) {
  checkBio(theSourceRules);
}

/*
 * Notes about packaging and differences from the BioCheck app
 *
 * Copied the following files:
 *   biography.js
 *   biographyResults.js
 *   personDate.js
 *   sourceRules.js
 * and changed each to remove the export
 * and change biography to remove the import
 * 
 * then put each of those files into features/biocheck
 * add each to the manifest.json
 * add each to core/options.html with a script type=module
 *
 * When checking a biography there is no check for privacy
 * to assume an undated profile is unsourced and
 * never check for the biography is auto-generated string
 */

function checkBio(theSourceRules) {
  let thePerson = new PersonDate();

  // get the bio text and person dates to check
  let bioString = document.getElementById("wpTextbox1").value;
  let birthDate = document.getElementById("mBirthDate").value;
  let deathDate = document.getElementById("mDeathDate").value;

  thePerson.initWithDates(birthDate, deathDate);
  let biography = new Biography(theSourceRules);
  biography.parse(bioString, thePerson.isPersonPre1500(), thePerson.isPersonPre1700(), thePerson.mustBeOpen(), thePerson.isUndated(), false);
  biography.validate();

  // now report from biography.bioResults
  // use HTML escape codes for special characters
  let ref = "&#60ref&#62";
  let refEnd = "&#60&#47ref&#62";
  let referencesTag = "&#60references &#47&#62";

  let profileReportLines = ([]);
  let profileStatus = "Profile appears to have sources.";
  if (biography.bioResults.stats.bioIsMarkedUnsourced) {
    profileStatus = "Profile is marked unsourced.";
  } else {
    if (!biography.bioResults.sources.sourcesFound) {
      profileStatus = "Profile may be unsourced.";
    }
  }
  profileReportLines.push(profileStatus);

  if (biography.bioResults.stats.bioIsEmpty) {
    profileStatus = "Profile is empty";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.misplacedLineCount > 0) {
    profileStatus = "Profile has " + biography.bioResults.style.misplacedLineCount;
    if (biography.bioResults.style.misplacedLineCount === 1) {
      profileStatus += " line";
    } else {
      profileStatus += " lines";
    }
    profileStatus += " between Sources and " + referencesTag;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.hasEndlessComment) {
    profileStatus = "Profile has comment with no end";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasRefWithoutEnd) {
    profileStatus = "Profile has inline " + ref + " with no ending " + refEnd;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasSpanWithoutEndingSpan) {
    profileStatus = "Profile has span with no ending span";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioIsMissingBiographyHeading) {
    profileStatus = "Profile is missing Biography heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasMultipleBioHeadings) {
    profileStatus = "Profile has more than one Biography heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHeadingWithNoLinesFollowing) {
    profileStatus = "Profile has empty  Biography section";
    profileReportLines.push(profileStatus);
  }
  let sourcesHeading = ([]);
  if (biography.bioResults.style.bioIsMissingSourcesHeading) {
    profileStatus = "Profile is missing Sources heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasMultipleSourceHeadings) {
    profileStatus = "Profile has more than one Sources heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.sourcesHeadingHasExtraEqual) {
    profileStatus = "Profile Sources heading has extra =";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioIsMissingReferencesTag) {
    profileStatus = "Profile is missing " + referencesTag;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasMultipleReferencesTags) {
    profileStatus = "Profile has more than one " + referencesTag;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasRefAfterReferences) {
    profileStatus = "Profile has inline " + ref + " tag after " +
        referencesTag;
    profileReportLines.push(profileStatus);
  }
  let acknowledgements = ([]);
  if (biography.bioResults.style.acknowledgementsHeadingHasExtraEqual) {
    profileStatus = "Profile Acknowledgements has extra =";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasAcknowledgementsBeforeSources) {
    profileStatus = "Profile has Acknowledgements before Sources heading";
    profileReportLines.push(profileStatus);
  }

  //console.log(profileReportLines);

  // add a list to the page
  reportResults(profileReportLines);
  
}

function reportResults(reportLines) {

  // If you have been here before get and remove the old list of results
  let previousResults = document.getElementById('bioCheckResultsList');
  let bioCheckResultsContainer = document.getElementById('bioCheckResultsContainer');
  if (!bioCheckResultsContainer) {
    bioCheckResultsContainer = document.createElement('div');
    bioCheckResultsContainer.setAttribute('id', 'biocheckContainer');

    let bioCheckTitle = document.createElement('b');
    bioCheckTitle.innerText = "BioCheck results";
    bioCheckResultsContainer.appendChild(bioCheckTitle);
  }
    
  // need a new set of results
  let bioResultsList = document.createElement('ul');
  bioResultsList.setAttribute('id', 'bioCheckResultsList');

  let numLines = reportLines.length;
  for (let i = 0; i < numLines; ++i) {
    let bioResultItem = document.createElement('li');
    bioResultItem.innerHTML = reportLines[i];
    bioResultsList.appendChild(bioResultItem);
  }
  // Add or replace the results
  if (previousResults) {
    previousResults.replaceWith(bioResultsList);
  } else {
    bioCheckResultsContainer.appendChild(bioResultsList);

    let lastContainer = document.getElementById('suggestionContainer');
    if (!lastContainer) {
      lastContainer = document.getElementById('validationContainer');
    }
    lastContainer.after(bioCheckResultsContainer);
  }
}


;// CONCATENATED MODULE: ./src/core/editToolbarCategoryOptions.js


/* harmony default export */ const editToolbarCategoryOptions = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: contentEdit_wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: contentEdit_wtPlus, params: { action: "AddTemplate" } },
			{
				title: "Category templates", items: [
					{ featureid: "wtplus", title: "Aka", call: contentEdit_wtPlus, params: { template: "Aka" } },
					{ featureid: "wtplus", title: "Top Level", call: contentEdit_wtPlus, params: { template: "Top Level" } },
					{ featureid: "wtplus", title: "Geographic Location", call: contentEdit_wtPlus, params: { template: "Geographic Location" } }
				]
			},
			{ "featureid": "wtplus", title: "Format Template Params", call: contentEdit_wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "CIB", items: [
			{ featureid: "wtplus", title: "Cemetery", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Cemetery" } },
			{ featureid: "wtplus", title: "Location", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Location" } },
			{ featureid: "wtplus", title: "Add any CIB", call: contentEdit_wtPlus, params: { action: "AddTemplate", data: "CategoryInfoBox" } },
			{
				title: "Cemeteries", items: [
					{ featureid: "wtplus", title: "Cemetery", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Cemetery" } },
					{ featureid: "wtplus", title: "Cemetery Group", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox CemeteryGroup" } }
				]
			},
			{
				title: "Religion", items: [
					{ featureid: "wtplus", title: "Religious Institution Group", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox ReligiousInstitutionGroup" } }
				]
			},
			{
				title: "Maintenance", items: [
					{ featureid: "wtplus", title: "Maintenance", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Maintenance" } },
					{ featureid: "wtplus", title: "Needs", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Needs" } },
					{ featureid: "wtplus", title: "Needs GEDCOM Cleanup", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox NeedsGEDCOMCleanup" } },
					{ featureid: "wtplus", title: "Unconnected", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Unconnected" } },
					{ featureid: "wtplus", title: "Unsourced", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Unsourced" } }
				]
			},
			{
				title: "Others", items: [
					{ featureid: "wtplus", title: "Location", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Location" } },
					{ featureid: "wtplus", title: "Migration", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox Migration" } },
					{ featureid: "wtplus", title: "One Name Study", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox OneNameStudy" } },
					{ featureid: "wtplus", title: "One Place Study", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox OnePlaceStudy" } },
					{ featureid: "wtplus", title: "CategoryInfoBox", call: contentEdit_wtPlus, params: { template: "CategoryInfoBox" } }
				]
			}
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: contentEdit_wtPlus, params: { action: "AutoUpdate" } },
		]
	},
	{
		button: "EditBOT", items: [
			{ featureid: "wtplus", title: "Rename Category", call: contentEdit_wtPlus, params: { template: "Rename Category" } },
			{ featureid: "wtplus", title: "Merge Category", call: contentEdit_wtPlus, params: { template: "Merge Category" } },
			{ featureid: "wtplus", title: "Delete Category", call: contentEdit_wtPlus, params: { template: "Delete Category" } },
			{ featureid: "wtplus", title: "Confirm for EditBOT", call: contentEdit_wtPlus, params: { action: "EditBOTConfirm" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Category_pages" } }
		]
	},
]);

;// CONCATENATED MODULE: ./src/core/editToolbarGenericOptions.js


/* harmony default export */ const editToolbarGenericOptions = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: contentEdit_wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: contentEdit_wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Format Template Params", call: contentEdit_wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: contentEdit_wtPlus, params: { action: "AutoUpdate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Other_pages" } }
		]
	}
]);

;// CONCATENATED MODULE: ./src/core/editToolbarProfileOptions.js


/* harmony default export */ const editToolbarProfileOptions = ([
	{
		button: "Sources",
		items: [
			{ featureid: "wtplus", title: "Paste sources", call: contentEdit_wtPlus, params: { action: "PasteSource" } }
		]
	}, {
		button: "Templates",
		items: [
			{ featureid: "wtplus", title: "Edit Template", call: contentEdit_wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: contentEdit_wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Add Project Box", call: contentEdit_wtPlus, params: { action: "AddTemplate", data: "Project Box" } },
			{ featureid: "wtplus", title: "Add Sticker", call: contentEdit_wtPlus, params: { action: "AddTemplate", data: "Sticker" } },
			{ featureid: "wtplus", title: "Add Research Note Box", call: contentEdit_wtPlus, params: { action: "AddTemplate", data: "Profile Box" } },
			{ featureid: "wtplus", title: "Add External links", call: contentEdit_wtPlus, params: { action: "AddTemplate", data: "External Link" } },
			{ featureid: "wtplus", title: "Format Template Params", call: contentEdit_wtPlus, params: { action: "AutoFormat" } }
		]
	}, {
		button: "Biography",
		items: [
			{ featureid: "wtplus", title: "Automated corrections", call: contentEdit_wtPlus, params: { action: "AutoUpdate" } }
		]
	}, {
		button: "Misc",
		items: [
			{
				title: "WikiTree Apps",
				items: [
					{ featureid: "wtplus", title: "DNA Confirmation", hint: "DNA Confirmation by Greg Clarke", call: editToolbarApp, params: { app: "clarke11007/DNAconf.php" } },
					{ featureid: "wtplus", title: "Ancestry Citation", hint: "Ancestry Citation by Greg Clarke", call: editToolbarApp, params: { app: "clarke11007/ancite.php" } },
					{ featureid: "wtplus", title: "Drouin Citer", hint: "Drouin Citer by Greg Clarke", call: editToolbarApp, params: { app: "clarke11007/drouinCite.php" } },
					{ featureid: "wtplus", title: "Surnames Generator", hint: "Surnames Generator by Greg Clarke", call: editToolbarApp, params: { app: "clarke11007/surnames.php" } },
					{ featureid: "wtplus", title: "Riksarkivet SVAR sources", hint: "Riksarkivet SVAR sources by Maria Lundholm", call: editToolbarApp, params: { app: "lundholm24/ref-making/ra-ref.php" } },
					{ featureid: "wtplus", title: "Arkiv Digital sources", hint: "Arkiv Digital sources by Maria Lundholm", call: editToolbarApp, params: { app: "lundholm24/ref-making/ad-ref.php" } },
					{ featureid: "wtplus", title: "Sveriges Dödbok sources", hint: "Sveriges Dödbok sources by Maria Lundholm", call: editToolbarApp, params: { app: "lundholm24/ref-making/sdb-ref.php" } },
					{ featureid: "wtplus", title: "Biography Generator", hint: "Biography Generator (for Open pr.) by Greg Shipley", call: editToolbarApp, params: { app: "shipley1223/Bio.html" } },
					{
						title: "Other Apps",
						items: [
							{ featureid: "wtplus", title: "Bio Check", hint: "Bio Check by Kay Knight", call: editToolbarApp, params: { app: "sands1865/biocheck/" } },
							{ featureid: "wtplus", title: "Fan Chart", hint: "Fan Chart by Greg Clarke", call: editToolbarApp, params: { app: "clarke11007/fan.php" } }
						]
					}
				]
			},
			{ featureid: "wtplus", title: "Help", call: editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Profile_pages" } }
		]
	}
]);

;// CONCATENATED MODULE: ./src/core/editToolbarTemplateOptions.js


/* harmony default export */ const editToolbarTemplateOptions = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Format Parameters", call: contentEdit_wtPlus, params: { action: "AutoFormat" } },
			{ featureid: "wtplus", title: "Edit Template", call: contentEdit_wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add TemplateParam", call: contentEdit_wtPlus, params: { template: "TemplateParam" } },
			{ featureid: "wtplus", title: "Add Documentation", call: contentEdit_wtPlus, params: { template: "Documentation" } },
			{
				title: "Add Base Templates", items: [
					{ featureid: "wtplus", title: "Project Box", call: contentEdit_wtPlus, params: { template: "Project Box" } },
					{ featureid: "wtplus", title: "Sticker", call: contentEdit_wtPlus, params: { template: "Sticker" } },
					{ featureid: "wtplus", title: "Research Note Box", call: contentEdit_wtPlus, params: { template: "Research Note Box" } }
				]
			},
			{
				title: "Add Other Templates", items: [
					{ featureid: "wtplus", title: "Project Box Instructions", call: contentEdit_wtPlus, params: { template: "Project Box Instructions" } }
				]
			},
			{ featureid: "wtplus", title: "Add any template", call: contentEdit_wtPlus, params: { action: "AddTemplate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Template_pages" } }
		]
	}
]);

;// CONCATENATED MODULE: ./src/core/editToolbarSpaceOptions.js


/* harmony default export */ const editToolbarSpaceOptions = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: contentEdit_wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: contentEdit_wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Format Template Params", call: contentEdit_wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: contentEdit_wtPlus, params: { action: "AutoUpdate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Other_pages" } }
		]
	}
]);

// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css
var editToolbar = __webpack_require__(884);
;// CONCATENATED MODULE: ./src/core/editToolbar.css

      
      
      
      
      
      
      
      
      

var editToolbar_options = {};

editToolbar_options.styleTagTransform = (styleTagTransform_default());
editToolbar_options.setAttributes = (setAttributesWithoutAttributes_default());

      editToolbar_options.insert = insertBySelector_default().bind(null, "head");
    
editToolbar_options.domAPI = (styleDomAPI_default());
editToolbar_options.insertStyleElement = (insertStyleElement_default());

var editToolbar_update = injectStylesIntoStyleTag_default()(editToolbar/* default */.Z, editToolbar_options);




       /* harmony default export */ const core_editToolbar = (editToolbar/* default */.Z && editToolbar/* default.locals */.Z.locals ? editToolbar/* default.locals */.Z.locals : undefined);

;// CONCATENATED MODULE: ./src/core/editToolbar.js







let editToolbarOptions = []

/* Common events for links */
function editToolbarWiki(params) {
	window.open('https://www.wikitree.com/wiki/' + params.wiki, '_blank')
}

function editToolbarApp(params) {
	let w = document.querySelector('h1 > .copyWidget') 
	let wikitreeID = w.getAttribute('data-copy-text');
	window.open('https://apps.wikitree.com/apps/' + params.app + '?wikitreeid=' + wikitreeID, '_blank')
}

/* Finds the clicked item in editToolbarOptions */
function editToolbarFindItem(items, name) {
	if (items && items.length) {
		for (var item of items) {
			if (item.button) {
				let result = editToolbarFindItem(item.items, name)
				if (result) { return result }
			} else if (name.toUpperCase() === item.title.toUpperCase()) {
				return item
			} else {
				let result = editToolbarFindItem(item.items, name)
				if (result) { return result }
			}
		}
	}
}

/* main event handler */
function editToolbarEvent(event) {
	let element = event.srcElement
	const id = element.dataset.id
	event.preventDefault();
	let item = editToolbarFindItem(editToolbarOptions, id);
	if (item) {
		return item.call(item.params || {})
	} else {
		alert("Unknown event " + id)
	}
}

/* creates html of the drop down menu */
function editToolbarCreateHtml(items, featureEnabled, level) {
	let result = '';
	if (items && items.length) {
		for (var item of items) {
			if ((!item.featureid) || featureEnabled[item.featureid]) {
				let s = editToolbarCreateHtml(item.items, featureEnabled, level + 1)
				if (s || item.call) {
					if (item.button) {
						result +=
							'<div id="editToolbarDiv">' +
							'<p id="editToolbarButton">' + item.button + '</p>' +
							// '<img src="/photo.php/8/89/WikiTree_Images-22.png" height="22" id="editToolbarButton" />' + 
							s +
							'</div>';
					} else {
						result += '<li><a '
						result += (item.hint ? 'title= "' + item.hint + '"' : "");
						result += 'href="javascript:void(0);" class="editToolbarClick" data-id="' + item.title + '"';
						result += '>' + item.title + (item.items ? " &gt;&gt;" : "") + "</a>";
						result += s;
						result += '</li>';
					}
				}
			}
		}
		if ((level >= 0) && (result))
			result = '<ul class="editToolbarMenu' + level + '">' + result + '</ul>';
	}
	return result;
}

/* creates menu next to the toolbar  */
function editToolbarCreate(options) {
	editToolbarOptions = options
	chrome.storage.sync.get(null, (featureEnabled) => {
		var menuHTML = editToolbarCreateHtml(editToolbarOptions, featureEnabled, -1);
		document.getElementById("toolbar").insertAdjacentHTML('afterend', '<div id="editToolbarExt">' + menuHTML + '</div>')
		document.querySelectorAll('a.editToolbarClick').forEach(i => i.addEventListener('click', event => editToolbarEvent(event)))
	})
}

if (window.location.href.match(/\/index.php\?title=Special:EditPerson&.*/g)) {
	editToolbarCreate(editToolbarProfileOptions);

} else if (window.location.href.match(/\/index.php\?title=Category:.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=Category:.*&action=submit.*/g)) {
	editToolbarCreate(editToolbarCategoryOptions);

} else if (window.location.href.match(/\/index.php\?title=Template:.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=Template:.*&action=submit.*/g)) {
	editToolbarCreate(editToolbarTemplateOptions);

} else if (window.location.href.match(/\/index.php\?title=Space:.*&action=edit.*/g) ||
		   window.location.href.match(/\/index.php\?title=Space:.*&action=submit.*/g)) {
	editToolbarCreate(editToolbarSpaceOptions);

} else if (window.location.href.match(/\/index.php\?title=.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=.*&action=submit.*/g)) {
	editToolbarCreate(editToolbarGenericOptions);
}

;// CONCATENATED MODULE: ./src/content.js


















createTopMenu();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/runtimeId */
/******/ 	(() => {
/******/ 		__webpack_require__.j = 998;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			998: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwikitree_browser_extension"] = self["webpackChunkwikitree_browser_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [736], () => (__webpack_require__(89)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;