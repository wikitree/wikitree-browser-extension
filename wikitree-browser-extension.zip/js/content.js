/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css":
/*!************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css ***!
  \************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\n#editToolbarExt {\r\n\tdisplay: inline-block;\r\n}\r\n\r\n#editToolbarDiv {\r\n\tposition: relative;\r\n\tfloat: left;\r\n\tz-index: 10;\r\n}\r\n\r\n#editToolbarDiv:hover .editToolbarMenu0 {\r\n\tdisplay: block;\r\n}\r\n\r\n#editToolbarButton {\r\n\tcursor: pointer;\r\n\tborder: 1px solid #aaa;\r\n\tborder-radius: 3px;\r\n\tpadding: 2px;\r\n\tmargin: 1px;\r\n\tbackground-color: #eee;\r\n}\r\n\r\n.editToolbarMenu2 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu2>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu2>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* second level of menus */\r\n.editToolbarMenu1 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu1>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu1>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* first level of menus */\r\n.editToolbarMenu0 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tleft: 0px;\r\n\tlist-style: none;\r\n\tpadding: 1px;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n\tz-index: 10;\r\n}\r\n\r\n.editToolbarMenu0>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmin-width: 160px;\r\n\tmargin-bottom: 1px;\r\n\tfloat: left;\r\n\tz-index: 11;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n\ttext-align: left;\r\n\ttext-decoration: none;\r\n\tcursor: pointer;\r\n}\r\n\r\n.editToolbarMenu0>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* On hover, display the next level's menu */\r\n.editToolbarMenu0 li:hover>ul {\r\n\tdisplay: inline;\r\n}\r\n\r\n/* Menu Link Styles - Apply to all links inside the multi-level menu */\r\n.editToolbarMenu0 a {\r\n\tfont: normal 11px verdana, arial, sans-serif;\r\n\tcolor: #000000;\r\n\ttext-decoration: none !important;\r\n\tpadding: 0px 5px;\r\n\r\n\t/* Make the link cover the entire list item-container */\r\n\tdisplay: block;\r\n\tline-height: 24px;\r\n}\r\n\r\n.editToolbarMenu0 a:link {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:hover {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:visited {\r\n\tcolor: #000000 !important;\r\n}", "",{"version":3,"sources":["webpack://./src/core/editToolbar.css"],"names":[],"mappings":";AACA;CACC,qBAAqB;AACtB;;AAEA;CACC,kBAAkB;CAClB,WAAW;CACX,WAAW;AACZ;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,eAAe;CACf,sBAAsB;CACtB,kBAAkB;CAClB,YAAY;CACZ,WAAW;CACX,sBAAsB;AACvB;;AAEA;CACC,aAAa;CACb,kBAAkB;CAClB,SAAS;CACT,WAAW;CACX,YAAY;CACZ,gBAAgB;CAChB,UAAU;CACV,SAAS;CACT,sBAAsB;AACvB;;AAEA;CACC,kBAAkB;CAClB,YAAY;CACZ,kBAAkB;CAClB,sBAAsB;CACtB,sBAAsB;AACvB;;AAEA;CACC,mBAAmB;AACpB;;AAEA,0BAA0B;AAC1B;CACC,aAAa;CACb,kBAAkB;CAClB,SAAS;CACT,WAAW;CACX,YAAY;CACZ,gBAAgB;CAChB,UAAU;CACV,SAAS;CACT,sBAAsB;AACvB;;AAEA;CACC,kBAAkB;CAClB,YAAY;CACZ,kBAAkB;CAClB,sBAAsB;CACtB,sBAAsB;AACvB;;AAEA;CACC,mBAAmB;AACpB;;AAEA,yBAAyB;AACzB;CACC,aAAa;CACb,kBAAkB;CAClB,SAAS;CACT,gBAAgB;CAChB,YAAY;CACZ,SAAS;CACT,sBAAsB;CACtB,WAAW;AACZ;;AAEA;CACC,kBAAkB;CAClB,YAAY;CACZ,gBAAgB;CAChB,kBAAkB;CAClB,WAAW;CACX,WAAW;CACX,sBAAsB;CACtB,sBAAsB;CACtB,gBAAgB;CAChB,qBAAqB;CACrB,eAAe;AAChB;;AAEA;CACC,mBAAmB;AACpB;;AAEA,4CAA4C;AAC5C;CACC,eAAe;AAChB;;AAEA,sEAAsE;AACtE;CACC,4CAA4C;CAC5C,cAAc;CACd,gCAAgC;CAChC,gBAAgB;;CAEhB,uDAAuD;CACvD,cAAc;CACd,iBAAiB;AAClB;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,yBAAyB;AAC1B","sourcesContent":["\r\n#editToolbarExt {\r\n\tdisplay: inline-block;\r\n}\r\n\r\n#editToolbarDiv {\r\n\tposition: relative;\r\n\tfloat: left;\r\n\tz-index: 10;\r\n}\r\n\r\n#editToolbarDiv:hover .editToolbarMenu0 {\r\n\tdisplay: block;\r\n}\r\n\r\n#editToolbarButton {\r\n\tcursor: pointer;\r\n\tborder: 1px solid #aaa;\r\n\tborder-radius: 3px;\r\n\tpadding: 2px;\r\n\tmargin: 1px;\r\n\tbackground-color: #eee;\r\n}\r\n\r\n.editToolbarMenu2 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu2>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu2>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* second level of menus */\r\n.editToolbarMenu1 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu1>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu1>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* first level of menus */\r\n.editToolbarMenu0 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tleft: 0px;\r\n\tlist-style: none;\r\n\tpadding: 1px;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n\tz-index: 10;\r\n}\r\n\r\n.editToolbarMenu0>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmin-width: 160px;\r\n\tmargin-bottom: 1px;\r\n\tfloat: left;\r\n\tz-index: 11;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n\ttext-align: left;\r\n\ttext-decoration: none;\r\n\tcursor: pointer;\r\n}\r\n\r\n.editToolbarMenu0>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* On hover, display the next level's menu */\r\n.editToolbarMenu0 li:hover>ul {\r\n\tdisplay: inline;\r\n}\r\n\r\n/* Menu Link Styles - Apply to all links inside the multi-level menu */\r\n.editToolbarMenu0 a {\r\n\tfont: normal 11px verdana, arial, sans-serif;\r\n\tcolor: #000000;\r\n\ttext-decoration: none !important;\r\n\tpadding: 0px 5px;\r\n\r\n\t/* Make the link cover the entire list item-container */\r\n\tdisplay: block;\r\n\tline-height: 24px;\r\n}\r\n\r\n.editToolbarMenu0 a:link {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:hover {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:visited {\r\n\tcolor: #000000 !important;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css":
/*!**********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css ***!
  \**********************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "menu#appsSubMenu {\r\n\tdisplay:none;\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tbackground-color:white !important;\t\r\n\toverflow:visible;\r\n}\r\nmenu#appsSubMenu a{\r\n\tmargin-left:-19.1em;\r\n\tbackground-color:white !important;\r\n\tborder:1px solid #ccc;\r\n\twidth:18em;\r\n\tdisplay:block;\r\n\tpadding:5px;\r\n\tfloat:none;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu a{\r\n\tmargin-left:-22.8em;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu {\r\n\tbackground-color:transparent !important;\r\n}\r\nmenu#appsSubMenu a:hover{\r\n\tbackground-color:#ffe270 !important;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/appsMenu/appsMenu.css"],"names":[],"mappings":"AAAA;CACC,YAAY;CACZ,iBAAiB;CACjB,KAAK;CACL,iCAAiC;CACjC,gBAAgB;AACjB;AACA;CACC,mBAAmB;CACnB,iCAAiC;CACjC,qBAAqB;CACrB,UAAU;CACV,aAAa;CACb,WAAW;CACX,UAAU;AACX;AACA;CACC,mBAAmB;AACpB;AACA;CACC,uCAAuC;AACxC;AACA;CACC,mCAAmC;AACpC","sourcesContent":["menu#appsSubMenu {\r\n\tdisplay:none;\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tbackground-color:white !important;\t\r\n\toverflow:visible;\r\n}\r\nmenu#appsSubMenu a{\r\n\tmargin-left:-19.1em;\r\n\tbackground-color:white !important;\r\n\tborder:1px solid #ccc;\r\n\twidth:18em;\r\n\tdisplay:block;\r\n\tpadding:5px;\r\n\tfloat:none;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu a{\r\n\tmargin-left:-22.8em;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu {\r\n\tbackground-color:transparent !important;\r\n}\r\nmenu#appsSubMenu a:hover{\r\n\tbackground-color:#ffe270 !important;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css ***!
  \**********************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "button.wikitreeturbo {\r\n    padding: 2px 10px;\r\n    font-family: monospace;\r\n    background-color: #eee;\r\n    color: #333;\r\n\tposition:absolute !important;\r\n\tmargin-left:-2.85em;\r\n\tmargin-top: -0.25em;\r\n}\r\nbutton.wikitreeturbo, button.wikitreeturbo:active {\r\n\ttop:auto !important;\r\n}\r\n#descendantsContainer li.collapse {\r\n\tposition:relative;\r\n}", "",{"version":3,"sources":["webpack://./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css"],"names":[],"mappings":"AAAA;IACI,iBAAiB;IACjB,sBAAsB;IACtB,sBAAsB;IACtB,WAAW;CACd,4BAA4B;CAC5B,mBAAmB;CACnB,mBAAmB;AACpB;AACA;CACC,mBAAmB;AACpB;AACA;CACC,iBAAiB;AAClB","sourcesContent":["button.wikitreeturbo {\r\n    padding: 2px 10px;\r\n    font-family: monospace;\r\n    background-color: #eee;\r\n    color: #333;\r\n\tposition:absolute !important;\r\n\tmargin-left:-2.85em;\r\n\tmargin-top: -0.25em;\r\n}\r\nbutton.wikitreeturbo, button.wikitreeturbo:active {\r\n\ttop:auto !important;\r\n}\r\n#descendantsContainer li.collapse {\r\n\tposition:relative;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css":
/*!**********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css ***!
  \**********************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "body.darkMode *,\r\nbody.darkMode html body,\r\nbody.darkMode .wrapper,\r\nbody.darkMode a,\r\nbody.darkMode a:link,\r\nbody.darkMode a:visited,\r\nbody.darkMode .SMALL,\r\nbody.darkMode .small,\r\nbody.darkMode .pureCssMenum,\r\nbody.darkMode .home,\r\nbody.darkMode .person,\r\nbody.darkMode .add,\r\nbody.darkMode .find,\r\nbody.darkMode .help,\r\nbody.darkMode strong,\r\nbody.darkMode a.viewsi,\r\nbody.darkMode ul.views a,\r\nbody.darkMode ul.pure-css-menu,\r\nbody.darkMode a:link.activeProfile,\r\nbody.darkMode a:hover.activeProfile,\r\nbody.darkMode a:visited.activeProfile a:active.activeProfile,\r\nbody.darkMode iframe.cke_wysiwyg_frame,\r\nbody.darkMode #cke_61_contents,\r\nbody.darkMode body.blackLinks strong,\r\nbody.darkMode menu#appsSubMenu a,\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode {\r\n  font-weight: 400;\r\n  background-color: #36393f !important;\r\n  color: #dcddde !important;\r\n}\r\nbody.darkMode .button,\r\nbody.darkMode div.pad form button,\r\nbody.darkMode input.button.green.search {\r\n  padding: 12px 12px !important;\r\n}\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode span#showHideDescendants {\r\n  padding: 6px !important;\r\n}\r\nbody.darkMode .qa-vote-buttons input {\r\n  padding: 0 !important;\r\n}\r\nbody.darkMode .large,\r\nbody.darkMode ul,\r\nbody.darkMode li {\r\n  background: none !important;\r\n}\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode div.stripes,\r\nbody.darkMode div.getstarted {\r\n  background-image: none !important;\r\n}\r\nbody.darkMode menu#appsSubMenu a:hover {\r\n  background: navy !important;\r\n}\r\nbody.darkMode ul.profile-tabs li,\r\nbody.darkMode {\r\n  font-weight: bold;\r\n  border: 1px solid white;\r\n}\r\nbody.darkMode ul.pureCssMenu ul li a:hover {\r\n  background-color: navy !important;\r\n}\r\nbody.darkMode .yourConnection,\r\nbody.darkMode #yourConnection {\r\n  background: white !important;\r\n}\r\nbody.darkMode #yourConnection {\r\n  margin-right: 4px;\r\n}\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode button,\r\nbody.darkMode input[type=\"button\"],\r\nbody.darkMode a.button,\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode span#showHideDescendants {\r\n  border: 1px solid white !important;\r\n}\r\nbody.darkMode button.copyWidget,\r\nbody.darkMode div.comment-actions button.button,\r\nbody.darkMode span.commentContainerToggle button,\r\nbody.darkMode div.qa-vote-buttons input,\r\nbody.darkMode input.qa-favorite-button,\r\nbody.darkMode #wtIDgo_go,\r\nbody.darkMode input.qa-form-light-button-reshow,\r\nbody.darkMode input.qa-form-light-button-hide,\r\nbody.darkMode input.qa-form-light-button-edit,\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  background: url(\"https://www.wikitree.com/images/icons/search-submit-icon.png\")\r\n    white !important;\r\n  font-size: 0;\r\n  top: -5px !important;\r\n}\r\nbody.darkMode input.qa-a-select-button {\r\n  background-image: url(\"https://www.wikitree.com/g2g/qa-theme/WikiTree/select-star.png\")\r\n    no-repeat !important;\r\n  border: 0 !important;\r\n  background-color: white !important;\r\n}\r\nbody.darkMode input.qa-form-light-button.qa-form-light-button-flag,\r\nbody.darkMode div.qa-vote-buttons qa-vote-buttons-net input {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode #header,\r\nbody.darkMode #footer {\r\n  background: #36393f;\r\n}\r\nbody.darkMode div.copyWidgetContainer,\r\nbody.darkMode div.copyWidgetContainerInner,\r\nbody.darkMode div.copyWidgetContainerInner button {\r\n  background: none !important;\r\n}\r\nbody.darkMode li.GREEN-ARROW {\r\n  background-blend-mode: color;\r\n}\r\nbody.darkMode div.qa-q-item-title a:link .checkmark,\r\nbody.darkMode span.qa-q-item-meta a.qa-q-item-what:link .checkmark {\r\n  color: #36393f !important;\r\n}\r\nbody.darkMode div.qa-nav-main a:hover,\r\nbody.darkMode div.qa-footer a:hover,\r\nbody.darkMode div.qa-nav-main a:visited:hover,\r\nbody.darkMode div.qa-footer a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:hover {\r\n  color: #36393f !important;\r\n  background: #dcddde !important;\r\n}\r\nbody.darkMode a[href*=\"wiki/Privacy\"] img,\r\nbody.darkMode img[src*=\"images/icons/privacy\"] {\r\n  background-color: #9196a1 !important;\r\n  border-radius: 50%;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/darkMode/darkMode.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;;;;;;;;;;;;;EA2BE,gBAAgB;EAChB,oCAAoC;EACpC,yBAAyB;AAC3B;AACA;;;EAGE,6BAA6B;AAC/B;AACA;;;EAGE,uBAAuB;AACzB;AACA;EACE,qBAAqB;AACvB;AACA;;;EAGE,2BAA2B;AAC7B;AACA;;;EAGE,iCAAiC;AACnC;AACA;EACE,2BAA2B;AAC7B;AACA;;EAEE,iBAAiB;EACjB,uBAAuB;AACzB;AACA;EACE,iCAAiC;AACnC;AACA;;EAEE,4BAA4B;AAC9B;AACA;EACE,iBAAiB;AACnB;AACA;;;;;;EAME,kCAAkC;AACpC;AACA;;;;;;;;;;EAUE,oBAAoB;AACtB;AACA;EACE;oBACkB;EAClB,YAAY;EACZ,oBAAoB;AACtB;AACA;EACE;wBACsB;EACtB,oBAAoB;EACpB,kCAAkC;AACpC;AACA;;EAEE,oBAAoB;AACtB;AACA;;EAEE,mBAAmB;AACrB;AACA;;;EAGE,2BAA2B;AAC7B;AACA;EACE,4BAA4B;AAC9B;AACA;;EAEE,yBAAyB;AAC3B;AACA;;;;;;EAME,yBAAyB;EACzB,8BAA8B;AAChC;AACA;;EAEE,oCAAoC;EACpC,kBAAkB;AACpB","sourcesContent":["body.darkMode *,\r\nbody.darkMode html body,\r\nbody.darkMode .wrapper,\r\nbody.darkMode a,\r\nbody.darkMode a:link,\r\nbody.darkMode a:visited,\r\nbody.darkMode .SMALL,\r\nbody.darkMode .small,\r\nbody.darkMode .pureCssMenum,\r\nbody.darkMode .home,\r\nbody.darkMode .person,\r\nbody.darkMode .add,\r\nbody.darkMode .find,\r\nbody.darkMode .help,\r\nbody.darkMode strong,\r\nbody.darkMode a.viewsi,\r\nbody.darkMode ul.views a,\r\nbody.darkMode ul.pure-css-menu,\r\nbody.darkMode a:link.activeProfile,\r\nbody.darkMode a:hover.activeProfile,\r\nbody.darkMode a:visited.activeProfile a:active.activeProfile,\r\nbody.darkMode iframe.cke_wysiwyg_frame,\r\nbody.darkMode #cke_61_contents,\r\nbody.darkMode body.blackLinks strong,\r\nbody.darkMode menu#appsSubMenu a,\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode {\r\n  font-weight: 400;\r\n  background-color: #36393f !important;\r\n  color: #dcddde !important;\r\n}\r\nbody.darkMode .button,\r\nbody.darkMode div.pad form button,\r\nbody.darkMode input.button.green.search {\r\n  padding: 12px 12px !important;\r\n}\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode span#showHideDescendants {\r\n  padding: 6px !important;\r\n}\r\nbody.darkMode .qa-vote-buttons input {\r\n  padding: 0 !important;\r\n}\r\nbody.darkMode .large,\r\nbody.darkMode ul,\r\nbody.darkMode li {\r\n  background: none !important;\r\n}\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode div.stripes,\r\nbody.darkMode div.getstarted {\r\n  background-image: none !important;\r\n}\r\nbody.darkMode menu#appsSubMenu a:hover {\r\n  background: navy !important;\r\n}\r\nbody.darkMode ul.profile-tabs li,\r\nbody.darkMode {\r\n  font-weight: bold;\r\n  border: 1px solid white;\r\n}\r\nbody.darkMode ul.pureCssMenu ul li a:hover {\r\n  background-color: navy !important;\r\n}\r\nbody.darkMode .yourConnection,\r\nbody.darkMode #yourConnection {\r\n  background: white !important;\r\n}\r\nbody.darkMode #yourConnection {\r\n  margin-right: 4px;\r\n}\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode button,\r\nbody.darkMode input[type=\"button\"],\r\nbody.darkMode a.button,\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode span#showHideDescendants {\r\n  border: 1px solid white !important;\r\n}\r\nbody.darkMode button.copyWidget,\r\nbody.darkMode div.comment-actions button.button,\r\nbody.darkMode span.commentContainerToggle button,\r\nbody.darkMode div.qa-vote-buttons input,\r\nbody.darkMode input.qa-favorite-button,\r\nbody.darkMode #wtIDgo_go,\r\nbody.darkMode input.qa-form-light-button-reshow,\r\nbody.darkMode input.qa-form-light-button-hide,\r\nbody.darkMode input.qa-form-light-button-edit,\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  background: url(\"https://www.wikitree.com/images/icons/search-submit-icon.png\")\r\n    white !important;\r\n  font-size: 0;\r\n  top: -5px !important;\r\n}\r\nbody.darkMode input.qa-a-select-button {\r\n  background-image: url(\"https://www.wikitree.com/g2g/qa-theme/WikiTree/select-star.png\")\r\n    no-repeat !important;\r\n  border: 0 !important;\r\n  background-color: white !important;\r\n}\r\nbody.darkMode input.qa-form-light-button.qa-form-light-button-flag,\r\nbody.darkMode div.qa-vote-buttons qa-vote-buttons-net input {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode #header,\r\nbody.darkMode #footer {\r\n  background: #36393f;\r\n}\r\nbody.darkMode div.copyWidgetContainer,\r\nbody.darkMode div.copyWidgetContainerInner,\r\nbody.darkMode div.copyWidgetContainerInner button {\r\n  background: none !important;\r\n}\r\nbody.darkMode li.GREEN-ARROW {\r\n  background-blend-mode: color;\r\n}\r\nbody.darkMode div.qa-q-item-title a:link .checkmark,\r\nbody.darkMode span.qa-q-item-meta a.qa-q-item-what:link .checkmark {\r\n  color: #36393f !important;\r\n}\r\nbody.darkMode div.qa-nav-main a:hover,\r\nbody.darkMode div.qa-footer a:hover,\r\nbody.darkMode div.qa-nav-main a:visited:hover,\r\nbody.darkMode div.qa-footer a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:hover {\r\n  color: #36393f !important;\r\n  background: #dcddde !important;\r\n}\r\nbody.darkMode a[href*=\"wiki/Privacy\"] img,\r\nbody.darkMode img[src*=\"images/icons/privacy\"] {\r\n  background-color: #9196a1 !important;\r\n  border-radius: 50%;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css ***!
  \****************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#distanceFromYou {\r\n  font-size: 0.5em;\r\n  font-weight: bold;\r\n  padding: 0.2em;\r\n  border: 2px solid forestgreen;\r\n  border-radius: 50%;\r\n  width: 3em;\r\n  text-align: center;\r\n  background: white;\r\n  opacity: 0.8;\r\n  z-index: 1;\r\n  cursor:default;\r\n}\r\nbutton.copyWidget {\r\n  z-index: 10;\r\n}\r\n\r\n#yourRelationshipText {\r\n  display: inline-block;\r\n  border: 1px solid green;\r\n  border-bottom: 2px solid forestgreen;\r\n  border-right: 2px solid forestgreen;\r\n  padding: 0.5em;\r\n  border-radius: 0.5em;\r\n  margin: 0.1em 1em 1em;\r\n  font-weight: bold;\r\n}\r\n#yourCommonAncestor {\r\n  margin: auto;\r\n  padding: 0;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li {\r\n  display: block;\r\n  margin: auto;\r\n  padding: auto;\r\n  list-style: none;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li:nth-child(n + 3) {\r\n  display: none;\r\n}\r\n#yourRelationshipText {\r\n  position: relative;\r\n  background: whitesmoke;\r\n}\r\n#showMoreAncestors {\r\n  position: absolute;\r\n  font-size: 0.8em;\r\n  padding: 0.5em;\r\n  top: -0.5em;\r\n  right: -0.5em;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/distanceAndRelationship/distanceAndRelationship.css"],"names":[],"mappings":"AAAA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,cAAc;EACd,6BAA6B;EAC7B,kBAAkB;EAClB,UAAU;EACV,kBAAkB;EAClB,iBAAiB;EACjB,YAAY;EACZ,UAAU;EACV,cAAc;AAChB;AACA;EACE,WAAW;AACb;;AAEA;EACE,qBAAqB;EACrB,uBAAuB;EACvB,oCAAoC;EACpC,mCAAmC;EACnC,cAAc;EACd,oBAAoB;EACpB,qBAAqB;EACrB,iBAAiB;AACnB;AACA;EACE,YAAY;EACZ,UAAU;AACZ;AACA;EACE,cAAc;EACd,YAAY;EACZ,aAAa;EACb,gBAAgB;AAClB;AACA;EACE,aAAa;AACf;AACA;EACE,kBAAkB;EAClB,sBAAsB;AACxB;AACA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,cAAc;EACd,WAAW;EACX,aAAa;AACf","sourcesContent":["#distanceFromYou {\r\n  font-size: 0.5em;\r\n  font-weight: bold;\r\n  padding: 0.2em;\r\n  border: 2px solid forestgreen;\r\n  border-radius: 50%;\r\n  width: 3em;\r\n  text-align: center;\r\n  background: white;\r\n  opacity: 0.8;\r\n  z-index: 1;\r\n  cursor:default;\r\n}\r\nbutton.copyWidget {\r\n  z-index: 10;\r\n}\r\n\r\n#yourRelationshipText {\r\n  display: inline-block;\r\n  border: 1px solid green;\r\n  border-bottom: 2px solid forestgreen;\r\n  border-right: 2px solid forestgreen;\r\n  padding: 0.5em;\r\n  border-radius: 0.5em;\r\n  margin: 0.1em 1em 1em;\r\n  font-weight: bold;\r\n}\r\n#yourCommonAncestor {\r\n  margin: auto;\r\n  padding: 0;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li {\r\n  display: block;\r\n  margin: auto;\r\n  padding: auto;\r\n  list-style: none;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li:nth-child(n + 3) {\r\n  display: none;\r\n}\r\n#yourRelationshipText {\r\n  position: relative;\r\n  background: whitesmoke;\r\n}\r\n#showMoreAncestors {\r\n  position: absolute;\r\n  font-size: 0.8em;\r\n  padding: 0.5em;\r\n  top: -0.5em;\r\n  right: -0.5em;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css":
/*!************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css ***!
  \************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#myDrafts {\r\n\tposition: absolute;\r\n\ttop: 100px;\r\n\tleft: 50%;\r\n\tz-index: 11000;\r\n\tbackground: white;\r\n\tborder: 2px solid forestgreen;\r\n\tborder-radius: 1em;\r\n\tbox-shadow: 0.1em 0.1em 0.1em 0.1em lightgreen;\r\n\tpadding: 1em;\r\n\tdisplay: none;\r\n\ttext-align: left;\r\n}\r\n\r\n#myDrafts x {\r\n\tfont-weight: bold;\r\n\tposition: absolute;\r\n\ttop: 0;\r\n\tright: 0.2em;\r\n\tcursor: pointer;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tmargin: 0.5em;\r\n}\r\n\r\n#myDrafts table td {\r\n\tpadding: 0.5em;\r\n\tlist-style: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n#myDrafts a {\r\n\tmargin: 0.2em 0.5em;\r\n}\r\n\r\n#myDrafts a.button:active {\r\n\tcolor: gold;\r\n\tbackground: rgb(0, 100, 0);\r\n}\r\n\r\n#myDrafts p {\r\n\ttext-align: center;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tpadding: 0.5em;\r\n}\r\n\r\nbody.qa-body-js-on .button.small {\r\n\tpadding: 7px 15px;\r\n\tbackground: #25422d;\r\n\tborder: 0;\r\n\toutline: none;\r\n\tcursor: pointer;\r\n\ttext-align: center;\r\n\ttext-transform: uppercase;\r\n\tborder-radius: 5px;\r\n\tcolor: #fff;\r\n\tfont-weight: normal;\r\n\ttext-decoration: none !important;\r\n\tcursor: pointer;\r\n\tline-height: normal;\r\n}", "",{"version":3,"sources":["webpack://./src/features/draftList/draftList.css"],"names":[],"mappings":"AAAA;CACC,kBAAkB;CAClB,UAAU;CACV,SAAS;CACT,cAAc;CACd,iBAAiB;CACjB,6BAA6B;CAC7B,kBAAkB;CAClB,8CAA8C;CAC9C,YAAY;CACZ,aAAa;CACb,gBAAgB;AACjB;;AAEA;CACC,iBAAiB;CACjB,kBAAkB;CAClB,MAAM;CACN,YAAY;CACZ,eAAe;AAChB;;AAEA;CACC,aAAa;AACd;;AAEA;CACC,cAAc;CACd,gBAAgB;CAChB,mBAAmB;AACpB;;AAEA;CACC,mBAAmB;AACpB;;AAEA;CACC,WAAW;CACX,0BAA0B;AAC3B;;AAEA;CACC,kBAAkB;AACnB;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,iBAAiB;CACjB,mBAAmB;CACnB,SAAS;CACT,aAAa;CACb,eAAe;CACf,kBAAkB;CAClB,yBAAyB;CACzB,kBAAkB;CAClB,WAAW;CACX,mBAAmB;CACnB,gCAAgC;CAChC,eAAe;CACf,mBAAmB;AACpB","sourcesContent":["#myDrafts {\r\n\tposition: absolute;\r\n\ttop: 100px;\r\n\tleft: 50%;\r\n\tz-index: 11000;\r\n\tbackground: white;\r\n\tborder: 2px solid forestgreen;\r\n\tborder-radius: 1em;\r\n\tbox-shadow: 0.1em 0.1em 0.1em 0.1em lightgreen;\r\n\tpadding: 1em;\r\n\tdisplay: none;\r\n\ttext-align: left;\r\n}\r\n\r\n#myDrafts x {\r\n\tfont-weight: bold;\r\n\tposition: absolute;\r\n\ttop: 0;\r\n\tright: 0.2em;\r\n\tcursor: pointer;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tmargin: 0.5em;\r\n}\r\n\r\n#myDrafts table td {\r\n\tpadding: 0.5em;\r\n\tlist-style: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n#myDrafts a {\r\n\tmargin: 0.2em 0.5em;\r\n}\r\n\r\n#myDrafts a.button:active {\r\n\tcolor: gold;\r\n\tbackground: rgb(0, 100, 0);\r\n}\r\n\r\n#myDrafts p {\r\n\ttext-align: center;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tpadding: 0.5em;\r\n}\r\n\r\nbody.qa-body-js-on .button.small {\r\n\tpadding: 7px 15px;\r\n\tbackground: #25422d;\r\n\tborder: 0;\r\n\toutline: none;\r\n\tcursor: pointer;\r\n\ttext-align: center;\r\n\ttext-transform: uppercase;\r\n\tborder-radius: 5px;\r\n\tcolor: #fff;\r\n\tfont-weight: normal;\r\n\ttext-decoration: none !important;\r\n\tcursor: pointer;\r\n\tline-height: normal;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css":
/*!**********************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css ***!
  \**********************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#timeline.wrap,\r\n.familySheet.wrap {\r\n  width: 80%;\r\n  white-space: normal;\r\n}\r\n#timeline,\r\n.familySheet {\r\n  white-space: nowrap;\r\n  height: auto;\r\n  position: absolute;\r\n  width: auto;\r\n  left: 10%;\r\n  z-index: 4000;\r\n  background: white;\r\n  border: 3px solid forestgreen;\r\n  border-radius: 1em;\r\n  box-shadow: 1em 1em 1em #ccc;\r\n  padding: 0.3em;\r\n  display: none;\r\n  cursor: move;\r\n}\r\n#timelineTable td {\r\n  padding: 0.3em;\r\n}\r\n#timelineTable caption {\r\n  font-size: 1.5em;\r\n  font-weight: bold;\r\n}\r\n.tlAge,\r\n.tlBioAge {\r\n  text-align: center;\r\n}\r\nth.tlBioAge {\r\n  text-align: center;\r\n}\r\n.tlEventName {\r\n  text-align: center;\r\n}\r\n.tlDate {\r\n  white-space: nowrap;\r\n}\r\n#timeline x,\r\n.familySheet x {\r\n  position: absolute;\r\n  top: 0;\r\n  right: 0.5em;\r\n  font-weight: bold;\r\n  cursor: pointer;\r\n}\r\n#timeline w {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0.5em;\r\n  font-weight: bold;\r\n  cursor: pointer;\r\n}\r\n#timeline .BioPerson,\r\n#timeline .marriage {\r\n  font-weight: bold;\r\n}\r\n#timeline tr.BioPerson.Birth {\r\n  border-top: 1px solid forestgreen;\r\n}\r\n#timeline tr.BioPerson.Death {\r\n  border-bottom: 1px solid forestgreen;\r\n}\r\n#timelineTable {\r\n  width: 98%;\r\n  margin: auto;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/familyTimeline/familyTimeline.css"],"names":[],"mappings":"AAAA;;EAEE,UAAU;EACV,mBAAmB;AACrB;AACA;;EAEE,mBAAmB;EACnB,YAAY;EACZ,kBAAkB;EAClB,WAAW;EACX,SAAS;EACT,aAAa;EACb,iBAAiB;EACjB,6BAA6B;EAC7B,kBAAkB;EAClB,4BAA4B;EAC5B,cAAc;EACd,aAAa;EACb,YAAY;AACd;AACA;EACE,cAAc;AAChB;AACA;EACE,gBAAgB;EAChB,iBAAiB;AACnB;AACA;;EAEE,kBAAkB;AACpB;AACA;EACE,kBAAkB;AACpB;AACA;EACE,kBAAkB;AACpB;AACA;EACE,mBAAmB;AACrB;AACA;;EAEE,kBAAkB;EAClB,MAAM;EACN,YAAY;EACZ,iBAAiB;EACjB,eAAe;AACjB;AACA;EACE,kBAAkB;EAClB,MAAM;EACN,WAAW;EACX,iBAAiB;EACjB,eAAe;AACjB;AACA;;EAEE,iBAAiB;AACnB;AACA;EACE,iCAAiC;AACnC;AACA;EACE,oCAAoC;AACtC;AACA;EACE,UAAU;EACV,YAAY;AACd","sourcesContent":["#timeline.wrap,\r\n.familySheet.wrap {\r\n  width: 80%;\r\n  white-space: normal;\r\n}\r\n#timeline,\r\n.familySheet {\r\n  white-space: nowrap;\r\n  height: auto;\r\n  position: absolute;\r\n  width: auto;\r\n  left: 10%;\r\n  z-index: 4000;\r\n  background: white;\r\n  border: 3px solid forestgreen;\r\n  border-radius: 1em;\r\n  box-shadow: 1em 1em 1em #ccc;\r\n  padding: 0.3em;\r\n  display: none;\r\n  cursor: move;\r\n}\r\n#timelineTable td {\r\n  padding: 0.3em;\r\n}\r\n#timelineTable caption {\r\n  font-size: 1.5em;\r\n  font-weight: bold;\r\n}\r\n.tlAge,\r\n.tlBioAge {\r\n  text-align: center;\r\n}\r\nth.tlBioAge {\r\n  text-align: center;\r\n}\r\n.tlEventName {\r\n  text-align: center;\r\n}\r\n.tlDate {\r\n  white-space: nowrap;\r\n}\r\n#timeline x,\r\n.familySheet x {\r\n  position: absolute;\r\n  top: 0;\r\n  right: 0.5em;\r\n  font-weight: bold;\r\n  cursor: pointer;\r\n}\r\n#timeline w {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0.5em;\r\n  font-weight: bold;\r\n  cursor: pointer;\r\n}\r\n#timeline .BioPerson,\r\n#timeline .marriage {\r\n  font-weight: bold;\r\n}\r\n#timeline tr.BioPerson.Birth {\r\n  border-top: 1px solid forestgreen;\r\n}\r\n#timeline tr.BioPerson.Death {\r\n  border-bottom: 1px solid forestgreen;\r\n}\r\n#timelineTable {\r\n  width: 98%;\r\n  margin: auto;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css":
/*!************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css ***!
  \************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".wrongPeriod {\r\n\tbackground: #ffe6ea;\r\n}\r\n\r\n.familyLoc.rightPeriod {\r\n\tbackground: #DAF7A6;\r\n}\r\n\r\n.familyLoc2.rightPeriod {\r\n\tbackground: lightgreen;\r\n}\r\n\r\n.autocomplete-suggestions div.currentSelectedLocation {\r\n\tbackground: #DCDCDC !important;\r\n}\r\n\r\ninput[name='mMarriageLocation'] {\r\n\twidth: 100%;\r\n}", "",{"version":3,"sources":["webpack://./src/features/locationsHelper/locationsHelper.css"],"names":[],"mappings":"AAAA;CACC,mBAAmB;AACpB;;AAEA;CACC,mBAAmB;AACpB;;AAEA;CACC,sBAAsB;AACvB;;AAEA;CACC,8BAA8B;AAC/B;;AAEA;CACC,WAAW;AACZ","sourcesContent":[".wrongPeriod {\r\n\tbackground: #ffe6ea;\r\n}\r\n\r\n.familyLoc.rightPeriod {\r\n\tbackground: #DAF7A6;\r\n}\r\n\r\n.familyLoc2.rightPeriod {\r\n\tbackground: lightgreen;\r\n}\r\n\r\n.autocomplete-suggestions div.currentSelectedLocation {\r\n\tbackground: #DCDCDC !important;\r\n}\r\n\r\ninput[name='mMarriageLocation'] {\r\n\twidth: 100%;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css":
/*!***************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css ***!
  \***************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\ntr.trSelect:hover { \r\n  background: #ffe270;; \r\n}\r\n\r\ntr.trSelected { \r\n  background: #CCCCCC !important; \r\n}\r\n\r\n::placeholder {\r\n  color:    #bbb;\r\n}\r\n\r\n/* dialog formatting  */\r\n\r\ndialog {\r\n  max-width: 600px;\r\n}  \r\n\r\ndialog input[type=\"text\"] {\r\n  min-width: 350px;\r\n  padding: 4px 4px;\r\n  margin: 2px;\r\n}\r\ndialog button, dialog .button{\r\n  padding: 8px 20px;\r\n  margin: 5px;\r\n}\r\ntd button{\r\n  padding: 5px 5px;\r\n  margin: 3px;\r\n  font-size: 14px;\r\n}\r\ndialog select{\r\n  overflow: auto;\r\n  background: unset;  \r\n}\r\ndialog textarea{\r\n  width: 100%;\r\n  margin: 5px;\r\n}\r\n\r\n.wtPlusRequired {\r\n  background-color: palevioletred;\r\n}\r\n.wtPlusPreferred {\r\n  background-color: palegreen;\r\n}\r\n.wtPlusOptional {\r\n  background-color: palegoldenrod;\r\n}\r\n.wtPlusDeprecated{\r\n  background-color:  lightgrey;\r\n  text-decoration-line: line-through;\r\n}\r\n\r\n.wtPlusLegend{\r\n  display: none;\r\n  background: white;\r\n  color: black;\r\n  text-align: left;\r\n  font-size: 14px;\r\n  text-transform: none;\r\n  position: absolute;\r\n  bottom: 65px;\r\n  left: 25px;\r\n  padding: 10px;\r\n  border: 1px solid black;\r\n  line-height: 35px;\r\n}\r\n\r\n#wtPlusLegendBtn:hover .wtPlusLegend{\r\n  display: block;\r\n}\r\n\r\n", "",{"version":3,"sources":["webpack://./src/features/wt+/wtPlus.css"],"names":[],"mappings":";AACA;EACE,mBAAmB;AACrB;;AAEA;EACE,8BAA8B;AAChC;;AAEA;EACE,cAAc;AAChB;;AAEA,uBAAuB;;AAEvB;EACE,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;EAChB,gBAAgB;EAChB,WAAW;AACb;AACA;EACE,iBAAiB;EACjB,WAAW;AACb;AACA;EACE,gBAAgB;EAChB,WAAW;EACX,eAAe;AACjB;AACA;EACE,cAAc;EACd,iBAAiB;AACnB;AACA;EACE,WAAW;EACX,WAAW;AACb;;AAEA;EACE,+BAA+B;AACjC;AACA;EACE,2BAA2B;AAC7B;AACA;EACE,+BAA+B;AACjC;AACA;EACE,4BAA4B;EAC5B,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,iBAAiB;EACjB,YAAY;EACZ,gBAAgB;EAChB,eAAe;EACf,oBAAoB;EACpB,kBAAkB;EAClB,YAAY;EACZ,UAAU;EACV,aAAa;EACb,uBAAuB;EACvB,iBAAiB;AACnB;;AAEA;EACE,cAAc;AAChB","sourcesContent":["\r\ntr.trSelect:hover { \r\n  background: #ffe270;; \r\n}\r\n\r\ntr.trSelected { \r\n  background: #CCCCCC !important; \r\n}\r\n\r\n::placeholder {\r\n  color:    #bbb;\r\n}\r\n\r\n/* dialog formatting  */\r\n\r\ndialog {\r\n  max-width: 600px;\r\n}  \r\n\r\ndialog input[type=\"text\"] {\r\n  min-width: 350px;\r\n  padding: 4px 4px;\r\n  margin: 2px;\r\n}\r\ndialog button, dialog .button{\r\n  padding: 8px 20px;\r\n  margin: 5px;\r\n}\r\ntd button{\r\n  padding: 5px 5px;\r\n  margin: 3px;\r\n  font-size: 14px;\r\n}\r\ndialog select{\r\n  overflow: auto;\r\n  background: unset;  \r\n}\r\ndialog textarea{\r\n  width: 100%;\r\n  margin: 5px;\r\n}\r\n\r\n.wtPlusRequired {\r\n  background-color: palevioletred;\r\n}\r\n.wtPlusPreferred {\r\n  background-color: palegreen;\r\n}\r\n.wtPlusOptional {\r\n  background-color: palegoldenrod;\r\n}\r\n.wtPlusDeprecated{\r\n  background-color:  lightgrey;\r\n  text-decoration-line: line-through;\r\n}\r\n\r\n.wtPlusLegend{\r\n  display: none;\r\n  background: white;\r\n  color: black;\r\n  text-align: left;\r\n  font-size: 14px;\r\n  text-transform: none;\r\n  position: absolute;\r\n  bottom: 65px;\r\n  left: 25px;\r\n  padding: 10px;\r\n  border: 1px solid black;\r\n  line-height: 35px;\r\n}\r\n\r\n#wtPlusLegendBtn:hover .wtPlusLegend{\r\n  display: block;\r\n}\r\n\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/core/editToolbar.css":
/*!**********************************!*\
  !*** ./src/core/editToolbar.css ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./editToolbar.css */ "./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/appsMenu/appsMenu.css":
/*!********************************************!*\
  !*** ./src/features/appsMenu/appsMenu.css ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./appsMenu.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css":
/*!********************************************************************************!*\
  !*** ./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./collapsibleDescendantsTree.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/darkMode/darkMode.css":
/*!********************************************!*\
  !*** ./src/features/darkMode/darkMode.css ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./darkMode.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/distanceAndRelationship/distanceAndRelationship.css":
/*!**************************************************************************!*\
  !*** ./src/features/distanceAndRelationship/distanceAndRelationship.css ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./distanceAndRelationship.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/draftList/draftList.css":
/*!**********************************************!*\
  !*** ./src/features/draftList/draftList.css ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./draftList.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/familyTimeline/familyTimeline.css":
/*!********************************************************!*\
  !*** ./src/features/familyTimeline/familyTimeline.css ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./familyTimeline.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/locationsHelper/locationsHelper.css":
/*!**********************************************************!*\
  !*** ./src/features/locationsHelper/locationsHelper.css ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./locationsHelper.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/wt+/wtPlus.css":
/*!*************************************!*\
  !*** ./src/features/wt+/wtPlus.css ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./wtPlus.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/content.js":
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/common */ "./src/core/common.js");
/* harmony import */ var _features_akaNameLinks_akaNameLinks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./features/akaNameLinks/akaNameLinks */ "./src/features/akaNameLinks/akaNameLinks.js");
/* harmony import */ var _features_appsMenu_appsMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./features/appsMenu/appsMenu */ "./src/features/appsMenu/appsMenu.js");
/* harmony import */ var _features_collapsibleDescendantsTree_collapsibleDescendantsTree__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./features/collapsibleDescendantsTree/collapsibleDescendantsTree */ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js");
/* harmony import */ var _features_darkMode_darkMode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./features/darkMode/darkMode */ "./src/features/darkMode/darkMode.js");
/* harmony import */ var _features_distanceAndRelationship_distanceAndRelationship__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./features/distanceAndRelationship/distanceAndRelationship */ "./src/features/distanceAndRelationship/distanceAndRelationship.js");
/* harmony import */ var _features_draftList_draftList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./features/draftList/draftList */ "./src/features/draftList/draftList.js");
/* harmony import */ var _features_familyGroup_familyGroup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./features/familyGroup/familyGroup */ "./src/features/familyGroup/familyGroup.js");
/* harmony import */ var _features_familyTimeline_familyTimeline__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./features/familyTimeline/familyTimeline */ "./src/features/familyTimeline/familyTimeline.js");
/* harmony import */ var _features_locationsHelper_locationsHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./features/locationsHelper/locationsHelper */ "./src/features/locationsHelper/locationsHelper.js");
/* harmony import */ var _features_printerfriendly_printerfriendly__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./features/printerfriendly/printerfriendly */ "./src/features/printerfriendly/printerfriendly.js");
/* harmony import */ var _features_randomProfile_randomProfile__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./features/randomProfile/randomProfile */ "./src/features/randomProfile/randomProfile.js");
/* harmony import */ var _features_sourcepreview_sourcepreview__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./features/sourcepreview/sourcepreview */ "./src/features/sourcepreview/sourcepreview.js");
/* harmony import */ var _features_spacepreview_spacepreview__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./features/spacepreview/spacepreview */ "./src/features/spacepreview/spacepreview.js");
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _features_bioCheck_bioCheck__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./features/bioCheck/bioCheck */ "./src/features/bioCheck/bioCheck.js");
/* harmony import */ var _core_editToolbar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./core/editToolbar */ "./src/core/editToolbar.js");


















(0,_core_common__WEBPACK_IMPORTED_MODULE_0__.createTopMenu)();


/***/ }),

/***/ "./src/core/common.js":
/*!****************************!*\
  !*** ./src/core/common.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createProfileSubmenuLink": () => (/* binding */ createProfileSubmenuLink),
/* harmony export */   "createTopMenu": () => (/* binding */ createTopMenu),
/* harmony export */   "createTopMenuItem": () => (/* binding */ createTopMenuItem),
/* harmony export */   "extractRelatives": () => (/* binding */ extractRelatives),
/* harmony export */   "familyArray": () => (/* binding */ familyArray),
/* harmony export */   "getRelatives": () => (/* binding */ getRelatives),
/* harmony export */   "isOK": () => (/* binding */ isOK),
/* harmony export */   "pageCategory": () => (/* binding */ pageCategory),
/* harmony export */   "pageG2G": () => (/* binding */ pageG2G),
/* harmony export */   "pageHelp": () => (/* binding */ pageHelp),
/* harmony export */   "pageProfile": () => (/* binding */ pageProfile),
/* harmony export */   "pageSpace": () => (/* binding */ pageSpace),
/* harmony export */   "pageSpecial": () => (/* binding */ pageSpecial),
/* harmony export */   "pageTemplate": () => (/* binding */ pageTemplate)
/* harmony export */ });
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


let pageProfile = false;
let pageHelp = false;
let pageSpecial = false;
let pageCategory = false;
let pageTemplate = false;
let pageSpace = false;
let pageG2G = false;

if (
    window.location.pathname.match(/(\/wiki\/)\w[^:]*-[0-9]*/g) ||
    window.location.href.match(/\?title\=\w[^:]+-[0-9]+/g)
  ) {
      // Is a Profile Page
	pageProfile = true;
} else if (window.location.pathname.match(/(\/wiki\/)Help:*/g)) {
	// Is a Help Page
	pageHelp = true;
} else if (window.location.pathname.match(/(\/wiki\/)Special:*/g)) {
	// Is a Special Page
	pageSpecial = true;
} else if (window.location.pathname.match(/(\/wiki\/)Category:*/g)) {
	// Is a Category Page
	pageCategory = true;
} else if (window.location.pathname.match(/(\/wiki\/)Template:*/g)) {
	// Is a Template Page
	pageTemplate = true;
} else if (window.location.pathname.match(/(\/wiki\/)Space:*/g)) {
	// Is a Space Page
	pageSpace = true;
} else if (window.location.pathname.match(/\/g2g\//g)) {
	// Is a G2G page
	pageG2G = true;
}

// Add wte class to body to let WikiTree BEE know not to add the same functions
document.querySelector("body").classList.add("wte");

/**
 * Creates a new menu item in the Apps dropdown menu.
 *
 */
function createTopMenuItem(options) {
  let title = options.title;
  let name = options.name;
  let id = options.id;
  let url = options.url;

  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#wte-topMenu").append(`<li>
        <a id="${id}" class="pureCssMenui" title="${title}">${name}</a>
    </li>`);
}

// Add a link to the short list of links below the tabs
function createProfileSubmenuLink(options) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.views.viewsm")
    .eq(0)
    .append(
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(
        `<li class='viewsi'><a title='${options.title}' href='${options.url}' id='${options.id}'>${options.text}</a></li>`
      )
    );
  let links = jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.views.viewsm:first li");
  // Re-sort the links into alphabetical order
  links.sort(function (a, b) {
    return jquery__WEBPACK_IMPORTED_MODULE_0___default()(a).text().localeCompare(jquery__WEBPACK_IMPORTED_MODULE_0___default()(b).text());
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.views.viewsm").eq(0).append(links);
}

function createTopMenu() {
  const newUL = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<ul class='pureCssMenu' id='wte-topMenuUL'></ul>");
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu").eq(0).after(newUL);
  newUL.append(`<li>
        <a class="pureCssMenui0">
            <span>App Features</span>
        </a>
        <ul class="pureCssMenum" id="wte-topMenu"></ul>
    </li>`);
}

// Used in familyTimeline, familyGroup, locationsHelper
async function getRelatives(id, fields = "*") {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: {
        action: "getRelatives",
        keys: id,
        fields: fields,
        getParents: 1,
        getSiblings: 1,
        getSpouses: 1,
        getChildren: 1,
      },
    });
    return result[0].items[0].person;
  } catch (error) {
    console.error(error);
  }
}

// Used in familyTimeline, familyGroup, locationsHelper
// Make the family member arrays easier to handle
function extractRelatives(rel, theRelation = false) {
  let people = [];
  if (typeof rel == undefined || rel == null) {
    return false;
  }
  const pKeys = Object.keys(rel);
  pKeys.forEach(function (pKey) {
    var aPerson = rel[pKey];
    if (theRelation != false) {
      aPerson.Relation = theRelation;
    }
    people.push(aPerson);
  });
  return people;
}

// Used in familyTimeline, familyGroup, locationsHelper
function familyArray(person) {
  // This is a person from getRelatives()
  const rels = ["Parents", "Siblings", "Spouses", "Children"];
  let familyArr = [person];
  rels.forEach(function (rel) {
    const relation = rel.replace(/s$/, "").replace(/ren$/, "");
    familyArr = familyArr.concat(extractRelatives(person[rel], relation));
  });
  return familyArr;
}

function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

// Check that a value is OK
// Used in familyTimeline and familyGroup
function isOK(thing) {
  const excludeValues = [
    "",
    null,
    "null",
    "0000-00-00",
    "unknown",
    "Unknown",
    "undefined",
    undefined,
    "0000",
    "0",
    0,
  ];
  if (!excludeValues.includes(thing)) {
    if (isNumeric(thing)) {
      return true;
    } else {
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default().type(thing) === "string") {
        const nanMatch = thing.match(/NaN/);
        if (nanMatch == null) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  } else {
    return false;
  }
}


/***/ }),

/***/ "./src/core/editToolbar.js":
/*!*********************************!*\
  !*** ./src/core/editToolbar.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "editToolbarApp": () => (/* binding */ editToolbarApp),
/* harmony export */   "editToolbarWiki": () => (/* binding */ editToolbarWiki)
/* harmony export */ });
/* harmony import */ var _editToolbarCategoryOptions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editToolbarCategoryOptions */ "./src/core/editToolbarCategoryOptions.js");
/* harmony import */ var _editToolbarGenericOptions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbarGenericOptions */ "./src/core/editToolbarGenericOptions.js");
/* harmony import */ var _editToolbarProfileOptions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./editToolbarProfileOptions */ "./src/core/editToolbarProfileOptions.js");
/* harmony import */ var _editToolbarTemplateOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./editToolbarTemplateOptions */ "./src/core/editToolbarTemplateOptions.js");
/* harmony import */ var _editToolbarSpaceOptions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./editToolbarSpaceOptions */ "./src/core/editToolbarSpaceOptions.js");
/* harmony import */ var _editToolbar_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./editToolbar.css */ "./src/core/editToolbar.css");







let editToolbarOptions = []

/* Common events for links */
function editToolbarWiki(params) {
	window.open('https://www.wikitree.com/wiki/' + params.wiki, '_blank')
}

function editToolbarApp(params) {
	let w = document.querySelector('h1 > .copyWidget') 
	let wikitreeID = w.getAttribute('data-copy-text');
	window.open('https://apps.wikitree.com/apps/' + params.app + '?wikitreeid=' + wikitreeID, '_blank')
}

/* Finds the clicked item in editToolbarOptions */
function editToolbarFindItem(items, name) {
	if (items && items.length) {
		for (var item of items) {
			if (item.button) {
				let result = editToolbarFindItem(item.items, name)
				if (result) { return result }
			} else if (name.toUpperCase() === item.title.toUpperCase()) {
				return item
			} else {
				let result = editToolbarFindItem(item.items, name)
				if (result) { return result }
			}
		}
	}
}

/* main event handler */
function editToolbarEvent(event) {
	let element = event.srcElement
	const id = element.dataset.id
	event.preventDefault();
	let item = editToolbarFindItem(editToolbarOptions, id);
	if (item) {
		return item.call(item.params || {})
	} else {
		alert("Unknown event " + id)
	}
}

/* creates html of the drop down menu */
function editToolbarCreateHtml(items, featureEnabled, level) {
	let result = '';
	if (items && items.length) {
		for (var item of items) {
			if ((!item.featureid) || featureEnabled[item.featureid]) {
				let s = editToolbarCreateHtml(item.items, featureEnabled, level + 1)
				if (s || item.call) {
					if (item.button) {
						result +=
							'<div id="editToolbarDiv">' +
							'<p id="editToolbarButton">' + item.button + '</p>' +
							// '<img src="/photo.php/8/89/WikiTree_Images-22.png" height="22" id="editToolbarButton" />' + 
							s +
							'</div>';
					} else {
						result += '<li><a '
						result += (item.hint ? 'title= "' + item.hint + '"' : "");
						result += 'href="javascript:void(0);" class="editToolbarClick" data-id="' + item.title + '"';
						result += '>' + item.title + (item.items ? " &gt;&gt;" : "") + "</a>";
						result += s;
						result += '</li>';
					}
				}
			}
		}
		if ((level >= 0) && (result))
			result = '<ul class="editToolbarMenu' + level + '">' + result + '</ul>';
	}
	return result;
}

/* creates menu next to the toolbar  */
function editToolbarCreate(options) {
	editToolbarOptions = options
	chrome.storage.sync.get(null, (featureEnabled) => {
		var menuHTML = editToolbarCreateHtml(editToolbarOptions, featureEnabled, -1);
		document.getElementById("toolbar").insertAdjacentHTML('afterend', '<div id="editToolbarExt">' + menuHTML + '</div>')
		document.querySelectorAll('a.editToolbarClick').forEach(i => i.addEventListener('click', event => editToolbarEvent(event)))
	})
}

if (window.location.href.match(/\/index.php\?title=Special:EditPerson&.*/g)) {
	editToolbarCreate(_editToolbarProfileOptions__WEBPACK_IMPORTED_MODULE_2__["default"]);

} else if (window.location.href.match(/\/index.php\?title=Category:.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=Category:.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarCategoryOptions__WEBPACK_IMPORTED_MODULE_0__["default"]);

} else if (window.location.href.match(/\/index.php\?title=Template:.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=Template:.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarTemplateOptions__WEBPACK_IMPORTED_MODULE_3__["default"]);

} else if (window.location.href.match(/\/index.php\?title=Space:.*&action=edit.*/g) ||
		   window.location.href.match(/\/index.php\?title=Space:.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarSpaceOptions__WEBPACK_IMPORTED_MODULE_4__["default"]);

} else if (window.location.href.match(/\/index.php\?title=.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarGenericOptions__WEBPACK_IMPORTED_MODULE_1__["default"]);
}


/***/ }),

/***/ "./src/core/editToolbarCategoryOptions.js":
/*!************************************************!*\
  !*** ./src/core/editToolbarCategoryOptions.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{
				title: "Category templates", items: [
					{ featureid: "wtplus", title: "Aka", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Aka" } },
					{ featureid: "wtplus", title: "Top Level", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Top Level" } },
					{ featureid: "wtplus", title: "Geographic Location", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Geographic Location" } }
				]
			},
			{ "featureid": "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "CIB", items: [
			{ featureid: "wtplus", title: "Cemetery", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Cemetery" } },
			{ featureid: "wtplus", title: "Location", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Location" } },
			{ featureid: "wtplus", title: "Add any CIB", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "CategoryInfoBox" } },
			{
				title: "Cemeteries", items: [
					{ featureid: "wtplus", title: "Cemetery", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Cemetery" } },
					{ featureid: "wtplus", title: "Cemetery Group", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox CemeteryGroup" } }
				]
			},
			{
				title: "Religion", items: [
					{ featureid: "wtplus", title: "Religious Institution Group", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox ReligiousInstitutionGroup" } }
				]
			},
			{
				title: "Maintenance", items: [
					{ featureid: "wtplus", title: "Maintenance", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Maintenance" } },
					{ featureid: "wtplus", title: "Needs", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Needs" } },
					{ featureid: "wtplus", title: "Needs GEDCOM Cleanup", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox NeedsGEDCOMCleanup" } },
					{ featureid: "wtplus", title: "Unconnected", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Unconnected" } },
					{ featureid: "wtplus", title: "Unsourced", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Unsourced" } }
				]
			},
			{
				title: "Others", items: [
					{ featureid: "wtplus", title: "Location", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Location" } },
					{ featureid: "wtplus", title: "Migration", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Migration" } },
					{ featureid: "wtplus", title: "One Name Study", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox OneNameStudy" } },
					{ featureid: "wtplus", title: "One Place Study", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox OnePlaceStudy" } },
					{ featureid: "wtplus", title: "CategoryInfoBox", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox" } }
				]
			}
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } },
		]
	},
	{
		button: "EditBOT", items: [
			{ featureid: "wtplus", title: "Rename Category", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Rename Category" } },
			{ featureid: "wtplus", title: "Merge Category", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Merge Category" } },
			{ featureid: "wtplus", title: "Delete Category", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Delete Category" } },
			{ featureid: "wtplus", title: "Confirm for EditBOT", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditBOTConfirm" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Category_pages" } }
		]
	},
]);


/***/ }),

/***/ "./src/core/editToolbarGenericOptions.js":
/*!***********************************************!*\
  !*** ./src/core/editToolbarGenericOptions.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Other_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/core/editToolbarProfileOptions.js":
/*!***********************************************!*\
  !*** ./src/core/editToolbarProfileOptions.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Sources",
		items: [
			{ featureid: "wtplus", title: "Paste sources", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "PasteSource" } }
		]
	}, {
		button: "Templates",
		items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Add Project Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "Project Box" } },
			{ featureid: "wtplus", title: "Add Sticker", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "Sticker" } },
			{ featureid: "wtplus", title: "Add Research Note Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "Profile Box" } },
			{ featureid: "wtplus", title: "Add External links", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "External Link" } },
			{ featureid: "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	}, {
		button: "Biography",
		items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } }
		]
	}, {
		button: "Misc",
		items: [
			{
				title: "WikiTree Apps",
				items: [
					{ featureid: "wtplus", title: "DNA Confirmation", hint: "DNA Confirmation by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/DNAconf.php" } },
					{ featureid: "wtplus", title: "Ancestry Citation", hint: "Ancestry Citation by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/ancite.php" } },
					{ featureid: "wtplus", title: "Drouin Citer", hint: "Drouin Citer by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/drouinCite.php" } },
					{ featureid: "wtplus", title: "Surnames Generator", hint: "Surnames Generator by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/surnames.php" } },
					{ featureid: "wtplus", title: "Riksarkivet SVAR sources", hint: "Riksarkivet SVAR sources by Maria Lundholm", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "lundholm24/ref-making/ra-ref.php" } },
					{ featureid: "wtplus", title: "Arkiv Digital sources", hint: "Arkiv Digital sources by Maria Lundholm", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "lundholm24/ref-making/ad-ref.php" } },
					{ featureid: "wtplus", title: "Sveriges Dödbok sources", hint: "Sveriges Dödbok sources by Maria Lundholm", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "lundholm24/ref-making/sdb-ref.php" } },
					{ featureid: "wtplus", title: "Biography Generator", hint: "Biography Generator (for Open pr.) by Greg Shipley", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "shipley1223/Bio.html" } },
					{
						title: "Other Apps",
						items: [
							{ featureid: "wtplus", title: "Bio Check", hint: "Bio Check by Kay Knight", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "sands1865/biocheck/" } },
							{ featureid: "wtplus", title: "Fan Chart", hint: "Fan Chart by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/fan.php" } }
						]
					}
				]
			},
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Profile_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/core/editToolbarSpaceOptions.js":
/*!*********************************************!*\
  !*** ./src/core/editToolbarSpaceOptions.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Other_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/core/editToolbarTemplateOptions.js":
/*!************************************************!*\
  !*** ./src/core/editToolbarTemplateOptions.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Format Parameters", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } },
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add TemplateParam", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "TemplateParam" } },
			{ featureid: "wtplus", title: "Add Documentation", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Documentation" } },
			{
				title: "Add Base Templates", items: [
					{ featureid: "wtplus", title: "Project Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Project Box" } },
					{ featureid: "wtplus", title: "Sticker", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Sticker" } },
					{ featureid: "wtplus", title: "Research Note Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Research Note Box" } }
				]
			},
			{
				title: "Add Other Templates", items: [
					{ featureid: "wtplus", title: "Project Box Instructions", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Project Box Instructions" } }
				]
			},
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Template_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/features/akaNameLinks/akaNameLinks.js":
/*!***************************************************!*\
  !*** ./src/features/akaNameLinks/akaNameLinks.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");



async function akaNames(){
// Make AKA last names clickable
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.profile").length){
        const nameBit = jquery__WEBPACK_IMPORTED_MODULE_0___default()(".VITALS").eq(0).find(".large");
        const nameText = nameBit.text();
        if (nameText.match("aka ")){
            const strongs = nameBit.find("strong");
            const lastStrong = strongs.eq(strongs.length-1);
            const akaText = lastStrong.text();
            const oAkaNames = akaText.split(",");
            lastStrong.text("");
            oAkaNames.forEach(function(akaName,i){
                jquery__WEBPACK_IMPORTED_MODULE_0___default()("<a href='https://www.wikitree.com/genealogy/"+akaName.trim()+"'>"+akaName.trim()+"</a>").appendTo(lastStrong);
                if (i+1<oAkaNames.length){
                    jquery__WEBPACK_IMPORTED_MODULE_0___default()("<span>, </span>").appendTo(lastStrong);
                }
            })
        }
    }
}

chrome.storage.sync.get('akaNameLinks', (result) => {
	if (result.akaNameLinks && _core_common__WEBPACK_IMPORTED_MODULE_1__.pageProfile == true) { 
        akaNames();
    }
})

/***/ }),

/***/ "./src/features/appsMenu/appsMenu.js":
/*!*******************************************!*\
  !*** ./src/features/appsMenu/appsMenu.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ "./node_modules/js-cookie/dist/js.cookie.mjs");
/* harmony import */ var _appsMenu_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./appsMenu.css */ "./src/features/appsMenu/appsMenu.css");




chrome.storage.sync.get('appsMenu', (result) => {
	if (result.appsMenu) {
		// Add a menu if WikiTree BEE hasn't already done so. 
		if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#appsSubMenu").length==0){
            addAppsMenu();
        }
	}
});

async function getAppsMenu(){
	try{
		const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({url: "https://wikitreebee.com/BEE.php?q=apps_menu", crossDomain: true, type: 'POST', dataType: 'json'})
		return result.apps_menu;
	} catch (error) {
		console.error(error);
	}
}

function attachAppsMenu(menu){
	const mWTID = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
	const appsList = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<menu class='subMenu' id='appsSubMenu'></menu>");
	menu.forEach(function(app){
		const appsLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<a class='pureCssMenui' href='"+app.URL.replace(/mWTID/,mWTID)+"'>"+app.title+"</a>");
		appsLi.appendTo(appsList);
	})
	appsList.appendTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").parent());
	const appsLink = jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").parent();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").text("« Apps");
	appsLink.hover(function(){appsList.show();},function(){appsList.hide();})
}

function addAppsMenu(){	
	const d = new Date();
	let day = d.getUTCDate();
	let getMenu = false;
	// Store the date if it hasn't been stored
	if (!localStorage.appsMenuCheck){
		localStorage.setItem("appsMenuCheck",day);
	}
	// Store the date and update the menu if it's a new day.
	else if (day!=localStorage.appsMenuCheck){
		localStorage.setItem("appsMenuCheck",day);
		getMenu = true;
	}
	if (!localStorage.appsMenu || getMenu == true){
		getAppsMenu().then((menu)=>{
			attachAppsMenu(menu);
			// Store the menu.
			localStorage.setItem("appsMenu",JSON.stringify(menu));
		})
	} else {  // Or use the stored menu.
		attachAppsMenu(JSON.parse(localStorage.appsMenu));
	}
}

/***/ }),

/***/ "./src/features/bioCheck/Biography.js":
/*!********************************************!*\
  !*** ./src/features/bioCheck/Biography.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Biography": () => (/* binding */ Biography)
/* harmony export */ });
/* harmony import */ var _BiographyResults_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BiographyResults.js */ "./src/features/bioCheck/BiographyResults.js");
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * Parse and validate a WikiTree biography
 * Gather information about style and the parts needed to validate
 * along with information about the bio and methods to parse and validate
 */

class Biography extends _BiographyResults_js__WEBPACK_IMPORTED_MODULE_0__.BiographyResults {

  sourceRules = null;             // rules for testing sources
  bioLines = ([]);                // lines in the biography
  bioHeadingsFound = [];          // biography headings found (multi lang)
  sourcesHeadingsFound = [];      // sources headings found (multi lang)
  invalidSpanTargetList = ([]);   // target of a span that are not valid
  refStringList = ([]);           // all the <ref> this </ref> lines
  namedRefStringList = ([]);      // all the <ref> with names

  bioInputString = "";            // input string may be modified by processing
  biographyIndex = -1;            // first line of biography
  acknowledgementsEndIndex = -1;  // next heading or end of bio
  sourcesIndex = -1;              // first line of sources
  referencesIndex = -1;           // index into vector for <references tag
  acknowledgementsIndex = -1;     // first line of acknowledgements
  researchNotesIndex = -1;        // first line of researchNotes
  researchNotesEndIndex = -1;     // last line of research notes is next heading

  isPre1700 = false;              // is this a pre1700 profile
  isPre1500 = false;              // is this a pre1500 profile
  tooOldToRemember = false;       // is this profile to old to remember
  treatAsPre1700 = false;         // treat all profiles as pre1700

  static START_OF_COMMENT = "<!--";
  static END_OF_COMMENT = "-->";
  static START_OF_BR = "<br";
  static REF_START = "<ref>";
  static REF_END = "</ref>";
  static END_BRACKET = ">";
  static REF_START_NAMED = "<ref name";
  static REF_END_NAMED = "/>";
  static HEADING_START = "==";
  static CATEGORY_START = "[[category";
  static REFERENCES_TAG = "<references";
  static UNSOURCED = "unsourced";
  static UNSOURCED_TAG = "{{unsourced";
  static UNSOURCED_TAG2 = "{{ unsourced";
  static QUESTIONABLE_TAG = "{{template:questionable";
  static UNCERTAIN_TAG = "{{uncertain existence";
  static DISPROVEN_TAG = "{{disproven existence";
  static DISPROVEN2_TAG = "{{disproven existence project";
  static AUTO_GENERATED = "auto-generated by a gedcom import";
  static SPAN_TARGET_START = "<span id=";
  static SPAN_TARGET_END = "</span>";
  static SPAN_REFERENCE_START = "[[#";
  static SPAN_REFERENCE_END = "]]";
  static MIN_SOURCE_LEN = 15;       // minimum length for valid source
  static SOURCE_START = "source:";

  /**
   * Constructor
   * @param sourceRules source rules for validating sources
   * @param bioResults container for BiographyResults
   */ 
  constructor(theSourceRules) {
    super();
     this.sourceRules = theSourceRules;
  }

  /**
   * Parse contents of the bio
   * @param inStr bio string as returned from server
   * @param isPre1500 true if profile is treated as Pre1500
   * @param isPre1700 true if profile is treated as Pre1700
   * @param mustBeOpen true if profile is treated as too old to remember
   * @param bioUndated true if profile has no dates
   * @param checkAutoGenerated true to report profiles with auto-generated * string
   * Side effects - set statistics and style
   */
  parse(inStr, isPre1500, isPre1700, mustBeOpen, bioUndated, checkAutoGenerated) {

    this.isPre1500 = isPre1500;
    this.isPre1700 = isPre1700;
    this.tooOldToRemember = mustBeOpen;
    this.bioResults.stats.bioIsUndated = bioUndated;

    this.bioInputString = inStr;
    // Check for empty bio
    if (this.bioInputString.length === 0) {
      this.bioResults.stats.bioIsEmpty = true;
      this.bioResults.style.bioHasStyleIssues = true;
      return;
    }
    // check for endless comment
    this.bioInputString = this.swallowComments(this.bioInputString);
    if (this.bioResults.style.hasEndlessComment) {
      this.bioResults.style.bioHasStyleIssues = true;
      return;
    }
    // assume no style issues
    this.bioResults.style.bioHasStyleIssues = false;

    // swallow any <br>
    this.bioInputString = this.swallowBr(this.bioInputString);

    // if auto generated from GEDCOM and testing this, report as style issue
    if (checkAutoGenerated) {
      let tmpLine = this.bioInputString.toLowerCase();
      if ((tmpLine.indexOf(Biography.AUTO_GENERATED)) > 0) {
        this.bioResults.style.bioHasStyleIssues = true;
        this.bioResults.style.bioIsAutoGenerated = true;
      }
    }

    // build a vector of each line in the bio then iterate
    this.getLines(this.bioInputString);
    let lineCount = this.bioLines.length;
    let currentIndex = 0;
    while (currentIndex < lineCount) {
      let line = this.bioLines[currentIndex].toLowerCase();
      // handle the case where there is no space before ending /
      // so it might start with a blank
      // TODO maybe report starting with a blank as a style issue?
      if (line.indexOf(Biography.REFERENCES_TAG) >= 0) {
        this.referencesIndex = currentIndex;
      } else {
        if (line.startsWith(Biography.CATEGORY_START)) {
          this.bioResults.stats.bioHasCategories = true;
          if (line.includes(Biography.UNSOURCED)) {
            this.bioResults.stats.bioIsMarkedUnsourced = true;
          }
        } else {
          if (line.startsWith(Biography.HEADING_START)) {
            this.evaluateHeadingLine(line, currentIndex);
          }       // end if a heading line
        }         // end if a category line
      }           // end if references tag
      currentIndex++;
    }
    // acknowlegements may go to end of bio
    if (this.acknowledgementsEndIndex < 0) {
      this.acknowledgementsEndIndex = lineCount;
    }
    let line = this.bioInputString.toLowerCase();
    if ((line.includes(Biography.UNSOURCED_TAG)) ||
          (line.includes(Biography.UNSOURCED_TAG2))) {
      this.bioResults.stats.bioIsMarkedUnsourced = true;
    }
    if (line.includes(Biography.QUESTIONABLE_TAG) ||
         (line.includes(Biography.UNCERTAIN_TAG)) ||
         (line.includes(Biography.DISPROVEN2_TAG)) ||
         (line.includes(Biography.DISPROVEN_TAG))) {
         this.bioResults.stats.bioIsUncertainExistance = true;
    }

    // Get the string that might contain <ref>xxx</ref> pairs
    let bioLineString = this.getBioLineString();
    this.findRef(bioLineString);
    this.findNamedRef(bioLineString);

    this.setBioStatisticsAndStyle();

    // Lose bio lines not considered to contain sources
    this.removeResearchNotes();
    this.removeAcknowledgements();

    if (this.bioResults.style.bioHasRefWithoutEnd) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
    return;
  }

  /**
   * Validate contents of bio
   * @return true if probably valid sources and no style issues, else false
   */
  validate() {

    let isValid = false;
    /*
     * Don't bother for empty bio, one already marked unsourced, uncertain existance
     * or the manager's own profile
     */
    if (!this.bioResults.stats.bioIsEmpty && 
        !this.bioResults.stats.bioIsMarkedUnsourced &&
        !this.bioResults.stats.bioIsUncertainExistance &&
        !this.bioResults.stats.bioIsUndated) {

      // Look for a partial string that makes it valid
      isValid = this.containsValidPartialSource(this.bioInputString.toLowerCase());

      /*
       * First validate strings after references. This will build a side effect of
       * a list of invalid span tags.
       * Next validate strings between Sources and <references />. This will update/build
       * a side effect list of invalid span tags.
       * Finally validate the references, looking at invalid span tags if needed.
       *
       * Strings after references and within named and unnamed ref tags are
       * validated to add those to the list of valid/invalid sources
       */
      if (!isValid) {
        isValid = this.validateReferenceStrings();
        if (this.validateRefStrings(this.refStringList)) {
          if (!isValid) {
            isValid = true;
          }
        }
        if (this.validateRefStrings(this.namedRefStringList)) {
          if (!isValid) {
            isValid = true;
          }
        }
        if (!isValid) {
          this.bioResults.sources.sourcesFound = false;
          isValid = false;
        }
      }
    }
    if (isValid) {
      this.bioResults.sources.sourcesFound = true;
    }
    return isValid;
  }

  /* *********************************************************************
   * ******************* PRIVATE METHODS *********************************
   * ******************* used by Parser **********************************
   * *********************************************************************
   */

  /*
   * Swallow comments
   * side effect set style if endless comment found
   * @param inStr
   * @return string with comments removed
  */
  swallowComments(inStr) {
    let outStr = "";
    /*
     * Find start of comment
     * Put everything before start in output string
     * Find end of comment, skip past the ending and start looking there
    */
    let pos = 0;               // starting position of the comment
    let endPos = 0;            // end position of the comment
    let len = inStr.length;    // length of input string
    pos = inStr.indexOf(Biography.START_OF_COMMENT);
    if (pos < 0) {
      outStr = inStr;         // no comments
    }
    while ((pos < len) && (pos >= 0)) {
      // get everything to start of comment unless comment is first line in bio
      if (pos > 0) {
        outStr = outStr + inStr.substring(endPos, pos - 1);
      }
      // Find end of comment
      endPos = inStr.indexOf(Biography.END_OF_COMMENT, pos);
      if (endPos > 0) {
        pos = endPos + 3;    // skip the --> and move starting position there
        if (pos <= len) {
          pos = inStr.indexOf(Biography.START_OF_COMMENT, pos);  // find next comment
          if (pos < 1) {
            outStr += inStr.substring(endPos + 3);
          }
        }
      } else {
        this.bioResults.style.hasEndlessComment = true;
        pos = inStr.length + 1;  // its an endless comment, just bail
      }
    }
    return outStr;
  }
  /* 
   * Swallow BR 
   * could be in the form <br> or <br/> or <br />
   * @param inStr
   * @return string with br removed
   */
  swallowBr(inStr) {
    let outStr = "";
    let pos = 0;
    let endPos = 0;
    let len = inStr.length;
    pos = inStr.indexOf(Biography.START_OF_BR);
    if (pos < 0) {
       outStr = inStr;         // no br
    } 
    while ((pos < len) && (pos >= 0)) {
      if (pos > 0) {
        outStr = outStr + inStr.substring(endPos, pos);
      }
      endPos = inStr.indexOf(Biography.END_BRACKET, pos);
      if (endPos > 0) {
        pos = endPos + 1;    // skip the /> and move starting position there
        if (pos <= len) {
          pos = inStr.indexOf(Biography.START_OF_BR, pos);  // find next comment
          if (pos < 1) {
            outStr += inStr.substring(endPos + 1);
          }
        }
      }
    }
    return outStr;
  }

  /*
   * Build an array of each line in the bio
   * lines are delimited by a newline
   * empty lines or those with only whitespace are eliminated
   * @param inStr bio string stripped of comments
   */
  getLines(inStr) {
    let splitString = inStr.split("\n");
    let line = "";
    let tmpString = "";
    let len = splitString.length;
    for (let i = 0; i < len; i++) {
      line = splitString[i];
      // line is nothing but ---- ignore it by replacing with spaces then
      // trimming
      tmpString = line.replace('-', ' ');
      tmpString = tmpString.trim();
      // Sanity check if the line with <references /> also has text following on same line
      if (tmpString.indexOf(Biography.REFERENCES_TAG) >= 0) {
        let endOfReferencesTag = tmpString.indexOf(Biography.END_BRACKET);
        if (endOfReferencesTag + 1 < tmpString.length) {
          // Oopsie. Add a line for references and another for the line
          // and report a style issue?
          let anotherLine = tmpString.substring(0, endOfReferencesTag + 1);
          this.bioLines.push(anotherLine);
          line = tmpString.substring(endOfReferencesTag + 2);
          if (!line.length === 0) {
            this.bioLines.push(tmpString);
          }
        } else {
          this.bioLines.push(tmpString);
        }
      } else {
        this.bioLines.push(line);
      }
    }
    return;
  }

  /* 
   * Process heading line to find Biography, Sources, Acknowledgements
   * set index to each section
   * Methods are used to find sections so that rules can specify 
   * alternate languages
   * @param inStr starting with ==
   * @param currentIndex into master list of strings
   */
  evaluateHeadingLine(inStr, currentIndex) {

    let headingText = "";
    let headingStartPos = 0;
    let headingLevel = 0;
    /*
     * the bioLineString should start with the larger of the start of the line
     * after the biography heading or 0
     * it should end with the smallest of the length of the bio string or
     * the first heading found after the biography heading
    */
    let len = inStr.length;
    while ((headingStartPos < len) && (headingLevel < 4)) {
      if (inStr.charAt(headingStartPos) === '=') {
        headingStartPos++;
        headingLevel++;                // number of =
      } else {
        // lose any leading ' for bold or italics
        let i = headingLevel;
        while ((i < len) && (inStr.charAt(i) === "'")) {
          i++;
        }
        headingText = (inStr.substring(i)).trim();
        headingStartPos = len + 1;       // break out of loop
      }
    }
    // Save index for this heading   
    if (this.isBiographyHeading(headingText)) {
      if (this.biographyIndex < 0) {
        this.biographyIndex = currentIndex;
      } else {
        if (this.researchNotesIndex > 0) {
          this.researchNotesEndIndex = currentIndex - 1;
        }
      }
    } else {
      if (this.isResearchNotesHeading(headingText)) {
            this.researchNotesIndex = currentIndex;
      } else {
        if (this.isSourcesHeading(headingText)) {
          if (headingLevel > 2) {
              this.bioResults.style.sourcesHeadingHasExtraEqual = true;
              this.bioResults.style.bioHasStyleIssues = true;
          }
          if (this.sourcesIndex < 0) {
            this.sourcesIndex = currentIndex;
            if (this.researchNotesIndex > 0) {
              this.researchNotesEndIndex = currentIndex - 1;
            }
            if (this.acknowledgementsIndex > 0) {
              this.acknowledgementsEndIndex = currentIndex - 1;
            }
          } else {
              //this.bioResults.style.bioHasMultipleSourceHeadings = true;
              //this.bioResults.style.bioHasStyleIssues = true;
          }
        } else {
          if (this.isAckHeading(headingText)) {
            if (headingLevel > 2) {
              this.bioResults.style.acknowledgementsHeadingHasExtraEqual = true;
              this.bioResults.style.bioHasStyleIssues = true;
            }
            if (this.sourcesIndex < 0) {
              this.bioResults.style.bioHasAcknowledgementsBeforeSources = true;
              this.bioResults.style.bioHasStyleIssues = true;
            }
            this.acknowledgementsIndex = currentIndex;
            if ((this.researchNotesIndex > 0) && (this.researchNotesEndIndex < 0)) {
               this.researchNotesEndIndex = currentIndex - 1;
            }
          } else {
            // TODO if this is before biography, add a style issue Heading
            // before Biography (aka biographyIndex < 0)
            // just a line
          } // endif Acknowledgements
        } // endif Sources
      } // endif Research Notes
    } // endif Biography
    return;
  }

  /*
   * Get string from bio to be searched for any inline <ref
   * the bioLineString should start with the beginning of the biography
   * or the line after the Biography heading whichever is last
   * it should end with the smallest of the length of the bio string or
   * the first heading found after the biography heading
   */
  getBioLineString() {

    let bioLinesString = "";
    let startIndex = 0;
    // Jump to the start of == Biography
    if (this.biographyIndex > 0 ) {
        startIndex = this.biographyIndex;
    }
    // assume it ends at end of bio then pick smallest
    // of Research Notes, Sources, references, acknowledgements
    // which is also after the start of the biography
    let endIndex = this.bioLines.length;
    if ((this.researchNotesIndex > 0) && (this.researchNotesIndex > startIndex)) {
      endIndex = this.researchNotesIndex;
    }
    if ((this.sourcesIndex > 0) && (this.sourcesIndex < endIndex)) {
      endIndex = this.sourcesIndex;
    }
    if ((this.referencesIndex > 0) &&
        (this.referencesIndex < endIndex)) {
      endIndex = this.referencesIndex;
    }
    if ((this.acknowledgementsIndex > 0) &&
        (this.acknowledgementsIndex < endIndex)) {
      endIndex = this.acknowledgementsIndex;
    }

    if (this.biographyIndex === endIndex) {
      this.bioResults.style.bioHeadingWithNoLinesFollowing = true;
      this.bioResults.style.bioHasStyleIssues = true;
    } else {
      if (endIndex >= 0) {
        while (startIndex < endIndex) {
          bioLinesString += this.bioLines[startIndex];
          startIndex++;
        }
      }
    }
    return bioLinesString;
  }

  /* 
   * Find <ref> </ref> pairs that don't have a name
   * @param bioLineString string to look in for pairs
   * adds contents of ref to refStringList
   */
  findRef(bioLineString) {

    let startOfRef = bioLineString.indexOf(Biography.REF_START);
    let endOfRef = bioLineString.indexOf(Biography.REF_END, startOfRef);     
    while ((startOfRef >= 0) && (!this.bioResults.style.bioHasRefWithoutEnd)) {
      if (endOfRef < 0) {
        // Oopsie, starting <ref> without an ending >
        this.bioResults.style.bioHasRefWithoutEnd = true;
        this.bioResults.style.bioHasStyleIssues = true;
      } else {
        // Now we should have the whole ref lose the <ref> and move past it
        if ((startOfRef + 5) < endOfRef) {
          startOfRef = startOfRef + 5;
        }
        let line = bioLineString.substring(startOfRef, endOfRef);
        this.refStringList.push(line);
        endOfRef++;
        if (endOfRef < bioLineString.length) {
          startOfRef = bioLineString.indexOf(Biography.REF_START, endOfRef);
          if (startOfRef > 0) {
            endOfRef = bioLineString.indexOf(Biography.REF_END, startOfRef);
          }
        }
      }
    }
    return;
  }

  /* 
   * Find named ref
   * which are pairs in the form <ref name= ></ref>
   * or in the form <ref name=xxxx />
   * @param bioLineString string to look in for pairs
   * adds contents of ref to namedRefStringList
   */
  findNamedRef(bioLineString) {

    let endOfRefNamed = -1;
    let endOfRef = -1;
    let end = -1;
    let bioLength = bioLineString.length;
    let startOfRef = bioLineString.indexOf(Biography.REF_START_NAMED);
    while (startOfRef >= 0) {
      endOfRef = bioLineString.indexOf(Biography.REF_END, startOfRef);
      endOfRefNamed = bioLineString.indexOf(Biography.REF_END_NAMED, startOfRef);
      if (endOfRef < 0) {
        endOfRef = bioLength;
      }
      if (endOfRefNamed < 0) {
        endOfRefNamed = bioLength;
      }
      // lose the <ref> portion and use first ending found
      if ((startOfRef + 5) < endOfRef) {
        startOfRef = startOfRef + 5;
      }
      end = endOfRef;
      if (endOfRef > endOfRefNamed) {
        end = endOfRefNamed;
      }
      // save just the part of the line after the name
      let line = bioLineString.substring(startOfRef, end);
      let refStart = line.indexOf(Biography.END_BRACKET);
      if (refStart > 0) {
        refStart++;
        this.namedRefStringList.push(line.substring(refStart));
      }

      // move past the ref
      end++;
      endOfRef++;
      if (end <= bioLength) {
        startOfRef = bioLineString.indexOf(Biography.REF_START_NAMED, end);
      } else {
        if (end > bioLength) {
          startOfRef = -1;        // we are done
        }
      }
    }
  }

  /*
   * Gather bio statistics and style issues
   * only examines items not considered in the parsing
   * Basic checks for the headings and content expected in the biography
   * Update results style
   */
  setBioStatisticsAndStyle() {
    this.bioResults.stats.totalBioLines = this.bioLines.length;
    if ((this.biographyIndex > 1) && !this.bioResults.stats.bioHasCategories) {
      this.bioResults.style.bioHasNonCategoryTestBeforeBiographyHeading = true;      // NOT a style issue
    }
    if (this.biographyIndex < 0) {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioIsMissingBiographyHeading = true;
    }
    if (this.sourcesIndex < 0) {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioIsMissingSourcesHeading = true;
    }
    if (this.referencesIndex < 0) {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioIsMissingReferencesTag = true;
    }
    if (this.bioResults.style.bioHasMultipleReferencesTags) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
    if (this.bioResults.style.misplacedLineCount < 0) {
      this.bioResults.style.misplacedLineCount = 0;
    }
    if (this.bioResults.style.misplacedLineCount > 0) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
    this.bioResults.stats.inlineReferencesCount =
         this.refStringList.length + this.namedRefStringList.length;

    this.bioResults.stats.possibleSourcesLineCount = this.acknowledgementsIndex - 1;
    if (this.bioResults.stats.possibleSourcesLineCount < 0) {
      this.bioResults.stats.possibleSourcesLineCount = this.bioLines.length;
    }
    this.bioResults.stats.possibleSourcesLineCount = this.bioResults.stats.possibleSourcesLineCount -
    this.referencesIndex + 1 + this.bioResults.style.misplacedLineCount;
    if (this.bioResults.style.bioHasAcknowledgementsBeforeSources) {
      this.bioResults.style.bioHasStyleIssues = true;
    }
  }

  /*
   * Determine if Biography heading
   * Uses rules to check for multiple languages
   * Adds bio headings to array of bio headings found
   * @param line to test
   * @return true if biography heading else false
   */
  isBiographyHeading(line) {
    let isBioHeading = false;
    let i = 0;
    while ((!isBioHeading) && (i < this.sourceRules.biographyHeadings.length)) {
      if (line.startsWith(this.sourceRules.biographyHeadings[i])) {
        isBioHeading = true;
        if (this.bioHeadingsFound.includes(line)) {
          this.bioResults.style.bioHasStyleIssues = true;
          this.bioResults.style.bioHasMultipleBioHeadings = true;
        } else {
          this.bioHeadingsFound.push(line);
        }
      }
      i++;
    }
    return isBioHeading;
  }
  /*
   * Determine if Research Notes heading
   * Uses rules to check for multiple languages
   * @param line to test
   * @return true if research notes heading else false
   */
  isResearchNotesHeading(line) {
    let isResearchNotesHeading = false;
    let i = 0;
    while ((!isResearchNotesHeading) && (i < this.sourceRules.researchNotesHeadings.length)) {
      if (line.startsWith(this.sourceRules.researchNotesHeadings[i])) {
        isResearchNotesHeading = true;
      }
      i++;
    }
    return isResearchNotesHeading;
  }

  /*
   * Determine if Sources heading
   * Uses rules to check for multiple languages
   * Adds sources headings to array of sources headings found
   * @param line to test
   * @return true if sources heading else false
   */
  isSourcesHeading(line) {
    let isSourcesHeading = false;
    let i = 0;
    while ((!isSourcesHeading) && (i < this.sourceRules.sourcesHeadings.length)) {
      if (line.startsWith(this.sourceRules.sourcesHeadings[i])) {
        isSourcesHeading = true;
        if (this.sourcesHeadingsFound.includes(line)) {
          this.bioResults.style.bioHasStyleIssues = true;
          this.bioResults.style.bioHasMultipleSourceHeadings = true;
        } else {
          this.sourcesHeadingsFound.push(line);
        }
      }
      i++;
    }
    return isSourcesHeading;
  }

  /*
   * Determine if Acknowledgements heading
   * Uses rules to check for multiple languages
   * @param line to test
   * @return true if acknowledgements heading else false
   */
  isAckHeading(line) {
    let isAckHeading = false;
    let i = 0;
    while ((!isAckHeading) && (i < this.sourceRules.acknowledgmentsHeadings.length)) {
      if (line.startsWith(this.sourceRules.acknowledgmentsHeadings[i])) {
        isAckHeading = true;
      }
      i++;
    }
    return isAckHeading;
  }

  /*
   * Remove Research Notes from bio lines
   * Remove lines between start of Research Notes
   * and end of Research Notes
   * Any content of Research Notes is not considered
   * as a source
   * Research Notes end when a Biography heading is found
   * or at the first Sources or Acknowledgements heading
   */
  removeResearchNotes() {
    let i = this.researchNotesIndex;
    let endIndex = this.researchNotesEndIndex;
    if (endIndex < 0) {
      endIndex = this.bioLines.length;
    }
    if (i > 0) {
      while (i <= endIndex) {
        this.bioLines[i] = "";
        i++;
      }
    }
  }

  /*
   * Remove acknowledgements from bio lines
   * Remove lines between start of Acknowledgements
   * and end of Acknowledgements
   * Any content of Acknowledgements is not considered
   * as a source
   * Acknowledgements end when a heading is found
   * or at the end of the biography
   */
  removeAcknowledgements() {
    let i = this.acknowledgementsIndex;
    let endIndex = this.acknowledgementsEndIndex;
    if (endIndex < 0) {
         endIndex = this.bioLines.length;
    }
    if (i > 0) {
      while (i <= endIndex) {
        this.bioLines[i] = "";
        i++;
      }
    }
  }


  /* *********************************************************************
   * ******************* PRIVATE METHODS *********************************
   * ******************* used by Validator *******************************
   * *********************************************************************
   */

  /*
   * Examine a single line to see if it is a valid source
   * Adds line to array of valid or invalid sources
   * @param mixedCaseLine line to test (and report)
   * @return true if valid else false
   */
  isValidSource(mixedCaseLine) {

    let isValid = false;                          // assume guilty 

    // just ignore starting *
    if (mixedCaseLine.startsWith("*")) {
         mixedCaseLine = mixedCaseLine.substring(1);
    }
    mixedCaseLine = mixedCaseLine.trim();
    
    // perform tests on lower case line
    let line = mixedCaseLine.toLowerCase().trim();
   
    // ignore starting source:
    if ((line.length > 0) && (line.startsWith(Biography.SOURCE_START))) {
        line = line.substring(7);
        line = line.trim();
    }
    // It takes a minimum number of characters to be valid
    if (line.length >= Biography.MIN_SOURCE_LEN) {

      if (!this.isInvalidStandAloneSource(line)) {
        line = line.trim();
        // FindAGrave citations may have partial strings that
        // would otherwise show up as invalid
        if (this.isFindAGraveCitation(line)) {
          isValid = true;
        } else {

          // Does line contain a phrase on the invalid partial source list?
          let invalidSourceString = this.onPartialSourceList(line);
          if (invalidSourceString.length > 0) {
            isValid = false;
          } else {
            // Check for line that starts with something on the invalid start partial list
            let partialSourceLine = "";
            let found = false;
            let max = this.sourceRules.invalidStartPartialSourceList.length;
            let i = 0;
            while (!found && (i < max)) {
              partialSourceLine = this.sourceRules.invalidStartPartialSourceList[i];
              if (line.startsWith(partialSourceLine)) {
                found = true;
              }
              i++;
            }
            if (found) {
              isValid = false;
            } else {

              // TODO can you refactor so this uses a plugin architecture?

              // Some other things to check
              if (!this.isJustCensus(line)) {
                if (!this.invalidFamilyTree(line)) {
                  if (!this.isJustRepository(line)) {
                    if (!this.isJustGedcomCrud(line)) {
                      // TODO add more logic to eliminate sources as valid
                      // TODO is the manager's name a valid source (this is hard)
                      // TODO add logic to check for just the name followed by grave
                      isValid = true;
                    }
                  }
                }
              }
            }     // endif starts with invalid phrase
          }       // endif contains a phrase on invalid partial source list
        }         // endif a findagrave citation
      }           // endif on the list of invalid sources
    }             // endif too short when stripped of whitespace

    // Save line for reporting
    if (isValid) { 
      this.bioResults.sources.validSource.push(mixedCaseLine);
    } else {
      this.bioResults.sources.invalidSource.push(mixedCaseLine);
    }
    return isValid;
  }

  /*
   * Determine if valid standalone source
   * @param line input source string
   * @return true if on the standalone list of invalid sources
   */
  isInvalidStandAloneSource(line) {

// TODO reverse this backward logic to check isValidStandAloneSource

    let isInvalidStandAloneSource = false;
    if (this.sourceRules.invalidSourceList.includes(line)) {
      isInvalidStandAloneSource = true;
    } else {
      if (this.tooOldToRemember && !isInvalidStandAloneSource) {
        if (this.sourceRules.tooOldToRememberSourceList.includes(line)) {
          isInvalidStandAloneSource = true;
        }
      }
      if ((this.isPre1700 || this.treatAsPre1700)
           && !isInvalidStandAloneSource) {
        if (this.sourceRules.invalidSourceListPre1700.includes(line)) {
          isInvalidStandAloneSource = true;
        }
      }
      if (this.bioResults.isPre1500 && !isInvalidStandAloneSource) {
        // TODO add more pre1500 validation
      }
    }
    return isInvalidStandAloneSource;
  }

  /*
   * Determine if found on partial source list
   * @param line input source string
   * @return string if on the partial source list
   */
  onPartialSourceList(line) {

    let foundOnPartialSourceList = false;
    let invalidSourceString = "";
    let partialSourceLine = "";
    let i = 0;
    while (!foundOnPartialSourceList && (i < this.sourceRules.invalidPartialSourceList.length)) {
      partialSourceLine = this.sourceRules.invalidPartialSourceList[i];
      if (line.includes(partialSourceLine)) {
        foundOnPartialSourceList = true;
        invalidSourceString = partialSourceLine;
      }
      i++;
    }
    if (this.tooOldToRemember && !foundOnPartialSourceList) {
      i = 0;
      while (!foundOnPartialSourceList && (i < this.sourceRules.invalidPartialSourceListTooOld.length)) {
        partialSourceLine = this.sourceRules.invalidPartialSourceListTooOld[i];
        if (line.includes(partialSourceLine)) {
          foundOnPartialSourceList = true;
          invalidSourceString = partialSourceLine;
        }
        i++;
      }
    }
    if ((this.isPre1700 || this.treatAsPre1700)
         && !foundOnPartialSourceList) {
      i = 0;
      while (!foundOnPartialSourceList && (i < this.sourceRules.invalidPartialSourceListPre1700.length)) {
        partialSourceLine = this.sourceRules.invalidPartialSourceListPre1700[i];
        if (line.includes(partialSourceLine)) {
          foundOnPartialSourceList = true;
          invalidSourceString = partialSourceLine;
        }
        i++;
      }
    }
    return invalidSourceString;
  }

  /*
   * Does string contain a phrase on the valid partial source list
   * This is a test case for strings that if found mean the profile is sourced
   * (thanks to David S for the test case)
   * @param str string to evaluate
   * @return true if string found, else false
   */
  containsValidPartialSource(str) {
    let found = false;
    let partialSourceLine = "";
    let i = 0;
    while (!found && (i < this.sourceRules.validPartialSourceList.length)) {
      partialSourceLine = this.sourceRules.validPartialSourceList[i];
      if (str.includes(partialSourceLine)) {
        found = true;
      }
      i++;
    }
    return found;
  }

  /* 
   * Validate content in <ref> tags
   * invalidSpanTargetList is used if line contains a span reference
   * @param refStrings array of string found within ref tag
   * @return true if at least one is valid else false
   */
  validateRefStrings(refStrings) {

    let isValid = false;                  // guilty until proven innnocent
    let line = "";
    let i = 0;
    while (i < refStrings.length) {
      line = refStrings[i];
      if (line.length > 0) {

        // Check span target if ref contains a span reference
        let startPos = line.indexOf(Biography.SPAN_REFERENCE_START);
        if (startPos >= 0) {
          startPos = startPos + 3;
          let endPos = line.indexOf("|");
          if (endPos < 0) {
            endPos = line.indexOf(Biography.SPAN_REFERENCE_END);
          }
          if ((endPos > 0) && (startPos < endPos)) {
            let spanId = line.substring(startPos, endPos);
            if (!this.invalidSpanTargetList.includes(spanId)) {
              isValid = true;
            }
          }
        } else {
          if (this.isValidSource(line)) {
            if (!isValid) {          // first one found?
              isValid = true;
            }
          }
        }
      }
      i++;
    }
    return isValid;
  }

  /* 
   * Validate all the strings after the == Sources heading
   * but before Acknowledgements or the end of the biography
   * @return true if at lease one valid else false
   */
  validateReferenceStrings() {
    let isValid = false;

    // start at the first of Sources or <references /> if neither, nothing to do
    // assume it is so messed up nothing to process
    let index = this.sourcesIndex + 1;
    if (index <= 0) {
      index = this.referencesIndex + 1;
    }
    if (index <= 0) {
      index = this.bioLines.length;
    }
    let lastIndex = this.bioLines.length;
    let line = "";
    let nextIndex = index + 1;
    while (index < lastIndex) {
      let mixedCaseLine = this.bioLines[index];
      line = mixedCaseLine.toLowerCase();
      // if line nothing but --- ignore it
      let tmpString = line.replaceAll('-', ' ');
      tmpString = tmpString.trim();
      if (tmpString.length <= 0) {
          line = tmpString;
      }
      nextIndex = index + 1;
      // Skip the <references line and any heading line or empty line
      if ((!line.startsWith(Biography.REFERENCES_TAG)) &&
          (!line.startsWith(Biography.HEADING_START)) &&
          (line.length > 0)) {

        // Now gather all lines from this line until an empty line
        // or a line that starts with * to test as the source
        let combinedLine = mixedCaseLine;
        let foundEndOfSource = false;
        while ((!foundEndOfSource) && (nextIndex < lastIndex)) {
          if (nextIndex < lastIndex) {
            // check next line
            let nextLine = this.bioLines[nextIndex];
            if (nextLine.length === 0) {
              foundEndOfSource = true;
            } else {
              if ((nextLine.startsWith("*")) || (nextLine.startsWith("--")) ||
                  (nextLine.startsWith("#")) ||
                  (nextLine.startsWith(Biography.REFERENCES_TAG)) ||
                  (nextLine.startsWith(Biography.HEADING_START))) {
                foundEndOfSource = true;
              } else {
                combinedLine = combinedLine + " " + nextLine;
                nextIndex++;
              }
            }
          }
        }
        mixedCaseLine = combinedLine;

        // At this point, the line should not contain an inline <ref
        // Unless all the ref are between Sources and references
        if ((line.indexOf("<ref") >= 0) && (index > this.referencesIndex)) {
          this.bioResults.style.bioHasStyleIssues = true;
          this.bioResults.style.bioHasRefAfterReferences = true;
        }
        if ((index < this.referencesIndex) || 
            (this.referencesIndex < 0)) {
          this.bioResults.style.misplacedLineCount++;
        }
        let spanTargetStartPos = mixedCaseLine.indexOf(Biography.SPAN_TARGET_START);
        if (spanTargetStartPos < 0) {
          if (this.isValidSource(mixedCaseLine)) {
            if (!isValid) {
              isValid = true;       // first one found
            }
          }
        } else {
          if (this.isValidSpanTarget(mixedCaseLine)) {
            if (!isValid) {
              isValid = true;       // first one found
            }
          }
        }
      }
      index = nextIndex;
    }
    return isValid;
  }

  /*
   * Validate string that is a span target
   * Side effect: add to invalidSpanTargetList for invalid target
   * @param line line to be evaluated
   * @param startPos starting position in line
   * @return true if valid else false
   */
  isValidSpanTarget(mixedCaseLine) {
    let isValid = false;
    let spanTargetStartPos = mixedCaseLine.indexOf(Biography.SPAN_TARGET_START);
    let beforeSpan = mixedCaseLine.substring(0, spanTargetStartPos - 1);

    // extract target id found here <span id='ID'>
    let pos = mixedCaseLine.indexOf("=");
    pos++; // skip the =
    pos++; // skip the '
    let endPos = mixedCaseLine.indexOf("'", pos);
    let spanId = mixedCaseLine.substring(pos, endPos);

    // Process the line starting after the end of the span target
    // but it might have source or repository before the <span>
    pos = mixedCaseLine.indexOf(Biography.SPAN_TARGET_END);
    if (pos > 0) {
      pos = pos + Biography.SPAN_TARGET_END.length;
    } else {
      this.bioResults.style.bioHasStyleIssues = true;
      this.bioResults.style.bioHasSpanWithoutEndingSpan = true;
      pos = mixedCaseLine.length;
    }
    if (pos < mixedCaseLine.length) {
      // something after ending span
      mixedCaseLine = beforeSpan + " " + mixedCaseLine.substring(pos).trim();
      isValid = this.isValidSource(mixedCaseLine);
    }
    if (!isValid) {
        this.invalidSpanTargetList.push(spanId);
    }
    return isValid;
  }

  /*
   * Check for a line that is just
   * some collection of numbers and digits then census
   * @param line to check
   * @return true if just a census line else false
   */
  isJustCensus(line) {

    let isCensus = false;
    line = line.replace(/[^a-z ]/g, "");
    line = line.trim();
    if (this.sourceRules.censusStrings.includes(line)) {
      isCensus = true;
    } else {
      // get the census string portion of the line
      let theStr = this.hasCensusString(line);
      if (theStr.length > 0) {
        // lose census, at, on and everything not an alpha char
        line = line.replace(theStr, "");
        line = line.replace(/at/g, "");
        line = line.replace(/on/g, "");
        line = line.replace(/[^a-z]/g, "");
        line = line.trim();
        if (line.length === 0) {
          isCensus = true;
        } else {
          // lose things like ancestry, familysearch by themselves
          if (this.sourceRules.invalidSourceList.includes(line)) {
            isCensus = true;
          }
        }
      }
    }
    if (isCensus) {
      return true;
    } else {
      return false;
    }
  }
  /*
  * Does line contain a census
  * @param line line to test
  * @return census string if line contains census string
  */
  hasCensusString(line) {
    let theStr = "";
    let isCensusString = false;
    let i = 0;
    while ((!isCensusString) && (i < this.sourceRules.censusStrings.length)) {
      if (line.includes(this.sourceRules.censusStrings[i])) {
        isCensusString = true;
        theStr = this.sourceRules.censusStrings[i];
      }
      i++;
    }
    return theStr;
  }

  /*
   * Check for a line that contains both findagrave and created by
   * created by is an invalid partial source string UNLESS part of a findagrave
   * citation
   * @param line to test
   * @return true if line contains both findagrave and created by
   */
  isFindAGraveCitation(line) {
    if (((line.indexOf("findagrave")) >= 0) && 
        ((line.indexOf("created by")) >=0)) {
      return true;
    } else {
      return false;
    }
  }

  /*
   * Check for Ancestry Family Trees without a tree id 
   * or a tree id less than 4 characters, such as 0
   * @param line to test
   * @return true if Ancestry tree seems to have an id
   */
  invalidFamilyTree(line) {
    let isInvalidFamilyTree = false;
    let startPos = line.indexOf("ancestry family tree");
    if (startPos < 0) {
      startPos = line.indexOf("public member tree");
      if (startPos < 0) {
        startPos = line.indexOf("ancestry member family tree");
      }
      if (startPos < 0) {
        startPos = line.indexOf("{{ancestry tree");
      }
    }
    if (startPos >= 0) {
      line = line.substring(startPos);
      let hasId = false;
      let matches = line.match(/(\d+)/g);
      if (matches) {
        for (let i = 0; i < matches.length; i++) {
          if (matches[i].length > 4) {
            hasId = true;
          }
        }
      }
      if (!hasId) {
        isInvalidFamilyTree = true;
      }
    }
    return isInvalidFamilyTree;
  }

  /*
   * Check for just a repository
   * @param line to test
   * @return true if this is just a repository line
   */
  isJustRepository(line) {
    let isRepository = false;
    if (line.includes("repository")) {
      let repositoryStrings = [
        "ancestry",
        "com",
        "name",
        "address",
        "http",
        "www",
        "the church of jesus christ of latter-day saints",
        "note",
        "family history library",
        "n west temple street",
        "salt lake city",
        "utah",
        "usa",
        "360 west 4800 north",
        "provo",
        "ut",
        "city",
        "country", 
        "not given",
        "e-mail",
        "phone number",
        "internet",
        "cont",
        "unknown",
      ];
      for (let i = 0; i < repositoryStrings.length; i++) {
        let str = repositoryStrings[i];
        line = line.replaceAll(str, "");
      }
      line = line.replace(/r-/g, "");
      line = line.replace(/#r/g, "");
      line = line.replace(/[^a-z]/g, "");
      line = line.trim();
      if (line.length > 0) {
        if (line === "repository") {
          isRepository = true;
        }
      }
    }
    return isRepository;
  }

  /*
   * check for GEDCOM crud see Suggestion 853
   * in most cases this is in the Bio not sources, 
   * so you don't see it
   * @param line line to test
   * @return true if line contains GEDCOM crud and nothing else
   */
  isJustGedcomCrud(line) {
    let isGedcomCrud = false;
    let crudStrings = [
      "user id",
      "data changed",
      "lds endowment",
      "lds baptism",
      "record file number",
      "submitter",
      "object",
      "color",
      "upd",
      "ppexclude",
    ];
    if (line.startsWith(":")) {
      line = line.substring(1);
    }
    line = line.trim();
    let i = 0;
    while ((i < crudStrings.length) && (!isGedcomCrud)) {
      if (line.startsWith(crudStrings[i])) {
        isGedcomCrud = true;
      }
      i++;
    }
    return isGedcomCrud;
  }

}


/***/ }),

/***/ "./src/features/bioCheck/BiographyResults.js":
/*!***************************************************!*\
  !*** ./src/features/bioCheck/BiographyResults.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiographyResults": () => (/* binding */ BiographyResults)
/* harmony export */ });
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * Hold results for parse and validate a WikiTree biography
 */
class BiographyResults {

   bioResults = {

      stats: {
         bioIsEmpty: false,
         bioHasCategories: false,
         bioIsMarkedUnsourced: false,
         bioIsUncertainExistance: false,
         bioIsUndated: false,
         totalBioLines: 0,
         inlineReferencesCount: 0,      // number of <ref>
         possibleSourcesLineCount: 0   // number of lines that might contain sources
      },
      style: {
         bioHasNonCategoryTestBeforeBiographyHeading: false,
         bioHasStyleIssues: false,
         hasEndlessComment: false,
         bioIsMissingBiographyHeading: false,
         bioHeadingWithNoLinesFollowing: false,
         bioHasMultipleBioHeadings: false,
         bioHasRefWithoutEnd: false,
         bioHasSpanWithoutEndingSpan: false,
         bioIsMissingSourcesHeading: false,
         sourcesHeadingHasExtraEqual: false,
         bioHasMultipleSourceHeadings: false,
         misplacedLineCount: 0,      // between Sources and <references /> 
         bioIsMissingReferencesTag: false,
         bioHasMultipleReferencesTags: false,
         bioHasRefAfterReferences: false,
         acknowledgementsHeadingHasExtraEqual: false,
         bioHasAcknowledgementsBeforeSources: false,
         bioIsAutoGenerated: false
      },
      sources: {
         sourcesFound: false,

         // Invalid sources that were found - each an array
         // might not need/want these, depends on reporting
         invalidSource: [],
         //invalidStandAloneSource: [],
         //invalidPartialSource: [],
         //invalidStartPartialSource: [],
         //invalidSpanTargetSource: [],
         validSource: [],
      }
   };

   constructor() {
   }

   getResults() {
     return this.bioResults;
   }
}


/***/ }),

/***/ "./src/features/bioCheck/PersonDate.js":
/*!*********************************************!*\
  !*** ./src/features/bioCheck/PersonDate.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PersonDate": () => (/* binding */ PersonDate)
/* harmony export */ });
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * Contains information about a WikiTree Profile
 * only contains a subset of the complete set of data available
 */
class PersonDate {

  static TOO_OLD_TO_REMEMBER_DEATH = 100;
  static TOO_OLD_TO_REMEMBER_BIRTH = 150;

  personDate = {
    birthDate: null,                // birth date as Date
    deathDate: null,                // death date as Date
    birthDateString: "",            // birth date string as from server
    deathDateString: "",            // death date string as from server
    hasBirthDate: true,
    hasDeathDate: true,
    lastDateCheckedEmpty: false,   // HACK
    oneYearAgo: null,
    isPre1700: false,
    isPre1500: false,
    tooOldToRemember: false,
    personUndated: false,
  }

  /**
   * constructor
   */
  constructor() {
  }

  /**
   * Initialize person dates from null, 0000 or various forms
   * @param bDay birth date
   * @param dDay death date
   */
  initWithDates(bDay, dDay) {
    if (bDay != null) {
      this.personDate.birthDateString = bDay;
      this.personDate.birthDate = this.getDate(this.personDate.birthDateString);
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasBirthDate = false;
    }
    if (dDay != null) {
      this.personDate.deathDateString = dDay;
      this.personDate.deathDate = this.getDate(this.personDate.deathDateString);
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasDeathDate = false;
    }

    // Go ahead and see if pre1500, pre1700 or too old
    this.isPersonPre1500();
    this.isPersonPre1700();
    this.mustBeOpen();
  }

  /**
   * Initialize person dates
   * @param profileObj containing the profile
   */
  init(profileObj) {

    if (profileObj.BirthDate != null) {
      this.personDate.birthDateString = profileObj.BirthDate;
      this.personDate.birthDate = this.getDate(this.personDate.birthDateString);
    } else {
      if (profileObj.BirthDateDecade != null) {
        this.personDate.birthDateString = profileObj.BirthDateDecade.slice(0, -1);
        this.personDate.birthDate = this.getDate(this.personDate.birthDateString);
      }
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasBirthDate = false;
    }
    if (profileObj.DeathDate != null) {
      this.personDate.deathDateString = profileObj.DeathDate;
      this.personDate.deathDate = this.getDate(this.personDate.deathDateString);
    } else {
      if (profileObj.DeathDateDecade != null) {
        this.personDate.deathDateString = profileObj.DeathDateDecade.slice(0, -1);
        this.personDate.deathDate = this.getDate(this.personDate.deathDateString);
      }
    }
    if (this.lastDateCheckedEmpty) {
      this.personDate.hasDeathDate = false;
    }

    // Go ahead and see if pre1500, pre1700 or too old
    this.isPersonPre1500();
    this.isPersonPre1700();
    this.mustBeOpen();

  }

  /**
   * Convert date from form returned by server to a Date
   * The server may have 00 for any year, month, day
   * In that case, the value 1 is used
   * @param dateString as input from server in the form 0000-00-00
   * @return Date for the input string
   */
  getDate(dateString) {
    let year = 0;             // default in case of 0 values
    let month = 0;
    let day = 0;
    this.lastDateCheckedEmpty = false;    // hack hack
    let splitString = dateString.split("-");
    let len = splitString.length;
    if (len > 0) {
      year = splitString[0];
    }
    if (len > 1) {
      month = splitString[1];
    }
    if (len >= 2) {
      day = splitString[2];
    }
    if ((year + month + day) === 0) {
      this.lastDateCheckedEmpty = true;
    }
    if (year === 0) {
      year = 1;
    }
    if (month === 0) {
      month = 1;
    }
    if (day === 0) {
      day = 1;
    }
    return (new Date(year, month, day));
  }

  /**
   * Is the person before 1500
   * @return true if either birth or death date before 1500
   */
  isPersonPre1500() {
    let theYear1500 = new Date("1500-01-01");
    if (this.personDate.birthDate != null) {
      if (this.personDate.birthDate < theYear1500) {
        this.isPre1500 = true;
      }
    }
    if (this.personDate.deathDate != null) {
      if (this.personDate.deathDate < theYear1500) {
        this.isPre1500 = true;
      }
    }
    if (this.isPre1500) {
      this.isPre1500 = true;
      this.isPre1700 = true;
      this.tooOldToRemember = true;
    }
    return this.isPre1500;
  }

  /**
   * Is the person before 1700
   * @return true if either birth or death date before 1700
   */
  isPersonPre1700() {
    let theYear1700 = new Date("1700-01-01");
    if (this.personDate.birthDate != null) {
      if (this.personDate.birthDate < theYear1700) {
        this.isPre1700 = true;
      }
    }
    if (this.personDate.deathDate != null) {
      if (this.personDate.deathDate < theYear1700) {
        this.isPre1700 = true;
      }
    }
    if (this.isPre1700) {
      this.tooOldToRemember = true;
    }
    return this.isPre1700;
  }
  /**
   * Is the person born > 150 years ago or died > 100 years ago
   * @return true if born > 150 years ago or died > 100 years ago
   */
  mustBeOpen() {
    let today = new Date();
    let year = today.getFullYear();
    let month = today.getMonth();
    let day = today.getDate();
    let earliestMemoryBeforeDeath = new Date(year - this.TOO_OLD_TO_REMEMBER_DEATH, month, day);
    let earliestMemoryBeforeBirth = new Date(year - this.TOO_OLD_TO_REMEMBER_BIRTH, month, day);
    if (this.personDate.birthDate != null) {
      if (this.personDate.birthDate < earliestMemoryBeforeBirth) {
        this.tooOldToRemember = true;
      }
    }
    if (this.personDate.deathDate != null) {
      if (this.personDate.deathDate < earliestMemoryBeforeDeath) {
        this.tooOldToRemember = true;
      }
    }
    /*
     * Since you already have today, pick up the date to use for
     * a source will be entered by xxxx tests
    */
    this.personDate.oneYearAgo = new Date(year - 1, month, day);
    
    return this.tooOldToRemember;
  }

  /**
   * Does the profile lack dates
   * @return true if profile has neither birth nor death date
   */
  isUndated() {
    if (!this.personDate.hasBirthDate && !this.personDate.hasDeathDate) {
      this.isPre1500 = true;
      this.isPre1700 = true;
      this.tooOldToRemember = true;
      return true;
    } else {
      return false;
    }
  }

  /**
   * Get birth date
   * @return birth date as Date
  */
  getBirthDate() {
    return this.personDate.birthDate;
  }
  /**
   * Get death date
   * @return death date as Date
  */
  getDeathDate() {
    return this.personDate.deathDate;
  }

  /**
   * Convert date to a display format
   * @param true to get birth date, else death date
   * @return string in the form yyyy mon dd
   */
  getReportDate(isBirth) {

    // handle cases without any date. sigh.
    let dateString = "";
    let hasDate = this.personDate.hasDeathDate;
    if (isBirth) {
      hasDate = this.personDate.hasBirthDate;
      if (hasDate) {
        dateString = this.personDate.birthDateString;
      }
    } else {
      if (hasDate) {
        dateString = this.personDate.deathDateString;
      }
    }
    let displayDate = "";
    if (hasDate) {
      let year = 0;             // default in case of 0 values
      let month = 0;
      let day = 0;
      let splitString = dateString.split("-");
      let len = splitString.length;
      if (len > 0) {
        year = splitString[0];
      }
      if (len > 1) {
        month = splitString[1];
      }
      if (len >= 2) {
        day = splitString[2];
      }
      if (day > 0) {
        displayDate = day + " ";
      }
      if (month > 0) {
        let months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        let monthNumber = parseInt(month);
        let monthName = months[monthNumber-1];
        displayDate += monthName + " ";
      }
      if (year > 0) {
        displayDate += year;
      }
    }
    return displayDate;
  }

}


/***/ }),

/***/ "./src/features/bioCheck/SourceRules.js":
/*!**********************************************!*\
  !*** ./src/features/bioCheck/SourceRules.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SourceRules": () => (/* binding */ SourceRules)
/* harmony export */ });
/*
The MIT License (MIT)

Copyright (c) 2022 Kathryn J Knight

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
* Rules for identifying sources in a biography that are not valid
* Intended to be a singleton and immutable
* and look like what could be read from database tables
*/
class SourceRules {

  // Valid text for biography heading
  biographyHeadings = [
    "biography",
    "biographie",
    "biografia",
    "biografie",
    "biografi",
    "elämäntarina",
    "Æviskrá",
    "bographie",
    "biografijo",
    "biografía",
  ];
  // Valid text for sources heading
  sourcesHeadings = [
    "sources",
    "quellen",
    "bronnen",
    "fuentes",
    "lähteet",
    "fonti",
    "kallor",
    "heimildir",
    "källor",
    "fontes",
    "kilder",
    "źródła",
    "izvor",
  ];
  // Valid text for research notes heading
  researchNotesHeadings = [
    "research notes",
    "notes de recherche",
    "onderzoeksnotities",
    "opmerkingen",
    "bemerkungen zur nachforschung",
    "forschungsnotizen",
    "notas de investigación",
    "note di ricerca",
    "forskningsanteckningar",
    "forskningsnotater",
    "notas de pesquisa",
    "forskningsnotater",
    "tutkimustiedot",
    "notatki badawcze",
    "raziskovalne opombe",
    "viittaukset",
    "rannsóknarnótur",
  ];
  // Valid text for acknowledgements heading
  acknowledgmentsHeadings = [
    "acknowledgements",
    "acknowledgments",
    "acknowledgement",
    "acknowledgment",
    "remerciements",
    "dankbetuiging",
    "anerkennung",
    "danksagungen",
    "agradecimientos",
    "ringraziamenti",
    "dankwoord",
    "erkännanden",
    "reconhecimentos",
    "riconoscimenti",
    "anerkendelser",
    "anerkjennelser",
    "bekräftelser",
    "tunnustukset",
    "podziękowanie",
    "priznanja",
  ];
  // strings that identify a census source
  // when used by itself or with nothing other than
  // date are not a valid source
  censusStrings = [
    "census",
    "recensement",
    "bevolkingsregister",
    "volkszählung",
    "censo",
    "censimento",
    "volkstelling",
    "folketælling",
    "telling",
    "folkräkning",
    "väestönlaskenta",
    "spis",
    "ludności",
    "popis",
    "väestönlaskenta",
    "manntal",
    "folketelling",
    "folkräkning",
    "us federal census",
    "united states federal census",
    "united states census",
    "us census",
    "u.s. census",
    "us census returns",
    "federal census",
    "swedish census",
    "canada census",
    "census of canada",
    "canadian census",
    "england census",
    "irish census",
    "ireland census",
    "census information",
    "new york state census",
    "iowa state census",
    "scotland census",
  ];

  /* order by length then alpha, but for efficiency
   * since most profiles are English, that is first
   * Note: logic checks for at least 15 characters so
   * shorter are commented out, but kept in case 
   * this is too aggressive
   * invalidSourceList are strings on a line by themselves
   */
  invalidSourceList = [
  /*
    ".",
    "*",
    "bmd",
    "---",
    "ibid",
    "----",
    "bible",
    "census",
    "family",
    "freebmd",
    "hinshaw",
    "ancestry",
    "footnote",
    "geneanet",
    "research",
    "see also",
    "footnotes",
    "see also:",
    "we relate",
    "findagrave",
    "footnotes:",
    "myheritage",
    "ancestrycom",
    "ancestry.uk",
    "ancestry.ca",
    "bdm records",
    "my heritage",
    "my research",
    "will follow",
    "ancestry.com",
    "familysearch",
    "family bible",
    "family trees",
    "find a grave",
    "find-a-grave",
    "find my past",
    "source list:",
    "ancestry.com:",
    "billiongraves",
    "family member",
    "family papers",
    "family search",
    "needs sources",
    ":source list:",
    "source needed",
    "we relate web",
    "ancestry.co.uk",
    "ancestrydotcom",
    "billion graves",
    "census records",
    "church records",
    "family history",
    "family records",
    "findagrave.com",
    "freebmd.org.uk",
    "internet files",
    "my family tree",
    "myheritage.com",
    "parish records",
    "passenger list",
    "'''see also'''",
    */
    "ancestry source",
    "census records.",
    "familysearchorg",
    "family accounts",
    "family research",
    "online research",
    "own family tree",
    "title: marriage",
    "'''see also:'''",
    "www.ancestry.ca",
    "www.bms2000.org",
    "familysearch.org",
    "family documents",
    "family knowledge",
    "findmypast.co.uk",
    "'''footnotes:'''",
    "internet records",
    "personal records",
    "research records",
    "www.ancestry.com",
    "acknowledgements:",
    "ancestry research",
    "familysearch tree",
    "family collection",
    "family tree files",
    "fellow researcher",
    "scotland's people",
    "wiki, family tree",
    ":'''footnotes:'''",
    "personal research",
    "private genealogy",
    "'''source list'''",
    ":'''source list'''",
    "'''source list:'''",
    "cemetery headstone",
    "citing this record",
    "family information",
    "newspaper obituary",
    "source information",
    "title: death index",
    "wwwfamilysearchorg",
    "www.ancestry.co.uk",
    "www.gencircles.com",
    "www.myheritage.com",
    "{{citation needed}}",
    "citing this record:",
    "familysearch search",
    "my heritage records",
    "my tree on ancestry",
    ":'''source list:'''",
    "real estate records",
    "ancestry family tree",
    "from family records.",
    "personal family tree",
    "personal information",
    "uk census; bmd index", 
    "www.familysearch.org",
    "ancestry family trees",
    "ancestry family site.",
    "family search records",
    "mormon church records",
    "replace this citation",
    "ancestry and documents",
    "scotlandspeople.gov.uk",
    "ancestry tree & sources",
    "family tree on ancestry",
    "personal family records",
    "no sources at this time",
    "family search family tree",
    "scotland's people website",
    "ancestry and family search",
    "www.scotlandspeople.gov.uk",
    "us census, public records.",
    "family tree on familysearch",
    "social security death index",
    "sources are on my family tree",
    "familysearch.org ancestry.com",
    "ancestry.com familysearch.org",
    "'''footnotes and citations:'''",
    ":'''footnotes and citations:'''",
    "family search files on internet",
    "online trees. will add sources.",
    "personal knowledge , census reports",
    "a source is still needed for this data.",
    "social security applications and claims",
    "a source for this information is needed",
    "a source for this information is needed.",
    "replace this citation if there is another source",
    "personal recollection, as told to me by their relative. notes and sources in their possession.",
    "michael lechner,",
    "virginia hanks",
    "teresa a. theodore",
    "michael eneriis",
    /*
    "spis",
    "censo",
    "popis",
    "badania",
    "ricerca",
    "se aven",
    "se även",
    "se også",
    "sukupuu",
    "telling",
    "zie ook",
    "ættartré",
    "ludności",
    "pesquisa",
    "se också",
    "stamboom",
    "tutkimus",
    "forschung",
    "forskning",
    "onderzoek",
    "recherche",
    "slægtstræ",
    "slektstre",
    "släktträd",
    "volgt nog",
    "bron nodig",
    "censimento",
    "familietre",
    "katso myös",
    "katso myös",
    "rannsóknir",
    "sjá einnig",
    "siehe auch",
    "voir aussi",
    "zobacz też",
    "familie træ",
    "folkräkning",
    "poglej tudi",
    "recensement",
    "veja também",
    "ver tambien",
    "familiebibel",
    "folketælling",
    "guarda anche",
    "källa behövs",
    "potreben vir",
    "raziskovanje",
    "volkszählung",
    "volkstelling",
    "bronnen nodig",
    "familienbibel",
    "familie bibel",
    "investigación",
    "nachforschung",
    "perheraamattu",
    "source requise",
    "voir également",
    "družinsko drevo",
    "drzewo rodzinne",
    "familiestamboom",
    "kilde nødvendig",
    "lähde tarvitaan",
    "tarvitaan lähde",
    "quelle benötigt",
    "väestönlaskenta",
    */
    "árbol de familia",
    "bible de famille",
    "fjölskyldubiblía",
    "fonte necessária",
    "fuente necesaria",
    "potrzebne źródło",
    "quelle notwendig",
    "familienstammbaum",
    "heimildar er þörf",
    "korvaa tämä viite",
    "source nécessaire",
    "albero genealogico",
    "arbre généalogique",
    "bevolkingsregister",
    "ersätt detta citat",
    "heimild nauðsynleg",
    "kilde er nødvendig",
    "nadomesti ta citat",
    "skiptið út heimild",
    "zastąpić ten cytat",
    "erstat henvisningen",
    "korvaa tämä lainaus",
    "udskift dette citat",
    "ersetze dieses zitat",
    "reemplazar esta cita",
    "vervang deze citatie",
    "erstatt dette sitatet",
    "substitua esta citação",
    "ersätt denna hänvisning",
    "remplacez cette citation",
    "erstatt denne henvisningen",
    "sostituire questa citazione",
  ];

  // anywhere in a line not a valid source
  invalidPartialSourceList = [
    "through the import of",
    "add sources here",
    "add [[sources]] here",
    "family tree maker",
    ".ftw",
    "replace this citation if there is another source",
    "replace this citation",
  ];

  // anywhere on a line is a valid source
  validPartialSourceList = [
    "sources are hidden to protect",
    "sources hidden to protect",
    "source hidden to protect"
  ];

  // on the start of a line not a valid source
  invalidStartPartialSourceList = [
    "entered by",
    "no sources.",
    "no repo record found",
    "source will be added by",
    "no sour record found",
    "no note record found",
  ];

  // on a line by itself
  // not a valid source for
  // profile born > 150 or died > 100
  tooOldToRememberSourceList = [
    "personal recollection of events witnessed by",
    "personal recollection of",
    "personal knowledge",
    "first hand knowledge",
    "firsthand knowledge",
    "førstehånds kendskab",
    "ensi käden tieto",
    "af fyrstu hendi",
    "førstehåndskjennskap",
    "förstahandskälla",
    "förstahands kännedom",
    "as remembered by",
    "selon la mémoire de",
    "zoals herinnerd door",
    "eigen kennis",
    "wie erinnert von",
    "wissen aus erster hand",
    "como lo recuerda",
    "como lembrado por",
    "come ricordato da",
    "wie erinnert",
    "comme rappelé par",
    "som husket av",
    "som minns av",
    "kuten muistaa",
    "jak zapamiętał",
    "kot se spominja",
    "som husket af",
    "kuten nn muistaa",
    "nnn mukaan",
    "samkvæmt minni",
    "husket av",
    "ihågkommet av",
  ];

  // anywhere in a line
  // not a valid source for
  // profile born > 150 or died > 100
  invalidPartialSourceListTooOld = [
    "first hand knowledge",
    "firsthand knowledge",
    "personal recollection",
    "as remembered by",
    "selon la mémoire de",
    "zoals herinnerd door",
    "eigen kennis",
    "wie erinnert von",
    "wissen aus erster hand",
    "como lo recuerda",
    "como lembrado por",
    "come ricordato da",
    "wie erinnert",
    "comme rappelé par",
    "som husket av",
    "som minns av",
    "kuten muistaa",
    "jak zapamiętał",
    "kot se spominja",
    "som husket af",
    "kuten nn muistaa",
    "nnn mukaan",
    "samkvæmt minni",
    "husket av",
    "first-hand information",
    "eigen kennis",
    "unsourced family tree handed down",
  ];

  // line by itself
  // not a valid source for Pre1700
  invalidSourceListPre1700 = [
    "birth certificate",
    "birth record",
    "marriage certificate",
    "marriage record",
    "death certificate",
    "death record",
    "igi",
    "family data",
    "certificat de naissance",
    "registre de naissance",
    "certificat de décès",
    "registre de décès",
    "registre de mariage",
    "geboorteakte",
    "geboorte akte",
    "overlijdensakte",
    "overlijdens acte",
    "overlijdens akte",
    "trouwakte",
    "trouwacte",
    "trouw oorkonde",
    "geburtsurkunde",
    "sterbeurkunde",
    "heiratsurkunde",
    "acta de nacimiento",
    "acte de naissance",
    "akt urodzenia",
    "certidão de nascimento",
    "certificado de nacimiento",
    "certificato di nascita",
    "födelsebevis",
    "födelsedokument",
    "fødselsattest",
    "fødselsrekord",
    "registro de nascimento",
    "rojstni list",
    "rojstni zapis",
    "syntymätiedot akt urodzenia",
    "syntymätodistus",
    "certidão de óbito",
    "certificado de defunción",
    "certificato di morte",
    "certyfikat śmierci",
    "døds sertifikat",
    "dødsattest",
    "dödscertifikat",
    "kuolintodistus",
    "mrliški list",
    "acta de defunción",
    "acte de décès",
    "akt zgonu",
    "dödsrekord",
    "kuolemantiedot",
    "registro de morte",
    "registro degli atti di morte",
    "smrtni zapis",
    "akt małżeństwa",
    "certidão de casamento",
    "certificado de matrimonio",
    "certificat de mariage",
    "certificato di matrimonio",
    "eheurkunde trauschein",
    "huwelijksakte",
    "poročni list",
    "vielsesattest",
    "vigselbevis",
    "vigselsattest",
    "vihkitodistus",
    "acte de mariage",
    "ægteskabsoptegnelse",
    "äktenskap rekord",
    "avioliitto ennätys",
    "ekteskapsrekord",
    "poročni zapis",
    "record di matrimonio",
    "registro de casamento",
    "registro de matrimonio",
    "dåbsattest",
    "dánarskrá",
    "dánarvottorð",
    "dödsattest",
    "dödsfallsintyg",
    "dödsnotis",
    "dødsregistrering",
    "dødsregistrering",
    "fæðingarskrá",
    "fæðingarvottorð",
    "födelsenotis",
    "fødselsregistrering",
    "hjúskaparskrá",
    "hjúskaparvottorð",
    "kuolinkirjaus",
    "kuolinmerkintä",
    "navneattest",
    "syntymäkirjaus",
    "syntymämerkintä",
    "vielselsattest el. vigselsattest",
    "vielseregistrering",
    "vigselnotis",
    "vihkimismerkintä",
  ];

  // anywhere on a line
  // not a valid source for Pre1700
  invalidPartialSourceListPre1700 = [
    "ancestry tree",
    "public member tree",
    "family tree",
    "arbre généalogique",
    "familienstammbaum",
    "stamboom",
    "árbol de familia",
    "družinsko drevo",
    "albero genealogico",
    "familiestamboom",
    "familie træ",
    "familietre",
    "släktträd",
    "sukupuu",
    "drzewo rodzinne",
    "family-tree",
    "familysearch.org/tree",
    "trees.ancestry.com",
    "geni tree",
    "ancestral file",
    "burke's peerage",
    "burke’s dormant and extinct peerages",
    "burke’s extinct and dormant baronetcies",
    "burke’s peerage and baronetage",
    "capedia",
    "dictionnaire universel de la noblesse de france",
    "fabpedigree.com",
    "family data collection",
    "genealogie.quebec",
    "genealogieonline",
    "genealogy of the wives of the american presidents",
    "geneanet tree",
    "historiske efterretninger om verfortiente danske adelsmaend",
    "https://kindred.stanford.edu",
    "international genealogical index",
    "jean-baptiste-pierre jullien de courcelles",
    "kindred britain",
    "millennium file",
    "myheritage tree",
    "nicolas viton de saint-allais",
    "nobiliaire universel de france",
    "nosorigines",
    "nos origines",
    "nos origines.",
    "our common ancestors",
    "our royal, titled, noble, and commoner ancestors",
    "our-royal-titled-noble-and-commoner-ancestors.com",
    "pedigree resource file",
    "roglo",
    "rootsweb tree",
    "stirnet.com",
    "the peerage",
    "thepeerage.com",
    "tudor place",
    "u.s. and international marriage records, 1560-1900",
    "us and international marriages Index",
    "vore fælles ahner",
    "www.genealogieonline.nl",
    "www.tudorplace.com.ar",
    "ancestry.com-oneworld tree",
    "one world tree",
    "family group sheet",
    "added by confirming a smart match",
    "world family tree",
    "derbund wft",
    "www.gencircles.com",
  ];

  sourceRulesList = [
    this.biographyHeadings,
    this.sourcesHeadings,
    this.researchNotesHeadings,
    this.acknowledgmentsHeadings,
    this.censusStrings,
    this.invalidSourceList,
    this.invalidPartialSourceList,
    this.validPartialSourceList,
    this.invalidStartPartialSourceList,
    this.tooOldToRememberSourceList,
    this.invalidPartialSourceListTooOld,
    this.invalidSourceListPre1700,
    this.invalidPartialSourceListPre1700
  ];

  constructor() {
  }
}


/***/ }),

/***/ "./src/features/bioCheck/bioCheck.js":
/*!*******************************************!*\
  !*** ./src/features/bioCheck/bioCheck.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SourceRules_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SourceRules.js */ "./src/features/bioCheck/SourceRules.js");
/* harmony import */ var _PersonDate_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PersonDate.js */ "./src/features/bioCheck/PersonDate.js");
/* harmony import */ var _Biography_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Biography.js */ "./src/features/bioCheck/Biography.js");




chrome.storage.sync.get('bioCheck', (result) => {
	if (result.bioCheck) {

    // want to check on start, on draft save, and
    // on a scheduled interval

    // Only do this if on the edit page for a person
    // And ASSUME that if there is a mBirthDate it's a person edit page
    // previous code tried if ($("body.page-Special_EditPerson").length) {
    if (document.getElementById("mBirthDate")) {
      let theSourceRules = new _SourceRules_js__WEBPACK_IMPORTED_MODULE_0__.SourceRules();
      checkBio(theSourceRules);


      let saveDraftButton = document.getElementById("wpSaveDraft");
      saveDraftButton.onclick = function(){checkBio(theSourceRules)};

      // and also once a minute
      setInterval(checkAtInterval, 60000, theSourceRules);

    }
  }
});

// Check at an interval
function checkAtInterval(theSourceRules) {
  checkBio(theSourceRules);
}

/*
 * Notes about packaging and differences from the BioCheck app
 *
 * Copied the following files:
 *   biography.js
 *   biographyResults.js
 *   personDate.js
 *   sourceRules.js
 * and changed each to remove the export
 * and change biography to remove the import
 * 
 * then put each of those files into features/biocheck
 * add each to the manifest.json
 * add each to core/options.html with a script type=module
 *
 * When checking a biography there is no check for privacy
 * to assume an undated profile is unsourced and
 * never check for the biography is auto-generated string
 */

function checkBio(theSourceRules) {
  let thePerson = new _PersonDate_js__WEBPACK_IMPORTED_MODULE_1__.PersonDate();

  // get the bio text and person dates to check
  let bioString = document.getElementById("wpTextbox1").value;
  let birthDate = document.getElementById("mBirthDate").value;
  let deathDate = document.getElementById("mDeathDate").value;

  thePerson.initWithDates(birthDate, deathDate);
  let biography = new _Biography_js__WEBPACK_IMPORTED_MODULE_2__.Biography(theSourceRules);
  biography.parse(bioString, thePerson.isPersonPre1500(), thePerson.isPersonPre1700(), thePerson.mustBeOpen(), thePerson.isUndated(), false);
  biography.validate();

  // now report from biography.bioResults
  // use HTML escape codes for special characters
  let ref = "&#60ref&#62";
  let refEnd = "&#60&#47ref&#62";
  let referencesTag = "&#60references &#47&#62";

  let profileReportLines = ([]);
  let profileStatus = "Profile appears to have sources.";
  if (biography.bioResults.stats.bioIsMarkedUnsourced) {
    profileStatus = "Profile is marked unsourced.";
  } else {
    if (!biography.bioResults.sources.sourcesFound) {
      profileStatus = "Profile may be unsourced.";
    }
  }
  profileReportLines.push(profileStatus);

  if (biography.bioResults.stats.bioIsEmpty) {
    profileStatus = "Profile is empty";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.misplacedLineCount > 0) {
    profileStatus = "Profile has " + biography.bioResults.style.misplacedLineCount;
    if (biography.bioResults.style.misplacedLineCount === 1) {
      profileStatus += " line";
    } else {
      profileStatus += " lines";
    }
    profileStatus += " between Sources and " + referencesTag;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.hasEndlessComment) {
    profileStatus = "Profile has comment with no end";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasRefWithoutEnd) {
    profileStatus = "Profile has inline " + ref + " with no ending " + refEnd;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasSpanWithoutEndingSpan) {
    profileStatus = "Profile has span with no ending span";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioIsMissingBiographyHeading) {
    profileStatus = "Profile is missing Biography heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasMultipleBioHeadings) {
    profileStatus = "Profile has more than one Biography heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHeadingWithNoLinesFollowing) {
    profileStatus = "Profile has empty  Biography section";
    profileReportLines.push(profileStatus);
  }
  let sourcesHeading = ([]);
  if (biography.bioResults.style.bioIsMissingSourcesHeading) {
    profileStatus = "Profile is missing Sources heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasMultipleSourceHeadings) {
    profileStatus = "Profile has more than one Sources heading";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.sourcesHeadingHasExtraEqual) {
    profileStatus = "Profile Sources heading has extra =";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioIsMissingReferencesTag) {
    profileStatus = "Profile is missing " + referencesTag;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasMultipleReferencesTags) {
    profileStatus = "Profile has more than one " + referencesTag;
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasRefAfterReferences) {
    profileStatus = "Profile has inline " + ref + " tag after " +
        referencesTag;
    profileReportLines.push(profileStatus);
  }
  let acknowledgements = ([]);
  if (biography.bioResults.style.acknowledgementsHeadingHasExtraEqual) {
    profileStatus = "Profile Acknowledgements has extra =";
    profileReportLines.push(profileStatus);
  }
  if (biography.bioResults.style.bioHasAcknowledgementsBeforeSources) {
    profileStatus = "Profile has Acknowledgements before Sources heading";
    profileReportLines.push(profileStatus);
  }

  //console.log(profileReportLines);

  // add a list to the page
  reportResults(profileReportLines);
  
}

function reportResults(reportLines) {

  // If you have been here before get and remove the old list of results
  let previousResults = document.getElementById('bioCheckResultsList');
  let bioCheckResultsContainer = document.getElementById('bioCheckResultsContainer');
  if (!bioCheckResultsContainer) {
    bioCheckResultsContainer = document.createElement('div');
    bioCheckResultsContainer.setAttribute('id', 'biocheckContainer');

    let bioCheckTitle = document.createElement('b');
    bioCheckTitle.innerText = "BioCheck results";
    bioCheckResultsContainer.appendChild(bioCheckTitle);
  }
    
  // need a new set of results
  let bioResultsList = document.createElement('ul');
  bioResultsList.setAttribute('id', 'bioCheckResultsList');

  let numLines = reportLines.length;
  for (let i = 0; i < numLines; ++i) {
    let bioResultItem = document.createElement('li');
    bioResultItem.innerHTML = reportLines[i];
    bioResultsList.appendChild(bioResultItem);
  }
  // Add or replace the results
  if (previousResults) {
    previousResults.replaceWith(bioResultsList);
  } else {
    bioCheckResultsContainer.appendChild(bioResultsList);

    let lastContainer = document.getElementById('suggestionContainer');
    if (!lastContainer) {
      lastContainer = document.getElementById('validationContainer');
    }
    lastContainer.after(bioCheckResultsContainer);
  }
}



/***/ }),

/***/ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js":
/*!*******************************************************************************!*\
  !*** ./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./collapsibleDescendantsTree.css */ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css");




chrome.storage.sync.get('collapsibleDescendantsTree', (result) => {
	if (result.collapsibleDescendantsTree && _core_common__WEBPACK_IMPORTED_MODULE_1__.pageProfile == true) { 

    // Look out for the appearance of new list items in the descendantsContainer
    const descendantsObserver = new MutationObserver(function (mutations_list) {
      mutations_list.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (added_node) {
        if (added_node.tagName == "OL") {
        theLIS = jquery__WEBPACK_IMPORTED_MODULE_0___default()(added_node).find("li");
        theLIS.each(function (index, thing) {
            setTimeout(function () {
            createDescendantsButton(index, thing);
              }, 10);
            })
          }
        });
      });
    });

    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#descendantsContainer").length) {
        descendantsObserver.observe(document.querySelector("#descendantsContainer"),
        { subtree: true, childList: true });
    }

    // Add buttons
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_Descendants").length) {
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("ol").length) {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("ol li").each(function (index, thing) {
          setTimeout(function () {
            createDescendantsButton(index, thing);
          }, 10);
        })
      }
    }

    async function createDescendantsButton(n, li) {
    // Attach class to avoid adding button more than once
      if (li.classList.contains('collapse')) {
        return;
      }
      if (!isNextSiblingDiv(li)) {
        return;
      }
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(li).addClass('collapse');
      const button = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<button class='wikitreeturbo'>-</button>");
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(button).click(toggleCollapse);
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(li).prepend(button);
    }

    function isNextSiblingDiv(el) {
      if(el.nextElementSibling) {
        if (el.nextElementSibling.tagName=="DIV") {
          return true;
        }
      }
      return false;
    }

    function toggleCollapse(e) {
      const s = jquery__WEBPACK_IMPORTED_MODULE_0___default()(e.target).text();
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(e.target).text(s=='-' ? '+' : '-');
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(e.target.parentElement.nextElementSibling).toggle();
    }
    
  }
});


/***/ }),

/***/ "./src/features/darkMode/darkMode.js":
/*!*******************************************!*\
  !*** ./src/features/darkMode/darkMode.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _darkMode_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darkMode.css */ "./src/features/darkMode/darkMode.css");



chrome.storage.sync.get("darkMode", (result) => {
  if (result.darkMode) {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body").addClass("darkMode");
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='wikitree-logo.png']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-white.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='wikitree-small.png']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-small-white.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='Wiki-Tree.gif']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-white-G2G.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='G2G.gif']").attr(
      "src",
      chrome.runtime.getURL("images/G2G-transparent.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1:contains(Connection Finder)").parent().css("background-image", "");
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.darkMode.page-Main_Page div.sixteen.columns.top").css(
      "background-image",
      "url(" + chrome.runtime.getURL("images/tree-white.png") + ")"
    );

    // Add code to iframes on merging comparison page.
    if (window.location.href.match("Special:MergePerson")) {
      setTimeout(function () {
        var iframes = document.querySelectorAll("iframe");
        iframes.forEach(function (frame) {
          let linkEl = document.createElement("link");
          linkEl.rel = "stylesheet";
          linkEl.href = chrome.runtime.getURL("features/darkMode/darkMode.css");
          linkEl.type = "text/css";
          let oDocument = frame.contentWindow.document;
          let theHead = oDocument.getElementsByTagName("head")[0];
          theHead.appendChild(linkEl);
          oDocument.getElementsByTagName("body")[0].classList.add("darkMode");
          let logo = oDocument.querySelector("img[src*='wikitree-small.png']");
          if (logo) {
            logo.setAttribute(
              "src",
              chrome.runtime.getURL("images/wikitree-logo-small-white.png")
            );
          }
        });
      }, 700);
    }
  }
});


/***/ }),

/***/ "./src/features/distanceAndRelationship/distanceAndRelationship.js":
/*!*************************************************************************!*\
  !*** ./src/features/distanceAndRelationship/distanceAndRelationship.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ "./node_modules/js-cookie/dist/js.cookie.mjs");
/* harmony import */ var dexie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! dexie */ "./node_modules/dexie/dist/modern/dexie.mjs");
/* harmony import */ var _distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./distanceAndRelationship.css */ "./src/features/distanceAndRelationship/distanceAndRelationship.css");





chrome.storage.sync.get("distanceAndRelationship", (result) => {
  if (
    result.distanceAndRelationship &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.BEE").length == 0 &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    const profileID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
    const userID = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
    var db = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("ConnectionFinderResults");
    db.version(1).stores({
      distance: "[userId+id]",
      connection: "[userId+id]",
    });
    db.open().then(function (db) {
      db.distance
        .get({ userId: userID, id: profileID })
        .then(function (result) {
          if (result == undefined) {
            initDistanceAndRelationship(userID, profileID);
          } else {
            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#distanceFromYou").length == 0) {
              const profileName = jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 span[itemprop='name']").text();
              jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
                jquery__WEBPACK_IMPORTED_MODULE_0___default()(
                  `<span id='distanceFromYou' title='${profileName} is ${result.distance} degrees from you. \nClick to refresh.'>${result.distance}°</span>`
                )
              );

              jquery__WEBPACK_IMPORTED_MODULE_0___default()("#distanceFromYou").click(function (e) {
                e.preventDefault();
                jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).fadeOut("slow").remove();
                jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").fadeOut("slow").remove();
                initDistanceAndRelationship(userID, profileID);
              });

              var rdb = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("RelationshipFinderResults");
              rdb.version(1).stores({
                relationship: "[userId+id]",
              });
              rdb.open().then(function (rdb) {
                rdb.relationship
                  .get({ userId: userID, id: profileID })
                  .then(function (result) {
                    if (result != undefined) {
                      if (result.relationship != "") {
                        if (
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").length == 0 &&
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".ancestorTextText").length == 0 &&
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#ancestorListBox").length == 0
                        ) {
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").remove();
                          addRelationshipText(
                            result.relationship,
                            result.commonAncestors
                          );
                        }
                      }
                    } else {
                      doRelationshipText(userID, profileID);
                    }
                  });
              });
            }
          }
        });
    });
  }
});

async function getProfile(id, fields = "*") {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: { action: "getProfile", key: id, fields: fields },
    });
    return result[0].profile;
  } catch (error) {
    console.error(error);
  }
}

async function getConnectionFinderResult(id1, id2, relatives = 0) {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://www.wikitree.com/index.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      data: {
        title: "Special:Connection",
        action: "connect",
        person1Name: id1,
        person2Name: id2,
        relation: relatives,
        ignoreIds: "",
      },
      type: "POST",
      dataType: "json",
      success: function (data) {},
      error: function (error) {
        console.log(error);
      },
    });
    return result;
  } catch (error) {
    console.error(error);
  }
}

async function getRelationshipFinderResult(id1, id2) {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://www.wikitree.com/index.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      data: {
        title: "Special:Relationship",
        action: "getRelationship",
        person1_name: id1,
        person2_name: id2,
      },
      type: "POST",
      dataType: "json",
      success: function (data) {},
      error: function (error) {
        console.log(error);
      },
    });
    return result;
  } catch (error) {
    console.error(error);
  }
}

function addRelationshipText(oText, commonAncestors) {
  const commonAncestorTextOut = commonAncestorText(commonAncestors);
  const cousinText = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
    "<div id='yourRelationshipText' title='Click to refresh' class='relationshipFinder'>Your " +
      oText +
      "<ul id='yourCommonAncestor' style='white-space:nowrap'>" +
      commonAncestorTextOut +
      "</ul></div>"
  );
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").after(cousinText);
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").click(function (e) {
    e.stopPropagation();
    let id1 = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
    let id2 = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
    initDistanceAndRelationship(id1, id2);
  });
  if (commonAncestors.length > 2) {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").append(
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("<button class='small' id='showMoreAncestors'>More</button>")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#showMoreAncestors").click(function (e) {
      e.preventDefault();
      e.stopPropagation();
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourCommonAncestor li:nth-child(n+3)").toggle();
    });
  }
}

function commonAncestorText(commonAncestors) {
  let ancestorTextOut = "";
  const profileGender = jquery__WEBPACK_IMPORTED_MODULE_0___default()("body")
    .find("meta[itemprop='gender']")
    .attr("content");
  let possessiveAdj = "their";
  if (profileGender == "male") {
    possessiveAdj = "his";
  }
  if (profileGender == "female") {
    possessiveAdj = "her";
  }
  commonAncestors.forEach(function (commonAncestor) {
    const thisAncestorType = ancestorType(
      commonAncestor.path2Length - 1,
      commonAncestor.ancestor.mGender
    ).toLowerCase();
    ancestorTextOut +=
      '<li>Your common ancestor, <a href="https://www.wikitree.com/wiki/' +
      commonAncestor.ancestor.mName +
      '">' +
      commonAncestor.ancestor.mDerived.LongNameWithDates +
      "</a>, is " +
      possessiveAdj +
      " " +
      thisAncestorType +
      ".</li>";
  });
  return ancestorTextOut;
}

function doRelationshipText(userID, profileID) {
  getRelationshipFinderResult(userID, profileID).then(function (data) {
    if (data) {
      let out = "";
      var aRelationship = true;
      const commonAncestors = [];
      let realOut = "";
      let dummy = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<html></html>");
      dummy.append(jquery__WEBPACK_IMPORTED_MODULE_0___default()(data.html));
      if (dummy.find("h1").length) {
        if (dummy.find("h1").eq(0).text() == "No Relationship Found") {
          aRelationship = false;
          console.log("No Relationship Found");
        }
      }
      if (dummy.find("h2").length && aRelationship == true) {
        let oh2 = dummy
          .find("h2")
          .eq(0)
          .text()
          .replaceAll(/[\t\n]/g, "");
        if (data.commonAncestors.length == 0) {
          out = dummy.find("b").text();
        } else {
          const profileGender = jquery__WEBPACK_IMPORTED_MODULE_0___default()("body")
            .find("meta[itemprop='gender']")
            .attr("content");
          if (oh2.match("is the")) {
            out = oh2.split("is the ")[1].split(" of")[0];
          } else if (oh2.match(" are ")) {
            out = oh2.split("are ")[1].replace(/cousins/, "cousin");
          }
          if (out.match(/nephew|niece/)) {
            if (profileGender == "male") {
              out = out.replace(/nephew|niece/, "uncle");
            }
            if (profileGender == "female") {
              out = out.replace(/nephew|niece/, "aunt");
            }
          }
        }
        let outSplit = out.split(" ");
        outSplit[0] = ordinalWordToNumberAndSuffix(outSplit[0]);
        out = outSplit.join(" ");
        if (
          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").length == 0 &&
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".ancestorTextText").length == 0 &&
          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#ancestorListBox").length == 0
        ) {
          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").remove();
          addRelationshipText(out, data.commonAncestors);
        }
      }

      var rdb = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("RelationshipFinderResults");
      rdb.version(1).stores({
        relationship: "[userId+id]",
      });
      rdb
        .open()
        .then(function (rdb) {
          rdb.relationship.put({
            userId: userID,
            id: profileID,
            relationship: out,
            commonAncestors: data.commonAncestors,
          });
          // Database opened successfully
        })
        .catch(function (err) {
          // Error occurred
        });
    }
  });
}

async function addDistance(data) {
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#degreesFromYou").length == 0) {
    window.distance = data.path.length;
    const profileName = jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 span[itemprop='name']").text();
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(
        `<span id='distanceFromYou' title='${profileName} is ${window.distance} degrees from you.'>${window.distance}°</span>`
      )
    );
    var db = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("ConnectionFinderResults");
    db.version(1).stores({
      distance: "[userId+id]",
      connection: "[userId+id]",
    });
    db.open()
      .then(function (db) {
        db.distance.put({
          userId: js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName"),
          id: jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text(),
          distance: window.distance,
        });
        // Database opened successfully
      })
      .catch(function (err) {
        // Error occurred
      });
  }
}

async function getDistance() {
  const id1 = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
  const id2 = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
  const data = await getConnectionFinderResult(id1, id2);
  addDistance(data);
}

function ordinal(i) {
  var j = i % 10,
    k = i % 100;
  if (j == 1 && k != 11) {
    return i + "st";
  }
  if (j == 2 && k != 12) {
    return i + "nd";
  }
  if (j == 3 && k != 13) {
    return i + "rd";
  }
  return i + "th";
}

function ancestorType(generation, gender) {
  let relType;
  if (generation > 0 || generation == 0) {
    if (gender == "Female") {
      relType = "Mother";
    } else if (gender == "Male") {
      relType = "Father";
    } else {
      relType = "Parent";
    }
  }
  if (generation > 1) {
    relType = "Grand" + relType.toLowerCase();
  }
  if (generation > 2) {
    relType = "Great-" + relType.toLowerCase();
  }
  if (generation > 3) {
    relType = ordinal(generation - 2) + " " + relType;
  }
  return relType;
}

function ordinalWordToNumberAndSuffix(word) {
  const ordinalsArray = [
    ["first", "1st"],
    ["second", "2nd"],
    ["third", "3rd"],
    ["fourth", "4th"],
    ["fifth", "5th"],
    ["sixth", "6th"],
    ["seventh", "7th"],
    ["eigth", "8th"],
    ["ninth", "9th"],
    ["tenth", "10th"],
    ["eleventh", "11th"],
    ["twelfth", "12th"],
    ["thirteenth", "13th"],
    ["fourteenth", "14th"],
    ["fifteenth", "15th"],
    ["sixteenth", "16th"],
    ["seventeenth", "17th"],
    ["eighteenth", "18th"],
    ["nineteenth", "19th"],
    ["twentieth", "20th"],
    ["twenty-first", "21st"],
    ["twenty-second", "22nd"],
    ["twenty-third", "23rd"],
    ["twenty-fourth", "24th"],
    ["twenty-fifth", "25th"],
  ];
  ordinalsArray.forEach(function (arr) {
    if (word == arr[0]) {
      word = arr[1];
      return arr[1];
    }
  });
  return word;
}

function initDistanceAndRelationship(userID, profileID) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#distanceFromYou").fadeOut().remove();
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").fadeOut().remove();
  getProfile(profileID).then((person) => {
    const nowTime = Date.parse(Date());
    const created = Date.parse(
      person.Created.substr(0, 8).replace(/(....)(..)(..)/, "$1-$2-$3")
    );
    const timeDifference = nowTime - created;
    const nineDays = 777600000;
    if (
      person.Privacy > 29 &&
      person.Connected == 1 &&
      timeDifference > nineDays
    ) {
      getDistance();
      doRelationshipText(userID, profileID);
    }
  });
}


/***/ }),

/***/ "./src/features/draftList/draftList.js":
/*!*********************************************!*\
  !*** ./src/features/draftList/draftList.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _draftList_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./draftList.css */ "./src/features/draftList/draftList.css");




chrome.storage.sync.get("draftList", (result) => {
  if (result.draftList) {
    // Check that WikiTree BEE hasn't added this already
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.drafts").length == 0) {
      addDraftsToFindMenu();
    }
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditPerson").length && jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.drafts").length) {
      saveDraftList();
    }
  }
});

async function updateDraftList() {
  const profileWTID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
  let addDraft = false;
  let timeNow = Date.now();
  let lastWeek = timeNow - 604800000;
  let isEditPage = false;
  let theName = jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1")
    .text()
    .replace("Edit Profile of ", "")
    .replaceAll(/\//g, "")
    .replaceAll(/ID|LINK|URL/g, "");
  if (
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#draftStatus:contains(saved),#status:contains(Starting with previous)")
      .length
  ) {
    addDraft = true;
  } else if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditPerson").length) {
    isEditPage = true;
  }
  if (localStorage.drafts) {
    let draftsArr = [];
    let draftsArrIDs = [];
    let drafts = JSON.parse(localStorage.drafts);
    drafts.forEach(function (draft) {
      if (!draftsArrIDs.includes(draft[0])) {
        if (
          (addDraft == false || window.fullSave == true) &&
          draft[0] == profileWTID &&
          isEditPage == true
        ) {
        } else {
          if (draft[1] > lastWeek) {
            draftsArr.push(draft);
            draftsArrIDs.push(draft[0]);
          }
        }
      }
    });

    if (!draftsArrIDs.includes(profileWTID) && addDraft == true) {
      draftsArr.push([profileWTID, timeNow, theName]);
    }

    localStorage.setItem("drafts", JSON.stringify(draftsArr));
  } else {
    if (addDraft == true && window.fullSave != true) {
      localStorage.setItem(
        "drafts",
        JSON.stringify([[profileWTID, timeNow, theName]])
      );
    }
  }
  return true;
}

async function showDraftList() {
  if (localStorage.drafts) {
    await updateDraftList();
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").remove();
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("body").append(
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("<div id='myDrafts'><h2>My Drafts</h2><x>x</x><table></table></div>")
  );
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").dblclick(function () {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).slideUp();
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts x").click(function () {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).parent().slideUp();
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").draggable();

  if (localStorage.drafts != undefined && localStorage.drafts != "[]") {
    window.drafts = JSON.parse(localStorage.drafts);
    window.draftCalls = 0;
    window.tempDraftArr = [];
    window.drafts.forEach(function (draft, index) {
      const theWTID = draft[0];
      if (!(0,_core_common__WEBPACK_IMPORTED_MODULE_1__.isOK)(theWTID)) {
        delete window.drafts[index];
        window.draftCalls++;
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
          url:
            "https://www.wikitree.com/index.php?title=" +
            theWTID +
            "&displayDraft=1",
          type: "GET",
          dataType: "html", // added data type
          success: function (res) {
            window.draftCalls++;
            const dummy = jquery__WEBPACK_IMPORTED_MODULE_0___default()(res);
            const aWTID = dummy.find("a.pureCssMenui0 span.person").text();
            if (
              dummy.find("div.status:contains('You have an uncommitted')")
                .length
            ) {
              window.tempDraftArr.push(aWTID);
              const useLink = dummy
                .find("a:contains(Use the Draft)")
                .attr("href");
              if (useLink != undefined) {
                const personID = useLink
                  .match(/&u=[0-9]+/)[0]
                  .replace("&u=", "");
                const draftID = useLink
                  .match(/&ud=[0-9]+/)[0]
                  .replace("&ud=", "");
                window.drafts.forEach(function (yDraft) {
                  if (yDraft[0] == aWTID) {
                    yDraft[3] = personID;
                    yDraft[4] = draftID;
                  }
                });
              }
            }
            if (window.draftCalls == window.drafts.length) {
              window.newDraftArr = [];
              window.drafts.forEach(function (aDraft) {
                if (
                  window.tempDraftArr.includes(aDraft[0]) &&
                  (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.isOK)(aDraft[0])
                ) {
                  window.newDraftArr.push(aDraft);
                }
              });

              newDraftArr.forEach(function (xDraft) {
                let dButtons = "<td></td><td></td>";
                if (xDraft[3] != undefined) {
                  dButtons =
                    "<td><a href='https://www.wikitree.com/index.php?title=Special:EditPerson&u=" +
                    xDraft[3] +
                    "&ud=" +
                    xDraft[4] +
                    "' class='small button'>USE</a></td><td><a href='https://www.wikitree.com/index.php?title=Special:EditPerson&u=" +
                    xDraft[3] +
                    "&dd=" +
                    xDraft[4] +
                    "' class='small button'>DISCARD</a></td>";
                }

                jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts table").append(
                  jquery__WEBPACK_IMPORTED_MODULE_0___default()(
                    "<tr><td><a href='https://www.wikitree.com/index.php?title=" +
                      xDraft[0] +
                      "&displayDraft=1'>" +
                      xDraft[2] +
                      "</a></td>" +
                      dButtons +
                      "</tr>"
                  )
                );
              });
              jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").slideDown();
              if (newDraftArr.length == 0) {
                jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").append(jquery__WEBPACK_IMPORTED_MODULE_0___default()("<p>No drafts!</p>"));
              }
              localStorage.setItem("drafts", JSON.stringify(newDraftArr));
            }
          },
          error: function (res) {},
        });
      }
    });
  } else {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").append(jquery__WEBPACK_IMPORTED_MODULE_0___default()("<p>No drafts!</p>"));
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").slideDown();
  }
}

function saveDraftList() {
  window.fullSave = false;
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#wpSave").click(function () {
    window.fullSave = true;
  });
  window.addEventListener("beforeunload", (event) => {
    updateDraftList();
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#wpSaveDraft").click(function () {
    updateDraftList();
  });
  setInterval(updateDraftList, 60000);
}

function addDraftsToFindMenu() {
  const connectionLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("li a.pureCssMenui[href='/wiki/Special:Connection']");
  const newLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
    "<li><a class='pureCssMenui drafts' id='draftsLink' title='See your uncommitted drafts'>Drafts</li>"
  );
  newLi.insertAfter(connectionLi.parent());
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("li a.drafts").click(function (e) {
    e.preventDefault();
    showDraftList();
  });
}


/***/ }),

/***/ "./src/features/familyGroup/familyGroup.js":
/*!*************************************************!*\
  !*** ./src/features/familyGroup/familyGroup.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery-ui/ui/widgets/draggable */ "./node_modules/jquery-ui/ui/widgets/draggable.js");
/* harmony import */ var jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _familyTimeline_familyTimeline_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../familyTimeline/familyTimeline.css */ "./src/features/familyTimeline/familyTimeline.css");





chrome.storage.sync.get("familyGroup", (result) => {
  if (
    result.familyGroup &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    // Add a link to the short list of links below the tabs
    const options = {
      title: "Display family group dates and locations",
      id: "familyGroupButton",
      text: "Family Group",
      url: "#n",
    };
    (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.createProfileSubmenuLink)(options);
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#" + options.id).click(function (e) {
      e.preventDefault();
      const profileID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
      showFamilySheet(jquery__WEBPACK_IMPORTED_MODULE_0___default()(this)[0], profileID);
    });

    async function showFamilySheet(theClicked, profileID) {
      // If the table already exists toggle it.
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#" + profileID.replace(" ", "_") + "_family").length) {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("#" + profileID.replace(" ", "_") + "_family").fadeToggle();
      } else {
        // Make the table and do other things
        (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.getRelatives)(profileID).then((person) => {
          const uPeople = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.familyArray)(person);
          // Make the table
          const familyTable = peopleToTable(uPeople);
          // Attach the table to the body, position it and make it draggable and toggleable
          familyTable.prependTo("body");
          familyTable.attr("id", profileID.replace(" ", "_") + "_family");
          familyTable.draggable();
          familyTable.fadeIn();
          familyTable.on("dblclick", function () {
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).fadeOut();
          });
          let theLeft = getOffset(jquery__WEBPACK_IMPORTED_MODULE_0___default()("div.ten.columns")[0]).left;
          familyTable.css({
            top: getOffset(theClicked).top + 50,
            left: theLeft,
          });
          // Adjust the position of the table on window resize
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(window).resize(function () {
            if (familyTable.length) {
              theLeft = getOffset(jquery__WEBPACK_IMPORTED_MODULE_0___default()("div.ten.columns")[0]).left;
              familyTable.css({
                top: getOffset(theClicked).top + 50,
                left: theLeft,
              });
            }
          });

          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet x").unbind();
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet x").click(function () {
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).parent().fadeOut();
          });
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet w").unbind();
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet w").click(function () {
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).parent().toggleClass("wrap");
          });
        });
      }
    }

    // Put a group of people in a table
    function peopleToTable(kPeople) {
      const kTable = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
        "<div class='familySheet'><w>↔</w><x>x</x><table><caption></caption><thead><tr><th>Relation</th><th>Name</th><th>Birth Date</th><th>Birth Place</th><th>Death Date</th><th>Death Place</th></tr></thead><tbody></tbody></table></div>"
      );
      kPeople.forEach(function (kPers) {
        let rClass = "";
        let isDecades = false;
        kPers.RelationShow = kPers.Relation;
        if (kPers.Relation == undefined || kPers.Active) {
          kPers.Relation = "Sibling";
          kPers.RelationShow = "";
          rClass = "self";
        }

        let bDate;
        if (kPers.BirthDate) {
          bDate = kPers.BirthDate;
        } else if (kPers.BirthDateDecade) {
          bDate = kPers.BirthDateDecade.slice(0, -1) + "-00-00";
          isDecades = true;
        } else {
          bDate = "0000-00-00";
        }

        let dDate;
        if (kPers.DeathDate) {
          dDate = kPers.DeathDate;
        } else if (kPers.DeathDateDecade) {
          if (kPers.DeathDateDecade == "unknown") {
            dDate = "0000-00-00";
          } else {
            dDate = kPers.DeathDateDecade.slice(0, -1) + "-00-00";
          }
        } else {
          dDate = "0000-00-00";
        }

        if (kPers.BirthLocation == null || kPers.BirthLocation == undefined) {
          kPers.BirthLocation = "";
        }

        if (kPers.DeathLocation == null || kPers.DeathLocation == undefined) {
          kPers.DeathLocation = "";
        }

        if (kPers.MiddleName == null) {
          kPers.MiddleName = "";
        }
        const oName = displayName(kPers)[0];

        if (kPers.Relation) {
          // The relation is stored as "Parents", "Spouses", etc., so...
          kPers.Relation = kPers.Relation.replace(/s$/, "").replace(/ren$/, "");
          if (rClass != "self") {
            kPers.RelationShow = kPers.Relation;
          }
        }
        if (oName) {
          let oBDate = ymdFix(bDate);
          let oDDate = ymdFix(dDate);
          if (isDecades == true) {
            oBDate = kPers.BirthDateDecade;
            if (oDDate != "") {
              oDDate = kPers.DeathDateDecade;
            }
          }
          const aLine = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
            "<tr data-name='" +
              kPers.Name +
              "' data-birthdate='" +
              bDate.replaceAll(/\-/g, "") +
              "' data-relation='" +
              kPers.Relation +
              "' class='" +
              rClass +
              " " +
              kPers.Gender +
              "'><td>" +
              kPers.RelationShow +
              "</td><td><a href='https://www.wikitree.com/wiki/" +
              htmlEntities(kPers.Name) +
              "'>" +
              oName +
              "</td><td class='aDate'>" +
              oBDate +
              "</td><td>" +
              kPers.BirthLocation +
              "</td><td class='aDate'>" +
              oDDate +
              "</td><td>" +
              kPers.DeathLocation +
              "</td></tr>"
          );

          kTable.find("tbody").append(aLine);
        }

        if (kPers.Relation == "Spouse") {
          let marriageDeets = "m.";
          const dMdate = ymdFix(kPers.marriage_date);
          if (dMdate != "") {
            marriageDeets += " " + dMdate;
          }
          if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(kPers.marriage_location)) {
            marriageDeets += " " + kPers.marriage_location;
          }
          if (marriageDeets != "m.") {
            let kGender;
            if (kPers.DataStatus.Gender == "blank") {
              kGender = "";
            } else {
              kGender = kPers.Gender;
            }
            const spouseLine = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
              "<tr class='marriageRow " +
                kGender +
                "' data-spouse='" +
                kPers.Name +
                "'><td>&nbsp;</td><td colspan='3'>" +
                marriageDeets +
                "</td><td></td><td></td></tr>"
            );
            kTable.find("tbody").append(spouseLine);
          }
        }
      });
      const rows = kTable.find("tbody tr");
      rows.sort((a, b) =>
        jquery__WEBPACK_IMPORTED_MODULE_0___default()(b).data("birthdate") < jquery__WEBPACK_IMPORTED_MODULE_0___default()(a).data("birthdate") ? 1 : -1
      );
      kTable.find("tbody").append(rows);

      const familyOrder = ["Parent", "Sibling", "Spouse", "Child"];
      familyOrder.forEach(function (relWord) {
        kTable.find("tr[data-relation='" + relWord + "']").each(function () {
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).appendTo(kTable.find("tbody"));
        });
      });

      kTable.find(".marriageRow").each(function () {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).insertAfter(
          kTable.find("tr[data-name='" + jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).data("spouse") + "']")
        );
      });

      return kTable;
    }

    // Find good names to display (as the API doesn't return the same fields all profiles)
    function displayName(fPerson) {
      if (fPerson != undefined) {
        let fName1 = "";
        if (typeof fPerson["LongName"] != "undefined") {
          if (fPerson["LongName"] != "") {
            fName1 = fPerson["LongName"].replace(/\s\s/, " ");
          }
        }
        let fName2 = "";
        let fName4 = "";
        if (typeof fPerson["MiddleName"] != "undefined") {
          if (
            fPerson["MiddleName"] == "" &&
            typeof fPerson["LongNamePrivate"] != "undefined"
          ) {
            if (fPerson["LongNamePrivate"] != "") {
              fName2 = fPerson["LongNamePrivate"].replace(/\s\s/, " ");
            }
          }
        } else {
          if (typeof fPerson["LongNamePrivate"] != "undefined") {
            if (fPerson["LongNamePrivate"] != "") {
              fName4 = fPerson["LongNamePrivate"].replace(/\s\s/, " ");
            }
          }
        }

        let fName3 = "";
        const checks = [
          "Prefix",
          "FirstName",
          "RealName",
          "MiddleName",
          "LastNameAtBirth",
          "LastNameCurrent",
          "Suffix",
        ];
        checks.forEach(function (dCheck) {
          if (typeof fPerson["" + dCheck + ""] != "undefined") {
            if (
              fPerson["" + dCheck + ""] != "" &&
              fPerson["" + dCheck + ""] != null
            ) {
              if (dCheck == "LastNameAtBirth") {
                if (fPerson["LastNameAtBirth"] != fPerson.LastNameCurrent) {
                  fName3 += "(" + fPerson["LastNameAtBirth"] + ") ";
                }
              } else if (dCheck == "RealName") {
                if (typeof fPerson["FirstName"] != "undefined") {
                } else {
                  fName3 += fPerson["RealName"] + " ";
                }
              } else {
                fName3 += fPerson["" + dCheck + ""] + " ";
              }
            }
          }
        });

        const arr = [fName1, fName2, fName3, fName4];
        var longest = arr.reduce(function (a, b) {
          return a.length > b.length ? a : b;
        });

        const fName = longest;

        let sName;
        if (fPerson["ShortName"]) {
          sName = fPerson["ShortName"];
        } else {
          sName = fName;
        }
        // fName = full name; sName = short name
        return [fName.trim(), sName.trim()];
      }
    }

    // Convert dates to ISO format (YYYY-MM-DD)
    function ymdFix(date) {
      let outDate;
      if (date == undefined || date == "") {
        outDate = "";
      } else {
        const dateBits1 = date.split(" ");
        if (dateBits1[2]) {
          const sMonths = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ];
          const lMonths = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          const dMonth = date.match(/[A-z]+/i);
          let dMonthNum;
          if (dMonth != null) {
            sMonths.forEach(function (aSM, i) {
              if (
                dMonth[0].toLowerCase() == aSM.toLowerCase() ||
                dMonth[0].toLowerCase() == aSM + ".".toLowerCase()
              ) {
                dMonthNum = (i + 1).toString().padStart(2, "0");
              }
            });
          }
          const dDate = date.match(/\b[0-9]{1,2}\b/);
          const dDateNum = dDate[0];
          const dYear = date.match(/\b[0-9]{4}\b/);
          const dYearNum = dYear[0];
          return dYearNum + "-" + dMonthNum + "-" + dDateNum;
        } else {
          const dateBits = date.split("-");
          outDate = date;
          if (dateBits[1] == "00" && dateBits[2] == "00") {
            if (dateBits[0] == "0000") {
              outDate = "";
            } else {
              outDate = dateBits[0];
            }
          }
        }
      }
      return outDate;
    }

    // Replace certain characters with HTML entities
    function htmlEntities(str) {
      return String(str)
        .replaceAll(/&/g, "&amp;")
        .replaceAll(/</g, "&lt;")
        .replaceAll(/>/g, "&gt;")
        .replaceAll(/"/g, "&quot;")
        .replaceAll(/'/g, "&apos;");
    }

    // Get the position of an element
    function getOffset(el) {
      const rect = el.getBoundingClientRect();
      return {
        left: rect.left + window.scrollX,
        top: rect.top + window.scrollY,
      };
    }
  }
});


/***/ }),

/***/ "./src/features/familyTimeline/familyTimeline.js":
/*!*******************************************************!*\
  !*** ./src/features/familyTimeline/familyTimeline.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery-ui/ui/widgets/draggable */ "./node_modules/jquery-ui/ui/widgets/draggable.js");
/* harmony import */ var jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _familyTimeline_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./familyTimeline.css */ "./src/features/familyTimeline/familyTimeline.css");





chrome.storage.sync.get("familyTimeline", (result) => {
  if (
    result.familyTimeline &&
    jquery__WEBPACK_IMPORTED_MODULE_0__("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    // Add a link to the short list of links below the tabs
    const options = {
      title: "Display a family timeline",
      id: "familyTimeLineButton",
      text: "Family Timeline",
      url: "#n",
    };
    (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.createProfileSubmenuLink)(options);
    jquery__WEBPACK_IMPORTED_MODULE_0__("#" + options.id).click(function (e) {
      e.preventDefault();
      timeline();
    });
  }
});

async function getRelatives(id, fields = "*") {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0__.ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: {
        action: "getRelatives",
        keys: id,
        fields: fields,
        getParents: 1,
        getSiblings: 1,
        getSpouses: 1,
        getChildren: 1,
      },
    });
    return result[0].items[0].person;
  } catch (error) {
    console.error(error);
  }
}

// Make the family member arrays easier to handle
function getRels(rel, person, theRelation = false) {
  let people = [];
  if (typeof rel == undefined || rel == null) {
    return false;
  }
  const pKeys = Object.keys(rel);
  pKeys.forEach(function (pKey) {
    var aPerson = rel[pKey];
    if (theRelation != false) {
      aPerson.Relation = theRelation;
    }
    people.push(aPerson);
  });
  return people;
}

// Get a year from the person's data
function getTheYear(theDate, ev, person) {
  if (!(0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(theDate)) {
    if (ev == "Birth" || ev == "Death") {
      theDate = person[ev + "DateDecade"];
    }
  }
  const theDateM = theDate.match(/[0-9]{4}/);
  if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(theDateM)) {
    return parseInt(theDateM[0]);
  } else {
    return false;
  }
}

// Convert a date to YYYY-MM-DD
function dateToYMD(enteredDate) {
  let enteredD;
  if (enteredDate.match(/[0-9]{3,4}\-[0-9]{2}\-[0-9]{2}/)) {
    enteredD = enteredDate;
  } else {
    let eDMonth = "00";
    let eDYear = enteredDate.match(/[0-9]{3,4}/);
    if (eDYear != null) {
      eDYear = eDYear[0];
    }
    let eDDate = enteredDate.match(/\b[0-9]{1,2}\b/);
    if (eDDate != null) {
      eDDate = eDDate[0].padStart(2, "0");
    }
    if (eDDate == null) {
      eDDate = "00";
    }
    if (enteredDate.match(/jan/i) != null) {
      eDMonth = "01";
    }
    if (enteredDate.match(/feb/i) != null) {
      eDMonth = "02";
    }
    if (enteredDate.match(/mar/i) != null) {
      eDMonth = "03";
    }
    if (enteredDate.match(/apr/i) != null) {
      eDMonth = "04";
    }
    if (enteredDate.match(/may/i) != null) {
      eDMonth = "05";
    }
    if (enteredDate.match(/jun/i) != null) {
      eDMonth = "06";
    }
    if (enteredDate.match(/jul/i) != null) {
      eDMonth = "07";
    }
    if (enteredDate.match(/aug/i) != null) {
      eDMonth = "08";
    }
    if (enteredDate.match(/sep/i) != null) {
      eDMonth = "09";
    }
    if (enteredDate.match(/oct/i) != null) {
      eDMonth = "10";
    }
    if (enteredDate.match(/nov/i) != null) {
      eDMonth = "11";
    }
    if (enteredDate.match(/dec/i) != null) {
      eDMonth = "12";
    }
    enteredD = eDYear + "-" + eDMonth + "-" + eDDate;
  }
  return enteredD;
}

// Use an approximate date instead of assuming that dates are Jan 1 or the 1st of a month
function getApproxDate(theDate) {
  let approx = false;
  let aDate;
  if (theDate.match(/0s$/) != null) {
    // Change a decade date to a year ending in '5'
    aDate = theDate.replace(/0s/, "5");
    approx = true;
  } else {
    // If we only have the year, assume the date to be July 2 (the midway date)
    const bits = theDate.split("-");
    if (theDate.match(/00\-00$/) != null) {
      aDate = bits[0] + "-07-02";
      approx = true;
    } else if (theDate.match(/-00$/) != null) {
      // If we have a month, but not a day/date, assume the date to be 16 (the midway date)
      aDate = bits[0] + "-" + bits[1] + "-" + "16";
      approx = true;
    } else {
      aDate = theDate;
    }
  }
  return { Date: aDate, Approx: approx };
}

function getAge(birth, death) {
  // must be date objects
  var age = death.getFullYear() - birth.getFullYear();
  var m = death.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && death.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

function capitalizeFirstLetter(string) {
  string = string.toLowerCase();
  const bits = string.split(" ");
  let out = "";
  bits.forEach(function (abit) {
    out += abit.charAt(0).toUpperCase() + abit.slice(1) + " ";
  });
  function replacer(match, p1) {
    return "-" + p1.toUpperCase();
  }
  out = out.replace(/\-([a-z])/, replacer);
  return out.trim();
}

function timeline() {
  jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").remove();
  const fields =
    "BirthDate,BirthLocation,BirthName,BirthDateDecade,DeathDate,DeathDateDecade,DeathLocation,IsLiving,Father,FirstName,Gender,Id,LastNameAtBirth,LastNameCurrent,Prefix,Suffix,LastNameOther,Derived.LongName,Derived.LongNamePrivate,Manager,MiddleName,Mother,Name,Photo,RealName,ShortName,Touched,DataStatus,Derived.BirthName,Bio";
  const id = jquery__WEBPACK_IMPORTED_MODULE_0__("a.pureCssMenui0 span.person").text();
  getRelatives(id, fields).then((personData) => {
    var person = personData;
    const parents = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Parents, "Parent");
    const siblings = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Siblings, "Sibling");
    const spouses = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Spouses, "Spouse");
    const children = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Children, "Child");
    const family = [person];
    const familyArr = [parents, siblings, spouses, children];
    // Make an array of family members
    familyArr.forEach(function (anArr) {
      if (anArr) {
        if (anArr.length > 0) {
          family.push(...anArr);
        }
      }
    });
    let familyFacts = [];
    const startDate = getTheYear(person.BirthDate, "Birth", person);
    // Get all BMD events for each family member
    family.forEach(function (aPerson) {
      const events = ["Birth", "Death", "marriage"];
      events.forEach(function (ev) {
        let evDate = "";
        let evLocation;
        if (aPerson[ev + "Date"]) {
          evDate = aPerson[ev + "Date"];
          evLocation = aPerson[ev + "Location"];
        } else if (aPerson[ev + "DateDecade"]) {
          evDate = aPerson[ev + "DateDecade"];
          evLocation = aPerson[ev + "Location"];
        }
        if (ev == "marriage") {
          if (aPerson[ev + "_date"]) {
            evDate = aPerson[ev + "_date"];
            evLocation = aPerson[ev + "_location"];
          }
        }
        if (aPerson.Relation) {
          aPerson.Relation = aPerson.Relation.replace(/s$/, "").replace(
            /ren$/,
            ""
          );
        }
        if (evDate != "" && evDate != "0000" && (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(evDate)) {
          let fName = aPerson.FirstName;
          if (!aPerson.FirstName) {
            fName = aPerson.RealName;
          }
          let bDate = aPerson.BirthDate;
          if (!aPerson.BirthDate) {
            bDate = aPerson.BirthDateDecade;
          }
          let mBio = aPerson.bio;
          if (!aPerson.bio) {
            mBio = "";
          }
          if (evLocation == undefined) {
            evLocation = "";
          }
          familyFacts.push([
            evDate,
            evLocation,
            fName,
            aPerson.LastNameAtBirth,
            aPerson.LastNameCurrent,
            bDate,
            aPerson.Relation,
            mBio,
            ev,
            aPerson.Name,
          ]);
        }
      });
      // Look for military events in bios
      if (aPerson.bio) {
        const tlTemplates = aPerson.bio.match(/\{\{[^]*?\}\}/gm);
        if (tlTemplates != null) {
          const warTemplates = [
            "The Great War",
            "Korean War",
            "Vietnam War",
            "World War II",
            "US Civil War",
            "War of 1812",
            "Mexican-American War",
            "French and Indian War",
            "Spanish-American War",
          ];
          tlTemplates.forEach(function (aTemp) {
            let evDate = "";
            let evLocation = "";
            let ev = "";
            let evDateStart = "";
            let evDateEnd = "";
            let evStart;
            let evEnd;
            aTemp = aTemp.replaceAll(/[{}]/g, "");
            const bits = aTemp.split("|");
            const templateTitle = bits[0].replaceAll(/\n/g, "").trim();
            bits.forEach(function (aBit) {
              const aBitBits = aBit.split("=");
              const aBitField = aBitBits[0].trim();
              if (aBitBits[1]) {
                const aBitFact = aBitBits[1].trim().replaceAll(/\n/g, "");
                if (warTemplates.includes(templateTitle) && (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(aBitFact)) {
                  if (aBitField == "startdate") {
                    evDateStart = dateToYMD(aBitFact);
                    evStart = "Joined " + templateTitle;
                  }
                  if (aBitField == "enddate") {
                    evDateEnd = dateToYMD(aBitFact);
                    evEnd = "Left " + templateTitle;
                  }
                  if (aBitField == "enlisted") {
                    evDateStart = dateToYMD(aBitFact);
                    evStart =
                      "Enlisted for " +
                      templateTitle.replace("american", "American");
                  }
                  if (aBitField == "discharged") {
                    evDateEnd = dateToYMD(aBitFact);
                    evEnd =
                      "Discharged from " +
                      templateTitle.replace("american", "American");
                  }
                  if (aBitField == "branch") {
                    evLocation = aBitFact;
                  }
                }
              }
            });
            if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(evDateStart)) {
              evDate = evDateStart;
              ev = evStart;
              familyFacts.push([
                evDate,
                evLocation,
                aPerson.FirstName,
                aPerson.LastNameAtBirth,
                aPerson.LastNameCurrent,
                aPerson.BirthDate,
                aPerson.Relation,
                aPerson.bio,
                ev,
                aPerson.Name,
              ]);
            }
            if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(evDateEnd)) {
              evDate = evDateEnd;
              ev = evEnd;
              familyFacts.push([
                evDate,
                evLocation,
                aPerson.FirstName,
                aPerson.LastNameAtBirth,
                aPerson.LastNameCurrent,
                aPerson.BirthDate,
                aPerson.Relation,
                aPerson.bio,
                ev,
                aPerson.Name,
              ]);
            }
          });
        }
      }
    });
    // Sort the events
    familyFacts.sort();
    if (!person.FirstName) {
      person.FirstName = person.RealName;
    }
    // Make a table
    const timelineTable = jquery__WEBPACK_IMPORTED_MODULE_0__(
      `<div class='wrap' id='timeline' data-wtid='${person.Name}'><w>↔</w><x>x</x><table id='timelineTable'>` +
        `<caption>Events in the life of ${person.FirstName}'s family</caption><thead><th class='tlDate'>Date</th><th class='tlBioAge'>Age (${person.FirstName})</th>` +
        `<th class='tlRelation'>Relation</th><th class='tlName'>Name</th><th class='tlAge'>Age</th><th class='tlEventName'>Event</th><th class='tlEventLocation'>Location</th>` +
        `</thead></table></div>`
    );
    // Attach the table to the container div
    timelineTable.prependTo(jquery__WEBPACK_IMPORTED_MODULE_0__("div.container.full-width"));
    if (jquery__WEBPACK_IMPORTED_MODULE_0__("#connectionList").length) {
      timelineTable.prependTo(jquery__WEBPACK_IMPORTED_MODULE_0__("#content"));
      timelineTable.css({ top: window.pointerY - 30, left: 10 });
    }
    let bpDead = false;
    let bpDeadAge;

    familyFacts.forEach(function (aFact) {
      // Add events to the table
      const showDate = aFact[0].replace("-00-00", "").replace("-00", "");
      const tlDate = "<td class='tlDate'>" + showDate + "</td>";
      let aboutAge = "";
      let bpBdate = person.BirthDate;
      if (!person.BirthDate) {
        bpBdate = person.BirthDateDecade.replace(/0s/, "5");
      }
      let hasBdate = true;
      if (bpBdate == "0000-00-00") {
        hasBdate = false;
      }
      const bpBD = getApproxDate(bpBdate);
      const evDate = getApproxDate(aFact[0]);
      const aPersonBD = getApproxDate(aFact[5]);
      if (bpBD.Approx == true) {
        aboutAge = "~";
      }
      if (evDate.Approx == true) {
        aboutAge = "~";
      }
      let bpAge = getAge(new Date(bpBD.Date), new Date(evDate.Date));
      if (bpAge == 0) {
        bpAge = "";
      }
      if (bpDead == true) {
        const theDiff = parseInt(bpAge - bpDeadAge);
        bpAge = bpAge + " (" + bpDeadAge + " + " + theDiff + ")";
      }
      let theBPAge;
      if (aboutAge != "" && bpAge != "") {
        theBPAge = "(" + bpAge + ")";
      } else {
        theBPAge = bpAge;
      }
      if (hasBdate == false) {
        theBPAge = "";
      }
      const tlBioAge = "<td class='tlBioAge'>" + theBPAge + "</td>";
      if (aFact[6] == undefined || aFact[9] == person.Name) {
        aFact[6] = "";
      }
      const tlRelation =
        "<td class='tlRelation'>" + aFact[6].replace(/s$/, "") + "</td>";
      let fNames = aFact[2];
      if (aFact[8] == "marriage") {
        fNames = person.FirstName + " and " + aFact[2];
      }
      const tlFirstName =
        "<td class='tlFirstName'><a href='https://www.wikitree.com/wiki/" +
        aFact[9] +
        "'>" +
        fNames +
        "</a></td>";
      const tlEventName =
        "<td class='tlEventName'>" +
        capitalizeFirstLetter(aFact[8])
          .replaceAll(/Us\b/g, "US")
          .replaceAll(/Ii\b/g, "II") +
        "</td>";
      const tlEventLocation = "<td class='tlEventLocation'>" + aFact[1] + "</td>";

      if (aPersonBD.Approx == true) {
        aboutAge = "~";
      }
      let aPersonAge = getAge(new Date(aPersonBD.Date), new Date(evDate.Date));
      if (aPersonAge == 0 || aPersonBD.Date.match(/0000/) != null) {
        aPersonAge = "";
        aboutAge = "";
      }
      let theAge;
      if (aboutAge != "" && aPersonAge != "") {
        theAge = "(" + aPersonAge + ")";
      } else {
        theAge = aPersonAge;
      }
      const tlAge = "<td class='tlAge'>" + theAge + "</td>";
      let classText = "";
      if (aFact[9] == person.Name) {
        classText += "BioPerson ";
      }
      classText += aFact[8] + " ";
      const tlTR = jquery__WEBPACK_IMPORTED_MODULE_0__(
        "<tr class='" +
          classText +
          "'>" +
          tlDate +
          tlBioAge +
          tlRelation +
          tlFirstName +
          tlAge +
          tlEventName +
          tlEventLocation +
          "</tr>"
      );
      jquery__WEBPACK_IMPORTED_MODULE_0__("#timelineTable").append(tlTR);
      if (aFact[8] == "Death" && aFact[9] == person.Name) {
        bpDead = true;
        bpDeadAge = bpAge;
      }
    });

    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").slideDown("slow");
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline x").click(function () {
      jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").slideUp();
    });
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline w").click(function () {
      jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").toggleClass("wrap");
    });
    // Use jquery-ui to make the table draggable
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").draggable();
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").dblclick(function () {
      jquery__WEBPACK_IMPORTED_MODULE_0__(this).slideUp("swing");
    });
  });
}


/***/ }),

/***/ "./src/features/locationsHelper/locationsHelper.js":
/*!*********************************************************!*\
  !*** ./src/features/locationsHelper/locationsHelper.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _locationsHelper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./locationsHelper.css */ "./src/features/locationsHelper/locationsHelper.css");




chrome.storage.sync.get("locationsHelper", (result) => {
  if (
    result.locationsHelper &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.BEE").length == 0 &&
    (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditPerson").length ||
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditFamily").length)
  ) {
    function addRelArraysToPerson(zPerson) {
      const zSpouses = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Spouses, "Spouse");
      zPerson.Spouse = zSpouses;
      const zChildren = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Children, "Child");
      zPerson.Child = zChildren;
      const zSiblings = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Siblings, "Sibling");
      zPerson.Sibling = zSiblings;
      const zParents = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Parents, "Parent");
      zPerson.Parent = zParents;
      return zPerson;
    }

    function editDistance(s1, s2) {
      s1 = s1.toLowerCase();
      s2 = s2.toLowerCase();
      let costs = new Array();
      for (var i = 0; i <= s1.length; i++) {
        var lastValue = i;
        for (var j = 0; j <= s2.length; j++) {
          if (i == 0) costs[j] = j;
          else {
            if (j > 0) {
              var newValue = costs[j - 1];
              if (s1.charAt(i - 1) != s2.charAt(j - 1))
                newValue =
                  Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
              costs[j - 1] = lastValue;
              lastValue = newValue;
            }
          }
        }
        if (i > 0) costs[s2.length] = lastValue;
      }
      return costs[s2.length];
    }

    function similarity(s1, s2) {
      s1 = s1.toLowerCase();
      s2 = s2.toLowerCase();
      var longer = s1;
      var shorter = s2;
      if (s1.length < s2.length) {
        longer = s2;
        shorter = s1;
      }
      var longerLength = longer.length;
      if (longerLength == 0) {
        return 1.0;
      }
      return (
        (longerLength - editDistance(longer, shorter)) /
        parseFloat(longerLength)
      );
    }

    async function locationsHelper() {
      let theID;
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditFamily").length) {
        theID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
      } else {
        theID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui:Contains(Edit)").attr("href").split("u=")[1];
      }
      (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.getRelatives)(theID).then((result) => {
        const thisFamily = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.familyArray)(result);
        window.bdLocations = [];
        thisFamily.forEach(function (aPe) {
          if (aPe.BirthLocation) {
            window.bdLocations.push(aPe.BirthLocation);
          }
          if (aPe.DeathLocation) {
            window.bdLocations.push(aPe.DeathLocation);
          }
        });
      });

      const observer2 = new MutationObserver(function (mutations_list) {
        mutations_list.forEach(function (mutation) {
          mutation.addedNodes.forEach(function (added_node) {
            if (added_node.className == "autocomplete-suggestion-container") {
              let activeEl = document.activeElement;
              let whichLocation = "";
              if (activeEl.id == "mBirthLocation") {
                whichLocation = "Birth";
              }
              if (activeEl.id == "mDeathLocation") {
                whichLocation = "Death";
              }
              if (activeEl.name == "mMarriageLocation") {
                whichLocation = "Marriage";
              }
              let dText = added_node.textContent;
              let currentBirthYearMatch = null;
              let currentDeathYearMatch = null;
              let currentMarriageYearMatch = null;
              if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mBirthDate").length) {
                currentBirthYearMatch = jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mBirthDate")
                  .val()
                  .match(/[0-9]{3,4}/);
              }
              if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mDeathDate").length) {
                currentDeathYearMatch = jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mDeathDate")
                  .val()
                  .match(/[0-9]{3,4}/);
              }
              if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mMarriageDate").length) {
                currentMarriageYearMatch = jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mMarriageDate")
                  .val()
                  .match(/[0-9]{3,4}/);
              }
              let startYear = "";
              let endYear = "";
              let goodDate = false;
              let familyLoc = false;
              let familyLoc2 = false;
              const yearsMatch = dText.match(/\([^A-z]*[0-9]{3,4}.*\)/g);
              if (yearsMatch != null) {
                years = yearsMatch[0].replaceAll(/[()]/g, "").split("-");
                //console.log(years);
                if (years[0].trim() != "") {
                  startYear = years[0].trim();
                }
                if (years[1].trim() != "") {
                  endYear = years[1].trim();
                }
              } else {
                goodDate = true;
              }
              let myYear = "";
              if (currentBirthYearMatch != null && whichLocation == "Birth") {
                myYear = currentBirthYearMatch[0];
              } else if (
                currentDeathYearMatch != null &&
                whichLocation == "Death"
              ) {
                myYear = currentDeathYearMatch[0];
              } else if (
                currentMarriageYearMatch != null &&
                whichLocation == "Marriage"
              ) {
                myYear = currentMarriageYearMatch[0];
              }
              if (myYear != "") {
                if (startYear == "" && parseInt(myYear) < parseInt(endYear)) {
                  goodDate = true;
                } else if (
                  endYear == "" &&
                  parseInt(myYear) > parseInt(startYear)
                ) {
                  goodDate = true;
                } else if (
                  parseInt(myYear) > parseInt(startYear) &&
                  parseInt(myYear) < parseInt(endYear)
                ) {
                  goodDate = true;
                }
              } else {
                goodDate = true;
              }
              window.bdLocations.forEach(function (aLoc) {
                dText = dText.split("(")[0].trim();
                if (similarity(aLoc, dText) > 0.8) {
                  familyLoc = true;
                }
                if (similarity(aLoc, dText) > 0.95) {
                  familyLoc2 = true;
                }
              });
              const theContainer = jquery__WEBPACK_IMPORTED_MODULE_0___default()(added_node).closest(
                ".autocomplete-suggestion-container"
              );
              if (goodDate == true) {
                theContainer.addClass("rightPeriod");
                if (familyLoc2 == true) {
                  theContainer
                    .addClass("familyLoc2")
                    .prependTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions"));
                } else if (familyLoc == true) {
                  theContainer
                    .addClass("familyLoc1")
                    .prependTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions"));
                }
              } else {
                theContainer
                  .addClass("wrongPeriod")
                  .appendTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions"));
              }
            }
          });
        });
      });

      setTimeout(function () {
        observer2.observe(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions").eq(0)[0], {
          subtree: false,
          childList: true,
        });
        if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mDeathLocation").length) {
          observer2.observe(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions").eq(1)[0], {
            subtree: false,
            childList: true,
          });
        }
      }, 3000);
    }
    locationsHelper();
  }
});


/***/ }),

/***/ "./src/features/printerfriendly/printerfriendly.js":
/*!*********************************************************!*\
  !*** ./src/features/printerfriendly/printerfriendly.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");



chrome.storage.sync.get('printerFriendly', (result) => {
	if (result.printerFriendly) {
		// create a top menu item
		(0,_core_common__WEBPACK_IMPORTED_MODULE_1__.createTopMenuItem)({
			title: 'Changes the format to a printer-friendly one.',
			name: 'Printer Friendly Bio',
			id: 'wte-tm-printer-friendly'
		});

		jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#wte-tm-printer-friendly`).on('click', () => {
			printBio();
		});
	}
});

// modified code from Steven's WikiTree Toolkit
function printBio() {
	var pTitleClean = jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).attr('title');
	var pTitleCleaner = pTitleClean.replace(' | WikiTree FREE Family Tree', '');
	var pTitle = pTitleCleaner.replace(' - WikiTree Profile', '');
	var pImage = jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src^='/photo.php/']").attr('src');
	var pTitleInsert = jquery__WEBPACK_IMPORTED_MODULE_0___default()('h2').first();
	pTitleInsert.before(
		`<div>
			<img style="float:left;" src="https://www.wikitree.com${pImage}" width="75" height="75">
			<div style="font-size: 2.1429em; line-height: 1.4em; margin-bottom:50px; padding: 20px 100px;">
				${pTitle}
			</div>
		</div>`
	);

	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[target='_Help']").parent().remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("span[title*='for the profile and']").parent().remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("div[style='background-color:#e1efbb;']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("div[style='background-color:#eee;']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[href^='/treewidget/']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[href='/g2g/']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[class='nohover']").remove();

	jquery__WEBPACK_IMPORTED_MODULE_0___default()('div').removeClass('ten columns');
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.VITALS').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.star').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.profile-tabs').remove();
	//$(".SMALL").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.showhidetree').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.row').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.button').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.large').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.sixteen').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.five').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.editsection').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.EDIT').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.comment-absent').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.box').remove();

	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#views-wrap').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#footer').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#commentPostDiv').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#comments').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#commentEditDiv').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#commentG2GDiv').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#header').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#showHideDescendants').remove();

	window.print();
	location.reload();
}


/***/ }),

/***/ "./src/features/randomProfile/randomProfile.js":
/*!*****************************************************!*\
  !*** ./src/features/randomProfile/randomProfile.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


chrome.storage.sync.get('randomProfile', (result) => {
	if (result.randomProfile && jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.BEE").length==0) {
        function getRandomProfile() {
            var randomProfileID = Math.floor(Math.random() * 36065988);
            var link = '';
            // check if exists
            jquery__WEBPACK_IMPORTED_MODULE_0___default().getJSON('https://api.wikitree.com/api.php?action=getPerson&key=' + randomProfileID)
                .done(function (json) {
                    // check to see if the profile is Open
                    if (json[0]['status'] == 0 && 'Privacy_IsOpen' in json[0]['person'] && json[0]['person']['Privacy_IsOpen']) {
                        link = 'https://www.wikitree.com/wiki/' + randomProfileID;
                        window.location = link;
                    } else { // If it isn't open, find a new profile
                        getRandomProfile();
                    }
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.log('getJSON request failed! ' + textStatus + ' ' + errorThrown);
                    getRandomProfile();
                });
        }

        // add random option to 'Find'
        async function addRandomToFindMenu() {
            const relationshipLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("li a.pureCssMenui[href='/wiki/Special:Relationship']");
            const newLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<li><a class='pureCssMenui randomProfile' title='Go to a random profile'>Random Profile</li>");
            newLi.insertBefore(relationshipLi.parent());
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(".randomProfile").click(function (e) {
                e.preventDefault();
                getRandomProfile()
            });
        }
    addRandomToFindMenu();
    }
})


/***/ }),

/***/ "./src/features/sourcepreview/sourcepreview.js":
/*!*****************************************************!*\
  !*** ./src/features/sourcepreview/sourcepreview.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


chrome.storage.sync.get('sPreviews', function (result) {
    if (result.sPreviews == true) {
        sourcePreview();

        function sourcePreview() {
            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()('.reference').length) { // and only if inline citations are found
                jquery__WEBPACK_IMPORTED_MODULE_0___default()('.reference').hover(function (e) { // jquery.hover() handlerIn (show sourcePreview)
                    var sourceID = this.id.replace('ref', 'note').replace(/(_[0-9]+$)/g, '');
                    var sPreview = document.createElement('div');
                    sPreview.setAttribute('id', 'sourcePreview');
                    sPreview.setAttribute('class', 'box rounded');
                    sPreview.setAttribute('style', 'z-index:999; width: 450px; position:absolute;');
                    document.getElementById(this.id).appendChild(sPreview);
                    document.getElementById('sourcePreview').innerHTML = document.getElementById(sourceID).innerHTML;
                },
                    // jqeury.hover() handlerOut (remove sourcePreview)
                    function () {
                        jquery__WEBPACK_IMPORTED_MODULE_0___default()('#sourcePreview').remove();
                    }
                )
            }
        }
        const targetNode = document.getElementById('previewbox');
        const config = { childList: true };
        const callback = (mutationList, observer) => {
            for (const mutation of mutationList) {
                if (mutation.type === 'childList') {
                    sourcePreview();
                }
            }
        };
        const observer = new MutationObserver(callback);
        if (jquery__WEBPACK_IMPORTED_MODULE_0___default()('#previewbox').length > 0) {
            observer.observe(targetNode, config);
        }
    }
})


/***/ }),

/***/ "./src/features/spacepreview/spacepreview.js":
/*!***************************************************!*\
  !*** ./src/features/spacepreview/spacepreview.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _thirdparty_jquery_hoverDelay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../thirdparty/jquery.hoverDelay */ "./src/thirdparty/jquery.hoverDelay.js");



chrome.storage.sync.get("spacePreviews", function (result) {
  if (result.spacePreviews == true) {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()('.ten.columns a[href*="/wiki/Space:"], .sixteen.columns a[href*="/wiki/Space:"]').hoverDelay({
      delayIn: 1000,
      delayOut: 0,
      handlerIn: function ($element) {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spacePreview").remove();
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spaceHover").attr("id", "");
        console.log($element[0].href);
        $element.attr("id", "spaceHover");
        var sPreview = document.createElement("div");
        sPreview.setAttribute("id", "spacePreview");
        sPreview.setAttribute("class", "box rounded");
        sPreview.setAttribute(
          "style",
          `z-index:9999; max-height:450px; overflow: scroll; position:absolute; padding: 10px; margin-top:-20px;`
        );
        document.getElementById("spaceHover").parentElement.appendChild(sPreview);
        jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
          url: $element[0].href,
          context: document.body,
        }).done(function (result) {
          var pageContent = jquery__WEBPACK_IMPORTED_MODULE_0___default()(result).find(".ten.columns").html();
          try {
            document.getElementById(
              "spacePreview"
            ).innerHTML = `<span style="float:right; font-weight:700;">click outside to close</span>${pageContent}`;
          } catch {}
        });
      },
    });
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).on("click", function (event) {
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(event.target).closest("#spacePreview").length === 0) {
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spacePreview").remove();
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spaceHover").attr("id", "");
    }
  });
});


/***/ }),

/***/ "./src/features/wt+/contentEdit.js":
/*!*****************************************!*\
  !*** ./src/features/wt+/contentEdit.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "wtPlus": () => (/* binding */ wtPlus)
/* harmony export */ });
/* harmony import */ var _wtPlus_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wtPlus.css */ "./src/features/wt+/wtPlus.css");


let tb = {};

function itemsFindByTemplate(name) {
	return tb.templates.filter(item => item.name.toUpperCase() === name.toUpperCase())[0]
}

function paramsCopy (templateName){
	tb.template = itemsFindByTemplate(templateName); 
	tb.templateitems = tb.template.prop.map(item => {        
		return {
			name: item.name,
			type: item.type,
			usage: item.usage,
			numbered: item.numbered,
			initial: item.initial,
			help: item.help,
			example: item.example,
			group: item.group,
			values: item.values || [], 
			value: ''
		}
	})
	tb.unknownParams = ''
}

function paramsFromSelection(){
	//finds menu item
//    var params = tb.textSelected.split(/.*?\|\s*([^{}[\]|]*?(?:\[\[[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\]\][^{}[\]|]*?|\{\{[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\}\}[^{}[\]|]*?)*?[^{}[\]|]*?)\s*(?:(?=\|)|}})/g).map(par => par.trim()).filter(par => par != '');
	var params = tb.textSelected.split(/\|\s*([^{}[\]|]*?(?:\[\[[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\]\][^{}[\]|]*?|\{\{[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\}\}[^{}[\]|]*?)*?[^{}[\]|]*?)\s*(?:(?=\|)|}})/g).map(par => par.trim()).filter(par => par != '');
	tb.textSelected = tb.textSelected.replace('{{', '').replace('}}', '');
	params[0] = params[0].replace('{{', '').replace('}}', '').replace('_', ' ')
	tb.template = itemsFindByTemplate(params[0]); 
	if (tb.template) {
		params.splice(0, 1);
		var paramsNumbered = params.filter(par => !(par.includes('=')));
		var paramsNamed = params.filter(par => par.includes('=')).map(item => item.split("=").map(par => par.trim()));
		tb.templateitems = tb.template.prop.map(item => {
			var x;
			if (item.numbered) {
				x = paramsNumbered[item.numbered-1]
			} else {
				x = paramsNamed.filter(par => par[0].toUpperCase() === item.name.toUpperCase()).map(par => par[1]).join('');
			};
			if (!x) {x = ''};
			return {
				name: item.name,
				type: item.type,
				usage: item.usage,
				numbered: item.numbered,
				initial: item.initial,
				help: item.help,
				example: item.example,
				group: item.group,                                
				values: item.values || [], 
				value: x.trim()
			}            
		})
		var unknownNamed = paramsNamed.filter(par => !Boolean(tb.templateitems.find(ti => ti.name.toUpperCase() === par[0].toUpperCase())))        
		var unknownNumbered = paramsNumbered.filter((par, i) => !Boolean(tb.templateitems.find(ti => ti.numbered === i+1)))
		tb.unknownParams = unknownNamed.map(i => '|' + i[0] + '= ' + i[1]).concat(unknownNumbered.map(i => '|' + i)).join('\n')
	} else {
		alert ('Template "' + params[0] + '" is not recognised by the extension')
	}   
};

function paramsInitialValues (){
	if (tb.templateitems && tb.templateitems.length) {
		for (let prop of tb.templateitems) {
			if (prop.value === '' && prop.initial) {
				if (prop.initial.startsWith("Title:")) {
					prop.value = document.title.replace(RegExp(prop.initial.substring(6)), '$1');
				}    
				if (prop.initial.startsWith("Category:") && (tb.categories)) {
					var r = RegExp(prop.initial.substring(9), 'mg')
					var a = tb.categories.match(r)
					prop.value = ((a) ? a.join('\n').replace(r, '$1') : '' )
				}    
			}
		}
	}
}

function reformatCoortoURL (s) {
	return 'https://www.openstreetmap.org/#map=18/' + s.replace (',', '/').replace ('%20', '')
}

function reformatURLtoCoor (s) {
	if (s.match ( /^ *[\d]* *° *[\d]* *[′'] *([\d.]* *[″”"])? *[NS][, ]*[\d]* *° *[\d]* *[′'] *([\d.]* *[″”"])? *[EW] *$/mgi)) {
		// 32°42'16.02"N, 17°8'0.67"W
		let s1 = s.replace(
			/^ *([\d]{1,2}) *° *([\d]{1,2}) *[′'] *(([\d.]{1,5}) *[″”"])? *([NS])[, ]*([\d]{1,3}) *° *([\d]{1,2}) *[′'] *(([\d.]{1,5}) *[″”"])? *([EW]) *$/mgi,
			'$1;$2;$4;$5;$6;$7;$9;$10')
		let arr = s1.split(';')
		var lon, lat
		lat = (arr[3] == 'S' ? -1 : 1) * (Number(arr[0]) + Number(arr[1]) / 60 + Number(arr[2]) / 3600)
		lon = (arr[7] == 'W' ? -1 : 1) * (Number(arr[4]) + Number(arr[5]) / 60 + Number(arr[6]) / 3600)
		return parseFloat(lat.toFixed(6)) + ', ' + parseFloat(lon.toFixed(6))
	} else if (s.match (/^https:\/\/www\.openstreetmap\.org\/#map=[\d]*\/[\d.-]*\/[\d.-]*$/mgi)) {
		// https://www.openstreetmap.org/#map=15/32.7051/-17.1220
		let s1 = s.replace(
			/^https:\/\/www\.openstreetmap\.org\/#map=[\d]{1,2}\/([\d.-]*)\/([\d.-]*)$/mgi,
			'$1, $2')
		return s1
	} else {  
		return s.replace ('/', ', ')
	}
}

function reformatTexttoWiki (s) {
	return s.replace (/ /g, '_');
}

function reformatWikitoText  (s) {
	return decodeURIComponent (s.replace (/_/g, ' '));
}

function getNumbertoSlash  (s) {
	return s.replace (/(\d*)\/.*/g, '$1');
}

const urlMappings = [
	{type: "", placeholder:"Undefined type"},
	{type: "typeText", placeholder:"Enter text"},
	{type: "typeNumber", placeholder:"Enter a number"},
	{type: "typeYear", placeholder:"Enter year"},
	{type: "typeYes", placeholder:"Enter yes"},
	{type: "typeNo", placeholder:"Enter no"},
	{type: "typeURL", placeholder:"Enter URL https://...", prefixURL:'', sufixURL:'', emptyURL:''},
	{type: "typeWikitreeID", placeholder:"Enter profile's WikitreeID", prefixURL:'https://www.wikitree.com/wiki/', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typePage", placeholder:"Enter Page name with Namespace", prefixURL:'https://www.wikitree.com/wiki/', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeCategory", placeholder:"Enter Category on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Category:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeProjectNeedsCategory", placeholder:"Enter Project Needs category", prefixURL:'', sufixURL:'', emptyURL:''},
	{type: "typeProject", placeholder:"Enter Project on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Project:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeTeam", placeholder:"Enter Team of the project on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Space:', sufixURL:' Team', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeSpace", placeholder:"Enter Space page on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Space:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeImage", placeholder:"Enter Image name", prefixURL:'https://www.wikitree.com/wiki/Image:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeG2G", placeholder:"Enter question ID", prefixURL:'https://www.wikitree.com/g2g/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeWikiTreeBlog", placeholder:"Enter blog name", prefixURL:'https://www.wikitree.com/blog/', sufixURL:'/', emptyURL:''},
	{type: "typeWikiData", placeholder:"Enter WikiData code", prefixURL:'https://www.wikidata.org/wiki/', sufixURL:''},
	{type: "typeYouTube", placeholder:"Enter YouTube code", prefixURL:'https://www.youtube.com/watch?v=', sufixURL:''},
	{type: "typeFAGID", placeholder:"Enter FindAGrave ID", prefixURL:'https://www.findagrave.com/memorial/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeFAGCemID", placeholder:"Enter FindAGrave Cemetery ID", prefixURL:'https://www.findagrave.com/cemetery/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeFAGLocID", placeholder:"Enter FindAGrave Location ID", prefixURL:'https://www.findagrave.com/cemetery/search?locationId='},
	{type: "typeBGID", placeholder:"Enter BillionGraves ID", prefixURL:'https://billiongraves.com/cemetery/Cemetery/', sufixURL:'', emptyURL:'https://billiongraves.com/'},
	{type: "typeCoor", placeholder:"Enter coordinate 15.123, -33.213", prefixURL:'', sufixURL:'', emptyURL:'https://www.openstreetmap.org/', toURL:reformatCoortoURL, fromURL:reformatURLtoCoor},
	{type: "typeTOC", placeholder:"Not enough prfiles"},
	{type: "typeReadOnly"},
];

/* Setting result */

function updateEdit (){
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}
	tb.elText.value = tb.textResult;
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}
	tb.elText.setSelectionRange(tb.selStart, tb.selEnd);

	if (tb.birthLocationResult) {
		tb.elBirthLocation.value = tb.birthLocationResult
	}
	if (tb.deathLocationResult) {
		tb.elDeathLocation.value = tb.deathLocationResult
	}

	if (tb.elSummary) {
		tb.elSummary.focus();
		var s = tb.elSummary.value;
		if (s) {
			if (s.indexOf(tb.addToSummary) == -1) {
				s += ', ' + tb.addToSummary
			}
		} else {
			s = tb.addToSummary
		};
		tb.elSummary.value = s;
	}
	tb.elText.focus();
	tb.addToSummary = ''

	// Let the page know that changes have been made so that the "Save Changes" button works
//    if ("createEvent" in document) {
	var evt = document.createEvent("HTMLEvents");
	evt.initEvent("change", false, true);
	tb.elText.dispatchEvent(evt);
//      } else {
//        textbox.fireEvent("onchange");
//      }
}


/**************************/
/* edit Template          */
/**************************/

function editTemplate (summaryPrefix){
	if (tb.template) {
		var group, groupExpanded 
		tb.elDlg.innerHTML = 
			'<h3 style="margin: 0 0 0 10px;">Editing ' + '<a href="/wiki/Template:' + tb.template.name + '" target="_blank">Template:' + tb.template.name + '</a></h3>' + 
			'<table style="margin-bottom: 10px;"><tr><td style="white-space: nowrap;padding-right: 10px;">' +
			(tb.template.type ? 'Type: <b>' + tb.template.type + '</b><br>' : '') + 
			(tb.template.group ? 'Group: <b>' + tb.template.group + '</b><br>' : '') + 
			(tb.template.subgroup ? 'SubGroup: <b>' + tb.template.subgroup + '</b>' : '') + 
			'</td><td>' + tb.template.help + '</td></tr></table>' + 
			'<div id="wtPlusDlgParams">'+
			'<table style="width: 100%;">' + 
			tb.templateitems.map((item, i) => {
				var itemDef = urlMappings.filter(a=>a.type == item.type)[0] 
				if (!itemDef) {
					console.log('Missing ' + item.type + ' type') 
					itemDef = urlMappings[0];
				};
				// Sets TOC parameter
				if (item.type === "typeTOC") {
					var has_link = [].some.call(document.links, function(link) {
						return link.innerHTML.endsWith(' 200');
					});
					item.value = (has_link) ? 'yes': ''
				}
				var x = ''
				// Group
				if (item.group !== group) {
					if (item.group) {
						groupExpanded = Boolean (tb.templateitems.find(a=> a.group == item.group && a.value)) 
						x += '<tr class="wtPlus' + item.group + '"><td colspan="2"><label>' + item.group + ':</label></td><td>' + 
							'<button id="groupBtn' + item.group + '" title="Expand/Collapse" class="dlgClick" data-op="onDlgEditTemplateExpCol" data-id="' + item.group + '">' + 
							(groupExpanded ? 'Collapse' : 'Expand') + '</button></td><td colspan="3"></td></tr>' 
					}
					group = item.group
				}
				x  += '<tr class="wtPlus' + item.usage + (item.group ? ' group' + item.group + '" ' + (groupExpanded ? '' : 'style="visibility: collapse;') : '' ) + '">';
				// Name
				x += '<td><label>' + item.name + ':</label></td>' 
				// Help
				x += '<td>' + (item.help ? 
					'<img src="/images/icons/help.gif" border="0" width="22" height="22" alt="Help" title="Usage: ' + item.usage + '\n' + item.help + (item.example ? '\nExample: ' + item.example : '' ) + '" />': '') + '</td>';
				// Input
				x += '<td><input type="text" name="wtparam' + i + '" class="dlgPaste' + /*((item.type === "typeCategory") ? ' dlgCat' : '' ) + */'" ' +
					 'data-op="onDlgEditTemplatePaste" data-id="' + i + '" value="' + item.value + '" ';
				x += 'placeholder="' + itemDef.placeholder + '" '
				x += 'list="wtPlusAutoComplete' + i + '" '
				if ((item.type === "typeReadOnly") || (item.type === "typeTOC")) {
					x += 'readonly '
				}
				if (i === 0) {
					x += 'autofocus '
				}
				x += '/><datalist id="wtPlusAutoComplete' + i + '">' 
				x += item.values.map(item => '<option value="' + item + '"/>' ).join('\n')
				x +='</datalist></td>';
				//Buttons
				x +='<td>' + ((item.type != "typeReadOnly") && (item.type != "typeTOC") ? 
					'<button title="Restore value" class="dlgClick" data-op="onDlgEditTemplateRestore" data-id="' + i + '" tabindex="-1">R</button>' : '') + '</td>' 
				x +='<td>' + ((item.initial) ? 
					'<button title="Auto value" class="dlgClick" data-op="onDlgEditTemplateInitial" data-id="' + i + '" tabindex="-1">A</button>' : '') + '</td>' 
				x +='<td>' + ((urlMappings.filter(a=>a.prefixURL !== undefined).map(a=>a.type).includes(item.type)) ? 
					'<button title="Open link" class="dlgClick" data-op="onDlgEditTemplateFollow" data-id="' + i + '" tabindex="-1">O</button>' : '') + '</td>' 
				x +='</tr>';
													
				return x
			}).join('') + 
			'</table>' +
			'</div>' +
			'<div style="display:flex">'+        
			//Legend
			'<button id="wtPlusLegendBtn" class="dlgClick" data-op="onDlgNone" tabindex="-1">Legend'+
			'<table class="wtPlusLegend">' + 
			'<tr><td colspan="2" class="wtPlusRequired">Required</td></tr>' +
			'<tr><td colspan="2" class="wtPlusPreferred">Preferred</td></tr>' +
			'<tr><td colspan="2" class="wtPlusOptional">Optional</td></tr>' +
			'<tr><td><img src="/images/icons/help.gif" border="0" width="22" height="22" alt="Help" /></td><td>Hower for hint</td></tr>' +
			'<tr><td><button title="Restore value" class="dlgClick" data-op="onDlgNone">R</button></td><td>Restore value</td></tr>' +
			'<tr><td><button title="Auto value" class="dlgClick" data-op="onDlgNone">A</button></td><td>Auto value</td></tr>' +
			'<tr><td><button title="Open link" class="dlgClick" data-op="onDlgNone">O</button></td><td>Open link</td></tr>' +
			'</table>' +
			'</button>' +
			'<div style="flex:1"></div>' +
			'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Edit_Template" target="_blank">Help</a>' +
			//OK, Cancel
			'<button style="text-align:right" class="dlgClick" data-op="onDlgEditTemplateBtn" data-id="0">Close</button>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgEditTemplateBtn" data-id="1" value="default">Update changes</button>' +
			'</div>' 

		tb.elDlgParams = document.getElementById("wtPlusDlgParams");
				  
		attachEvents('button.dlgClick', 'click')
		attachEvents('input.dlgPaste', 'paste')
		attachEvents('input.dlgPaste', 'keypress')
		
		tb.addToSummary = summaryPrefix + " Template:" + tb.template.name;
		if (tb.unknownParams) 
		  alert('Unrecognized parameters:\n' + tb.unknownParams + '\n\nThey will be removed, unless you cancel.')
		tb.elDlg.showModal();
	}    
};
/*

	if ($('#addCategoryInput').length) {
		$('#addCategoryInput').autoComplete({
			cache: false,
			source: function(term, suggest) {
				wtCategorySuggestion(term, suggest);
			},
			renderItem: function(category, search) {
				return wtCategorySuggestionItemRender(category, search);
			},
			onSelect: function(e, term, item) {
				changesMade = 1;
				var categoryText = "[[Category:" + term + "]]\n";
				categoryText = categoryText.replace(/_/g, ' ');
				if ((typeof coloredEditor !== 'undefined') && (coloredEditor)) {
					coloredEditor.setCursor(0, 0);
					var cursor = coloredEditor.getCursor();
					coloredEditor.replaceRange(categoryText, cursor, cursor);
					coloredEditor.focus();
				} else {
					var textArea = document.editform.wpTextbox1;
					var textScroll = textArea.scrollTop;
					textArea.value = categoryText + textArea.value;
					textArea.selectionStart = 0;
					textArea.selectionEnd = categoryText.length;
					textArea.scrollTop = textScroll;
					textArea.focus();
				}
				$('#addCategoryInput').val('').hide();
				e.preventDefault();
				return false;
			},
		});
	}
});
function wtCategorySuggestion(term, suggest) {
	var includeAll = 0;
	if ($('#categorySuggestionIncludeAll').length && $('#categorySuggestionIncludeAll').val()) {
		includeAll = 1;
	}
	sajax_do_call("Title::ajaxCategorySearch", [term, includeAll], function(result) {
		var suggestions = JSON.parse(result.responseText);
		suggest(suggestions);
	});
}
function wtCategorySuggestionItemRender(item, search) {
	search = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
	var re = new RegExp("(" + search.split(' ').join('|') + ")","gi");
	var html = '';
	html += '<div class="autocomplete-suggestion" data-val="' + item + '">';
	html += item.replace(re, "<b>$1</b>");
	html += '</div>';
	return html;
}

*/
function onDlgEditTemplateBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		var a = tb.elDlgParams.querySelectorAll('input');
		for (var i in tb.templateitems) {tb.templateitems[i].value = a[i].value.trim()};
		tb.inserttext = '';
		var line = '';
		if (tb.templateitems && tb.templateitems.length) {
			var line = '\n';
			for (let prop of tb.templateitems) {
				if (prop.numbered) {
					line = '';
					if (prop.value) {
						tb.inserttext += '|' + prop.value;
					} else {
						switch(prop.usage) {
						case "Required":
						case "Preferred":
						tb.inserttext += '|';
						break;
						} 
					}    
				} else {
					if (prop.value) {
						tb.inserttext += '\n|' + prop.name + '= ' + prop.value;
					} else {
						switch(prop.usage) {
							case "Required":
							case "Preferred":
							tb.inserttext += '\n|' + prop.name + '= ';
							break;
						} 
					}    
				}
			}
		}
		tb.inserttext = '{{' + tb.template.name + tb.inserttext + line + '}}' ;
		tb.inserttext += (tb.textAfter[0]==='\n') ? '': line;
		
		tb.textResult = tb.textBefore + tb.inserttext + tb.textAfter;
		tb.selStart = tb.textBefore.length
		tb.selEnd = tb.selStart +  tb.inserttext.length;
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		updateEdit();
	};
	tb.elDlg.innerHTML = '';
	tb.addToSummary = ''
	return false
};

//listener for paste event
function onDlgEditTemplatePaste(i, evt) {
	if (evt.type == 'keypress') {
		var key = evt.which || evt.keyCode;
		if (key === 13) { 
			onDlgEditTemplateBtn('1')
		} 
	} 
	if (evt.type == 'paste') {
		let clipdata = evt.clipboardData || window.clipboardData;
		var s = clipdata.getData('text/plain');
		s = decodeURIComponent (s);
		for(const j of urlMappings) {
			if (tb.templateitems[i].type === j.type) {
				if (s.startsWith(j.prefixURL)) {
					s = s.replace(j.prefixURL, '');
					if ((j.sufixURL!='') && (s.endsWith(j.sufixURL))) {
						s = s.replace(j.sufixURL, '');
					}    
					s = j.fromURL ? j.fromURL(s) : s
					document.execCommand("insertHTML", false, s);
					evt.preventDefault();
				}
			}
		}
	}
}

function onDlgEditTemplateFollow(i) {
	var item=tb.templateitems[i];
	var e=tb.elDlgParams.querySelectorAll('input')[i];
	var s = e.value;

	for(const i of urlMappings) {
		if (item.type === i.type) {
			if (s) {
				s = (i.prefixURL === '') ? encodeURI (s) : encodeURIComponent (s)
				s = i.toURL ? i.toURL(s) : s
				s = i.prefixURL + s + i.sufixURL
			} else {
				s = i.emptyURL !== undefined ? i.emptyURL : i.prefixURL
			}
		}
	}
   
	if (s.startsWith('http')) {
		window.open(s, '_blank');
	}
	return false
};

function onDlgEditTemplateInitial(i) {
	var item=tb.templateitems[i];
	var e=tb.elDlgParams.querySelectorAll('input')[i];
	if (item.initial.startsWith("Title:")) {
		e.value = document.title.replace(RegExp(item.initial.substring(6)), '$1');
	}    
	if (item.initial.startsWith("Category:") && (tb.categories)) {
		var r=RegExp(item.initial.substring(9), 'mg')
		e.value = tb.categories.match(r).join('\n').replace(r, '$1');
	}
	return false
};

function onDlgEditTemplateRestore(i) {
	var item=tb.templateitems[i];
	var e = tb.elDlgParams.querySelectorAll('input')[i];
	e.value = item.value;
	return false
};

function onDlgEditTemplateExpCol(gName) {
	var e = tb.elDlg.getElementsByClassName('group' + gName);
	var b = document.getElementById('groupBtn' + gName);
	if (b.innerHTML == 'Expand') {
		b.innerHTML = 'Collapse'
		for(var ei of e) {ei.style.visibility = 'visible';}
	} else {
		b.innerHTML = 'Expand'
		for(var ei of e) {ei.style.visibility = 'collapse';}
	}
	return false
};

function WikiTreeGetCategory (query, fixed){
	fetch("https://www.wikitree.com/index.php?action=ajax&rs=Title::ajaxCategorySearch&rsargs[]=" + query + "&rsargs[]=1")
	.then((resp) => resp.json())
	.then(jsonData => {
		console.log('cat: ' + jsonData);
		return (jsonData);
	})
};

/**************************/
/* Select template to add */
/**************************/
 
function selectTemplate (data) {
	tb.elDlg.innerHTML = 
		'<h3>Select template</h3>' + 
		'<input type="checkbox" class="cbFilter" id="cb1" name="cb1" data-op="onDlgSelectTemplateFlt" data-id="1" value="Project Box"' + (data=="Project Box" ? ' checked' : '') + '><label for="cb1"> Project Box</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb2" name="cb2" data-op="onDlgSelectTemplateFlt" data-id="2" value="Sticker"' + (data=="Sticker" ? ' checked' : '') + '><label for="cb2"> Sticker</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb3" name="cb3" data-op="onDlgSelectTemplateFlt" data-id="3" value="Profile Box"' + (data=="Profile Box" ? ' checked' : '') + '><label for="cb3"> Research Note</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb4" name="cb4" data-op="onDlgSelectTemplateFlt" data-id="4" value="External Link"' + (data=="External Link" ? ' checked' : '') + '><label for="cb4"> External Link</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb5" name="cb5" data-op="onDlgSelectTemplateFlt" data-id="5" value="CategoryInfoBox"' + (data=="CategoryInfoBox" ? ' checked' : '') + '><label for="cb5"> CategoryInfoBox</label><br>' +
		'<label for="flt1">Filter: </label><input type="text" class="cbFilter" id="flt1" name="flt1" data-op="onDlgSelectTemplateFlt" data-id="9"><br>' +
		'<div style="min-width: 600px;overflow-y:auto;height: 400px;"><table style="width: 100%;" id="tb">' +
		tb.templates.map(item => '<tr class="trSelect" data-op="onDlgSelectTemplateTrSel"><td>' + item.name + '</td><td>' + item.group + '</td><td>' + item.subgroup + '</td></tr>' ).join('\n') +
		'</table></div>' +
		'<div style="text-align:right">'+
		'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Add_Template" target="_blank">Help</a>' +
		//OK, Cancel
		'<button style="text-align:right" class="dlgClick" data-op="onDlgSelectTemplateBtn" data-id="0">Close</button>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgSelectTemplateBtn" data-id="1" value="default">Select</button>' +
		'</div>' 
	attachEvents('button.dlgClick', 'click')
	attachEvents('input.cbFilter', 'input')
	attachEvents('tr.trSelect', 'click')
	onDlgSelectTemplateFlt ()
	tb.elDlg.showModal();
};

function onDlgSelectTemplateFlt () {
	let lb = tb.elDlg.querySelector("#tb")
	var s0 = '';
	for (let i=1;i<=5;i++) {
		if (tb.elDlg.querySelector("#cb"+i).checked)
		  s0 += (s0=='' ? '' : '|') + tb.elDlg.querySelector("#cb"+i).value
	}
	var r0 = new RegExp('('+s0+')','i')
	
	var s1 = tb.elDlg.querySelector("#flt1").value
	var r1 = new RegExp(s1,'i')
	
	lb.innerHTML = tb.templates.filter(item=> 
		((s0==='') || item.type.match(r0)) && 
		((s1==='') || item.name.match(r1) || item.group.match(r1) || item.subgroup.match(r1))
//    ).map(item => '<option value="' + item.name + '">' + item.name + ' (' + item.group + ': ' + item.subgroup + ')</option>' ).join('\n') 
		).map(item => '<tr class="trSelect" data-op="onDlgSelectTemplateTrSel"><td>' + item.name + '</td><td>' + item.group + '</td><td>' + item.subgroup + '</td></tr>' ).join('\n') 
	attachEvents('tr.trSelect', 'click')
}

function onDlgSelectTemplateTrSel (tr) {
	removeClass ('tr.trSelect', 'trSelected')
	tr.classList.add("trSelected")
}

function onDlgSelectTemplateBtn(update) {
	if (update==='1') {
		if (tb.elDlg.querySelectorAll('.trSelected>td').length === 0) {
			alert ('No template selected: Select a template before closing the dialog')
			return false
		}
		tb.elDlg.close();
		//Add template 
		var templateName = tb.elDlg.querySelectorAll('.trSelected>td')[0].innerText
		paramsCopy (templateName)
		paramsInitialValues ();
		editTemplate ("Added");
	} else {
		tb.elDlg.close();
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};

/*********************************/
/* Automatic update like EditBOT */
/*********************************/

function AutoUpdate () {
	let s0 = ''
	let s1 = ''
	let s2 = ''
	for (var loc=0;loc<3;loc++) {
		let actArr = ''
		if (loc==0) {
			if (tb.birthLocation) {
				s0 = 'Birth Location'
				s1 = tb.birthLocation
				actArr = tb.locations
			}
		} else if (loc==1) {
			if (tb.deathLocation) {
				s0 = 'Death Location'
				s1 = tb.deathLocation
				actArr = tb.locations
			}
		} else if (loc==2) {
			if (tb.textAll) {
				s0 = 'Bio'
				s1 = tb.textAll
				actArr = tb.cleanup
			}
		}
		if (actArr) {
			for (var j=0;j<actArr.length;j++) {
				let clean = actArr[j]
				let s3 = ''
				for (var i=0;i<clean.actions.length;i++) {
					let s = s1
					let action = clean.actions[i]
					switch(action.action) {
						case "replaceRegEx": 
						let reg = RegExp(action.from, action.flags)
						s1 = s1.replace(reg, action.to)
						break;
						case "replace": 
						s1 = s1.replace(action.from, action.to)
						break;
							default: 
						alert ('Unknown action: ' + action.action + ' defined for source: ' + clean.name)
						s1 = ''
					}
					if (s1=='') break
					if ((s1!=='') && (s !== s1)) {
						s3 += (s3!=='' ? ', ' : '') + action.description
					}    
				}
				if (s3!=='') {
					s2 += '<input type="checkbox" class="cb' + loc + '_' + j + '" id="cb' + loc + '_' + j + '" name="cb' + loc + '_' + j + '" data-op="onDlgPasteSourceCB" data-id="1" value="' + loc + '_' + j + '" checked>' +
						'<label for="cb' + loc + '_' + j + '"> ' + s0 + ' ' + clean.description + ' ' + ' (' + s3 + ')</label><br>\n' 
				}
			}
		}
	}
	if (s2 == '') {
		alert ('Nothing to change.')
	} else {
		tb.elDlg.innerHTML = 
			'<h3>Automated cleanup</h3>' + 
			s2 +
			'<div style="text-align:right">'+
			//OK, Cancel
			'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Profile_Cleanup" target="_blank">Help</a>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgProfileCleanupBtn" data-id="0">Close</button>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgProfileCleanupBtn" data-id="1" value="default">Select</button>' +
			'</div>' 
		attachEvents('button.dlgClick', 'click')
		attachEvents('input.cbInline', 'input')
		tb.elDlg.showModal();
	}
};

function onDlgProfileCleanupBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		//Set updated text

		let s0 = ''
		let s1 = ''
		let s2 = ''
		let actArr = []
		for (var loc=0;loc<3;loc++) {
			if (loc==0) {
				s0 = 'Birth Location'
				s1 = tb.birthLocation
				actArr = tb.locations
			} else if (loc==1) {
				s0 = 'Death Location'
				s1 = tb.deathLocation
				actArr = tb.locations
			} else if (loc==2) {
				s0 = 'Bio'
				s1 = tb.textAll
				actArr = tb.cleanup
			}
			if (actArr) {
				for (var j=0;j<actArr.length;j++) {
					var cb = tb.elDlg.querySelectorAll('#cb'+loc+'_'+j)[0]
					if ((cb) && (cb.checked)) {
						let clean = actArr[j]

						let s = ''
						let s1 = ''
						let s3 = ''
						for (var i=0;i<clean.actions.length;i++) {
							s = s1
							let action = clean.actions[i]
							switch(action.action) {
								case "replaceRegEx": 
								let reg = RegExp(action.from, action.flags)
								s1 = s1.replace(reg, action.to)
								break;
								case "replace": 
								s1 = s1.replace(action.from, action.to)
								break;
								default: 
								s1 = ''
							}
							if (s1=='') break
							if ((s1!=='') && (s !== s1)) {
								s3 += (s3!=='' ? ', ' : '') + action.description
							}    
						}
						if (s3!=='') {
							s2 += (s2!=='' ? ', ' : '' ) + '+' + s0 + ' ' + clean.description + ' (' + s3 + ')' 
						}
					}
				}
			}
			if (loc==0) {
				tb.birthLocationResult = s1;
			} else if (loc==1) {
				tb.deathLocationResult = s1;
			} else if (loc==2) {
				tb.textResult = s1;
			}
		}
		tb.addToSummary = s2;
		updateEdit();
	} else {
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};


/**************************/
/* Paste source reformat  */
/**************************/

function pasteSource () {
	tb.elDlg.innerHTML = 
		'<h3>Paste source</h3>' + 
		'<label for="srcPaste">Clipboard:</label><br>' +
		'<textarea class="srcPaste" data-op="onDlgPasteSourcePaste" data-id="1" placeholder="Paste a source or URL here." rows="5" cols="80"></textarea><br>' +
		'<input type="checkbox" class="cbInline" id="cb1" name="cb1" data-op="onDlgPasteSourceCB" data-id="1" value="Inline" checked><label for="cb1"> Inline citation</label><br>' +
		'<label for="resultFld">Citation to add:</label><br>' +
		'<textarea class="resultFld" rows="5" cols="80"></textarea>' +
		'<div style="text-align:right">'+
		//OK, Cancel
		'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Paste_Sources" target="_blank">Help</a>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgPasteSourceBtn" data-id="0">Close</button>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgPasteSourceBtn" data-id="1" value="default">Select</button>' +
		'</div>' 
	attachEvents('button.dlgClick', 'click')
	attachEvents('input.cbInline', 'input')
	attachEvents('textarea.srcPaste', 'paste')
	tb.elDlg.showModal();
};

function onDlgPasteSourceBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		//Add template 
		tb.inserttext = tb.elDlg.querySelectorAll('.resultFld')[0].value;
		tb.inserttext += (tb.textAfter[0]==='\n') ? '': '\n';
		tb.textResult = tb.textBefore + tb.inserttext + tb.textAfter;
		tb.selStart = tb.textBefore.length
		tb.selEnd = tb.selStart +  tb.inserttext.length;
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		updateEdit();
	} else {
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};

function onDlgPasteSourceCB(i, evt) {
	var e = tb.elDlg.querySelectorAll('.resultFld')[0]
	let s = e.value.replace('<ref>', '').replace('</ref>', '').replace('* ', '')
	if (tb.elDlg.querySelectorAll('.cbInline')[0].checked) {
		e.value = '<ref>' + s + '</ref>'
	} else {
		e.value = '* ' + s
	}
}

//listener for paste event
function onDlgPasteSourcePaste(i, evt) {
	if (evt.type == 'keypress') {
		var key = evt.which || evt.keyCode;
		if (key === 13) { 
			onDlgPasteSourceBtn('1')
		} 
	} 
	if (evt.type == 'paste') {
		var clipdata = evt.clipboardData || window.clipboardData;
		var s = clipdata.getData('text/plain');
		var s1 = '';
		s = decodeURIComponent (s);

		if (tb.sources) {
			for (let source of tb.sources) {
				var b = false
				for (let condition of source.conditions) {
					switch(condition.action) {
						case "startsWith": 
						b = s.startsWith(condition.find)
						break;
						case "includes": 
						b = s.includes(condition.find)
						break;
						default: alert ('Unknown condition: ' + condition.action + ' defined for source: ' + source.name)
					}   
					if (b) break;
				}
				if (b) {
					s1 = s
					for (let action of source.actions) {
						switch(action.action) {
							case "replaceRegEx": 
							let reg = RegExp(action.from, 'mg')
							s1 = s1.replace(reg, action.to)
							break;
							case "replace": 
							s1 = s1.replace(action.from, action.to)
							break;
							default: 
							alert ('Unknown action: ' + action.action + ' defined for source: ' + source.name)
							s1 = ''
						}
						if (s1=='') break
					}
					if (s1!=='') {
						tb.addToSummary = 'Added ' + source.description
						break
					}
				}
			}
		}

		// Adding inline citation
		if (s1!=='') {
			if (tb.elDlg.querySelectorAll('.cbInline')[0].checked) {
				s1 = '<ref>' + s1 + '</ref>'
			} else {
				s1 = '* ' + s1
			} 
		}
		tb.elDlg.querySelectorAll('.resultFld')[0].value = s1
	}
}

/**************************/
/* Menu events            */
/**************************/

function posToOffset (txt, pos){
  const arr=txt.split("\n");
  var len=0;
  for (var i=0;i<pos.line;i++) 
	len+= length(arr[i]) + 1 ;
  return len+pos.ch ;
};

function wtPlus (params){
	if (tb.elText.style.display == "none") {
		alert('Enhanced editor is not supported.\n\nTurning it off to use the extension.');
		tb.elEnhanced.click();
	}

	//Sets all edit variables
	tb.elEnhancedActive = (tb.elText.style.display == "none");
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
			
			
//            alert ('Enhanced editor is not supported.<br>Turn it off to use WikiTree+ extension.');
/*
		if (window.coloredEditor) {
			tb.textAll = coloredEditor.getValue().replace(/\r\n|\n\r|\n|\r/g, '\n')
			tb.selStart = posToOffset (tb.textAll, coloredEditor.getCursor("from"))
			tb.selEnd = posToOffset (tb.textAll, coloredEditor.getCursor("to"))
*/
		}

	tb.selStart = tb.elText.selectionStart;
	tb.selEnd = tb.elText.selectionEnd;
	tb.textAll = tb.elText.value;
	if (tb.elBirthLocation) {
		tb.birthLocation = tb.elBirthLocation.value;
	}
	if (tb.elDeathLocation) {
		tb.deathLocation = tb.elDeathLocation.value;
	}
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}

	tb.textBefore = tb.textAll.substring(0,  tb.selStart);
	tb.textSelected = tb.selEnd == tb.selStart ? '' : tb.textAll.substring(tb.selStart, tb.selEnd);
	tb.textAfter = tb.textAll.substring(tb.selEnd);
	tb.categories = tb.textAll.match(/\[\[Category:.*?\]\]/mgi)
	if (tb.categories){
		tb.categories = tb.categories.join('\n').replace(/\[\[Category:\s*(.*?)\s*\]\]/mgi, '$1');
	}        
	tb.textResult = tb.textAll; 

	if (params.template) {
		//Add template 
		paramsCopy (params.template)
		paramsInitialValues ();
		editTemplate ("Added");
	} else {
		switch(params.action) {
			case "": break;
			case "EditTemplate": //Edit template
//            var expression = /{{[\s\S]*?}}/g
		var expression = /\{\{.*?(\[\[[^{}[\]]*?\]\][^{}[\]]*?|\[[^{}[\]]*?\][^{}[\]]*?|\{\{[^{}[\]]*?\}\}[^{}[\]]*?)*?[^{}[\]]*?\}\}/gms


		if (tb.selStart != tb.selEnd) {
			let tem = tb.textSelected.match(expression);
			if (tem && (tem.length == 1)) {
				var s = tb.textSelected.split(expression);
				tb.textBefore += s[0];
				tb.textSelected = tem[0];
				tb.textAfter = s[2] + tb.textAfter;
				tb.selStart = tb.textBefore.length
				tb.selEnd = tb.selStart + tb.textSelected.length;
				paramsFromSelection();
				editTemplate("Edited");
			} else {
				alert ('There is no template in selected text');
			}    
		} else {
			let tem = tb.textAll.match(expression);
			if (tem) {
				if (tem.length == 1) {
					var s = tb.textAll.split(expression);
					tb.textBefore = s[0];
					tb.textSelected = tem[0];
					tb.textAfter  = s[2];
					tb.selStart = tb.textBefore.length
					tb.selEnd = tb.selStart + tb.textSelected.length;
					paramsFromSelection();
					editTemplate("Edited");
				} else {
					let match = ''
					while (match = expression.exec(tb.textAll)) {
						if ((match.index < tb.selStart) && (expression.lastIndex > tb.selStart)) {
							tb.textBefore = tb.textAll.substring(0,  match.index);
							tb.textSelected = match[0];
							tb.textAfter  = tb.textAll.substring(expression.lastIndex);
							tb.selStart = tb.textBefore.length
							tb.selEnd = tb.selStart + tb.textSelected.length;
							paramsFromSelection();
							editTemplate("Edited");
							return;
						};
					};
					alert ('There is no template at cursor position.')
				}
			} else {
				alert ('There is no template on the page.')
			}
		}
		break;

		case "AutoFormat": //automatic formting
		tb.textResult = tb.textAll.replace(/^ *\| *([^ =|]*) *= */mg, "|$1= ")
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		tb.addToSummary = ''
		updateEdit ();
		break;

		case "AutoUpdate": //automatic corrections
		AutoUpdate ();
		break;   

		case "EditBOTConfirm": //EditBOT confirmation
		tb.textResult = tb.textAll.replace(/\|(Review|Manual)\}\}/mg, "|Confirmed}}")
		tb.textResult = tb.textResult.replace(/\s\s\}\}/mg, " ")
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		tb.addToSummary = "Confirmation for EditBOT"
		updateEdit ();
		break;
		
		case "AddTemplate": //add any template
		selectTemplate (params.data);
		break;

		case "PasteSource": //paste a source citation
		pasteSource ();
		break;
		

		default: alert ("Unknown event " + params.action)
		};
	};
	
};

/* Classes */

const attachClass = (selector, className) => {
	document.querySelectorAll(selector).forEach(i=>i.classList.add(className))
}

const removeClass = (selector, className) => {
	document.querySelectorAll(selector).forEach(i=>i.classList.remove(className))
}

/* Events */

const attachEvents = (selector, eventType) => {
	document.querySelectorAll(selector).forEach(i=>i.addEventListener(eventType, event=>mainEventLoop(event)))
}
function mainEventLoop (event) {

	if (tb.elText.style.display == "none") {
		alert ('Enhanced editor is not supported.\n\nTurning it off to use the extension.');
		tb.elEnhanced.click();
	}   

	let element = event.srcElement
	if (element.tagName == 'TD') {
		element = element.parentElement
	}
	const op = element.dataset.op
	const id = element.dataset.id
	if (op === 'wtPlus')    {event.preventDefault(); return wtPlus(id)}
	
	if (op === 'onDlgEditTemplateExpCol') {event.preventDefault(); return onDlgEditTemplateExpCol(id)}
	if (op === 'onDlgEditTemplateRestore')    {event.preventDefault(); return onDlgEditTemplateRestore(id)}
	if (op === 'onDlgEditTemplateInitial')    {event.preventDefault(); return onDlgEditTemplateInitial(id)}
	if (op === 'onDlgEditTemplateFollow') {event.preventDefault(); return onDlgEditTemplateFollow(id)}
	if (op === 'onDlgEditTemplateBtn')  {event.preventDefault(); return onDlgEditTemplateBtn(id)}
	if (op === 'onDlgEditTemplatePaste')  return onDlgEditTemplatePaste(id, event)

	if (op === 'onDlgPasteSourcePaste')  return onDlgPasteSourcePaste(id, event)
	if (op === 'onDlgPasteSourceCB')  return onDlgPasteSourceCB(id, event)    
	if (op === 'onDlgPasteSourceBtn') {event.preventDefault(); return onDlgPasteSourceBtn(id)}

	if (op === 'onDlgProfileCleanupBtn') {event.preventDefault(); return onDlgProfileCleanupBtn(id)}

	if (op === 'onDlgSelectTemplateFlt') return onDlgSelectTemplateFlt()
	if (op === 'onDlgSelectTemplateTrSel') return onDlgSelectTemplateTrSel(element)
	if (op === 'onDlgSelectTemplateBtn') {event.preventDefault(); return onDlgSelectTemplateBtn(id)}

	if (op === 'onDlgNone') {event.preventDefault(); return}
	
	console.error ('Missing data-op on ', element)
}

function isEditPage() {
	return (window.location.href.match(/\/index.php\?title=Special:EditPerson&.*/g) ||
	        window.location.href.match(/\/index.php\?title=.*&action=edit.*/g) ||
			window.location.href.match(/\/index.php\?title=.*&action=submit.*/g));
}

/* Initialization */
chrome.storage.sync.get('wtplus', (result) => {
	if (result.wtplus && isEditPage()) {
		tb.nameSpace = (document.title.startsWith('Edit Person ')) ? 'Profile' : ''
		let w = document.querySelector('h1 > .copyWidget')
		if (w) {
			tb.wikitreeID = w.getAttribute('data-copy-text');
		}
		tb.elText = document.getElementById("wpTextbox1");
		tb.elBirthLocation = document.getElementById("mBirthLocation");
		tb.elDeathLocation = document.getElementById("mDeathLocation");

		tb.elSummary = document.getElementById("wpSummary");
		tb.elEnhanced = document.getElementById("toggleMarkupColor");

		document.getElementById("toolbar").insertAdjacentHTML('beforeend', '<dialog id="wtPlusDlg"></dialog>')
		tb.elDlg = document.getElementById("wtPlusDlg");

		// Loading of template definition From Storage
		chrome.storage.local.get(['alltemplates'], function(a){
			if (a.alltemplates && a.alltemplates.version) {
				// Is in storage
				tb.templates = a.alltemplates.templates;
				tb.cleanup = a.alltemplates.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
				tb.locations = a.alltemplates.locations; if (!(tb.locations)) {tb.locations = []};
				tb.sources = a.alltemplates.sources; if (!(tb.sources)) {tb.sources = []};
				tb.dataVersion = new Date(a.alltemplates.version);
				console.log('Storage: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates' + ', ' +  tb.cleanup.length + ' cleanup' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
			} else {
				// Not in storage
				tb.dataVersion = new Date("2000-01-01T00:00:00+01:00");
			} 
			// Loading of template definition From Extension
			fetch(chrome.runtime.getURL("features/wt+/templatesExp.json"))
			.then((resp) => resp.json())
			.then(jsonData => {
				const d = new Date(jsonData.version)
				if (d.getTime () > tb.dataVersion.getTime ()) {
					// Extension definition is newer
					tb.templates = jsonData.templates;
					tb.cleanup = jsonData.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
					tb.locations = jsonData.locations; if (!(tb.locations)) {tb.locations = []};
					tb.sources = jsonData.sources; if (!(tb.sources)) {tb.sources = []};
					tb.dataVersion = d;
					console.log('Extension: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates.' + ', ' +  tb.cleanup.length + ' cleanup.' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
					chrome.storage.local.set({"alltemplates": jsonData});
				}
				if (tb.dataVersion.getTime () < new Date().getTime () - 6 * 3600 * 1000) {
					// Loading of template definition From Web
					fetch("https://wikitree.sdms.si/chrome/templatesExp.json")
					.then((resp) => resp.json())
					.then(jsonData => {
						const d = new Date(jsonData.version)
						if (d.getTime () > tb.dataVersion.getTime ()) {
							// Web definition is newer
							tb.templates = jsonData.templates;
							tb.cleanup = jsonData.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
							tb.locations = jsonData.locations; if (!(tb.locations)) {tb.locations = []};
							tb.sources = jsonData.sources; if (!(tb.sources)) {tb.sources = []};
							tb.dataVersion = d;
							console.log('Web: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates.' + ', ' +  tb.cleanup.length + ' cleanup.' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
							chrome.storage.local.set({"alltemplates": jsonData});
						}
					})
				}
			})
		});
	}
});

/*
Todo. Add spaces on edit comment.
1.0.4
  * Condensed template info in the dialog to occupy less space.
  * After switching off the enhanced editor the selected function is executed if possible.
  * AutoCorrection of location fields.
  * Added AutoCorrection to categories
  * Implemented case insensitive in template parameter names recognition
*/


/***/ }),

/***/ "./src/thirdparty/jquery.hoverDelay.js":
/*!*********************************************!*\
  !*** ./src/thirdparty/jquery.hoverDelay.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


(jquery__WEBPACK_IMPORTED_MODULE_0___default().fn.hoverDelay) = function (n) {
  var e = { delayIn: 300, delayOut: 300, handlerIn: function () {}, handlerOut: function () {} };
  return (
    (n = jquery__WEBPACK_IMPORTED_MODULE_0___default().extend(e, n)),
    this.each(function () {
      var e,
        t,
        u = jquery__WEBPACK_IMPORTED_MODULE_0___default()(this);
      u.hover(
        function () {
          t && clearTimeout(t),
            (e = setTimeout(function () {
              n.handlerIn(u);
            }, n.delayIn));
        },
        function () {
          e && clearTimeout(e),
            (t = setTimeout(function () {
              n.handlerOut(u);
            }, n.delayOut));
        }
      );
    })
  );
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"content": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwikitree_browser_extension"] = self["webpackChunkwikitree_browser_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/content.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUM2RztBQUNqQjtBQUM1Riw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsK0RBQStELDRCQUE0QixLQUFLLHlCQUF5Qix5QkFBeUIsa0JBQWtCLGtCQUFrQixLQUFLLGlEQUFpRCxxQkFBcUIsS0FBSyw0QkFBNEIsc0JBQXNCLDZCQUE2Qix5QkFBeUIsbUJBQW1CLGtCQUFrQiw2QkFBNkIsS0FBSywyQkFBMkIsb0JBQW9CLHlCQUF5QixnQkFBZ0Isa0JBQWtCLG1CQUFtQix1QkFBdUIsaUJBQWlCLGdCQUFnQiw2QkFBNkIsS0FBSyw4QkFBOEIseUJBQXlCLG1CQUFtQix5QkFBeUIsNkJBQTZCLDZCQUE2QixLQUFLLG9DQUFvQywwQkFBMEIsS0FBSywwREFBMEQsb0JBQW9CLHlCQUF5QixnQkFBZ0Isa0JBQWtCLG1CQUFtQix1QkFBdUIsaUJBQWlCLGdCQUFnQiw2QkFBNkIsS0FBSyw4QkFBOEIseUJBQXlCLG1CQUFtQix5QkFBeUIsNkJBQTZCLDZCQUE2QixLQUFLLG9DQUFvQywwQkFBMEIsS0FBSyx5REFBeUQsb0JBQW9CLHlCQUF5QixnQkFBZ0IsdUJBQXVCLG1CQUFtQixnQkFBZ0IsNkJBQTZCLGtCQUFrQixLQUFLLDhCQUE4Qix5QkFBeUIsbUJBQW1CLHVCQUF1Qix5QkFBeUIsa0JBQWtCLGtCQUFrQiw2QkFBNkIsNkJBQTZCLHVCQUF1Qiw0QkFBNEIsc0JBQXNCLEtBQUssb0NBQW9DLDBCQUEwQixLQUFLLHdGQUF3RixzQkFBc0IsS0FBSyx3R0FBd0csbURBQW1ELHFCQUFxQix1Q0FBdUMsdUJBQXVCLHVGQUF1Rix3QkFBd0IsS0FBSyxrQ0FBa0MscUJBQXFCLEtBQUssbUNBQW1DLHFCQUFxQixLQUFLLHFDQUFxQyxnQ0FBZ0MsS0FBSyxPQUFPLHVGQUF1RixLQUFLLFlBQVksT0FBTyxLQUFLLFlBQVksV0FBVyxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxVQUFVLFlBQVksYUFBYSxXQUFXLFVBQVUsWUFBWSxPQUFPLEtBQUssVUFBVSxZQUFZLFdBQVcsVUFBVSxVQUFVLFlBQVksV0FBVyxVQUFVLFlBQVksT0FBTyxLQUFLLFlBQVksV0FBVyxZQUFZLGFBQWEsYUFBYSxPQUFPLEtBQUssWUFBWSxPQUFPLFlBQVksTUFBTSxVQUFVLFlBQVksV0FBVyxVQUFVLFVBQVUsWUFBWSxXQUFXLFVBQVUsWUFBWSxPQUFPLEtBQUssWUFBWSxXQUFXLFlBQVksYUFBYSxhQUFhLE9BQU8sS0FBSyxZQUFZLE9BQU8sWUFBWSxNQUFNLFVBQVUsWUFBWSxXQUFXLFlBQVksV0FBVyxVQUFVLFlBQVksV0FBVyxNQUFNLEtBQUssWUFBWSxXQUFXLFlBQVksYUFBYSxXQUFXLFVBQVUsWUFBWSxhQUFhLGFBQWEsYUFBYSxXQUFXLE9BQU8sS0FBSyxZQUFZLE9BQU8sWUFBWSxNQUFNLFVBQVUsT0FBTyxZQUFZLE1BQU0sWUFBWSxXQUFXLFlBQVksY0FBYyxhQUFhLFdBQVcsWUFBWSxPQUFPLEtBQUssVUFBVSxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssWUFBWSwrQ0FBK0MsNEJBQTRCLEtBQUsseUJBQXlCLHlCQUF5QixrQkFBa0Isa0JBQWtCLEtBQUssaURBQWlELHFCQUFxQixLQUFLLDRCQUE0QixzQkFBc0IsNkJBQTZCLHlCQUF5QixtQkFBbUIsa0JBQWtCLDZCQUE2QixLQUFLLDJCQUEyQixvQkFBb0IseUJBQXlCLGdCQUFnQixrQkFBa0IsbUJBQW1CLHVCQUF1QixpQkFBaUIsZ0JBQWdCLDZCQUE2QixLQUFLLDhCQUE4Qix5QkFBeUIsbUJBQW1CLHlCQUF5Qiw2QkFBNkIsNkJBQTZCLEtBQUssb0NBQW9DLDBCQUEwQixLQUFLLDBEQUEwRCxvQkFBb0IseUJBQXlCLGdCQUFnQixrQkFBa0IsbUJBQW1CLHVCQUF1QixpQkFBaUIsZ0JBQWdCLDZCQUE2QixLQUFLLDhCQUE4Qix5QkFBeUIsbUJBQW1CLHlCQUF5Qiw2QkFBNkIsNkJBQTZCLEtBQUssb0NBQW9DLDBCQUEwQixLQUFLLHlEQUF5RCxvQkFBb0IseUJBQXlCLGdCQUFnQix1QkFBdUIsbUJBQW1CLGdCQUFnQiw2QkFBNkIsa0JBQWtCLEtBQUssOEJBQThCLHlCQUF5QixtQkFBbUIsdUJBQXVCLHlCQUF5QixrQkFBa0Isa0JBQWtCLDZCQUE2Qiw2QkFBNkIsdUJBQXVCLDRCQUE0QixzQkFBc0IsS0FBSyxvQ0FBb0MsMEJBQTBCLEtBQUssd0ZBQXdGLHNCQUFzQixLQUFLLHdHQUF3RyxtREFBbUQscUJBQXFCLHVDQUF1Qyx1QkFBdUIsdUZBQXVGLHdCQUF3QixLQUFLLGtDQUFrQyxxQkFBcUIsS0FBSyxtQ0FBbUMscUJBQXFCLEtBQUsscUNBQXFDLGdDQUFnQyxLQUFLLG1CQUFtQjtBQUMzdk07QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsNERBQTRELG1CQUFtQix3QkFBd0IsWUFBWSx3Q0FBd0MseUJBQXlCLEtBQUssdUJBQXVCLDBCQUEwQix3Q0FBd0MsNEJBQTRCLGlCQUFpQixvQkFBb0Isa0JBQWtCLGlCQUFpQixLQUFLLDBDQUEwQywwQkFBMEIsS0FBSyx5Q0FBeUMsOENBQThDLEtBQUssNkJBQTZCLDBDQUEwQyxLQUFLLFdBQVcscUdBQXFHLFVBQVUsWUFBWSxXQUFXLFlBQVksYUFBYSxNQUFNLEtBQUssWUFBWSxhQUFhLGFBQWEsV0FBVyxVQUFVLFVBQVUsVUFBVSxLQUFLLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSw0Q0FBNEMsbUJBQW1CLHdCQUF3QixZQUFZLHdDQUF3Qyx5QkFBeUIsS0FBSyx1QkFBdUIsMEJBQTBCLHdDQUF3Qyw0QkFBNEIsaUJBQWlCLG9CQUFvQixrQkFBa0IsaUJBQWlCLEtBQUssMENBQTBDLDBCQUEwQixLQUFLLHlDQUF5Qyw4Q0FBOEMsS0FBSyw2QkFBNkIsMENBQTBDLEtBQUssdUJBQXVCO0FBQ3ZpRDtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxnRUFBZ0UsMEJBQTBCLCtCQUErQiwrQkFBK0Isb0JBQW9CLG1DQUFtQywwQkFBMEIsMEJBQTBCLEtBQUssdURBQXVELDBCQUEwQixLQUFLLHVDQUF1Qyx3QkFBd0IsS0FBSyxPQUFPLHlJQUF5SSxZQUFZLGFBQWEsYUFBYSxXQUFXLFlBQVksYUFBYSxhQUFhLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLGdEQUFnRCwwQkFBMEIsK0JBQStCLCtCQUErQixvQkFBb0IsbUNBQW1DLDBCQUEwQiwwQkFBMEIsS0FBSyx1REFBdUQsMEJBQTBCLEtBQUssdUNBQXVDLHdCQUF3QixLQUFLLG1CQUFtQjtBQUM1bEM7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsdzFCQUF3MUIsdUJBQXVCLDJDQUEyQyxnQ0FBZ0MsS0FBSyw2R0FBNkcsb0NBQW9DLEtBQUsseUhBQXlILDhCQUE4QixLQUFLLDBDQUEwQyw0QkFBNEIsS0FBSyxvRUFBb0Usa0NBQWtDLEtBQUssZ0dBQWdHLHdDQUF3QyxLQUFLLDRDQUE0QyxrQ0FBa0MsS0FBSyx3REFBd0Qsd0JBQXdCLDhCQUE4QixLQUFLLGdEQUFnRCx3Q0FBd0MsS0FBSyxxRUFBcUUsbUNBQW1DLEtBQUssbUNBQW1DLHdCQUF3QixLQUFLLHNOQUFzTix5Q0FBeUMsS0FBSyxxY0FBcWMsMkJBQTJCLEtBQUssNENBQTRDLGdIQUFnSCxtQkFBbUIsMkJBQTJCLEtBQUssNENBQTRDLDRIQUE0SCwyQkFBMkIseUNBQXlDLEtBQUssd0lBQXdJLDJCQUEyQixLQUFLLHFEQUFxRCwwQkFBMEIsS0FBSyxnSkFBZ0osa0NBQWtDLEtBQUssa0NBQWtDLG1DQUFtQyxLQUFLLGdJQUFnSSxnQ0FBZ0MsS0FBSywrUUFBK1EsZ0NBQWdDLHFDQUFxQyxLQUFLLHNHQUFzRywyQ0FBMkMseUJBQXlCLEtBQUssV0FBVywrSEFBK0gsYUFBYSxhQUFhLGFBQWEsTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxNQUFNLFlBQVksYUFBYSxNQUFNLEtBQUssWUFBWSxNQUFNLE1BQU0sWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLFVBQVUsWUFBWSxNQUFNLGNBQWMsWUFBWSxNQUFNLEtBQUssS0FBSyxPQUFPLFdBQVcsWUFBWSxNQUFNLEtBQUssS0FBSyxPQUFPLGFBQWEsYUFBYSxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sWUFBWSxNQUFNLE9BQU8sWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLE1BQU0sWUFBWSxNQUFNLFVBQVUsWUFBWSxhQUFhLE1BQU0sTUFBTSxZQUFZLGFBQWEsdzBCQUF3MEIsdUJBQXVCLDJDQUEyQyxnQ0FBZ0MsS0FBSyw2R0FBNkcsb0NBQW9DLEtBQUsseUhBQXlILDhCQUE4QixLQUFLLDBDQUEwQyw0QkFBNEIsS0FBSyxvRUFBb0Usa0NBQWtDLEtBQUssZ0dBQWdHLHdDQUF3QyxLQUFLLDRDQUE0QyxrQ0FBa0MsS0FBSyx3REFBd0Qsd0JBQXdCLDhCQUE4QixLQUFLLGdEQUFnRCx3Q0FBd0MsS0FBSyxxRUFBcUUsbUNBQW1DLEtBQUssbUNBQW1DLHdCQUF3QixLQUFLLHNOQUFzTix5Q0FBeUMsS0FBSyxxY0FBcWMsMkJBQTJCLEtBQUssNENBQTRDLGdIQUFnSCxtQkFBbUIsMkJBQTJCLEtBQUssNENBQTRDLDRIQUE0SCwyQkFBMkIseUNBQXlDLEtBQUssd0lBQXdJLDJCQUEyQixLQUFLLHFEQUFxRCwwQkFBMEIsS0FBSyxnSkFBZ0osa0NBQWtDLEtBQUssa0NBQWtDLG1DQUFtQyxLQUFLLGdJQUFnSSxnQ0FBZ0MsS0FBSywrUUFBK1EsZ0NBQWdDLHFDQUFxQyxLQUFLLHNHQUFzRywyQ0FBMkMseUJBQXlCLEtBQUssdUJBQXVCO0FBQ3A4UztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSw0REFBNEQsdUJBQXVCLHdCQUF3QixxQkFBcUIsb0NBQW9DLHlCQUF5QixpQkFBaUIseUJBQXlCLHdCQUF3QixtQkFBbUIsaUJBQWlCLHFCQUFxQixLQUFLLHVCQUF1QixrQkFBa0IsS0FBSywrQkFBK0IsNEJBQTRCLDhCQUE4QiwyQ0FBMkMsMENBQTBDLHFCQUFxQiwyQkFBMkIsNEJBQTRCLHdCQUF3QixLQUFLLHlCQUF5QixtQkFBbUIsaUJBQWlCLEtBQUssb0RBQW9ELHFCQUFxQixtQkFBbUIsb0JBQW9CLHVCQUF1QixLQUFLLHFFQUFxRSxvQkFBb0IsS0FBSywyQkFBMkIseUJBQXlCLDZCQUE2QixLQUFLLHdCQUF3Qix5QkFBeUIsdUJBQXVCLHFCQUFxQixrQkFBa0Isb0JBQW9CLEtBQUssV0FBVyxtSUFBbUksWUFBWSxhQUFhLFdBQVcsWUFBWSxhQUFhLFdBQVcsWUFBWSxhQUFhLFdBQVcsVUFBVSxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxZQUFZLGFBQWEsYUFBYSxhQUFhLFdBQVcsWUFBWSxhQUFhLGFBQWEsTUFBTSxLQUFLLFVBQVUsVUFBVSxLQUFLLEtBQUssVUFBVSxVQUFVLFVBQVUsWUFBWSxNQUFNLEtBQUssVUFBVSxLQUFLLEtBQUssWUFBWSxhQUFhLE1BQU0sS0FBSyxZQUFZLGFBQWEsV0FBVyxVQUFVLFVBQVUsMkNBQTJDLHVCQUF1Qix3QkFBd0IscUJBQXFCLG9DQUFvQyx5QkFBeUIsaUJBQWlCLHlCQUF5Qix3QkFBd0IsbUJBQW1CLGlCQUFpQixxQkFBcUIsS0FBSyx1QkFBdUIsa0JBQWtCLEtBQUssK0JBQStCLDRCQUE0Qiw4QkFBOEIsMkNBQTJDLDBDQUEwQyxxQkFBcUIsMkJBQTJCLDRCQUE0Qix3QkFBd0IsS0FBSyx5QkFBeUIsbUJBQW1CLGlCQUFpQixLQUFLLG9EQUFvRCxxQkFBcUIsbUJBQW1CLG9CQUFvQix1QkFBdUIsS0FBSyxxRUFBcUUsb0JBQW9CLEtBQUssMkJBQTJCLHlCQUF5Qiw2QkFBNkIsS0FBSyx3QkFBd0IseUJBQXlCLHVCQUF1QixxQkFBcUIsa0JBQWtCLG9CQUFvQixLQUFLLHVCQUF1QjtBQUM5M0Y7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EscURBQXFELHlCQUF5QixpQkFBaUIsZ0JBQWdCLHFCQUFxQix3QkFBd0Isb0NBQW9DLHlCQUF5QixxREFBcUQsbUJBQW1CLG9CQUFvQix1QkFBdUIsS0FBSyxxQkFBcUIsd0JBQXdCLHlCQUF5QixhQUFhLG1CQUFtQixzQkFBc0IsS0FBSyxzQkFBc0Isb0JBQW9CLEtBQUssNEJBQTRCLHFCQUFxQix1QkFBdUIsMEJBQTBCLEtBQUsscUJBQXFCLDBCQUEwQixLQUFLLG1DQUFtQyxrQkFBa0IsaUNBQWlDLEtBQUsscUJBQXFCLHlCQUF5QixLQUFLLHNCQUFzQixxQkFBcUIsS0FBSywwQ0FBMEMsd0JBQXdCLDBCQUEwQixnQkFBZ0Isb0JBQW9CLHNCQUFzQix5QkFBeUIsZ0NBQWdDLHlCQUF5QixrQkFBa0IsMEJBQTBCLHVDQUF1QyxzQkFBc0IsMEJBQTBCLEtBQUssT0FBTyx1R0FBdUcsWUFBWSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsYUFBYSxhQUFhLFdBQVcsVUFBVSxZQUFZLE9BQU8sS0FBSyxZQUFZLGFBQWEsV0FBVyxVQUFVLFVBQVUsT0FBTyxLQUFLLFVBQVUsTUFBTSxLQUFLLFVBQVUsWUFBWSxhQUFhLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxVQUFVLFlBQVksT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLFVBQVUsTUFBTSxLQUFLLFlBQVksYUFBYSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsYUFBYSxXQUFXLFlBQVksYUFBYSxXQUFXLFlBQVkscUNBQXFDLHlCQUF5QixpQkFBaUIsZ0JBQWdCLHFCQUFxQix3QkFBd0Isb0NBQW9DLHlCQUF5QixxREFBcUQsbUJBQW1CLG9CQUFvQix1QkFBdUIsS0FBSyxxQkFBcUIsd0JBQXdCLHlCQUF5QixhQUFhLG1CQUFtQixzQkFBc0IsS0FBSyxzQkFBc0Isb0JBQW9CLEtBQUssNEJBQTRCLHFCQUFxQix1QkFBdUIsMEJBQTBCLEtBQUsscUJBQXFCLDBCQUEwQixLQUFLLG1DQUFtQyxrQkFBa0IsaUNBQWlDLEtBQUsscUJBQXFCLHlCQUF5QixLQUFLLHNCQUFzQixxQkFBcUIsS0FBSywwQ0FBMEMsd0JBQXdCLDBCQUEwQixnQkFBZ0Isb0JBQW9CLHNCQUFzQix5QkFBeUIsZ0NBQWdDLHlCQUF5QixrQkFBa0IsMEJBQTBCLHVDQUF1QyxzQkFBc0IsMEJBQTBCLEtBQUssbUJBQW1CO0FBQ3hoRztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxnRkFBZ0YsaUJBQWlCLDBCQUEwQixLQUFLLGdDQUFnQywwQkFBMEIsbUJBQW1CLHlCQUF5QixrQkFBa0IsZ0JBQWdCLG9CQUFvQix3QkFBd0Isb0NBQW9DLHlCQUF5QixtQ0FBbUMscUJBQXFCLG9CQUFvQixtQkFBbUIsS0FBSyx1QkFBdUIscUJBQXFCLEtBQUssNEJBQTRCLHVCQUF1Qix3QkFBd0IsS0FBSywwQkFBMEIseUJBQXlCLEtBQUssaUJBQWlCLHlCQUF5QixLQUFLLGtCQUFrQix5QkFBeUIsS0FBSyxhQUFhLDBCQUEwQixLQUFLLG9DQUFvQyx5QkFBeUIsYUFBYSxtQkFBbUIsd0JBQXdCLHNCQUFzQixLQUFLLGlCQUFpQix5QkFBeUIsYUFBYSxrQkFBa0Isd0JBQXdCLHNCQUFzQixLQUFLLGtEQUFrRCx3QkFBd0IsS0FBSyxrQ0FBa0Msd0NBQXdDLEtBQUssa0NBQWtDLDJDQUEyQyxLQUFLLG9CQUFvQixpQkFBaUIsbUJBQW1CLEtBQUssV0FBVyxrSEFBa0gsVUFBVSxZQUFZLE1BQU0sTUFBTSxZQUFZLFdBQVcsWUFBWSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsYUFBYSxhQUFhLFdBQVcsVUFBVSxVQUFVLEtBQUssS0FBSyxVQUFVLE1BQU0sS0FBSyxZQUFZLGFBQWEsTUFBTSxNQUFNLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxNQUFNLFlBQVksV0FBVyxVQUFVLFlBQVksV0FBVyxNQUFNLEtBQUssWUFBWSxXQUFXLFVBQVUsWUFBWSxXQUFXLE1BQU0sTUFBTSxZQUFZLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxVQUFVLFVBQVUsK0RBQStELGlCQUFpQiwwQkFBMEIsS0FBSyxnQ0FBZ0MsMEJBQTBCLG1CQUFtQix5QkFBeUIsa0JBQWtCLGdCQUFnQixvQkFBb0Isd0JBQXdCLG9DQUFvQyx5QkFBeUIsbUNBQW1DLHFCQUFxQixvQkFBb0IsbUJBQW1CLEtBQUssdUJBQXVCLHFCQUFxQixLQUFLLDRCQUE0Qix1QkFBdUIsd0JBQXdCLEtBQUssMEJBQTBCLHlCQUF5QixLQUFLLGlCQUFpQix5QkFBeUIsS0FBSyxrQkFBa0IseUJBQXlCLEtBQUssYUFBYSwwQkFBMEIsS0FBSyxvQ0FBb0MseUJBQXlCLGFBQWEsbUJBQW1CLHdCQUF3QixzQkFBc0IsS0FBSyxpQkFBaUIseUJBQXlCLGFBQWEsa0JBQWtCLHdCQUF3QixzQkFBc0IsS0FBSyxrREFBa0Qsd0JBQXdCLEtBQUssa0NBQWtDLHdDQUF3QyxLQUFLLGtDQUFrQywyQ0FBMkMsS0FBSyxvQkFBb0IsaUJBQWlCLG1CQUFtQixLQUFLLHVCQUF1QjtBQUM5MUc7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0Esd0RBQXdELDBCQUEwQixLQUFLLGdDQUFnQywwQkFBMEIsS0FBSyxpQ0FBaUMsNkJBQTZCLEtBQUssK0RBQStELHFDQUFxQyxLQUFLLHlDQUF5QyxrQkFBa0IsS0FBSyxPQUFPLG1IQUFtSCxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxVQUFVLHVDQUF1QywwQkFBMEIsS0FBSyxnQ0FBZ0MsMEJBQTBCLEtBQUssaUNBQWlDLDZCQUE2QixLQUFLLCtEQUErRCxxQ0FBcUMsS0FBSyx5Q0FBeUMsa0JBQWtCLEtBQUssbUJBQW1CO0FBQzErQjtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxrRUFBa0UsNEJBQTRCLEtBQUssd0JBQXdCLHNDQUFzQyxLQUFLLHVCQUF1QixxQkFBcUIsS0FBSyxnREFBZ0QsdUJBQXVCLE9BQU8scUNBQXFDLHVCQUF1Qix1QkFBdUIsa0JBQWtCLEtBQUssa0NBQWtDLHdCQUF3QixrQkFBa0IsS0FBSyxjQUFjLHVCQUF1QixrQkFBa0Isc0JBQXNCLEtBQUssa0JBQWtCLHFCQUFxQiwwQkFBMEIsS0FBSyxvQkFBb0Isa0JBQWtCLGtCQUFrQixLQUFLLHlCQUF5QixzQ0FBc0MsS0FBSyxzQkFBc0Isa0NBQWtDLEtBQUsscUJBQXFCLHNDQUFzQyxLQUFLLHNCQUFzQixtQ0FBbUMseUNBQXlDLEtBQUssc0JBQXNCLG9CQUFvQix3QkFBd0IsbUJBQW1CLHVCQUF1QixzQkFBc0IsMkJBQTJCLHlCQUF5QixtQkFBbUIsaUJBQWlCLG9CQUFvQiw4QkFBOEIsd0JBQXdCLEtBQUssNkNBQTZDLHFCQUFxQixLQUFLLGVBQWUsMEZBQTBGLEtBQUssWUFBWSxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxPQUFPLGFBQWEsTUFBTSxZQUFZLE9BQU8sS0FBSyxZQUFZLGFBQWEsV0FBVyxLQUFLLEtBQUssWUFBWSxXQUFXLEtBQUssS0FBSyxZQUFZLFdBQVcsVUFBVSxNQUFNLEtBQUssVUFBVSxZQUFZLE1BQU0sS0FBSyxVQUFVLFVBQVUsTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksYUFBYSxPQUFPLEtBQUssVUFBVSxZQUFZLFdBQVcsWUFBWSxXQUFXLFlBQVksYUFBYSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsT0FBTyxLQUFLLFVBQVUsa0RBQWtELDRCQUE0QixLQUFLLHdCQUF3QixzQ0FBc0MsS0FBSyx1QkFBdUIscUJBQXFCLEtBQUssZ0RBQWdELHVCQUF1QixPQUFPLHFDQUFxQyx1QkFBdUIsdUJBQXVCLGtCQUFrQixLQUFLLGtDQUFrQyx3QkFBd0Isa0JBQWtCLEtBQUssY0FBYyx1QkFBdUIsa0JBQWtCLHNCQUFzQixLQUFLLGtCQUFrQixxQkFBcUIsMEJBQTBCLEtBQUssb0JBQW9CLGtCQUFrQixrQkFBa0IsS0FBSyx5QkFBeUIsc0NBQXNDLEtBQUssc0JBQXNCLGtDQUFrQyxLQUFLLHFCQUFxQixzQ0FBc0MsS0FBSyxzQkFBc0IsbUNBQW1DLHlDQUF5QyxLQUFLLHNCQUFzQixvQkFBb0Isd0JBQXdCLG1CQUFtQix1QkFBdUIsc0JBQXNCLDJCQUEyQix5QkFBeUIsbUJBQW1CLGlCQUFpQixvQkFBb0IsOEJBQThCLHdCQUF3QixLQUFLLDZDQUE2QyxxQkFBcUIsS0FBSywyQkFBMkI7QUFDbjBHO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTnZDLE1BQWtHO0FBQ2xHLE1BQXdGO0FBQ3hGLE1BQStGO0FBQy9GLE1BQWtIO0FBQ2xILE1BQTJHO0FBQzNHLE1BQTJHO0FBQzNHLE1BQTRHO0FBQzVHO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsNEZBQU87Ozs7QUFJc0Q7QUFDOUUsT0FBTyxpRUFBZSw0RkFBTyxJQUFJLG1HQUFjLEdBQUcsbUdBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBNEc7QUFDNUc7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyx5RkFBTzs7OztBQUlzRDtBQUM5RSxPQUFPLGlFQUFlLHlGQUFPLElBQUksZ0dBQWMsR0FBRyxnR0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUE4SDtBQUM5SDtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDJHQUFPOzs7O0FBSXdFO0FBQ2hHLE9BQU8saUVBQWUsMkdBQU8sSUFBSSxrSEFBYyxHQUFHLGtIQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QjdFLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQTRHO0FBQzVHO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMseUZBQU87Ozs7QUFJc0Q7QUFDOUUsT0FBTyxpRUFBZSx5RkFBTyxJQUFJLGdHQUFjLEdBQUcsZ0dBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBMkg7QUFDM0g7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyx3R0FBTzs7OztBQUlxRTtBQUM3RixPQUFPLGlFQUFlLHdHQUFPLElBQUksK0dBQWMsR0FBRywrR0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUE2RztBQUM3RztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDBGQUFPOzs7O0FBSXVEO0FBQy9FLE9BQU8saUVBQWUsMEZBQU8sSUFBSSxpR0FBYyxHQUFHLGlHQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QjdFLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQWtIO0FBQ2xIO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsK0ZBQU87Ozs7QUFJNEQ7QUFDcEYsT0FBTyxpRUFBZSwrRkFBTyxJQUFJLHNHQUFjLEdBQUcsc0dBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBbUg7QUFDbkg7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyxnR0FBTzs7OztBQUk2RDtBQUNyRixPQUFPLGlFQUFlLGdHQUFPLElBQUksdUdBQWMsR0FBRyx1R0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUEwRztBQUMxRztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLHVGQUFPOzs7O0FBSW9EO0FBQzVFLE9BQU8saUVBQWUsdUZBQU8sSUFBSSw4RkFBYyxHQUFHLDhGQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQmpDO0FBQ0U7QUFDUjtBQUNvQztBQUNwQztBQUM4QjtBQUM1QjtBQUNJO0FBQ007QUFDRTtBQUNBO0FBQ0o7QUFDQTtBQUNGO0FBQ1Y7QUFDRTtBQUNWO0FBQzVCO0FBQ0EsMkRBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xCVTtBQUN2QjtBQUNPO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFLDZDQUFDO0FBQ0gsaUJBQWlCLEdBQUcsZ0NBQWdDLE1BQU0sSUFBSSxLQUFLO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxFQUFFLDZDQUFDO0FBQ0g7QUFDQTtBQUNBLE1BQU0sNkNBQUM7QUFDUCx3Q0FBd0MsY0FBYyxVQUFVLFlBQVksUUFBUSxXQUFXLElBQUksYUFBYTtBQUNoSDtBQUNBO0FBQ0EsY0FBYyw2Q0FBQztBQUNmO0FBQ0E7QUFDQSxXQUFXLDZDQUFDLHlCQUF5Qiw2Q0FBQztBQUN0QyxHQUFHO0FBQ0gsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDTztBQUNQLGdCQUFnQiw2Q0FBQztBQUNqQixFQUFFLDZDQUFDO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLHlCQUF5QixrREFBTTtBQUMvQjtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTixVQUFVLGtEQUFNO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvS3NFO0FBQ0Y7QUFDQTtBQUNFO0FBQ047QUFDckM7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQixLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DO0FBQ3BDLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsMENBQTBDO0FBQzFDLHVEQUF1RCxJQUFJO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixrRUFBeUI7QUFDNUM7QUFDQSxFQUFFO0FBQ0Y7QUFDQSxtQkFBbUIsbUVBQTBCO0FBQzdDO0FBQ0EsRUFBRTtBQUNGO0FBQ0EsbUJBQW1CLG1FQUEwQjtBQUM3QztBQUNBLEVBQUU7QUFDRjtBQUNBLG1CQUFtQixnRUFBdUI7QUFDMUM7QUFDQSxFQUFFO0FBQ0Y7QUFDQSxtQkFBbUIsa0VBQXlCO0FBQzVDOzs7Ozs7Ozs7Ozs7Ozs7OztBQzlHbUQ7QUFDVztBQUM5RCxpRUFBZTtBQUNmO0FBQ0E7QUFDQSxLQUFLLG1EQUFtRCw0REFBTSxZQUFZLDBCQUEwQjtBQUNwRyxLQUFLLHNEQUFzRCw0REFBTSxZQUFZLHlCQUF5QjtBQUN0RztBQUNBO0FBQ0EsT0FBTyx5Q0FBeUMsNERBQU0sWUFBWSxtQkFBbUI7QUFDckYsT0FBTywrQ0FBK0MsNERBQU0sWUFBWSx5QkFBeUI7QUFDakcsT0FBTyx5REFBeUQsNERBQU0sWUFBWTtBQUNsRjtBQUNBLElBQUk7QUFDSixLQUFLLDhEQUE4RCw0REFBTSxZQUFZO0FBQ3JGO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxLQUFLLDhDQUE4Qyw0REFBTSxZQUFZLHdDQUF3QztBQUM3RyxLQUFLLDhDQUE4Qyw0REFBTSxZQUFZLHdDQUF3QztBQUM3RyxLQUFLLGlEQUFpRCw0REFBTSxZQUFZLGtEQUFrRDtBQUMxSDtBQUNBO0FBQ0EsT0FBTyw4Q0FBOEMsNERBQU0sWUFBWSx3Q0FBd0M7QUFDL0csT0FBTyxvREFBb0QsNERBQU0sWUFBWTtBQUM3RTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsT0FBTyxpRUFBaUUsNERBQU0sWUFBWTtBQUMxRjtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsT0FBTyxpREFBaUQsNERBQU0sWUFBWSwyQ0FBMkM7QUFDckgsT0FBTywyQ0FBMkMsNERBQU0sWUFBWSxxQ0FBcUM7QUFDekcsT0FBTywwREFBMEQsNERBQU0sWUFBWSxrREFBa0Q7QUFDckksT0FBTyxpREFBaUQsNERBQU0sWUFBWSwyQ0FBMkM7QUFDckgsT0FBTywrQ0FBK0MsNERBQU0sWUFBWTtBQUN4RTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsT0FBTyw4Q0FBOEMsNERBQU0sWUFBWSx3Q0FBd0M7QUFDL0csT0FBTywrQ0FBK0MsNERBQU0sWUFBWSx5Q0FBeUM7QUFDakgsT0FBTyxvREFBb0QsNERBQU0sWUFBWSw0Q0FBNEM7QUFDekgsT0FBTyxxREFBcUQsNERBQU0sWUFBWSw2Q0FBNkM7QUFDM0gsT0FBTyxxREFBcUQsNERBQU0sWUFBWTtBQUM5RTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMkRBQTJELDREQUFNLFlBQVksd0JBQXdCO0FBQzFHO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxLQUFLLHFEQUFxRCw0REFBTSxZQUFZLCtCQUErQjtBQUMzRyxLQUFLLG9EQUFvRCw0REFBTSxZQUFZLDhCQUE4QjtBQUN6RyxLQUFLLHFEQUFxRCw0REFBTSxZQUFZLCtCQUErQjtBQUMzRyxLQUFLLHlEQUF5RCw0REFBTSxZQUFZO0FBQ2hGO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxLQUFLLDBDQUEwQyx5REFBZSxZQUFZO0FBQzFFO0FBQ0EsRUFBRTtBQUNGLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RWlEO0FBQ1c7QUFDOUQsaUVBQWU7QUFDZjtBQUNBO0FBQ0EsS0FBSyxtREFBbUQsNERBQU0sWUFBWSwwQkFBMEI7QUFDcEcsS0FBSyxzREFBc0QsNERBQU0sWUFBWSx5QkFBeUI7QUFDdEcsS0FBSyw0REFBNEQsNERBQU0sWUFBWTtBQUNuRjtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsS0FBSywyREFBMkQsNERBQU0sWUFBWTtBQUNsRjtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsS0FBSywwQ0FBMEMseURBQWUsWUFBWTtBQUMxRTtBQUNBO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BCaUQ7QUFDVztBQUM5RCxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBLEtBQUssbURBQW1ELDREQUFNLFlBQVk7QUFDMUU7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssbURBQW1ELDREQUFNLFlBQVksMEJBQTBCO0FBQ3BHLEtBQUssc0RBQXNELDREQUFNLFlBQVkseUJBQXlCO0FBQ3RHLEtBQUsscURBQXFELDREQUFNLFlBQVksOENBQThDO0FBQzFILEtBQUssaURBQWlELDREQUFNLFlBQVksMENBQTBDO0FBQ2xILEtBQUssMkRBQTJELDREQUFNLFlBQVksOENBQThDO0FBQ2hJLEtBQUssd0RBQXdELDREQUFNLFlBQVksZ0RBQWdEO0FBQy9ILEtBQUssNERBQTRELDREQUFNLFlBQVk7QUFDbkY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMkRBQTJELDREQUFNLFlBQVk7QUFDbEY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sK0ZBQStGLHdEQUFjLFlBQVksa0NBQWtDO0FBQ2xLLE9BQU8saUdBQWlHLHdEQUFjLFlBQVksaUNBQWlDO0FBQ25LLE9BQU8sdUZBQXVGLHdEQUFjLFlBQVkscUNBQXFDO0FBQzdKLE9BQU8sbUdBQW1HLHdEQUFjLFlBQVksbUNBQW1DO0FBQ3ZLLE9BQU8sa0hBQWtILHdEQUFjLFlBQVksMkNBQTJDO0FBQzlMLE9BQU8sNEdBQTRHLHdEQUFjLFlBQVksMkNBQTJDO0FBQ3hMLE9BQU8sZ0hBQWdILHdEQUFjLFlBQVksNENBQTRDO0FBQzdMLE9BQU8scUhBQXFILHdEQUFjLFlBQVksK0JBQStCO0FBQ3JMO0FBQ0E7QUFDQTtBQUNBLFNBQVMsZ0ZBQWdGLHdEQUFjLFlBQVksOEJBQThCO0FBQ2pKLFNBQVMsaUZBQWlGLHdEQUFjLFlBQVk7QUFDcEg7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLEtBQUssMENBQTBDLHlEQUFlLFlBQVk7QUFDMUU7QUFDQTtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRGlEO0FBQ1c7QUFDOUQsaUVBQWU7QUFDZjtBQUNBO0FBQ0EsS0FBSyxtREFBbUQsNERBQU0sWUFBWSwwQkFBMEI7QUFDcEcsS0FBSyxzREFBc0QsNERBQU0sWUFBWSx5QkFBeUI7QUFDdEcsS0FBSyw0REFBNEQsNERBQU0sWUFBWTtBQUNuRjtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsS0FBSywyREFBMkQsNERBQU0sWUFBWTtBQUNsRjtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsS0FBSywwQ0FBMEMseURBQWUsWUFBWTtBQUMxRTtBQUNBO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BCaUQ7QUFDVztBQUM5RCxpRUFBZTtBQUNmO0FBQ0E7QUFDQSxLQUFLLHVEQUF1RCw0REFBTSxZQUFZLHdCQUF3QjtBQUN0RyxLQUFLLG1EQUFtRCw0REFBTSxZQUFZLDBCQUEwQjtBQUNwRyxLQUFLLHVEQUF1RCw0REFBTSxZQUFZLDZCQUE2QjtBQUMzRyxLQUFLLHVEQUF1RCw0REFBTSxZQUFZLDZCQUE2QjtBQUMzRztBQUNBO0FBQ0EsT0FBTyxpREFBaUQsNERBQU0sWUFBWSwyQkFBMkI7QUFDckcsT0FBTyw2Q0FBNkMsNERBQU0sWUFBWSx1QkFBdUI7QUFDN0YsT0FBTyx1REFBdUQsNERBQU0sWUFBWTtBQUNoRjtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsT0FBTyw4REFBOEQsNERBQU0sWUFBWTtBQUN2RjtBQUNBLElBQUk7QUFDSixLQUFLLHNEQUFzRCw0REFBTSxZQUFZO0FBQzdFO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxLQUFLLDBDQUEwQyx5REFBZSxZQUFZO0FBQzFFO0FBQ0E7QUFDQSxDQUFDLEVBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzdCcUI7QUFDdUI7QUFDOUM7QUFDQTtBQUNBO0FBQ0EsUUFBUSw2Q0FBQztBQUNULHdCQUF3Qiw2Q0FBQztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZDQUFDO0FBQ2pCO0FBQ0Esb0JBQW9CLDZDQUFDO0FBQ3JCO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIscURBQVc7QUFDdkM7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzVCc0I7QUFDUztBQUNSO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSw2Q0FBQztBQUNQO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsa0RBQU0sRUFBRSxzR0FBc0c7QUFDckk7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUscURBQVc7QUFDMUIsa0JBQWtCLDZDQUFDO0FBQ25CO0FBQ0EsaUJBQWlCLDZDQUFDO0FBQ2xCO0FBQ0EsRUFBRTtBQUNGLG1CQUFtQiw2Q0FBQztBQUNwQixrQkFBa0IsNkNBQUM7QUFDbkIsQ0FBQyw2Q0FBQztBQUNGLDJCQUEyQixpQkFBaUIsWUFBWSxpQkFBaUI7QUFDekU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxHQUFHLFFBQVE7QUFDWDtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ3pEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDd0Q7QUFDakQsd0JBQXdCLGtFQUFnQjtBQUMvQztBQUNBLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQztBQUNBLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEM7QUFDQSxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIsOEJBQThCO0FBQzlCLCtCQUErQjtBQUMvQiw0QkFBNEI7QUFDNUIsNEJBQTRCO0FBQzVCLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCLGtCQUFrQjtBQUNsQixrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQiwrQkFBK0I7QUFDL0IsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0EsaUVBQWlFO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQSw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixTQUFTO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUM7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWixVQUFVO0FBQ1YsUUFBUTtBQUNSLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUZBQXFGO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtEO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEIsa0JBQWtCO0FBQ2xCLGtCQUFrQjtBQUNsQixrQkFBa0I7QUFDbEIsa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0EscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEM7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0Esb0NBQW9DO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1gsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLG9CQUFvQjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQiw4QkFBOEI7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ3p5Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUM5RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBLDBDQUEwQztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDeFRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8saUJBQWlCO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUM5ckI4QztBQUNGO0FBQ0Y7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQix3REFBVztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBLDJDQUEyQztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHNEQUFVO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLG9EQUFTO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsY0FBYztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3pNdUI7QUFDdUI7QUFDSjtBQUMxQztBQUNBO0FBQ0EsMENBQTBDLHFEQUFXO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQiw2Q0FBQztBQUNsQjtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2YsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNULE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxRQUFRLDZDQUFDO0FBQ1Q7QUFDQSxVQUFVLGdDQUFnQztBQUMxQztBQUNBO0FBQ0E7QUFDQSxRQUFRLDZDQUFDO0FBQ1QsVUFBVSw2Q0FBQztBQUNYLFFBQVEsNkNBQUM7QUFDVDtBQUNBO0FBQ0EsV0FBVztBQUNYLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSw2Q0FBQztBQUNQLHFCQUFxQiw2Q0FBQztBQUN0QixNQUFNLDZDQUFDO0FBQ1AsTUFBTSw2Q0FBQztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiw2Q0FBQztBQUNqQixNQUFNLDZDQUFDO0FBQ1AsTUFBTSw2Q0FBQztBQUNQO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ3JFc0I7QUFDQztBQUN4QjtBQUNBO0FBQ0E7QUFDQSxJQUFJLDZDQUFDO0FBQ0wsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksNkNBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksNkNBQUM7QUFDTCxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULE9BQU87QUFDUDtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwRHNCO0FBQ1M7QUFDTjtBQUNhO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMLElBQUksNkNBQUM7QUFDTDtBQUNBO0FBQ0Esc0JBQXNCLDZDQUFDO0FBQ3ZCLG1CQUFtQixxREFBVztBQUM5QixpQkFBaUIsNkNBQUs7QUFDdEI7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxlQUFlLCtCQUErQjtBQUM5QztBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1osZ0JBQWdCLDZDQUFDO0FBQ2pCLGtDQUFrQyw2Q0FBQztBQUNuQyxjQUFjLDZDQUFDO0FBQ2YsZ0JBQWdCLDZDQUFDO0FBQ2pCLHVEQUF1RCxhQUFhLEtBQUssaUJBQWlCLHlDQUF5QyxnQkFBZ0I7QUFDbko7QUFDQTtBQUNBO0FBQ0EsY0FBYyw2Q0FBQztBQUNmO0FBQ0EsZ0JBQWdCLDZDQUFDO0FBQ2pCLGdCQUFnQiw2Q0FBQztBQUNqQjtBQUNBLGVBQWU7QUFDZjtBQUNBLDRCQUE0Qiw2Q0FBSztBQUNqQztBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQSx5QkFBeUIsK0JBQStCO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLDZDQUFDO0FBQzNCLDBCQUEwQiw2Q0FBQztBQUMzQiwwQkFBMEIsNkNBQUM7QUFDM0I7QUFDQSwwQkFBMEIsNkNBQUM7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkIsZUFBZTtBQUNmO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixrREFBTTtBQUMvQjtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0EsY0FBYywrQ0FBK0M7QUFDN0QsS0FBSztBQUNMO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixrREFBTTtBQUMvQjtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixrREFBTTtBQUMvQjtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLDZDQUFDO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSCxFQUFFLDZDQUFDO0FBQ0g7QUFDQSxjQUFjLHFEQUFXO0FBQ3pCLGNBQWMsNkNBQUM7QUFDZjtBQUNBLEdBQUc7QUFDSDtBQUNBLElBQUksNkNBQUM7QUFDTCxNQUFNLDZDQUFDO0FBQ1A7QUFDQSxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBLE1BQU0sNkNBQUM7QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qiw2Q0FBQztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsNkNBQUM7QUFDbkIsbUJBQW1CLDZDQUFDO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1YsZ0NBQWdDLDZDQUFDO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsNkNBQUM7QUFDWCxVQUFVLDZDQUFDO0FBQ1gsVUFBVSw2Q0FBQztBQUNYO0FBQ0EsVUFBVSw2Q0FBQztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLDZDQUFLO0FBQ3pCO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLE1BQU0sNkNBQUM7QUFDUDtBQUNBLHdCQUF3Qiw2Q0FBQztBQUN6QixJQUFJLDZDQUFDO0FBQ0wsTUFBTSw2Q0FBQztBQUNQLDZDQUE2QyxhQUFhLEtBQUssaUJBQWlCLHFCQUFxQixnQkFBZ0I7QUFDckg7QUFDQTtBQUNBLGlCQUFpQiw2Q0FBSztBQUN0QjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLHFEQUFXO0FBQzdCLGNBQWMsNkNBQUM7QUFDZjtBQUNBLFNBQVM7QUFDVDtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxxREFBVztBQUN6QixjQUFjLDZDQUFDO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSCxFQUFFLDZDQUFDO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOzs7Ozs7Ozs7Ozs7Ozs7O0FDeFp1QjtBQUNrQjtBQUNoQjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsNkNBQUM7QUFDVDtBQUNBO0FBQ0EsUUFBUSw2Q0FBQywyQ0FBMkMsNkNBQUM7QUFDckQ7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSxzQkFBc0IsNkNBQUM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsNkNBQUM7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksNkNBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLFNBQVMsNkNBQUM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFLDZDQUFDO0FBQ0gsRUFBRSw2Q0FBQztBQUNILElBQUksNkNBQUM7QUFDTDtBQUNBLEVBQUUsNkNBQUM7QUFDSCxJQUFJLDZDQUFDO0FBQ0wsR0FBRztBQUNILEVBQUUsNkNBQUM7QUFDSCxJQUFJLDZDQUFDO0FBQ0wsR0FBRztBQUNILEVBQUUsNkNBQUM7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsa0RBQUk7QUFDZjtBQUNBO0FBQ0EsUUFBUTtBQUNSLFFBQVEsa0RBQU07QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLDZDQUFDO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixrREFBSTtBQUN0QjtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsNkNBQUM7QUFDakIsa0JBQWtCLDZDQUFDO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixjQUFjLDZDQUFDO0FBQ2Y7QUFDQSxnQkFBZ0IsNkNBQUMscUJBQXFCLDZDQUFDO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWCxrQ0FBa0M7QUFDbEMsU0FBUztBQUNUO0FBQ0EsS0FBSztBQUNMLElBQUk7QUFDSixJQUFJLDZDQUFDLHFCQUFxQiw2Q0FBQztBQUMzQixJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsNkNBQUM7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qiw2Q0FBQztBQUN4QixnQkFBZ0IsNkNBQUM7QUFDakI7QUFDQTtBQUNBO0FBQ0EsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xOdUI7QUFDaUI7QUFNYjtBQUNtQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksNkNBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHNFQUF3QjtBQUM1QixJQUFJLDZDQUFDO0FBQ0w7QUFDQSx3QkFBd0IsNkNBQUM7QUFDekIsc0JBQXNCLDZDQUFDO0FBQ3ZCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxVQUFVLDZDQUFDO0FBQ1gsUUFBUSw2Q0FBQztBQUNULFFBQVE7QUFDUjtBQUNBLFFBQVEsMERBQVk7QUFDcEIsMEJBQTBCLHlEQUFXO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDZDQUFDO0FBQ2IsV0FBVztBQUNYLGtDQUFrQyw2Q0FBQztBQUNuQztBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQSxVQUFVLDZDQUFDO0FBQ1g7QUFDQSxrQ0FBa0MsNkNBQUM7QUFDbkM7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0EsV0FBVztBQUNYO0FBQ0EsVUFBVSw2Q0FBQztBQUNYLFVBQVUsNkNBQUM7QUFDWCxZQUFZLDZDQUFDO0FBQ2IsV0FBVztBQUNYLFVBQVUsNkNBQUM7QUFDWCxVQUFVLDZDQUFDO0FBQ1gsWUFBWSw2Q0FBQztBQUNiLFdBQVc7QUFDWCxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw2Q0FBQztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsNkNBQUM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxrREFBSTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLCtCQUErQiw2Q0FBQztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLFFBQVEsNkNBQUMsd0JBQXdCLDZDQUFDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsNkNBQUM7QUFDWCxTQUFTO0FBQ1QsT0FBTztBQUNQO0FBQ0E7QUFDQSxRQUFRLDZDQUFDO0FBQ1QseUNBQXlDLDZDQUFDO0FBQzFDO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSw0Q0FBNEMsSUFBSTtBQUNoRDtBQUNBLDRDQUE0QyxFQUFFO0FBQzlDO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDLCtCQUErQjtBQUMvQiwrQkFBK0I7QUFDL0IsaUNBQWlDO0FBQ2pDLGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdFkyQjtBQUNZO0FBQzJDO0FBQ3JEO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxtQ0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksc0VBQXdCO0FBQzVCLElBQUksbUNBQUM7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLHlCQUF5Qix3Q0FBTTtBQUMvQjtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxrREFBSTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLEVBQUU7QUFDMUMsTUFBTSxrREFBSTtBQUNWO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLElBQUksUUFBUSxFQUFFLFFBQVEsRUFBRTtBQUN2RDtBQUNBLElBQUk7QUFDSjtBQUNBLDBDQUEwQyxJQUFJO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxJQUFJO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsbUNBQUM7QUFDSDtBQUNBO0FBQ0EsYUFBYSxtQ0FBQztBQUNkO0FBQ0E7QUFDQSxvQkFBb0IsOERBQWdCO0FBQ3BDLHFCQUFxQiw4REFBZ0I7QUFDckMsb0JBQW9CLDhEQUFnQjtBQUNwQyxxQkFBcUIsOERBQWdCO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxrREFBSTtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsaURBQWlELEVBQUUsT0FBTyxFQUFFO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUM7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsa0RBQUk7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsZ0JBQWdCLGtEQUFJO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixrREFBSTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsbUNBQUM7QUFDM0Isb0RBQW9ELFlBQVk7QUFDaEUsMENBQTBDLGlCQUFpQixrRkFBa0YsaUJBQWlCO0FBQzlKO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLG1DQUFDO0FBQzdCLFFBQVEsbUNBQUM7QUFDVCw4QkFBOEIsbUNBQUM7QUFDL0IsMEJBQTBCLHFDQUFxQztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG1DQUFDO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sbUNBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLElBQUksbUNBQUM7QUFDTCxJQUFJLG1DQUFDO0FBQ0wsTUFBTSxtQ0FBQztBQUNQLEtBQUs7QUFDTCxJQUFJLG1DQUFDO0FBQ0wsTUFBTSxtQ0FBQztBQUNQLEtBQUs7QUFDTDtBQUNBLElBQUksbUNBQUM7QUFDTCxJQUFJLG1DQUFDO0FBQ0wsTUFBTSxtQ0FBQztBQUNQLEtBQUs7QUFDTCxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuZnVCO0FBQ3lEO0FBQ2pEO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMLEtBQUssNkNBQUM7QUFDTixNQUFNLDZDQUFDO0FBQ1A7QUFDQTtBQUNBLHVCQUF1Qiw4REFBZ0I7QUFDdkM7QUFDQSx3QkFBd0IsOERBQWdCO0FBQ3hDO0FBQ0Esd0JBQXdCLDhEQUFnQjtBQUN4QztBQUNBLHVCQUF1Qiw4REFBZ0I7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixnQkFBZ0I7QUFDdEM7QUFDQSx3QkFBd0IsZ0JBQWdCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLDZDQUFDO0FBQ1gsZ0JBQWdCLDZDQUFDO0FBQ2pCLFFBQVE7QUFDUixnQkFBZ0IsNkNBQUM7QUFDakI7QUFDQSxNQUFNLDBEQUFZO0FBQ2xCLDJCQUEyQix5REFBVztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLDZDQUFDO0FBQ25CLHdDQUF3Qyw2Q0FBQztBQUN6QztBQUNBLGdDQUFnQyxJQUFJO0FBQ3BDO0FBQ0Esa0JBQWtCLDZDQUFDO0FBQ25CLHdDQUF3Qyw2Q0FBQztBQUN6QztBQUNBLGdDQUFnQyxJQUFJO0FBQ3BDO0FBQ0Esa0JBQWtCLDZDQUFDO0FBQ25CLDJDQUEyQyw2Q0FBQztBQUM1QztBQUNBLGdDQUFnQyxJQUFJO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RCxJQUFJO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixtQ0FBbUMsNkNBQUM7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsNkNBQUM7QUFDaEMsa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQSwrQkFBK0IsNkNBQUM7QUFDaEM7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBLDRCQUE0Qiw2Q0FBQztBQUM3QjtBQUNBO0FBQ0EsV0FBVztBQUNYLFNBQVM7QUFDVCxPQUFPO0FBQ1A7QUFDQTtBQUNBLDBCQUEwQiw2Q0FBQztBQUMzQjtBQUNBO0FBQ0EsU0FBUztBQUNULFlBQVksNkNBQUM7QUFDYiw0QkFBNEIsNkNBQUM7QUFDN0I7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUN6TnNCO0FBQzZCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSwrREFBaUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsRUFBRSw2Q0FBQztBQUNIO0FBQ0EsR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiw2Q0FBQztBQUNwQjtBQUNBO0FBQ0EsY0FBYyw2Q0FBQztBQUNmLG9CQUFvQiw2Q0FBQztBQUNyQjtBQUNBO0FBQ0EsMEJBQTBCLGlDQUFpQyxPQUFPO0FBQ2xFLG9DQUFvQyxvQkFBb0Isb0JBQW9CLG9CQUFvQjtBQUNoRyxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUMsc0NBQXNDO0FBQ3hDLENBQUMsNkNBQUMsbUNBQW1DO0FBQ3JDLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGO0FBQ0EsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGO0FBQ0EsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGO0FBQ0EsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7QUNyRXVCO0FBQ3ZCO0FBQ0E7QUFDQSw2QkFBNkIsNkNBQUM7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLHFEQUFTO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsT0FBTztBQUM3QjtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyw2Q0FBQztBQUNwQywwQkFBMEIsNkNBQUM7QUFDM0I7QUFDQSxZQUFZLDZDQUFDO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7OztBQ3BDc0I7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZDQUFDLHlCQUF5QjtBQUMxQyxnQkFBZ0IsNkNBQUMsb0NBQW9DO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLGNBQWMsa0JBQWtCO0FBQ2pHO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLHdCQUF3Qiw2Q0FBQztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDZDQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDdENzQjtBQUNvQjtBQUMzQztBQUNBO0FBQ0E7QUFDQSxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsUUFBUSw2Q0FBQztBQUNULFFBQVEsNkNBQUM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixrQkFBa0Isa0JBQWtCLG1CQUFtQixlQUFlLGlCQUFpQjtBQUNoSDtBQUNBO0FBQ0EsUUFBUSxrREFBTTtBQUNkO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsNEJBQTRCLDZDQUFDO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxnQkFBZ0IsaUNBQWlDLFlBQVk7QUFDbEgsWUFBWTtBQUNaLFNBQVM7QUFDVCxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0EsRUFBRSw2Q0FBQztBQUNILFFBQVEsNkNBQUM7QUFDVCxNQUFNLDZDQUFDO0FBQ1AsTUFBTSw2Q0FBQztBQUNQO0FBQ0EsR0FBRztBQUNILENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Q3FCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQsa0JBQWtCLGdCQUFnQixjQUFjLGVBQWUsVUFBVSxFQUFFLElBQUksZ0JBQWdCLGNBQWMsU0FBUyxFQUFFLElBQUksY0FBYyx1QkFBdUI7QUFDeE4sK0NBQStDLGtCQUFrQixnQkFBZ0IsY0FBYyxlQUFlLFVBQVUsRUFBRSxJQUFJLGdCQUFnQixjQUFjLFNBQVMsRUFBRSxJQUFJLGNBQWMsdUJBQXVCO0FBQ2hOLDhDQUE4QyxrQkFBa0I7QUFDaEUsa0NBQWtDLGtCQUFrQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLElBQUksWUFBWSxJQUFJLGlCQUFpQixJQUFJLDZCQUE2QixJQUFJLFlBQVksSUFBSSxpQkFBaUIsSUFBSTtBQUM1SCxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0FBQ3pCLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0Esa0RBQWtELElBQUk7QUFDdEQ7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSx1Q0FBdUM7QUFDekMsRUFBRSwyQ0FBMkM7QUFDN0MsRUFBRSxpREFBaUQ7QUFDbkQsRUFBRSwyQ0FBMkM7QUFDN0MsRUFBRSx5Q0FBeUM7QUFDM0MsRUFBRSx1Q0FBdUM7QUFDekMsRUFBRSw2RkFBNkY7QUFDL0YsRUFBRSw2TEFBNkw7QUFDL0wsRUFBRSwyTEFBMkw7QUFDN0wsRUFBRSxvTUFBb007QUFDdE0sRUFBRSxxSEFBcUg7QUFDdkgsRUFBRSxpTUFBaU07QUFDbk0sRUFBRSw2TUFBNk07QUFDL00sRUFBRSxnTUFBZ007QUFDbE0sRUFBRSxvTEFBb0w7QUFDdEwsRUFBRSxnSkFBZ0o7QUFDbEosRUFBRSwrSEFBK0g7QUFDakksRUFBRSxpSEFBaUg7QUFDbkgsRUFBRSxpSEFBaUg7QUFDbkgsRUFBRSwySkFBMko7QUFDN0osRUFBRSx1S0FBdUs7QUFDekssRUFBRSxxSUFBcUk7QUFDdkksRUFBRSxxS0FBcUs7QUFDdkssRUFBRSwyTEFBMkw7QUFDN0wsRUFBRSxrREFBa0Q7QUFDcEQsRUFBRSxxQkFBcUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLHNDQUFzQyxxQ0FBcUMsb0JBQW9CO0FBQy9GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2SUFBNkk7QUFDN0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLDhDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixpREFBaUQ7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEIsR0FBRztBQUNIO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxnQkFBZ0IsY0FBYyw0QkFBNEI7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxLQUFLO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsTUFBTTtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGdCQUFnQjtBQUNoQztBQUNBO0FBQ0EsaUJBQWlCLHVCQUF1QjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsTUFBTTtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixnQkFBZ0I7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsdUJBQXVCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsV0FBVztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsVUFBVTtBQUM1QyxzQkFBc0IsRUFBRSxZQUFZLGNBQWMsYUFBYSxZQUFZLFNBQVMsRUFBRSxJQUFJLFFBQVEsRUFBRSxJQUFJLGFBQWEsUUFBUSxFQUFFO0FBQy9IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlELEVBQUUsa0JBQWtCO0FBQzdFLCtDQUErQyxFQUFFO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLHdCQUF3QjtBQUNsRDtBQUNBLHdDQUF3Qyx3QkFBd0I7QUFDaEUsNENBQTRDLHdCQUF3QjtBQUNwRSw0Q0FBNEMsd0JBQXdCO0FBQ3BFLHdDQUF3Qyx3QkFBd0I7QUFDaEUsc0NBQXNDLHdCQUF3QjtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyx3QkFBd0I7QUFDNUQ7QUFDQSx1Q0FBdUMsd0JBQXdCO0FBQy9EO0FBQ0E7QUFDQTtBQUNBLHVDQUF1Qyx3QkFBd0I7QUFDL0Q7QUFDQSwwQkFBMEIsd0JBQXdCO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxvQkFBb0I7QUFDN0QsNkNBQTZDLHNCQUFzQjtBQUNuRSx5Q0FBeUMsb0JBQW9CO0FBQzdEO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxvQkFBb0I7QUFDeEQsd0NBQXdDLHNCQUFzQjtBQUM5RCxvQ0FBb0Msb0JBQW9CO0FBQ3hEO0FBQ0E7QUFDQSwrQkFBK0IseUJBQXlCO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLG9CQUFvQjtBQUMxRCwwQ0FBMEMsc0JBQXNCO0FBQ2hFLHNDQUFzQyxvQkFBb0I7QUFDMUQ7QUFDQTtBQUNBLGlDQUFpQyx5QkFBeUI7QUFDMUQ7QUFDQSxNQUFNO0FBQ047QUFDQSxJQUFJO0FBQ0osR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7OztBQ2huQ3VCO0FBQ3ZCO0FBQ0EsNkRBQWU7QUFDZixZQUFZLHNEQUFzRDtBQUNsRTtBQUNBLFNBQVMsb0RBQVE7QUFDakI7QUFDQTtBQUNBO0FBQ0EsWUFBWSw2Q0FBQztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7Ozs7OztVQzFCQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOztVQUVBO1VBQ0E7Ozs7O1dDekJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsK0JBQStCLHdDQUF3QztXQUN2RTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlCQUFpQixxQkFBcUI7V0FDdEM7V0FDQTtXQUNBLGtCQUFrQixxQkFBcUI7V0FDdkM7V0FDQTtXQUNBLEtBQUs7V0FDTDtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDM0JBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7OztXQ05BOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7V0NoREE7Ozs7O1VFQUE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXIuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2FwcHNNZW51L2FwcHNNZW51LmNzcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5jc3MiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZGFya01vZGUvZGFya01vZGUuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2Rpc3RhbmNlQW5kUmVsYXRpb25zaGlwL2Rpc3RhbmNlQW5kUmVsYXRpb25zaGlwLmNzcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kcmFmdExpc3QvZHJhZnRMaXN0LmNzcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9mYW1pbHlUaW1lbGluZS9mYW1pbHlUaW1lbGluZS5jc3MiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvbG9jYXRpb25zSGVscGVyL2xvY2F0aW9uc0hlbHBlci5jc3MiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvd3QrL3d0UGx1cy5jc3MiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvY29yZS9lZGl0VG9vbGJhci5jc3M/OTczNSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9hcHBzTWVudS9hcHBzTWVudS5jc3M/NTcwYSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5jc3M/N2FhNiIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kYXJrTW9kZS9kYXJrTW9kZS5jc3M/ZGIxYSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC5jc3M/MTA2ZSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kcmFmdExpc3QvZHJhZnRMaXN0LmNzcz83OGM1Iiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2ZhbWlseVRpbWVsaW5lL2ZhbWlseVRpbWVsaW5lLmNzcz82NDJiIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2xvY2F0aW9uc0hlbHBlci9sb2NhdGlvbnNIZWxwZXIuY3NzPzc3MDYiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvd3QrL3d0UGx1cy5jc3M/MTBkMyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9jb250ZW50LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvY29tbW9uLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXIuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvY29yZS9lZGl0VG9vbGJhckNhdGVnb3J5T3B0aW9ucy5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9jb3JlL2VkaXRUb29sYmFyR2VuZXJpY09wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvY29yZS9lZGl0VG9vbGJhclByb2ZpbGVPcHRpb25zLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXJTcGFjZU9wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvY29yZS9lZGl0VG9vbGJhclRlbXBsYXRlT3B0aW9ucy5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9ha2FOYW1lTGlua3MvYWthTmFtZUxpbmtzLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2FwcHNNZW51L2FwcHNNZW51LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2Jpb0NoZWNrL0Jpb2dyYXBoeS5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9iaW9DaGVjay9CaW9ncmFwaHlSZXN1bHRzLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2Jpb0NoZWNrL1BlcnNvbkRhdGUuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvYmlvQ2hlY2svU291cmNlUnVsZXMuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvYmlvQ2hlY2svYmlvQ2hlY2suanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUvY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZGFya01vZGUvZGFya01vZGUuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAvZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZHJhZnRMaXN0L2RyYWZ0TGlzdC5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9mYW1pbHlHcm91cC9mYW1pbHlHcm91cC5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9mYW1pbHlUaW1lbGluZS9mYW1pbHlUaW1lbGluZS5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9sb2NhdGlvbnNIZWxwZXIvbG9jYXRpb25zSGVscGVyLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL3ByaW50ZXJmcmllbmRseS9wcmludGVyZnJpZW5kbHkuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvcmFuZG9tUHJvZmlsZS9yYW5kb21Qcm9maWxlLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL3NvdXJjZXByZXZpZXcvc291cmNlcHJldmlldy5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9zcGFjZXByZXZpZXcvc3BhY2VwcmV2aWV3LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL3d0Ky9jb250ZW50RWRpdC5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy90aGlyZHBhcnR5L2pxdWVyeS5ob3ZlckRlbGF5LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9jaHVuayBsb2FkZWQiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2NvbXBhdCBnZXQgZGVmYXVsdCBleHBvcnQiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvbm9uY2UiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiXFxyXFxuI2VkaXRUb29sYmFyRXh0IHtcXHJcXG5cXHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxyXFxufVxcclxcblxcclxcbiNlZGl0VG9vbGJhckRpdiB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGZsb2F0OiBsZWZ0O1xcclxcblxcdHotaW5kZXg6IDEwO1xcclxcbn1cXHJcXG5cXHJcXG4jZWRpdFRvb2xiYXJEaXY6aG92ZXIgLmVkaXRUb29sYmFyTWVudTAge1xcclxcblxcdGRpc3BsYXk6IGJsb2NrO1xcclxcbn1cXHJcXG5cXHJcXG4jZWRpdFRvb2xiYXJCdXR0b24ge1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjYWFhO1xcclxcblxcdGJvcmRlci1yYWRpdXM6IDNweDtcXHJcXG5cXHRwYWRkaW5nOiAycHg7XFxyXFxuXFx0bWFyZ2luOiAxcHg7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2VlZTtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTIge1xcclxcblxcdGRpc3BsYXk6IG5vbmU7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogLTFweDtcXHJcXG5cXHRsZWZ0OiAxNjFweDtcXHJcXG5cXHR3aWR0aDogMTYwcHg7XFxyXFxuXFx0bGlzdC1zdHlsZTogbm9uZTtcXHJcXG5cXHRwYWRkaW5nOiAxO1xcclxcblxcdG1hcmdpbjogMDtcXHJcXG5cXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51Mj5saSB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGhlaWdodDogMjRweDtcXHJcXG5cXHRtYXJnaW4tYm90dG9tOiAxcHg7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51Mj5saTpob3ZlciB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0NDQ0NDQztcXHJcXG59XFxyXFxuXFxyXFxuLyogc2Vjb25kIGxldmVsIG9mIG1lbnVzICovXFxyXFxuLmVkaXRUb29sYmFyTWVudTEge1xcclxcblxcdGRpc3BsYXk6IG5vbmU7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogLTFweDtcXHJcXG5cXHRsZWZ0OiAxNjFweDtcXHJcXG5cXHR3aWR0aDogMTYwcHg7XFxyXFxuXFx0bGlzdC1zdHlsZTogbm9uZTtcXHJcXG5cXHRwYWRkaW5nOiAxO1xcclxcblxcdG1hcmdpbjogMDtcXHJcXG5cXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MT5saSB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGhlaWdodDogMjRweDtcXHJcXG5cXHRtYXJnaW4tYm90dG9tOiAxcHg7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MT5saTpob3ZlciB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0NDQ0NDQztcXHJcXG59XFxyXFxuXFxyXFxuLyogZmlyc3QgbGV2ZWwgb2YgbWVudXMgKi9cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCB7XFxyXFxuXFx0ZGlzcGxheTogbm9uZTtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0bGVmdDogMHB4O1xcclxcblxcdGxpc3Qtc3R5bGU6IG5vbmU7XFxyXFxuXFx0cGFkZGluZzogMXB4O1xcclxcblxcdG1hcmdpbjogMDtcXHJcXG5cXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcclxcblxcdHotaW5kZXg6IDEwO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MD5saSB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGhlaWdodDogMjRweDtcXHJcXG5cXHRtaW4td2lkdGg6IDE2MHB4O1xcclxcblxcdG1hcmdpbi1ib3R0b206IDFweDtcXHJcXG5cXHRmbG9hdDogbGVmdDtcXHJcXG5cXHR6LWluZGV4OiAxMTtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcclxcblxcdGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XFxyXFxuXFx0dGV4dC1hbGlnbjogbGVmdDtcXHJcXG5cXHR0ZXh0LWRlY29yYXRpb246IG5vbmU7XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MD5saTpob3ZlciB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0NDQ0NDQztcXHJcXG59XFxyXFxuXFxyXFxuLyogT24gaG92ZXIsIGRpc3BsYXkgdGhlIG5leHQgbGV2ZWwncyBtZW51ICovXFxyXFxuLmVkaXRUb29sYmFyTWVudTAgbGk6aG92ZXI+dWwge1xcclxcblxcdGRpc3BsYXk6IGlubGluZTtcXHJcXG59XFxyXFxuXFxyXFxuLyogTWVudSBMaW5rIFN0eWxlcyAtIEFwcGx5IHRvIGFsbCBsaW5rcyBpbnNpZGUgdGhlIG11bHRpLWxldmVsIG1lbnUgKi9cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBhIHtcXHJcXG5cXHRmb250OiBub3JtYWwgMTFweCB2ZXJkYW5hLCBhcmlhbCwgc2Fucy1zZXJpZjtcXHJcXG5cXHRjb2xvcjogIzAwMDAwMDtcXHJcXG5cXHR0ZXh0LWRlY29yYXRpb246IG5vbmUgIWltcG9ydGFudDtcXHJcXG5cXHRwYWRkaW5nOiAwcHggNXB4O1xcclxcblxcclxcblxcdC8qIE1ha2UgdGhlIGxpbmsgY292ZXIgdGhlIGVudGlyZSBsaXN0IGl0ZW0tY29udGFpbmVyICovXFxyXFxuXFx0ZGlzcGxheTogYmxvY2s7XFxyXFxuXFx0bGluZS1oZWlnaHQ6IDI0cHg7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwIGE6bGluayB7XFxyXFxuXFx0Y29sb3I6ICMwMDAwMDA7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwIGE6aG92ZXIge1xcclxcblxcdGNvbG9yOiAjMDAwMDAwO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBhOnZpc2l0ZWQge1xcclxcblxcdGNvbG9yOiAjMDAwMDAwICFpbXBvcnRhbnQ7XFxyXFxufVwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9jb3JlL2VkaXRUb29sYmFyLmNzc1wiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiO0FBQ0E7Q0FDQyxxQkFBcUI7QUFDdEI7O0FBRUE7Q0FDQyxrQkFBa0I7Q0FDbEIsV0FBVztDQUNYLFdBQVc7QUFDWjs7QUFFQTtDQUNDLGNBQWM7QUFDZjs7QUFFQTtDQUNDLGVBQWU7Q0FDZixzQkFBc0I7Q0FDdEIsa0JBQWtCO0NBQ2xCLFlBQVk7Q0FDWixXQUFXO0NBQ1gsc0JBQXNCO0FBQ3ZCOztBQUVBO0NBQ0MsYUFBYTtDQUNiLGtCQUFrQjtDQUNsQixTQUFTO0NBQ1QsV0FBVztDQUNYLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsVUFBVTtDQUNWLFNBQVM7Q0FDVCxzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLGtCQUFrQjtDQUNsQixzQkFBc0I7Q0FDdEIsc0JBQXNCO0FBQ3ZCOztBQUVBO0NBQ0MsbUJBQW1CO0FBQ3BCOztBQUVBLDBCQUEwQjtBQUMxQjtDQUNDLGFBQWE7Q0FDYixrQkFBa0I7Q0FDbEIsU0FBUztDQUNULFdBQVc7Q0FDWCxZQUFZO0NBQ1osZ0JBQWdCO0NBQ2hCLFVBQVU7Q0FDVixTQUFTO0NBQ1Qsc0JBQXNCO0FBQ3ZCOztBQUVBO0NBQ0Msa0JBQWtCO0NBQ2xCLFlBQVk7Q0FDWixrQkFBa0I7Q0FDbEIsc0JBQXNCO0NBQ3RCLHNCQUFzQjtBQUN2Qjs7QUFFQTtDQUNDLG1CQUFtQjtBQUNwQjs7QUFFQSx5QkFBeUI7QUFDekI7Q0FDQyxhQUFhO0NBQ2Isa0JBQWtCO0NBQ2xCLFNBQVM7Q0FDVCxnQkFBZ0I7Q0FDaEIsWUFBWTtDQUNaLFNBQVM7Q0FDVCxzQkFBc0I7Q0FDdEIsV0FBVztBQUNaOztBQUVBO0NBQ0Msa0JBQWtCO0NBQ2xCLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsa0JBQWtCO0NBQ2xCLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsc0JBQXNCO0NBQ3RCLHNCQUFzQjtDQUN0QixnQkFBZ0I7Q0FDaEIscUJBQXFCO0NBQ3JCLGVBQWU7QUFDaEI7O0FBRUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUEsNENBQTRDO0FBQzVDO0NBQ0MsZUFBZTtBQUNoQjs7QUFFQSxzRUFBc0U7QUFDdEU7Q0FDQyw0Q0FBNEM7Q0FDNUMsY0FBYztDQUNkLGdDQUFnQztDQUNoQyxnQkFBZ0I7O0NBRWhCLHVEQUF1RDtDQUN2RCxjQUFjO0NBQ2QsaUJBQWlCO0FBQ2xCOztBQUVBO0NBQ0MsY0FBYztBQUNmOztBQUVBO0NBQ0MsY0FBYztBQUNmOztBQUVBO0NBQ0MseUJBQXlCO0FBQzFCXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIlxcclxcbiNlZGl0VG9vbGJhckV4dCB7XFxyXFxuXFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xcclxcbn1cXHJcXG5cXHJcXG4jZWRpdFRvb2xiYXJEaXYge1xcclxcblxcdHBvc2l0aW9uOiByZWxhdGl2ZTtcXHJcXG5cXHRmbG9hdDogbGVmdDtcXHJcXG5cXHR6LWluZGV4OiAxMDtcXHJcXG59XFxyXFxuXFxyXFxuI2VkaXRUb29sYmFyRGl2OmhvdmVyIC5lZGl0VG9vbGJhck1lbnUwIHtcXHJcXG5cXHRkaXNwbGF5OiBibG9jaztcXHJcXG59XFxyXFxuXFxyXFxuI2VkaXRUb29sYmFyQnV0dG9uIHtcXHJcXG5cXHRjdXJzb3I6IHBvaW50ZXI7XFxyXFxuXFx0Ym9yZGVyOiAxcHggc29saWQgI2FhYTtcXHJcXG5cXHRib3JkZXItcmFkaXVzOiAzcHg7XFxyXFxuXFx0cGFkZGluZzogMnB4O1xcclxcblxcdG1hcmdpbjogMXB4O1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6ICNlZWU7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUyIHtcXHJcXG5cXHRkaXNwbGF5OiBub25lO1xcclxcblxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG5cXHR0b3A6IC0xcHg7XFxyXFxuXFx0bGVmdDogMTYxcHg7XFxyXFxuXFx0d2lkdGg6IDE2MHB4O1xcclxcblxcdGxpc3Qtc3R5bGU6IG5vbmU7XFxyXFxuXFx0cGFkZGluZzogMTtcXHJcXG5cXHRtYXJnaW46IDA7XFxyXFxuXFx0dmVydGljYWwtYWxpZ246IG1pZGRsZTtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTI+bGkge1xcclxcblxcdHBvc2l0aW9uOiByZWxhdGl2ZTtcXHJcXG5cXHRoZWlnaHQ6IDI0cHg7XFxyXFxuXFx0bWFyZ2luLWJvdHRvbTogMXB4O1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6ICNmZmY7XFxyXFxuXFx0Ym9yZGVyOiAxcHggc29saWQgI2NjYztcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTI+bGk6aG92ZXIge1xcclxcblxcdGJhY2tncm91bmQ6ICNDQ0NDQ0M7XFxyXFxufVxcclxcblxcclxcbi8qIHNlY29uZCBsZXZlbCBvZiBtZW51cyAqL1xcclxcbi5lZGl0VG9vbGJhck1lbnUxIHtcXHJcXG5cXHRkaXNwbGF5OiBub25lO1xcclxcblxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG5cXHR0b3A6IC0xcHg7XFxyXFxuXFx0bGVmdDogMTYxcHg7XFxyXFxuXFx0d2lkdGg6IDE2MHB4O1xcclxcblxcdGxpc3Qtc3R5bGU6IG5vbmU7XFxyXFxuXFx0cGFkZGluZzogMTtcXHJcXG5cXHRtYXJnaW46IDA7XFxyXFxuXFx0dmVydGljYWwtYWxpZ246IG1pZGRsZTtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTE+bGkge1xcclxcblxcdHBvc2l0aW9uOiByZWxhdGl2ZTtcXHJcXG5cXHRoZWlnaHQ6IDI0cHg7XFxyXFxuXFx0bWFyZ2luLWJvdHRvbTogMXB4O1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6ICNmZmY7XFxyXFxuXFx0Ym9yZGVyOiAxcHggc29saWQgI2NjYztcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTE+bGk6aG92ZXIge1xcclxcblxcdGJhY2tncm91bmQ6ICNDQ0NDQ0M7XFxyXFxufVxcclxcblxcclxcbi8qIGZpcnN0IGxldmVsIG9mIG1lbnVzICovXFxyXFxuLmVkaXRUb29sYmFyTWVudTAge1xcclxcblxcdGRpc3BsYXk6IG5vbmU7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdGxlZnQ6IDBweDtcXHJcXG5cXHRsaXN0LXN0eWxlOiBub25lO1xcclxcblxcdHBhZGRpbmc6IDFweDtcXHJcXG5cXHRtYXJnaW46IDA7XFxyXFxuXFx0dmVydGljYWwtYWxpZ246IG1pZGRsZTtcXHJcXG5cXHR6LWluZGV4OiAxMDtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTA+bGkge1xcclxcblxcdHBvc2l0aW9uOiByZWxhdGl2ZTtcXHJcXG5cXHRoZWlnaHQ6IDI0cHg7XFxyXFxuXFx0bWluLXdpZHRoOiAxNjBweDtcXHJcXG5cXHRtYXJnaW4tYm90dG9tOiAxcHg7XFxyXFxuXFx0ZmxvYXQ6IGxlZnQ7XFxyXFxuXFx0ei1pbmRleDogMTE7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xcclxcblxcdHRleHQtYWxpZ246IGxlZnQ7XFxyXFxuXFx0dGV4dC1kZWNvcmF0aW9uOiBub25lO1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTA+bGk6aG92ZXIge1xcclxcblxcdGJhY2tncm91bmQ6ICNDQ0NDQ0M7XFxyXFxufVxcclxcblxcclxcbi8qIE9uIGhvdmVyLCBkaXNwbGF5IHRoZSBuZXh0IGxldmVsJ3MgbWVudSAqL1xcclxcbi5lZGl0VG9vbGJhck1lbnUwIGxpOmhvdmVyPnVsIHtcXHJcXG5cXHRkaXNwbGF5OiBpbmxpbmU7XFxyXFxufVxcclxcblxcclxcbi8qIE1lbnUgTGluayBTdHlsZXMgLSBBcHBseSB0byBhbGwgbGlua3MgaW5zaWRlIHRoZSBtdWx0aS1sZXZlbCBtZW51ICovXFxyXFxuLmVkaXRUb29sYmFyTWVudTAgYSB7XFxyXFxuXFx0Zm9udDogbm9ybWFsIDExcHggdmVyZGFuYSwgYXJpYWwsIHNhbnMtc2VyaWY7XFxyXFxuXFx0Y29sb3I6ICMwMDAwMDA7XFxyXFxuXFx0dGV4dC1kZWNvcmF0aW9uOiBub25lICFpbXBvcnRhbnQ7XFxyXFxuXFx0cGFkZGluZzogMHB4IDVweDtcXHJcXG5cXHJcXG5cXHQvKiBNYWtlIHRoZSBsaW5rIGNvdmVyIHRoZSBlbnRpcmUgbGlzdCBpdGVtLWNvbnRhaW5lciAqL1xcclxcblxcdGRpc3BsYXk6IGJsb2NrO1xcclxcblxcdGxpbmUtaGVpZ2h0OiAyNHB4O1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBhOmxpbmsge1xcclxcblxcdGNvbG9yOiAjMDAwMDAwO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBhOmhvdmVyIHtcXHJcXG5cXHRjb2xvcjogIzAwMDAwMDtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTAgYTp2aXNpdGVkIHtcXHJcXG5cXHRjb2xvcjogIzAwMDAwMCAhaW1wb3J0YW50O1xcclxcbn1cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCJtZW51I2FwcHNTdWJNZW51IHtcXHJcXG5cXHRkaXNwbGF5Om5vbmU7XFxyXFxuXFx0cG9zaXRpb246YWJzb2x1dGU7XFxyXFxuXFx0dG9wOjA7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjp3aGl0ZSAhaW1wb3J0YW50O1xcdFxcclxcblxcdG92ZXJmbG93OnZpc2libGU7XFxyXFxufVxcclxcbm1lbnUjYXBwc1N1Yk1lbnUgYXtcXHJcXG5cXHRtYXJnaW4tbGVmdDotMTkuMWVtO1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6d2hpdGUgIWltcG9ydGFudDtcXHJcXG5cXHRib3JkZXI6MXB4IHNvbGlkICNjY2M7XFxyXFxuXFx0d2lkdGg6MThlbTtcXHJcXG5cXHRkaXNwbGF5OmJsb2NrO1xcclxcblxcdHBhZGRpbmc6NXB4O1xcclxcblxcdGZsb2F0Om5vbmU7XFxyXFxufVxcclxcbmJvZHkucWEtYm9keS1qcy1vbiBtZW51I2FwcHNTdWJNZW51IGF7XFxyXFxuXFx0bWFyZ2luLWxlZnQ6LTIyLjhlbTtcXHJcXG59XFxyXFxuYm9keS5xYS1ib2R5LWpzLW9uIG1lbnUjYXBwc1N1Yk1lbnUge1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQgIWltcG9ydGFudDtcXHJcXG59XFxyXFxubWVudSNhcHBzU3ViTWVudSBhOmhvdmVye1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6I2ZmZTI3MCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvYXBwc01lbnUvYXBwc01lbnUuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBO0NBQ0MsWUFBWTtDQUNaLGlCQUFpQjtDQUNqQixLQUFLO0NBQ0wsaUNBQWlDO0NBQ2pDLGdCQUFnQjtBQUNqQjtBQUNBO0NBQ0MsbUJBQW1CO0NBQ25CLGlDQUFpQztDQUNqQyxxQkFBcUI7Q0FDckIsVUFBVTtDQUNWLGFBQWE7Q0FDYixXQUFXO0NBQ1gsVUFBVTtBQUNYO0FBQ0E7Q0FDQyxtQkFBbUI7QUFDcEI7QUFDQTtDQUNDLHVDQUF1QztBQUN4QztBQUNBO0NBQ0MsbUNBQW1DO0FBQ3BDXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIm1lbnUjYXBwc1N1Yk1lbnUge1xcclxcblxcdGRpc3BsYXk6bm9uZTtcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZTtcXHJcXG5cXHR0b3A6MDtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOndoaXRlICFpbXBvcnRhbnQ7XFx0XFxyXFxuXFx0b3ZlcmZsb3c6dmlzaWJsZTtcXHJcXG59XFxyXFxubWVudSNhcHBzU3ViTWVudSBhe1xcclxcblxcdG1hcmdpbi1sZWZ0Oi0xOS4xZW07XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjp3aGl0ZSAhaW1wb3J0YW50O1xcclxcblxcdGJvcmRlcjoxcHggc29saWQgI2NjYztcXHJcXG5cXHR3aWR0aDoxOGVtO1xcclxcblxcdGRpc3BsYXk6YmxvY2s7XFxyXFxuXFx0cGFkZGluZzo1cHg7XFxyXFxuXFx0ZmxvYXQ6bm9uZTtcXHJcXG59XFxyXFxuYm9keS5xYS1ib2R5LWpzLW9uIG1lbnUjYXBwc1N1Yk1lbnUgYXtcXHJcXG5cXHRtYXJnaW4tbGVmdDotMjIuOGVtO1xcclxcbn1cXHJcXG5ib2R5LnFhLWJvZHktanMtb24gbWVudSNhcHBzU3ViTWVudSB7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5tZW51I2FwcHNTdWJNZW51IGE6aG92ZXJ7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjojZmZlMjcwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcImJ1dHRvbi53aWtpdHJlZXR1cmJvIHtcXHJcXG4gICAgcGFkZGluZzogMnB4IDEwcHg7XFxyXFxuICAgIGZvbnQtZmFtaWx5OiBtb25vc3BhY2U7XFxyXFxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZWU7XFxyXFxuICAgIGNvbG9yOiAjMzMzO1xcclxcblxcdHBvc2l0aW9uOmFic29sdXRlICFpbXBvcnRhbnQ7XFxyXFxuXFx0bWFyZ2luLWxlZnQ6LTIuODVlbTtcXHJcXG5cXHRtYXJnaW4tdG9wOiAtMC4yNWVtO1xcclxcbn1cXHJcXG5idXR0b24ud2lraXRyZWV0dXJibywgYnV0dG9uLndpa2l0cmVldHVyYm86YWN0aXZlIHtcXHJcXG5cXHR0b3A6YXV0byAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG4jZGVzY2VuZGFudHNDb250YWluZXIgbGkuY29sbGFwc2Uge1xcclxcblxcdHBvc2l0aW9uOnJlbGF0aXZlO1xcclxcbn1cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUvY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBO0lBQ0ksaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixzQkFBc0I7SUFDdEIsV0FBVztDQUNkLDRCQUE0QjtDQUM1QixtQkFBbUI7Q0FDbkIsbUJBQW1CO0FBQ3BCO0FBQ0E7Q0FDQyxtQkFBbUI7QUFDcEI7QUFDQTtDQUNDLGlCQUFpQjtBQUNsQlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJidXR0b24ud2lraXRyZWV0dXJibyB7XFxyXFxuICAgIHBhZGRpbmc6IDJweCAxMHB4O1xcclxcbiAgICBmb250LWZhbWlseTogbW9ub3NwYWNlO1xcclxcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWVlO1xcclxcbiAgICBjb2xvcjogIzMzMztcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZSAhaW1wb3J0YW50O1xcclxcblxcdG1hcmdpbi1sZWZ0Oi0yLjg1ZW07XFxyXFxuXFx0bWFyZ2luLXRvcDogLTAuMjVlbTtcXHJcXG59XFxyXFxuYnV0dG9uLndpa2l0cmVldHVyYm8sIGJ1dHRvbi53aWtpdHJlZXR1cmJvOmFjdGl2ZSB7XFxyXFxuXFx0dG9wOmF1dG8gIWltcG9ydGFudDtcXHJcXG59XFxyXFxuI2Rlc2NlbmRhbnRzQ29udGFpbmVyIGxpLmNvbGxhcHNlIHtcXHJcXG5cXHRwb3NpdGlvbjpyZWxhdGl2ZTtcXHJcXG59XCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiYm9keS5kYXJrTW9kZSAqLFxcclxcbmJvZHkuZGFya01vZGUgaHRtbCBib2R5LFxcclxcbmJvZHkuZGFya01vZGUgLndyYXBwZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBhLFxcclxcbmJvZHkuZGFya01vZGUgYTpsaW5rLFxcclxcbmJvZHkuZGFya01vZGUgYTp2aXNpdGVkLFxcclxcbmJvZHkuZGFya01vZGUgLlNNQUxMLFxcclxcbmJvZHkuZGFya01vZGUgLnNtYWxsLFxcclxcbmJvZHkuZGFya01vZGUgLnB1cmVDc3NNZW51bSxcXHJcXG5ib2R5LmRhcmtNb2RlIC5ob21lLFxcclxcbmJvZHkuZGFya01vZGUgLnBlcnNvbixcXHJcXG5ib2R5LmRhcmtNb2RlIC5hZGQsXFxyXFxuYm9keS5kYXJrTW9kZSAuZmluZCxcXHJcXG5ib2R5LmRhcmtNb2RlIC5oZWxwLFxcclxcbmJvZHkuZGFya01vZGUgc3Ryb25nLFxcclxcbmJvZHkuZGFya01vZGUgYS52aWV3c2ksXFxyXFxuYm9keS5kYXJrTW9kZSB1bC52aWV3cyBhLFxcclxcbmJvZHkuZGFya01vZGUgdWwucHVyZS1jc3MtbWVudSxcXHJcXG5ib2R5LmRhcmtNb2RlIGE6bGluay5hY3RpdmVQcm9maWxlLFxcclxcbmJvZHkuZGFya01vZGUgYTpob3Zlci5hY3RpdmVQcm9maWxlLFxcclxcbmJvZHkuZGFya01vZGUgYTp2aXNpdGVkLmFjdGl2ZVByb2ZpbGUgYTphY3RpdmUuYWN0aXZlUHJvZmlsZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGlmcmFtZS5ja2Vfd3lzaXd5Z19mcmFtZSxcXHJcXG5ib2R5LmRhcmtNb2RlICNja2VfNjFfY29udGVudHMsXFxyXFxuYm9keS5kYXJrTW9kZSBib2R5LmJsYWNrTGlua3Mgc3Ryb25nLFxcclxcbmJvZHkuZGFya01vZGUgbWVudSNhcHBzU3ViTWVudSBhLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnN0cmlwZXMtMSxcXHJcXG5ib2R5LmRhcmtNb2RlIHtcXHJcXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzYzOTNmICFpbXBvcnRhbnQ7XFxyXFxuICBjb2xvcjogI2RjZGRkZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC5idXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucGFkIGZvcm0gYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQuYnV0dG9uLmdyZWVuLnNlYXJjaCB7XFxyXFxuICBwYWRkaW5nOiAxMnB4IDEycHggIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuLnNob3dIaWRlVHJlZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W3R5cGU9XFxcInN1Ym1pdFxcXCJdLFxcclxcbmJvZHkuZGFya01vZGUgc3BhbiNzaG93SGlkZURlc2NlbmRhbnRzIHtcXHJcXG4gIHBhZGRpbmc6IDZweCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC5xYS12b3RlLWJ1dHRvbnMgaW5wdXQge1xcclxcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC5sYXJnZSxcXHJcXG5ib2R5LmRhcmtNb2RlIHVsLFxcclxcbmJvZHkuZGFya01vZGUgbGkge1xcclxcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5zdHJpcGVzLTEsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuc3RyaXBlcyxcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5nZXRzdGFydGVkIHtcXHJcXG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBtZW51I2FwcHNTdWJNZW51IGE6aG92ZXIge1xcclxcbiAgYmFja2dyb3VuZDogbmF2eSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIHVsLnByb2ZpbGUtdGFicyBsaSxcXHJcXG5ib2R5LmRhcmtNb2RlIHtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgdWwucHVyZUNzc01lbnUgdWwgbGkgYTpob3ZlciB7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiBuYXZ5ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgLnlvdXJDb25uZWN0aW9uLFxcclxcbmJvZHkuZGFya01vZGUgI3lvdXJDb25uZWN0aW9uIHtcXHJcXG4gIGJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgI3lvdXJDb25uZWN0aW9uIHtcXHJcXG4gIG1hcmdpbi1yaWdodDogNHB4O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W3R5cGU9XFxcInN1Ym1pdFxcXCJdLFxcclxcbmJvZHkuZGFya01vZGUgYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbdHlwZT1cXFwiYnV0dG9uXFxcIl0sXFxyXFxuYm9keS5kYXJrTW9kZSBhLmJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4uc2hvd0hpZGVUcmVlLFxcclxcbmJvZHkuZGFya01vZGUgc3BhbiNzaG93SGlkZURlc2NlbmRhbnRzIHtcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgYnV0dG9uLmNvcHlXaWRnZXQsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29tbWVudC1hY3Rpb25zIGJ1dHRvbi5idXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuLmNvbW1lbnRDb250YWluZXJUb2dnbGUgYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLXZvdGUtYnV0dG9ucyBpbnB1dCxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZhdm9yaXRlLWJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlICN3dElEZ29fZ28sXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi1yZXNob3csXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi1oaWRlLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtZm9ybS1saWdodC1idXR0b24tZWRpdCxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W25hbWU9XFxcIndwU2VhcmNoXFxcIl0ge1xcclxcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbbmFtZT1cXFwid3BTZWFyY2hcXFwiXSB7XFxyXFxuICBiYWNrZ3JvdW5kOiB1cmwoXFxcImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbWFnZXMvaWNvbnMvc2VhcmNoLXN1Ym1pdC1pY29uLnBuZ1xcXCIpXFxyXFxuICAgIHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxuICBmb250LXNpemU6IDA7XFxyXFxuICB0b3A6IC01cHggIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1hLXNlbGVjdC1idXR0b24ge1xcclxcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFxcXCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vZzJnL3FhLXRoZW1lL1dpa2lUcmVlL3NlbGVjdC1zdGFyLnBuZ1xcXCIpXFxyXFxuICAgIG5vLXJlcGVhdCAhaW1wb3J0YW50O1xcclxcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZvcm0tbGlnaHQtYnV0dG9uLnFhLWZvcm0tbGlnaHQtYnV0dG9uLWZsYWcsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtdm90ZS1idXR0b25zIHFhLXZvdGUtYnV0dG9ucy1uZXQgaW5wdXQge1xcclxcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgI2hlYWRlcixcXHJcXG5ib2R5LmRhcmtNb2RlICNmb290ZXIge1xcclxcbiAgYmFja2dyb3VuZDogIzM2MzkzZjtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29weVdpZGdldENvbnRhaW5lcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5jb3B5V2lkZ2V0Q29udGFpbmVySW5uZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29weVdpZGdldENvbnRhaW5lcklubmVyIGJ1dHRvbiB7XFxyXFxuICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgbGkuR1JFRU4tQVJST1cge1xcclxcbiAgYmFja2dyb3VuZC1ibGVuZC1tb2RlOiBjb2xvcjtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtcS1pdGVtLXRpdGxlIGE6bGluayAuY2hlY2ttYXJrLFxcclxcbmJvZHkuZGFya01vZGUgc3Bhbi5xYS1xLWl0ZW0tbWV0YSBhLnFhLXEtaXRlbS13aGF0OmxpbmsgLmNoZWNrbWFyayB7XFxyXFxuICBjb2xvcjogIzM2MzkzZiAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1uYXYtbWFpbiBhOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLWZvb3RlciBhOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1tYWluIGE6dmlzaXRlZDpob3ZlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1mb290ZXIgYTp2aXNpdGVkOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1zdWIgYTp2aXNpdGVkOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1zdWIgYTpob3ZlciB7XFxyXFxuICBjb2xvcjogIzM2MzkzZiAhaW1wb3J0YW50O1xcclxcbiAgYmFja2dyb3VuZDogI2RjZGRkZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGFbaHJlZio9XFxcIndpa2kvUHJpdmFjeVxcXCJdIGltZyxcXHJcXG5ib2R5LmRhcmtNb2RlIGltZ1tzcmMqPVxcXCJpbWFnZXMvaWNvbnMvcHJpdmFjeVxcXCJdIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6ICM5MTk2YTEgIWltcG9ydGFudDtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcXHJcXG59XFxyXFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL2ZlYXR1cmVzL2RhcmtNb2RlL2RhcmtNb2RlLmNzc1wiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBMkJFLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMseUJBQXlCO0FBQzNCO0FBQ0E7OztFQUdFLDZCQUE2QjtBQUMvQjtBQUNBOzs7RUFHRSx1QkFBdUI7QUFDekI7QUFDQTtFQUNFLHFCQUFxQjtBQUN2QjtBQUNBOzs7RUFHRSwyQkFBMkI7QUFDN0I7QUFDQTs7O0VBR0UsaUNBQWlDO0FBQ25DO0FBQ0E7RUFDRSwyQkFBMkI7QUFDN0I7QUFDQTs7RUFFRSxpQkFBaUI7RUFDakIsdUJBQXVCO0FBQ3pCO0FBQ0E7RUFDRSxpQ0FBaUM7QUFDbkM7QUFDQTs7RUFFRSw0QkFBNEI7QUFDOUI7QUFDQTtFQUNFLGlCQUFpQjtBQUNuQjtBQUNBOzs7Ozs7RUFNRSxrQ0FBa0M7QUFDcEM7QUFDQTs7Ozs7Ozs7OztFQVVFLG9CQUFvQjtBQUN0QjtBQUNBO0VBQ0U7b0JBQ2tCO0VBQ2xCLFlBQVk7RUFDWixvQkFBb0I7QUFDdEI7QUFDQTtFQUNFO3dCQUNzQjtFQUN0QixvQkFBb0I7RUFDcEIsa0NBQWtDO0FBQ3BDO0FBQ0E7O0VBRUUsb0JBQW9CO0FBQ3RCO0FBQ0E7O0VBRUUsbUJBQW1CO0FBQ3JCO0FBQ0E7OztFQUdFLDJCQUEyQjtBQUM3QjtBQUNBO0VBQ0UsNEJBQTRCO0FBQzlCO0FBQ0E7O0VBRUUseUJBQXlCO0FBQzNCO0FBQ0E7Ozs7OztFQU1FLHlCQUF5QjtFQUN6Qiw4QkFBOEI7QUFDaEM7QUFDQTs7RUFFRSxvQ0FBb0M7RUFDcEMsa0JBQWtCO0FBQ3BCXCIsXCJzb3VyY2VzQ29udGVudFwiOltcImJvZHkuZGFya01vZGUgKixcXHJcXG5ib2R5LmRhcmtNb2RlIGh0bWwgYm9keSxcXHJcXG5ib2R5LmRhcmtNb2RlIC53cmFwcGVyLFxcclxcbmJvZHkuZGFya01vZGUgYSxcXHJcXG5ib2R5LmRhcmtNb2RlIGE6bGluayxcXHJcXG5ib2R5LmRhcmtNb2RlIGE6dmlzaXRlZCxcXHJcXG5ib2R5LmRhcmtNb2RlIC5TTUFMTCxcXHJcXG5ib2R5LmRhcmtNb2RlIC5zbWFsbCxcXHJcXG5ib2R5LmRhcmtNb2RlIC5wdXJlQ3NzTWVudW0sXFxyXFxuYm9keS5kYXJrTW9kZSAuaG9tZSxcXHJcXG5ib2R5LmRhcmtNb2RlIC5wZXJzb24sXFxyXFxuYm9keS5kYXJrTW9kZSAuYWRkLFxcclxcbmJvZHkuZGFya01vZGUgLmZpbmQsXFxyXFxuYm9keS5kYXJrTW9kZSAuaGVscCxcXHJcXG5ib2R5LmRhcmtNb2RlIHN0cm9uZyxcXHJcXG5ib2R5LmRhcmtNb2RlIGEudmlld3NpLFxcclxcbmJvZHkuZGFya01vZGUgdWwudmlld3MgYSxcXHJcXG5ib2R5LmRhcmtNb2RlIHVsLnB1cmUtY3NzLW1lbnUsXFxyXFxuYm9keS5kYXJrTW9kZSBhOmxpbmsuYWN0aXZlUHJvZmlsZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGE6aG92ZXIuYWN0aXZlUHJvZmlsZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGE6dmlzaXRlZC5hY3RpdmVQcm9maWxlIGE6YWN0aXZlLmFjdGl2ZVByb2ZpbGUsXFxyXFxuYm9keS5kYXJrTW9kZSBpZnJhbWUuY2tlX3d5c2l3eWdfZnJhbWUsXFxyXFxuYm9keS5kYXJrTW9kZSAjY2tlXzYxX2NvbnRlbnRzLFxcclxcbmJvZHkuZGFya01vZGUgYm9keS5ibGFja0xpbmtzIHN0cm9uZyxcXHJcXG5ib2R5LmRhcmtNb2RlIG1lbnUjYXBwc1N1Yk1lbnUgYSxcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5zdHJpcGVzLTEsXFxyXFxuYm9keS5kYXJrTW9kZSB7XFxyXFxuICBmb250LXdlaWdodDogNDAwO1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM2MzkzZiAhaW1wb3J0YW50O1xcclxcbiAgY29sb3I6ICNkY2RkZGUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSAuYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnBhZCBmb3JtIGJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LmJ1dHRvbi5ncmVlbi5zZWFyY2gge1xcclxcbiAgcGFkZGluZzogMTJweCAxMnB4ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgc3Bhbi5zaG93SGlkZVRyZWUsXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dFt0eXBlPVxcXCJzdWJtaXRcXFwiXSxcXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4jc2hvd0hpZGVEZXNjZW5kYW50cyB7XFxyXFxuICBwYWRkaW5nOiA2cHggIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSAucWEtdm90ZS1idXR0b25zIGlucHV0IHtcXHJcXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSAubGFyZ2UsXFxyXFxuYm9keS5kYXJrTW9kZSB1bCxcXHJcXG5ib2R5LmRhcmtNb2RlIGxpIHtcXHJcXG4gIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuc3RyaXBlcy0xLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnN0cmlwZXMsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuZ2V0c3RhcnRlZCB7XFxyXFxuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgbWVudSNhcHBzU3ViTWVudSBhOmhvdmVyIHtcXHJcXG4gIGJhY2tncm91bmQ6IG5hdnkgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSB1bC5wcm9maWxlLXRhYnMgbGksXFxyXFxuYm9keS5kYXJrTW9kZSB7XFxyXFxuICBmb250LXdlaWdodDogYm9sZDtcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIHVsLnB1cmVDc3NNZW51IHVsIGxpIGE6aG92ZXIge1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogbmF2eSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC55b3VyQ29ubmVjdGlvbixcXHJcXG5ib2R5LmRhcmtNb2RlICN5b3VyQ29ubmVjdGlvbiB7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlICN5b3VyQ29ubmVjdGlvbiB7XFxyXFxuICBtYXJnaW4tcmlnaHQ6IDRweDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dFt0eXBlPVxcXCJzdWJtaXRcXFwiXSxcXHJcXG5ib2R5LmRhcmtNb2RlIGJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W3R5cGU9XFxcImJ1dHRvblxcXCJdLFxcclxcbmJvZHkuZGFya01vZGUgYS5idXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuLnNob3dIaWRlVHJlZSxcXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4jc2hvd0hpZGVEZXNjZW5kYW50cyB7XFxyXFxuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGJ1dHRvbi5jb3B5V2lkZ2V0LFxcclxcbmJvZHkuZGFya01vZGUgZGl2LmNvbW1lbnQtYWN0aW9ucyBidXR0b24uYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgc3Bhbi5jb21tZW50Q29udGFpbmVyVG9nZ2xlIGJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS12b3RlLWJ1dHRvbnMgaW5wdXQsXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mYXZvcml0ZS1idXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSAjd3RJRGdvX2dvLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtZm9ybS1saWdodC1idXR0b24tcmVzaG93LFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtZm9ybS1saWdodC1idXR0b24taGlkZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZvcm0tbGlnaHQtYnV0dG9uLWVkaXQsXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dFtuYW1lPVxcXCJ3cFNlYXJjaFxcXCJdIHtcXHJcXG4gIGJvcmRlcjogMCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W25hbWU9XFxcIndwU2VhcmNoXFxcIl0ge1xcclxcbiAgYmFja2dyb3VuZDogdXJsKFxcXCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vaW1hZ2VzL2ljb25zL3NlYXJjaC1zdWJtaXQtaWNvbi5wbmdcXFwiKVxcclxcbiAgICB3aGl0ZSAhaW1wb3J0YW50O1xcclxcbiAgZm9udC1zaXplOiAwO1xcclxcbiAgdG9wOiAtNXB4ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtYS1zZWxlY3QtYnV0dG9uIHtcXHJcXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcXFwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2cyZy9xYS10aGVtZS9XaWtpVHJlZS9zZWxlY3Qtc3Rhci5wbmdcXFwiKVxcclxcbiAgICBuby1yZXBlYXQgIWltcG9ydGFudDtcXHJcXG4gIGJvcmRlcjogMCAhaW1wb3J0YW50O1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi1mbGFnLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLXZvdGUtYnV0dG9ucyBxYS12b3RlLWJ1dHRvbnMtbmV0IGlucHV0IHtcXHJcXG4gIGJvcmRlcjogMCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlICNoZWFkZXIsXFxyXFxuYm9keS5kYXJrTW9kZSAjZm9vdGVyIHtcXHJcXG4gIGJhY2tncm91bmQ6ICMzNjM5M2Y7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgZGl2LmNvcHlXaWRnZXRDb250YWluZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29weVdpZGdldENvbnRhaW5lcklubmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LmNvcHlXaWRnZXRDb250YWluZXJJbm5lciBidXR0b24ge1xcclxcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGxpLkdSRUVOLUFSUk9XIHtcXHJcXG4gIGJhY2tncm91bmQtYmxlbmQtbW9kZTogY29sb3I7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLXEtaXRlbS10aXRsZSBhOmxpbmsgLmNoZWNrbWFyayxcXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4ucWEtcS1pdGVtLW1ldGEgYS5xYS1xLWl0ZW0td2hhdDpsaW5rIC5jaGVja21hcmsge1xcclxcbiAgY29sb3I6ICMzNjM5M2YgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtbmF2LW1haW4gYTpob3ZlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1mb290ZXIgYTpob3ZlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1uYXYtbWFpbiBhOnZpc2l0ZWQ6aG92ZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtZm9vdGVyIGE6dmlzaXRlZDpob3ZlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1uYXYtc3ViIGE6dmlzaXRlZDpob3ZlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1uYXYtc3ViIGE6aG92ZXIge1xcclxcbiAgY29sb3I6ICMzNjM5M2YgIWltcG9ydGFudDtcXHJcXG4gIGJhY2tncm91bmQ6ICNkY2RkZGUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBhW2hyZWYqPVxcXCJ3aWtpL1ByaXZhY3lcXFwiXSBpbWcsXFxyXFxuYm9keS5kYXJrTW9kZSBpbWdbc3JjKj1cXFwiaW1hZ2VzL2ljb25zL3ByaXZhY3lcXFwiXSB7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTE5NmExICFpbXBvcnRhbnQ7XFxyXFxuICBib3JkZXItcmFkaXVzOiA1MCU7XFxyXFxufVxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIiNkaXN0YW5jZUZyb21Zb3Uge1xcclxcbiAgZm9udC1zaXplOiAwLjVlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbiAgcGFkZGluZzogMC4yZW07XFxyXFxuICBib3JkZXI6IDJweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcXHJcXG4gIHdpZHRoOiAzZW07XFxyXFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcXHJcXG4gIG9wYWNpdHk6IDAuODtcXHJcXG4gIHotaW5kZXg6IDE7XFxyXFxuICBjdXJzb3I6ZGVmYXVsdDtcXHJcXG59XFxyXFxuYnV0dG9uLmNvcHlXaWRnZXQge1xcclxcbiAgei1pbmRleDogMTA7XFxyXFxufVxcclxcblxcclxcbiN5b3VyUmVsYXRpb25zaGlwVGV4dCB7XFxyXFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxyXFxuICBib3JkZXI6IDFweCBzb2xpZCBncmVlbjtcXHJcXG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG4gIGJvcmRlci1yaWdodDogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgcGFkZGluZzogMC41ZW07XFxyXFxuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcXHJcXG4gIG1hcmdpbjogMC4xZW0gMWVtIDFlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbn1cXHJcXG4jeW91ckNvbW1vbkFuY2VzdG9yIHtcXHJcXG4gIG1hcmdpbjogYXV0bztcXHJcXG4gIHBhZGRpbmc6IDA7XFxyXFxufVxcclxcbiN5b3VyUmVsYXRpb25zaGlwVGV4dCAjeW91ckNvbW1vbkFuY2VzdG9yID4gbGkge1xcclxcbiAgZGlzcGxheTogYmxvY2s7XFxyXFxuICBtYXJnaW46IGF1dG87XFxyXFxuICBwYWRkaW5nOiBhdXRvO1xcclxcbiAgbGlzdC1zdHlsZTogbm9uZTtcXHJcXG59XFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0ICN5b3VyQ29tbW9uQW5jZXN0b3IgPiBsaTpudGgtY2hpbGQobiArIDMpIHtcXHJcXG4gIGRpc3BsYXk6IG5vbmU7XFxyXFxufVxcclxcbiN5b3VyUmVsYXRpb25zaGlwVGV4dCB7XFxyXFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZXNtb2tlO1xcclxcbn1cXHJcXG4jc2hvd01vcmVBbmNlc3RvcnMge1xcclxcbiAgcG9zaXRpb246IGFic29sdXRlO1xcclxcbiAgZm9udC1zaXplOiAwLjhlbTtcXHJcXG4gIHBhZGRpbmc6IDAuNWVtO1xcclxcbiAgdG9wOiAtMC41ZW07XFxyXFxuICByaWdodDogLTAuNWVtO1xcclxcbn1cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAvZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixjQUFjO0VBQ2QsNkJBQTZCO0VBQzdCLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1Ysa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osVUFBVTtFQUNWLGNBQWM7QUFDaEI7QUFDQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQix1QkFBdUI7RUFDdkIsb0NBQW9DO0VBQ3BDLG1DQUFtQztFQUNuQyxjQUFjO0VBQ2Qsb0JBQW9CO0VBQ3BCLHFCQUFxQjtFQUNyQixpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLFlBQVk7RUFDWixVQUFVO0FBQ1o7QUFDQTtFQUNFLGNBQWM7RUFDZCxZQUFZO0VBQ1osYUFBYTtFQUNiLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsYUFBYTtBQUNmO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxXQUFXO0VBQ1gsYUFBYTtBQUNmXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIiNkaXN0YW5jZUZyb21Zb3Uge1xcclxcbiAgZm9udC1zaXplOiAwLjVlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbiAgcGFkZGluZzogMC4yZW07XFxyXFxuICBib3JkZXI6IDJweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcXHJcXG4gIHdpZHRoOiAzZW07XFxyXFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcXHJcXG4gIG9wYWNpdHk6IDAuODtcXHJcXG4gIHotaW5kZXg6IDE7XFxyXFxuICBjdXJzb3I6ZGVmYXVsdDtcXHJcXG59XFxyXFxuYnV0dG9uLmNvcHlXaWRnZXQge1xcclxcbiAgei1pbmRleDogMTA7XFxyXFxufVxcclxcblxcclxcbiN5b3VyUmVsYXRpb25zaGlwVGV4dCB7XFxyXFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxyXFxuICBib3JkZXI6IDFweCBzb2xpZCBncmVlbjtcXHJcXG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG4gIGJvcmRlci1yaWdodDogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgcGFkZGluZzogMC41ZW07XFxyXFxuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcXHJcXG4gIG1hcmdpbjogMC4xZW0gMWVtIDFlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbn1cXHJcXG4jeW91ckNvbW1vbkFuY2VzdG9yIHtcXHJcXG4gIG1hcmdpbjogYXV0bztcXHJcXG4gIHBhZGRpbmc6IDA7XFxyXFxufVxcclxcbiN5b3VyUmVsYXRpb25zaGlwVGV4dCAjeW91ckNvbW1vbkFuY2VzdG9yID4gbGkge1xcclxcbiAgZGlzcGxheTogYmxvY2s7XFxyXFxuICBtYXJnaW46IGF1dG87XFxyXFxuICBwYWRkaW5nOiBhdXRvO1xcclxcbiAgbGlzdC1zdHlsZTogbm9uZTtcXHJcXG59XFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0ICN5b3VyQ29tbW9uQW5jZXN0b3IgPiBsaTpudGgtY2hpbGQobiArIDMpIHtcXHJcXG4gIGRpc3BsYXk6IG5vbmU7XFxyXFxufVxcclxcbiN5b3VyUmVsYXRpb25zaGlwVGV4dCB7XFxyXFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZXNtb2tlO1xcclxcbn1cXHJcXG4jc2hvd01vcmVBbmNlc3RvcnMge1xcclxcbiAgcG9zaXRpb246IGFic29sdXRlO1xcclxcbiAgZm9udC1zaXplOiAwLjhlbTtcXHJcXG4gIHBhZGRpbmc6IDAuNWVtO1xcclxcbiAgdG9wOiAtMC41ZW07XFxyXFxuICByaWdodDogLTAuNWVtO1xcclxcbn1cXHJcXG5cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIjbXlEcmFmdHMge1xcclxcblxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG5cXHR0b3A6IDEwMHB4O1xcclxcblxcdGxlZnQ6IDUwJTtcXHJcXG5cXHR6LWluZGV4OiAxMTAwMDtcXHJcXG5cXHRiYWNrZ3JvdW5kOiB3aGl0ZTtcXHJcXG5cXHRib3JkZXI6IDJweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG5cXHRib3JkZXItcmFkaXVzOiAxZW07XFxyXFxuXFx0Ym94LXNoYWRvdzogMC4xZW0gMC4xZW0gMC4xZW0gMC4xZW0gbGlnaHRncmVlbjtcXHJcXG5cXHRwYWRkaW5nOiAxZW07XFxyXFxuXFx0ZGlzcGxheTogbm9uZTtcXHJcXG5cXHR0ZXh0LWFsaWduOiBsZWZ0O1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgeCB7XFxyXFxuXFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogMDtcXHJcXG5cXHRyaWdodDogMC4yZW07XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgaDIge1xcclxcblxcdG1hcmdpbjogMC41ZW07XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyB0YWJsZSB0ZCB7XFxyXFxuXFx0cGFkZGluZzogMC41ZW07XFxyXFxuXFx0bGlzdC1zdHlsZTogbm9uZTtcXHJcXG5cXHR3aGl0ZS1zcGFjZTogbm93cmFwO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgYSB7XFxyXFxuXFx0bWFyZ2luOiAwLjJlbSAwLjVlbTtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIGEuYnV0dG9uOmFjdGl2ZSB7XFxyXFxuXFx0Y29sb3I6IGdvbGQ7XFxyXFxuXFx0YmFja2dyb3VuZDogcmdiKDAsIDEwMCwgMCk7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBwIHtcXHJcXG5cXHR0ZXh0LWFsaWduOiBjZW50ZXI7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBoMiB7XFxyXFxuXFx0cGFkZGluZzogMC41ZW07XFxyXFxufVxcclxcblxcclxcbmJvZHkucWEtYm9keS1qcy1vbiAuYnV0dG9uLnNtYWxsIHtcXHJcXG5cXHRwYWRkaW5nOiA3cHggMTVweDtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjMjU0MjJkO1xcclxcblxcdGJvcmRlcjogMDtcXHJcXG5cXHRvdXRsaW5lOiBub25lO1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG5cXHR0ZXh0LWFsaWduOiBjZW50ZXI7XFxyXFxuXFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcXHJcXG5cXHRib3JkZXItcmFkaXVzOiA1cHg7XFxyXFxuXFx0Y29sb3I6ICNmZmY7XFxyXFxuXFx0Zm9udC13ZWlnaHQ6IG5vcm1hbDtcXHJcXG5cXHR0ZXh0LWRlY29yYXRpb246IG5vbmUgIWltcG9ydGFudDtcXHJcXG5cXHRjdXJzb3I6IHBvaW50ZXI7XFxyXFxuXFx0bGluZS1oZWlnaHQ6IG5vcm1hbDtcXHJcXG59XCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL2ZlYXR1cmVzL2RyYWZ0TGlzdC9kcmFmdExpc3QuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBO0NBQ0Msa0JBQWtCO0NBQ2xCLFVBQVU7Q0FDVixTQUFTO0NBQ1QsY0FBYztDQUNkLGlCQUFpQjtDQUNqQiw2QkFBNkI7Q0FDN0Isa0JBQWtCO0NBQ2xCLDhDQUE4QztDQUM5QyxZQUFZO0NBQ1osYUFBYTtDQUNiLGdCQUFnQjtBQUNqQjs7QUFFQTtDQUNDLGlCQUFpQjtDQUNqQixrQkFBa0I7Q0FDbEIsTUFBTTtDQUNOLFlBQVk7Q0FDWixlQUFlO0FBQ2hCOztBQUVBO0NBQ0MsYUFBYTtBQUNkOztBQUVBO0NBQ0MsY0FBYztDQUNkLGdCQUFnQjtDQUNoQixtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxXQUFXO0NBQ1gsMEJBQTBCO0FBQzNCOztBQUVBO0NBQ0Msa0JBQWtCO0FBQ25COztBQUVBO0NBQ0MsY0FBYztBQUNmOztBQUVBO0NBQ0MsaUJBQWlCO0NBQ2pCLG1CQUFtQjtDQUNuQixTQUFTO0NBQ1QsYUFBYTtDQUNiLGVBQWU7Q0FDZixrQkFBa0I7Q0FDbEIseUJBQXlCO0NBQ3pCLGtCQUFrQjtDQUNsQixXQUFXO0NBQ1gsbUJBQW1CO0NBQ25CLGdDQUFnQztDQUNoQyxlQUFlO0NBQ2YsbUJBQW1CO0FBQ3BCXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIiNteURyYWZ0cyB7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogMTAwcHg7XFxyXFxuXFx0bGVmdDogNTAlO1xcclxcblxcdHotaW5kZXg6IDExMDAwO1xcclxcblxcdGJhY2tncm91bmQ6IHdoaXRlO1xcclxcblxcdGJvcmRlcjogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcblxcdGJvcmRlci1yYWRpdXM6IDFlbTtcXHJcXG5cXHRib3gtc2hhZG93OiAwLjFlbSAwLjFlbSAwLjFlbSAwLjFlbSBsaWdodGdyZWVuO1xcclxcblxcdHBhZGRpbmc6IDFlbTtcXHJcXG5cXHRkaXNwbGF5OiBub25lO1xcclxcblxcdHRleHQtYWxpZ246IGxlZnQ7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyB4IHtcXHJcXG5cXHRmb250LXdlaWdodDogYm9sZDtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0dG9wOiAwO1xcclxcblxcdHJpZ2h0OiAwLjJlbTtcXHJcXG5cXHRjdXJzb3I6IHBvaW50ZXI7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBoMiB7XFxyXFxuXFx0bWFyZ2luOiAwLjVlbTtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIHRhYmxlIHRkIHtcXHJcXG5cXHRwYWRkaW5nOiAwLjVlbTtcXHJcXG5cXHRsaXN0LXN0eWxlOiBub25lO1xcclxcblxcdHdoaXRlLXNwYWNlOiBub3dyYXA7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBhIHtcXHJcXG5cXHRtYXJnaW46IDAuMmVtIDAuNWVtO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgYS5idXR0b246YWN0aXZlIHtcXHJcXG5cXHRjb2xvcjogZ29sZDtcXHJcXG5cXHRiYWNrZ3JvdW5kOiByZ2IoMCwgMTAwLCAwKTtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIHAge1xcclxcblxcdHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIGgyIHtcXHJcXG5cXHRwYWRkaW5nOiAwLjVlbTtcXHJcXG59XFxyXFxuXFxyXFxuYm9keS5xYS1ib2R5LWpzLW9uIC5idXR0b24uc21hbGwge1xcclxcblxcdHBhZGRpbmc6IDdweCAxNXB4O1xcclxcblxcdGJhY2tncm91bmQ6ICMyNTQyMmQ7XFxyXFxuXFx0Ym9yZGVyOiAwO1xcclxcblxcdG91dGxpbmU6IG5vbmU7XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcblxcdHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG5cXHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xcclxcblxcdGJvcmRlci1yYWRpdXM6IDVweDtcXHJcXG5cXHRjb2xvcjogI2ZmZjtcXHJcXG5cXHRmb250LXdlaWdodDogbm9ybWFsO1xcclxcblxcdHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG5cXHRsaW5lLWhlaWdodDogbm9ybWFsO1xcclxcbn1cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIjdGltZWxpbmUud3JhcCxcXHJcXG4uZmFtaWx5U2hlZXQud3JhcCB7XFxyXFxuICB3aWR0aDogODAlO1xcclxcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcXHJcXG59XFxyXFxuI3RpbWVsaW5lLFxcclxcbi5mYW1pbHlTaGVldCB7XFxyXFxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xcclxcbiAgaGVpZ2h0OiBhdXRvO1xcclxcbiAgcG9zaXRpb246IGFic29sdXRlO1xcclxcbiAgd2lkdGg6IGF1dG87XFxyXFxuICBsZWZ0OiAxMCU7XFxyXFxuICB6LWluZGV4OiA0MDAwO1xcclxcbiAgYmFja2dyb3VuZDogd2hpdGU7XFxyXFxuICBib3JkZXI6IDNweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDFlbTtcXHJcXG4gIGJveC1zaGFkb3c6IDFlbSAxZW0gMWVtICNjY2M7XFxyXFxuICBwYWRkaW5nOiAwLjNlbTtcXHJcXG4gIGRpc3BsYXk6IG5vbmU7XFxyXFxuICBjdXJzb3I6IG1vdmU7XFxyXFxufVxcclxcbiN0aW1lbGluZVRhYmxlIHRkIHtcXHJcXG4gIHBhZGRpbmc6IDAuM2VtO1xcclxcbn1cXHJcXG4jdGltZWxpbmVUYWJsZSBjYXB0aW9uIHtcXHJcXG4gIGZvbnQtc2l6ZTogMS41ZW07XFxyXFxuICBmb250LXdlaWdodDogYm9sZDtcXHJcXG59XFxyXFxuLnRsQWdlLFxcclxcbi50bEJpb0FnZSB7XFxyXFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxyXFxufVxcclxcbnRoLnRsQmlvQWdlIHtcXHJcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG59XFxyXFxuLnRsRXZlbnROYW1lIHtcXHJcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG59XFxyXFxuLnRsRGF0ZSB7XFxyXFxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xcclxcbn1cXHJcXG4jdGltZWxpbmUgeCxcXHJcXG4uZmFtaWx5U2hlZXQgeCB7XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICB0b3A6IDA7XFxyXFxuICByaWdodDogMC41ZW07XFxyXFxuICBmb250LXdlaWdodDogYm9sZDtcXHJcXG4gIGN1cnNvcjogcG9pbnRlcjtcXHJcXG59XFxyXFxuI3RpbWVsaW5lIHcge1xcclxcbiAgcG9zaXRpb246IGFic29sdXRlO1xcclxcbiAgdG9wOiAwO1xcclxcbiAgbGVmdDogMC41ZW07XFxyXFxuICBmb250LXdlaWdodDogYm9sZDtcXHJcXG4gIGN1cnNvcjogcG9pbnRlcjtcXHJcXG59XFxyXFxuI3RpbWVsaW5lIC5CaW9QZXJzb24sXFxyXFxuI3RpbWVsaW5lIC5tYXJyaWFnZSB7XFxyXFxuICBmb250LXdlaWdodDogYm9sZDtcXHJcXG59XFxyXFxuI3RpbWVsaW5lIHRyLkJpb1BlcnNvbi5CaXJ0aCB7XFxyXFxuICBib3JkZXItdG9wOiAxcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxufVxcclxcbiN0aW1lbGluZSB0ci5CaW9QZXJzb24uRGVhdGgge1xcclxcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbn1cXHJcXG4jdGltZWxpbmVUYWJsZSB7XFxyXFxuICB3aWR0aDogOTglO1xcclxcbiAgbWFyZ2luOiBhdXRvO1xcclxcbn1cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvZmFtaWx5VGltZWxpbmUvZmFtaWx5VGltZWxpbmUuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBOztFQUVFLFVBQVU7RUFDVixtQkFBbUI7QUFDckI7QUFDQTs7RUFFRSxtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsU0FBUztFQUNULGFBQWE7RUFDYixpQkFBaUI7RUFDakIsNkJBQTZCO0VBQzdCLGtCQUFrQjtFQUNsQiw0QkFBNEI7RUFDNUIsY0FBYztFQUNkLGFBQWE7RUFDYixZQUFZO0FBQ2Q7QUFDQTtFQUNFLGNBQWM7QUFDaEI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixpQkFBaUI7QUFDbkI7QUFDQTs7RUFFRSxrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0Usa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxtQkFBbUI7QUFDckI7QUFDQTs7RUFFRSxrQkFBa0I7RUFDbEIsTUFBTTtFQUNOLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsZUFBZTtBQUNqQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLE1BQU07RUFDTixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLGVBQWU7QUFDakI7QUFDQTs7RUFFRSxpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLGlDQUFpQztBQUNuQztBQUNBO0VBQ0Usb0NBQW9DO0FBQ3RDO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsWUFBWTtBQUNkXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIiN0aW1lbGluZS53cmFwLFxcclxcbi5mYW1pbHlTaGVldC53cmFwIHtcXHJcXG4gIHdpZHRoOiA4MCU7XFxyXFxuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xcclxcbn1cXHJcXG4jdGltZWxpbmUsXFxyXFxuLmZhbWlseVNoZWV0IHtcXHJcXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XFxyXFxuICBoZWlnaHQ6IGF1dG87XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICB3aWR0aDogYXV0bztcXHJcXG4gIGxlZnQ6IDEwJTtcXHJcXG4gIHotaW5kZXg6IDQwMDA7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcXHJcXG4gIGJvcmRlcjogM3B4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgYm9yZGVyLXJhZGl1czogMWVtO1xcclxcbiAgYm94LXNoYWRvdzogMWVtIDFlbSAxZW0gI2NjYztcXHJcXG4gIHBhZGRpbmc6IDAuM2VtO1xcclxcbiAgZGlzcGxheTogbm9uZTtcXHJcXG4gIGN1cnNvcjogbW92ZTtcXHJcXG59XFxyXFxuI3RpbWVsaW5lVGFibGUgdGQge1xcclxcbiAgcGFkZGluZzogMC4zZW07XFxyXFxufVxcclxcbiN0aW1lbGluZVRhYmxlIGNhcHRpb24ge1xcclxcbiAgZm9udC1zaXplOiAxLjVlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbn1cXHJcXG4udGxBZ2UsXFxyXFxuLnRsQmlvQWdlIHtcXHJcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG59XFxyXFxudGgudGxCaW9BZ2Uge1xcclxcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcclxcbn1cXHJcXG4udGxFdmVudE5hbWUge1xcclxcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcclxcbn1cXHJcXG4udGxEYXRlIHtcXHJcXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XFxyXFxufVxcclxcbiN0aW1lbGluZSB4LFxcclxcbi5mYW1pbHlTaGVldCB4IHtcXHJcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG4gIHRvcDogMDtcXHJcXG4gIHJpZ2h0OiAwLjVlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbiAgY3Vyc29yOiBwb2ludGVyO1xcclxcbn1cXHJcXG4jdGltZWxpbmUgdyB7XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICB0b3A6IDA7XFxyXFxuICBsZWZ0OiAwLjVlbTtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbiAgY3Vyc29yOiBwb2ludGVyO1xcclxcbn1cXHJcXG4jdGltZWxpbmUgLkJpb1BlcnNvbixcXHJcXG4jdGltZWxpbmUgLm1hcnJpYWdlIHtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbn1cXHJcXG4jdGltZWxpbmUgdHIuQmlvUGVyc29uLkJpcnRoIHtcXHJcXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCBmb3Jlc3RncmVlbjtcXHJcXG59XFxyXFxuI3RpbWVsaW5lIHRyLkJpb1BlcnNvbi5EZWF0aCB7XFxyXFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxufVxcclxcbiN0aW1lbGluZVRhYmxlIHtcXHJcXG4gIHdpZHRoOiA5OCU7XFxyXFxuICBtYXJnaW46IGF1dG87XFxyXFxufVxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi53cm9uZ1BlcmlvZCB7XFxyXFxuXFx0YmFja2dyb3VuZDogI2ZmZTZlYTtcXHJcXG59XFxyXFxuXFxyXFxuLmZhbWlseUxvYy5yaWdodFBlcmlvZCB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0RBRjdBNjtcXHJcXG59XFxyXFxuXFxyXFxuLmZhbWlseUxvYzIucmlnaHRQZXJpb2Qge1xcclxcblxcdGJhY2tncm91bmQ6IGxpZ2h0Z3JlZW47XFxyXFxufVxcclxcblxcclxcbi5hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnMgZGl2LmN1cnJlbnRTZWxlY3RlZExvY2F0aW9uIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjRENEQ0RDICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcblxcclxcbmlucHV0W25hbWU9J21NYXJyaWFnZUxvY2F0aW9uJ10ge1xcclxcblxcdHdpZHRoOiAxMDAlO1xcclxcbn1cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvbG9jYXRpb25zSGVscGVyL2xvY2F0aW9uc0hlbHBlci5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyw4QkFBOEI7QUFDL0I7O0FBRUE7Q0FDQyxXQUFXO0FBQ1pcIixcInNvdXJjZXNDb250ZW50XCI6W1wiLndyb25nUGVyaW9kIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjZmZlNmVhO1xcclxcbn1cXHJcXG5cXHJcXG4uZmFtaWx5TG9jLnJpZ2h0UGVyaW9kIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjREFGN0E2O1xcclxcbn1cXHJcXG5cXHJcXG4uZmFtaWx5TG9jMi5yaWdodFBlcmlvZCB7XFxyXFxuXFx0YmFja2dyb3VuZDogbGlnaHRncmVlbjtcXHJcXG59XFxyXFxuXFxyXFxuLmF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucyBkaXYuY3VycmVudFNlbGVjdGVkTG9jYXRpb24ge1xcclxcblxcdGJhY2tncm91bmQ6ICNEQ0RDREMgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuXFxyXFxuaW5wdXRbbmFtZT0nbU1hcnJpYWdlTG9jYXRpb24nXSB7XFxyXFxuXFx0d2lkdGg6IDEwMCU7XFxyXFxufVwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIlxcclxcbnRyLnRyU2VsZWN0OmhvdmVyIHsgXFxyXFxuICBiYWNrZ3JvdW5kOiAjZmZlMjcwOzsgXFxyXFxufVxcclxcblxcclxcbnRyLnRyU2VsZWN0ZWQgeyBcXHJcXG4gIGJhY2tncm91bmQ6ICNDQ0NDQ0MgIWltcG9ydGFudDsgXFxyXFxufVxcclxcblxcclxcbjo6cGxhY2Vob2xkZXIge1xcclxcbiAgY29sb3I6ICAgICNiYmI7XFxyXFxufVxcclxcblxcclxcbi8qIGRpYWxvZyBmb3JtYXR0aW5nICAqL1xcclxcblxcclxcbmRpYWxvZyB7XFxyXFxuICBtYXgtd2lkdGg6IDYwMHB4O1xcclxcbn0gIFxcclxcblxcclxcbmRpYWxvZyBpbnB1dFt0eXBlPVxcXCJ0ZXh0XFxcIl0ge1xcclxcbiAgbWluLXdpZHRoOiAzNTBweDtcXHJcXG4gIHBhZGRpbmc6IDRweCA0cHg7XFxyXFxuICBtYXJnaW46IDJweDtcXHJcXG59XFxyXFxuZGlhbG9nIGJ1dHRvbiwgZGlhbG9nIC5idXR0b257XFxyXFxuICBwYWRkaW5nOiA4cHggMjBweDtcXHJcXG4gIG1hcmdpbjogNXB4O1xcclxcbn1cXHJcXG50ZCBidXR0b257XFxyXFxuICBwYWRkaW5nOiA1cHggNXB4O1xcclxcbiAgbWFyZ2luOiAzcHg7XFxyXFxuICBmb250LXNpemU6IDE0cHg7XFxyXFxufVxcclxcbmRpYWxvZyBzZWxlY3R7XFxyXFxuICBvdmVyZmxvdzogYXV0bztcXHJcXG4gIGJhY2tncm91bmQ6IHVuc2V0OyAgXFxyXFxufVxcclxcbmRpYWxvZyB0ZXh0YXJlYXtcXHJcXG4gIHdpZHRoOiAxMDAlO1xcclxcbiAgbWFyZ2luOiA1cHg7XFxyXFxufVxcclxcblxcclxcbi53dFBsdXNSZXF1aXJlZCB7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiBwYWxldmlvbGV0cmVkO1xcclxcbn1cXHJcXG4ud3RQbHVzUHJlZmVycmVkIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHBhbGVncmVlbjtcXHJcXG59XFxyXFxuLnd0UGx1c09wdGlvbmFsIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHBhbGVnb2xkZW5yb2Q7XFxyXFxufVxcclxcbi53dFBsdXNEZXByZWNhdGVke1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogIGxpZ2h0Z3JleTtcXHJcXG4gIHRleHQtZGVjb3JhdGlvbi1saW5lOiBsaW5lLXRocm91Z2g7XFxyXFxufVxcclxcblxcclxcbi53dFBsdXNMZWdlbmR7XFxyXFxuICBkaXNwbGF5OiBub25lO1xcclxcbiAgYmFja2dyb3VuZDogd2hpdGU7XFxyXFxuICBjb2xvcjogYmxhY2s7XFxyXFxuICB0ZXh0LWFsaWduOiBsZWZ0O1xcclxcbiAgZm9udC1zaXplOiAxNHB4O1xcclxcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICBib3R0b206IDY1cHg7XFxyXFxuICBsZWZ0OiAyNXB4O1xcclxcbiAgcGFkZGluZzogMTBweDtcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xcclxcbiAgbGluZS1oZWlnaHQ6IDM1cHg7XFxyXFxufVxcclxcblxcclxcbiN3dFBsdXNMZWdlbmRCdG46aG92ZXIgLnd0UGx1c0xlZ2VuZHtcXHJcXG4gIGRpc3BsYXk6IGJsb2NrO1xcclxcbn1cXHJcXG5cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvd3QrL3d0UGx1cy5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIjtBQUNBO0VBQ0UsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0UsY0FBYztBQUNoQjs7QUFFQSx1QkFBdUI7O0FBRXZCO0VBQ0UsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixXQUFXO0FBQ2I7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsY0FBYztFQUNkLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0UsV0FBVztFQUNYLFdBQVc7QUFDYjs7QUFFQTtFQUNFLCtCQUErQjtBQUNqQztBQUNBO0VBQ0UsMkJBQTJCO0FBQzdCO0FBQ0E7RUFDRSwrQkFBK0I7QUFDakM7QUFDQTtFQUNFLDRCQUE0QjtFQUM1QixrQ0FBa0M7QUFDcEM7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGNBQWM7QUFDaEJcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxyXFxudHIudHJTZWxlY3Q6aG92ZXIgeyBcXHJcXG4gIGJhY2tncm91bmQ6ICNmZmUyNzA7OyBcXHJcXG59XFxyXFxuXFxyXFxudHIudHJTZWxlY3RlZCB7IFxcclxcbiAgYmFja2dyb3VuZDogI0NDQ0NDQyAhaW1wb3J0YW50OyBcXHJcXG59XFxyXFxuXFxyXFxuOjpwbGFjZWhvbGRlciB7XFxyXFxuICBjb2xvcjogICAgI2JiYjtcXHJcXG59XFxyXFxuXFxyXFxuLyogZGlhbG9nIGZvcm1hdHRpbmcgICovXFxyXFxuXFxyXFxuZGlhbG9nIHtcXHJcXG4gIG1heC13aWR0aDogNjAwcHg7XFxyXFxufSAgXFxyXFxuXFxyXFxuZGlhbG9nIGlucHV0W3R5cGU9XFxcInRleHRcXFwiXSB7XFxyXFxuICBtaW4td2lkdGg6IDM1MHB4O1xcclxcbiAgcGFkZGluZzogNHB4IDRweDtcXHJcXG4gIG1hcmdpbjogMnB4O1xcclxcbn1cXHJcXG5kaWFsb2cgYnV0dG9uLCBkaWFsb2cgLmJ1dHRvbntcXHJcXG4gIHBhZGRpbmc6IDhweCAyMHB4O1xcclxcbiAgbWFyZ2luOiA1cHg7XFxyXFxufVxcclxcbnRkIGJ1dHRvbntcXHJcXG4gIHBhZGRpbmc6IDVweCA1cHg7XFxyXFxuICBtYXJnaW46IDNweDtcXHJcXG4gIGZvbnQtc2l6ZTogMTRweDtcXHJcXG59XFxyXFxuZGlhbG9nIHNlbGVjdHtcXHJcXG4gIG92ZXJmbG93OiBhdXRvO1xcclxcbiAgYmFja2dyb3VuZDogdW5zZXQ7ICBcXHJcXG59XFxyXFxuZGlhbG9nIHRleHRhcmVhe1xcclxcbiAgd2lkdGg6IDEwMCU7XFxyXFxuICBtYXJnaW46IDVweDtcXHJcXG59XFxyXFxuXFxyXFxuLnd0UGx1c1JlcXVpcmVkIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHBhbGV2aW9sZXRyZWQ7XFxyXFxufVxcclxcbi53dFBsdXNQcmVmZXJyZWQge1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogcGFsZWdyZWVuO1xcclxcbn1cXHJcXG4ud3RQbHVzT3B0aW9uYWwge1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogcGFsZWdvbGRlbnJvZDtcXHJcXG59XFxyXFxuLnd0UGx1c0RlcHJlY2F0ZWR7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAgbGlnaHRncmV5O1xcclxcbiAgdGV4dC1kZWNvcmF0aW9uLWxpbmU6IGxpbmUtdGhyb3VnaDtcXHJcXG59XFxyXFxuXFxyXFxuLnd0UGx1c0xlZ2VuZHtcXHJcXG4gIGRpc3BsYXk6IG5vbmU7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcXHJcXG4gIGNvbG9yOiBibGFjaztcXHJcXG4gIHRleHQtYWxpZ246IGxlZnQ7XFxyXFxuICBmb250LXNpemU6IDE0cHg7XFxyXFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXHJcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG4gIGJvdHRvbTogNjVweDtcXHJcXG4gIGxlZnQ6IDI1cHg7XFxyXFxuICBwYWRkaW5nOiAxMHB4O1xcclxcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XFxyXFxuICBsaW5lLWhlaWdodDogMzVweDtcXHJcXG59XFxyXFxuXFxyXFxuI3d0UGx1c0xlZ2VuZEJ0bjpob3ZlciAud3RQbHVzTGVnZW5ke1xcclxcbiAgZGlzcGxheTogYmxvY2s7XFxyXFxufVxcclxcblxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZWRpdFRvb2xiYXIuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9lZGl0VG9vbGJhci5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vYXBwc01lbnUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9hcHBzTWVudS5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZGFya01vZGUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9kYXJrTW9kZS5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZHJhZnRMaXN0LmNzc1wiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZHJhZnRMaXN0LmNzc1wiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9mYW1pbHlUaW1lbGluZS5jc3NcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2ZhbWlseVRpbWVsaW5lLmNzc1wiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9sb2NhdGlvbnNIZWxwZXIuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9sb2NhdGlvbnNIZWxwZXIuY3NzXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3d0UGx1cy5jc3NcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3d0UGx1cy5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJpbXBvcnQge2NyZWF0ZVRvcE1lbnV9IGZyb20gJy4vY29yZS9jb21tb24nO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvYWthTmFtZUxpbmtzL2FrYU5hbWVMaW5rcyc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9hcHBzTWVudS9hcHBzTWVudSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9kYXJrTW9kZS9kYXJrTW9kZSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcCc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9kcmFmdExpc3QvZHJhZnRMaXN0JztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2ZhbWlseUdyb3VwL2ZhbWlseUdyb3VwJztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2ZhbWlseVRpbWVsaW5lL2ZhbWlseVRpbWVsaW5lJztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2xvY2F0aW9uc0hlbHBlci9sb2NhdGlvbnNIZWxwZXInO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvcHJpbnRlcmZyaWVuZGx5L3ByaW50ZXJmcmllbmRseSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9yYW5kb21Qcm9maWxlL3JhbmRvbVByb2ZpbGUnO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvc291cmNlcHJldmlldy9zb3VyY2VwcmV2aWV3JztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL3NwYWNlcHJldmlldy9zcGFjZXByZXZpZXcnO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvd3QrL2NvbnRlbnRFZGl0JztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2Jpb0NoZWNrL2Jpb0NoZWNrJztcclxuaW1wb3J0ICcuL2NvcmUvZWRpdFRvb2xiYXInO1xyXG5cclxuY3JlYXRlVG9wTWVudSgpO1xyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuZXhwb3J0IGxldCBwYWdlUHJvZmlsZSA9IGZhbHNlO1xyXG5leHBvcnQgbGV0IHBhZ2VIZWxwID0gZmFsc2U7XHJcbmV4cG9ydCBsZXQgcGFnZVNwZWNpYWwgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlQ2F0ZWdvcnkgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlVGVtcGxhdGUgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlU3BhY2UgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlRzJHID0gZmFsc2U7XHJcblxyXG5pZiAoXHJcbiAgICB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUubWF0Y2goLyhcXC93aWtpXFwvKVxcd1teOl0qLVswLTldKi9nKSB8fFxyXG4gICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcP3RpdGxlXFw9XFx3W146XSstWzAtOV0rL2cpXHJcbiAgKSB7XHJcbiAgICAgIC8vIElzIGEgUHJvZmlsZSBQYWdlXHJcblx0cGFnZVByb2ZpbGUgPSB0cnVlO1xyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5tYXRjaCgvKFxcL3dpa2lcXC8pSGVscDoqL2cpKSB7XHJcblx0Ly8gSXMgYSBIZWxwIFBhZ2VcclxuXHRwYWdlSGVscCA9IHRydWU7XHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLm1hdGNoKC8oXFwvd2lraVxcLylTcGVjaWFsOiovZykpIHtcclxuXHQvLyBJcyBhIFNwZWNpYWwgUGFnZVxyXG5cdHBhZ2VTcGVjaWFsID0gdHJ1ZTtcclxufSBlbHNlIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUubWF0Y2goLyhcXC93aWtpXFwvKUNhdGVnb3J5OiovZykpIHtcclxuXHQvLyBJcyBhIENhdGVnb3J5IFBhZ2VcclxuXHRwYWdlQ2F0ZWdvcnkgPSB0cnVlO1xyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5tYXRjaCgvKFxcL3dpa2lcXC8pVGVtcGxhdGU6Ki9nKSkge1xyXG5cdC8vIElzIGEgVGVtcGxhdGUgUGFnZVxyXG5cdHBhZ2VUZW1wbGF0ZSA9IHRydWU7XHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLm1hdGNoKC8oXFwvd2lraVxcLylTcGFjZToqL2cpKSB7XHJcblx0Ly8gSXMgYSBTcGFjZSBQYWdlXHJcblx0cGFnZVNwYWNlID0gdHJ1ZTtcclxufSBlbHNlIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUubWF0Y2goL1xcL2cyZ1xcLy9nKSkge1xyXG5cdC8vIElzIGEgRzJHIHBhZ2VcclxuXHRwYWdlRzJHID0gdHJ1ZTtcclxufVxyXG5cclxuLy8gQWRkIHd0ZSBjbGFzcyB0byBib2R5IHRvIGxldCBXaWtpVHJlZSBCRUUga25vdyBub3QgdG8gYWRkIHRoZSBzYW1lIGZ1bmN0aW9uc1xyXG5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYm9keVwiKS5jbGFzc0xpc3QuYWRkKFwid3RlXCIpO1xyXG5cclxuLyoqXHJcbiAqIENyZWF0ZXMgYSBuZXcgbWVudSBpdGVtIGluIHRoZSBBcHBzIGRyb3Bkb3duIG1lbnUuXHJcbiAqXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVG9wTWVudUl0ZW0ob3B0aW9ucykge1xyXG4gIGxldCB0aXRsZSA9IG9wdGlvbnMudGl0bGU7XHJcbiAgbGV0IG5hbWUgPSBvcHRpb25zLm5hbWU7XHJcbiAgbGV0IGlkID0gb3B0aW9ucy5pZDtcclxuICBsZXQgdXJsID0gb3B0aW9ucy51cmw7XHJcblxyXG4gICQoXCIjd3RlLXRvcE1lbnVcIikuYXBwZW5kKGA8bGk+XHJcbiAgICAgICAgPGEgaWQ9XCIke2lkfVwiIGNsYXNzPVwicHVyZUNzc01lbnVpXCIgdGl0bGU9XCIke3RpdGxlfVwiPiR7bmFtZX08L2E+XHJcbiAgICA8L2xpPmApO1xyXG59XHJcblxyXG4vLyBBZGQgYSBsaW5rIHRvIHRoZSBzaG9ydCBsaXN0IG9mIGxpbmtzIGJlbG93IHRoZSB0YWJzXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVQcm9maWxlU3VibWVudUxpbmsob3B0aW9ucykge1xyXG4gICQoXCJ1bC52aWV3cy52aWV3c21cIilcclxuICAgIC5lcSgwKVxyXG4gICAgLmFwcGVuZChcclxuICAgICAgJChcclxuICAgICAgICBgPGxpIGNsYXNzPSd2aWV3c2knPjxhIHRpdGxlPScke29wdGlvbnMudGl0bGV9JyBocmVmPScke29wdGlvbnMudXJsfScgaWQ9JyR7b3B0aW9ucy5pZH0nPiR7b3B0aW9ucy50ZXh0fTwvYT48L2xpPmBcclxuICAgICAgKVxyXG4gICAgKTtcclxuICBsZXQgbGlua3MgPSAkKFwidWwudmlld3Mudmlld3NtOmZpcnN0IGxpXCIpO1xyXG4gIC8vIFJlLXNvcnQgdGhlIGxpbmtzIGludG8gYWxwaGFiZXRpY2FsIG9yZGVyXHJcbiAgbGlua3Muc29ydChmdW5jdGlvbiAoYSwgYikge1xyXG4gICAgcmV0dXJuICQoYSkudGV4dCgpLmxvY2FsZUNvbXBhcmUoJChiKS50ZXh0KCkpO1xyXG4gIH0pO1xyXG4gICQoXCJ1bC52aWV3cy52aWV3c21cIikuZXEoMCkuYXBwZW5kKGxpbmtzKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVRvcE1lbnUoKSB7XHJcbiAgY29uc3QgbmV3VUwgPSAkKFwiPHVsIGNsYXNzPSdwdXJlQ3NzTWVudScgaWQ9J3d0ZS10b3BNZW51VUwnPjwvdWw+XCIpO1xyXG4gICQoXCJ1bC5wdXJlQ3NzTWVudVwiKS5lcSgwKS5hZnRlcihuZXdVTCk7XHJcbiAgbmV3VUwuYXBwZW5kKGA8bGk+XHJcbiAgICAgICAgPGEgY2xhc3M9XCJwdXJlQ3NzTWVudWkwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuPkFwcCBGZWF0dXJlczwvc3Bhbj5cclxuICAgICAgICA8L2E+XHJcbiAgICAgICAgPHVsIGNsYXNzPVwicHVyZUNzc01lbnVtXCIgaWQ9XCJ3dGUtdG9wTWVudVwiPjwvdWw+XHJcbiAgICA8L2xpPmApO1xyXG59XHJcblxyXG4vLyBVc2VkIGluIGZhbWlseVRpbWVsaW5lLCBmYW1pbHlHcm91cCwgbG9jYXRpb25zSGVscGVyXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWxhdGl2ZXMoaWQsIGZpZWxkcyA9IFwiKlwiKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0ICQuYWpheCh7XHJcbiAgICAgIHVybDogXCJodHRwczovL2FwaS53aWtpdHJlZS5jb20vYXBpLnBocFwiLFxyXG4gICAgICBjcm9zc0RvbWFpbjogdHJ1ZSxcclxuICAgICAgeGhyRmllbGRzOiB7IHdpdGhDcmVkZW50aWFsczogdHJ1ZSB9LFxyXG4gICAgICB0eXBlOiBcIlBPU1RcIixcclxuICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgYWN0aW9uOiBcImdldFJlbGF0aXZlc1wiLFxyXG4gICAgICAgIGtleXM6IGlkLFxyXG4gICAgICAgIGZpZWxkczogZmllbGRzLFxyXG4gICAgICAgIGdldFBhcmVudHM6IDEsXHJcbiAgICAgICAgZ2V0U2libGluZ3M6IDEsXHJcbiAgICAgICAgZ2V0U3BvdXNlczogMSxcclxuICAgICAgICBnZXRDaGlsZHJlbjogMSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlc3VsdFswXS5pdGVtc1swXS5wZXJzb247XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gVXNlZCBpbiBmYW1pbHlUaW1lbGluZSwgZmFtaWx5R3JvdXAsIGxvY2F0aW9uc0hlbHBlclxyXG4vLyBNYWtlIHRoZSBmYW1pbHkgbWVtYmVyIGFycmF5cyBlYXNpZXIgdG8gaGFuZGxlXHJcbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0UmVsYXRpdmVzKHJlbCwgdGhlUmVsYXRpb24gPSBmYWxzZSkge1xyXG4gIGxldCBwZW9wbGUgPSBbXTtcclxuICBpZiAodHlwZW9mIHJlbCA9PSB1bmRlZmluZWQgfHwgcmVsID09IG51bGwpIHtcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcbiAgY29uc3QgcEtleXMgPSBPYmplY3Qua2V5cyhyZWwpO1xyXG4gIHBLZXlzLmZvckVhY2goZnVuY3Rpb24gKHBLZXkpIHtcclxuICAgIHZhciBhUGVyc29uID0gcmVsW3BLZXldO1xyXG4gICAgaWYgKHRoZVJlbGF0aW9uICE9IGZhbHNlKSB7XHJcbiAgICAgIGFQZXJzb24uUmVsYXRpb24gPSB0aGVSZWxhdGlvbjtcclxuICAgIH1cclxuICAgIHBlb3BsZS5wdXNoKGFQZXJzb24pO1xyXG4gIH0pO1xyXG4gIHJldHVybiBwZW9wbGU7XHJcbn1cclxuXHJcbi8vIFVzZWQgaW4gZmFtaWx5VGltZWxpbmUsIGZhbWlseUdyb3VwLCBsb2NhdGlvbnNIZWxwZXJcclxuZXhwb3J0IGZ1bmN0aW9uIGZhbWlseUFycmF5KHBlcnNvbikge1xyXG4gIC8vIFRoaXMgaXMgYSBwZXJzb24gZnJvbSBnZXRSZWxhdGl2ZXMoKVxyXG4gIGNvbnN0IHJlbHMgPSBbXCJQYXJlbnRzXCIsIFwiU2libGluZ3NcIiwgXCJTcG91c2VzXCIsIFwiQ2hpbGRyZW5cIl07XHJcbiAgbGV0IGZhbWlseUFyciA9IFtwZXJzb25dO1xyXG4gIHJlbHMuZm9yRWFjaChmdW5jdGlvbiAocmVsKSB7XHJcbiAgICBjb25zdCByZWxhdGlvbiA9IHJlbC5yZXBsYWNlKC9zJC8sIFwiXCIpLnJlcGxhY2UoL3JlbiQvLCBcIlwiKTtcclxuICAgIGZhbWlseUFyciA9IGZhbWlseUFyci5jb25jYXQoZXh0cmFjdFJlbGF0aXZlcyhwZXJzb25bcmVsXSwgcmVsYXRpb24pKTtcclxuICB9KTtcclxuICByZXR1cm4gZmFtaWx5QXJyO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc051bWVyaWMobikge1xyXG4gIHJldHVybiAhaXNOYU4ocGFyc2VGbG9hdChuKSkgJiYgaXNGaW5pdGUobik7XHJcbn1cclxuXHJcbi8vIENoZWNrIHRoYXQgYSB2YWx1ZSBpcyBPS1xyXG4vLyBVc2VkIGluIGZhbWlseVRpbWVsaW5lIGFuZCBmYW1pbHlHcm91cFxyXG5leHBvcnQgZnVuY3Rpb24gaXNPSyh0aGluZykge1xyXG4gIGNvbnN0IGV4Y2x1ZGVWYWx1ZXMgPSBbXHJcbiAgICBcIlwiLFxyXG4gICAgbnVsbCxcclxuICAgIFwibnVsbFwiLFxyXG4gICAgXCIwMDAwLTAwLTAwXCIsXHJcbiAgICBcInVua25vd25cIixcclxuICAgIFwiVW5rbm93blwiLFxyXG4gICAgXCJ1bmRlZmluZWRcIixcclxuICAgIHVuZGVmaW5lZCxcclxuICAgIFwiMDAwMFwiLFxyXG4gICAgXCIwXCIsXHJcbiAgICAwLFxyXG4gIF07XHJcbiAgaWYgKCFleGNsdWRlVmFsdWVzLmluY2x1ZGVzKHRoaW5nKSkge1xyXG4gICAgaWYgKGlzTnVtZXJpYyh0aGluZykpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoJC50eXBlKHRoaW5nKSA9PT0gXCJzdHJpbmdcIikge1xyXG4gICAgICAgIGNvbnN0IG5hbk1hdGNoID0gdGhpbmcubWF0Y2goL05hTi8pO1xyXG4gICAgICAgIGlmIChuYW5NYXRjaCA9PSBudWxsKSB7XHJcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgZWRpdFRvb2xiYXJDYXRlZ29yeU9wdGlvbnMgZnJvbSAnLi9lZGl0VG9vbGJhckNhdGVnb3J5T3B0aW9ucyc7XHJcbmltcG9ydCBlZGl0VG9vbGJhckdlbmVyaWNPcHRpb25zIGZyb20gJy4vZWRpdFRvb2xiYXJHZW5lcmljT3B0aW9ucyc7XHJcbmltcG9ydCBlZGl0VG9vbGJhclByb2ZpbGVPcHRpb25zIGZyb20gJy4vZWRpdFRvb2xiYXJQcm9maWxlT3B0aW9ucyc7XHJcbmltcG9ydCBlZGl0VG9vbGJhclRlbXBsYXRlT3B0aW9ucyBmcm9tICcuL2VkaXRUb29sYmFyVGVtcGxhdGVPcHRpb25zJztcclxuaW1wb3J0IGVkaXRUb29sYmFyU3BhY2VPcHRpb25zIGZyb20gJy4vZWRpdFRvb2xiYXJTcGFjZU9wdGlvbnMnO1xyXG5pbXBvcnQgJy4vZWRpdFRvb2xiYXIuY3NzJztcclxuXHJcbmxldCBlZGl0VG9vbGJhck9wdGlvbnMgPSBbXVxyXG5cclxuLyogQ29tbW9uIGV2ZW50cyBmb3IgbGlua3MgKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVkaXRUb29sYmFyV2lraShwYXJhbXMpIHtcclxuXHR3aW5kb3cub3BlbignaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvJyArIHBhcmFtcy53aWtpLCAnX2JsYW5rJylcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGVkaXRUb29sYmFyQXBwKHBhcmFtcykge1xyXG5cdGxldCB3ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaDEgPiAuY29weVdpZGdldCcpIFxyXG5cdGxldCB3aWtpdHJlZUlEID0gdy5nZXRBdHRyaWJ1dGUoJ2RhdGEtY29weS10ZXh0Jyk7XHJcblx0d2luZG93Lm9wZW4oJ2h0dHBzOi8vYXBwcy53aWtpdHJlZS5jb20vYXBwcy8nICsgcGFyYW1zLmFwcCArICc/d2lraXRyZWVpZD0nICsgd2lraXRyZWVJRCwgJ19ibGFuaycpXHJcbn1cclxuXHJcbi8qIEZpbmRzIHRoZSBjbGlja2VkIGl0ZW0gaW4gZWRpdFRvb2xiYXJPcHRpb25zICovXHJcbmZ1bmN0aW9uIGVkaXRUb29sYmFyRmluZEl0ZW0oaXRlbXMsIG5hbWUpIHtcclxuXHRpZiAoaXRlbXMgJiYgaXRlbXMubGVuZ3RoKSB7XHJcblx0XHRmb3IgKHZhciBpdGVtIG9mIGl0ZW1zKSB7XHJcblx0XHRcdGlmIChpdGVtLmJ1dHRvbikge1xyXG5cdFx0XHRcdGxldCByZXN1bHQgPSBlZGl0VG9vbGJhckZpbmRJdGVtKGl0ZW0uaXRlbXMsIG5hbWUpXHJcblx0XHRcdFx0aWYgKHJlc3VsdCkgeyByZXR1cm4gcmVzdWx0IH1cclxuXHRcdFx0fSBlbHNlIGlmIChuYW1lLnRvVXBwZXJDYXNlKCkgPT09IGl0ZW0udGl0bGUudG9VcHBlckNhc2UoKSkge1xyXG5cdFx0XHRcdHJldHVybiBpdGVtXHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0bGV0IHJlc3VsdCA9IGVkaXRUb29sYmFyRmluZEl0ZW0oaXRlbS5pdGVtcywgbmFtZSlcclxuXHRcdFx0XHRpZiAocmVzdWx0KSB7IHJldHVybiByZXN1bHQgfVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4vKiBtYWluIGV2ZW50IGhhbmRsZXIgKi9cclxuZnVuY3Rpb24gZWRpdFRvb2xiYXJFdmVudChldmVudCkge1xyXG5cdGxldCBlbGVtZW50ID0gZXZlbnQuc3JjRWxlbWVudFxyXG5cdGNvbnN0IGlkID0gZWxlbWVudC5kYXRhc2V0LmlkXHJcblx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHRsZXQgaXRlbSA9IGVkaXRUb29sYmFyRmluZEl0ZW0oZWRpdFRvb2xiYXJPcHRpb25zLCBpZCk7XHJcblx0aWYgKGl0ZW0pIHtcclxuXHRcdHJldHVybiBpdGVtLmNhbGwoaXRlbS5wYXJhbXMgfHwge30pXHJcblx0fSBlbHNlIHtcclxuXHRcdGFsZXJ0KFwiVW5rbm93biBldmVudCBcIiArIGlkKVxyXG5cdH1cclxufVxyXG5cclxuLyogY3JlYXRlcyBodG1sIG9mIHRoZSBkcm9wIGRvd24gbWVudSAqL1xyXG5mdW5jdGlvbiBlZGl0VG9vbGJhckNyZWF0ZUh0bWwoaXRlbXMsIGZlYXR1cmVFbmFibGVkLCBsZXZlbCkge1xyXG5cdGxldCByZXN1bHQgPSAnJztcclxuXHRpZiAoaXRlbXMgJiYgaXRlbXMubGVuZ3RoKSB7XHJcblx0XHRmb3IgKHZhciBpdGVtIG9mIGl0ZW1zKSB7XHJcblx0XHRcdGlmICgoIWl0ZW0uZmVhdHVyZWlkKSB8fCBmZWF0dXJlRW5hYmxlZFtpdGVtLmZlYXR1cmVpZF0pIHtcclxuXHRcdFx0XHRsZXQgcyA9IGVkaXRUb29sYmFyQ3JlYXRlSHRtbChpdGVtLml0ZW1zLCBmZWF0dXJlRW5hYmxlZCwgbGV2ZWwgKyAxKVxyXG5cdFx0XHRcdGlmIChzIHx8IGl0ZW0uY2FsbCkge1xyXG5cdFx0XHRcdFx0aWYgKGl0ZW0uYnV0dG9uKSB7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPVxyXG5cdFx0XHRcdFx0XHRcdCc8ZGl2IGlkPVwiZWRpdFRvb2xiYXJEaXZcIj4nICtcclxuXHRcdFx0XHRcdFx0XHQnPHAgaWQ9XCJlZGl0VG9vbGJhckJ1dHRvblwiPicgKyBpdGVtLmJ1dHRvbiArICc8L3A+JyArXHJcblx0XHRcdFx0XHRcdFx0Ly8gJzxpbWcgc3JjPVwiL3Bob3RvLnBocC84Lzg5L1dpa2lUcmVlX0ltYWdlcy0yMi5wbmdcIiBoZWlnaHQ9XCIyMlwiIGlkPVwiZWRpdFRvb2xiYXJCdXR0b25cIiAvPicgKyBcclxuXHRcdFx0XHRcdFx0XHRzICtcclxuXHRcdFx0XHRcdFx0XHQnPC9kaXY+JztcclxuXHRcdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPSAnPGxpPjxhICdcclxuXHRcdFx0XHRcdFx0cmVzdWx0ICs9IChpdGVtLmhpbnQgPyAndGl0bGU9IFwiJyArIGl0ZW0uaGludCArICdcIicgOiBcIlwiKTtcclxuXHRcdFx0XHRcdFx0cmVzdWx0ICs9ICdocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApO1wiIGNsYXNzPVwiZWRpdFRvb2xiYXJDbGlja1wiIGRhdGEtaWQ9XCInICsgaXRlbS50aXRsZSArICdcIic7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPSAnPicgKyBpdGVtLnRpdGxlICsgKGl0ZW0uaXRlbXMgPyBcIiAmZ3Q7Jmd0O1wiIDogXCJcIikgKyBcIjwvYT5cIjtcclxuXHRcdFx0XHRcdFx0cmVzdWx0ICs9IHM7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPSAnPC9saT4nO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0aWYgKChsZXZlbCA+PSAwKSAmJiAocmVzdWx0KSlcclxuXHRcdFx0cmVzdWx0ID0gJzx1bCBjbGFzcz1cImVkaXRUb29sYmFyTWVudScgKyBsZXZlbCArICdcIj4nICsgcmVzdWx0ICsgJzwvdWw+JztcclxuXHR9XHJcblx0cmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyogY3JlYXRlcyBtZW51IG5leHQgdG8gdGhlIHRvb2xiYXIgICovXHJcbmZ1bmN0aW9uIGVkaXRUb29sYmFyQ3JlYXRlKG9wdGlvbnMpIHtcclxuXHRlZGl0VG9vbGJhck9wdGlvbnMgPSBvcHRpb25zXHJcblx0Y2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQobnVsbCwgKGZlYXR1cmVFbmFibGVkKSA9PiB7XHJcblx0XHR2YXIgbWVudUhUTUwgPSBlZGl0VG9vbGJhckNyZWF0ZUh0bWwoZWRpdFRvb2xiYXJPcHRpb25zLCBmZWF0dXJlRW5hYmxlZCwgLTEpO1xyXG5cdFx0ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0b29sYmFyXCIpLmluc2VydEFkamFjZW50SFRNTCgnYWZ0ZXJlbmQnLCAnPGRpdiBpZD1cImVkaXRUb29sYmFyRXh0XCI+JyArIG1lbnVIVE1MICsgJzwvZGl2PicpXHJcblx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdhLmVkaXRUb29sYmFyQ2xpY2snKS5mb3JFYWNoKGkgPT4gaS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGV2ZW50ID0+IGVkaXRUb29sYmFyRXZlbnQoZXZlbnQpKSlcclxuXHR9KVxyXG59XHJcblxyXG5pZiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVNwZWNpYWw6RWRpdFBlcnNvbiYuKi9nKSkge1xyXG5cdGVkaXRUb29sYmFyQ3JlYXRlKGVkaXRUb29sYmFyUHJvZmlsZU9wdGlvbnMpO1xyXG5cclxufSBlbHNlIGlmICh3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9Q2F0ZWdvcnk6LiomYWN0aW9uPWVkaXQuKi9nKSB8fFxyXG4gICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKC9cXC9pbmRleC5waHBcXD90aXRsZT1DYXRlZ29yeTouKiZhY3Rpb249c3VibWl0LiovZykpIHtcclxuXHRlZGl0VG9vbGJhckNyZWF0ZShlZGl0VG9vbGJhckNhdGVnb3J5T3B0aW9ucyk7XHJcblxyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKC9cXC9pbmRleC5waHBcXD90aXRsZT1UZW1wbGF0ZTouKiZhY3Rpb249ZWRpdC4qL2cpIHx8XHJcbiAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVRlbXBsYXRlOi4qJmFjdGlvbj1zdWJtaXQuKi9nKSkge1xyXG5cdGVkaXRUb29sYmFyQ3JlYXRlKGVkaXRUb29sYmFyVGVtcGxhdGVPcHRpb25zKTtcclxuXHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVNwYWNlOi4qJmFjdGlvbj1lZGl0LiovZykgfHxcclxuXHRcdCAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKC9cXC9pbmRleC5waHBcXD90aXRsZT1TcGFjZTouKiZhY3Rpb249c3VibWl0LiovZykpIHtcclxuXHRlZGl0VG9vbGJhckNyZWF0ZShlZGl0VG9vbGJhclNwYWNlT3B0aW9ucyk7XHJcblxyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKC9cXC9pbmRleC5waHBcXD90aXRsZT0uKiZhY3Rpb249ZWRpdC4qL2cpIHx8XHJcbiAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPS4qJmFjdGlvbj1zdWJtaXQuKi9nKSkge1xyXG5cdGVkaXRUb29sYmFyQ3JlYXRlKGVkaXRUb29sYmFyR2VuZXJpY09wdGlvbnMpO1xyXG59XHJcbiIsImltcG9ydCB7d3RQbHVzfSBmcm9tICcuLi9mZWF0dXJlcy93dCsvY29udGVudEVkaXQnO1xyXG5pbXBvcnQge2VkaXRUb29sYmFyQXBwLCBlZGl0VG9vbGJhcldpa2l9IGZyb20gJy4vZWRpdFRvb2xiYXInO1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIlRlbXBsYXRlc1wiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRWRpdCBUZW1wbGF0ZVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiRWRpdFRlbXBsYXRlXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQWRkIGFueSB0ZW1wbGF0ZVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQWRkVGVtcGxhdGVcIiB9IH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aXRsZTogXCJDYXRlZ29yeSB0ZW1wbGF0ZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBa2FcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQWthXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlRvcCBMZXZlbFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJUb3AgTGV2ZWxcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiR2VvZ3JhcGhpYyBMb2NhdGlvblwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJHZW9ncmFwaGljIExvY2F0aW9uXCIgfSB9XHJcblx0XHRcdFx0XVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7IFwiZmVhdHVyZWlkXCI6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkZvcm1hdCBUZW1wbGF0ZSBQYXJhbXNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9Gb3JtYXRcIiB9IH1cclxuXHRcdF1cclxuXHR9LFxyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJDSUJcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkNlbWV0ZXJ5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBDZW1ldGVyeVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkxvY2F0aW9uXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBMb2NhdGlvblwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBhbnkgQ0lCXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiLCBkYXRhOiBcIkNhdGVnb3J5SW5mb0JveFwiIH0gfSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIkNlbWV0ZXJpZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJDZW1ldGVyeVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggQ2VtZXRlcnlcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQ2VtZXRlcnkgR3JvdXBcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IENlbWV0ZXJ5R3JvdXBcIiB9IH1cclxuXHRcdFx0XHRdXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aXRsZTogXCJSZWxpZ2lvblwiLCBpdGVtczogW1xyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlJlbGlnaW91cyBJbnN0aXR1dGlvbiBHcm91cFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggUmVsaWdpb3VzSW5zdGl0dXRpb25Hcm91cFwiIH0gfVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIk1haW50ZW5hbmNlXCIsIGl0ZW1zOiBbXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiTWFpbnRlbmFuY2VcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IE1haW50ZW5hbmNlXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIk5lZWRzXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBOZWVkc1wiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJOZWVkcyBHRURDT00gQ2xlYW51cFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggTmVlZHNHRURDT01DbGVhbnVwXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlVuY29ubmVjdGVkXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBVbmNvbm5lY3RlZFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJVbnNvdXJjZWRcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IFVuc291cmNlZFwiIH0gfVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIk90aGVyc1wiLCBpdGVtczogW1xyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkxvY2F0aW9uXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBMb2NhdGlvblwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJNaWdyYXRpb25cIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IE1pZ3JhdGlvblwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJPbmUgTmFtZSBTdHVkeVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggT25lTmFtZVN0dWR5XCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIk9uZSBQbGFjZSBTdHVkeVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggT25lUGxhY2VTdHVkeVwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJDYXRlZ29yeUluZm9Cb3hcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94XCIgfSB9XHJcblx0XHRcdFx0XVxyXG5cdFx0XHR9XHJcblx0XHRdXHJcblx0fSxcclxuXHR7XHJcblx0XHRidXR0b246IFwiQ29udGVudFwiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQXV0b21hdGVkIGNvcnJlY3Rpb25zXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBdXRvVXBkYXRlXCIgfSB9LFxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIkVkaXRCT1RcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlJlbmFtZSBDYXRlZ29yeVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJSZW5hbWUgQ2F0ZWdvcnlcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJNZXJnZSBDYXRlZ29yeVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJNZXJnZSBDYXRlZ29yeVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkRlbGV0ZSBDYXRlZ29yeVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJEZWxldGUgQ2F0ZWdvcnlcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJDb25maXJtIGZvciBFZGl0Qk9UXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJFZGl0Qk9UQ29uZmlybVwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIk1pc2NcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkhlbHBcIiwgY2FsbDogZWRpdFRvb2xiYXJXaWtpLCBwYXJhbXM6IHsgd2lraTogXCJTcGFjZTpXaWtpVHJlZV9QbHVzX0Nocm9tZV9FeHRlbnNpb24jT25fQ2F0ZWdvcnlfcGFnZXNcIiB9IH1cclxuXHRcdF1cclxuXHR9LFxyXG5dO1xyXG4iLCJpbXBvcnQge3d0UGx1c30gZnJvbSAnLi4vZmVhdHVyZXMvd3QrL2NvbnRlbnRFZGl0JztcclxuaW1wb3J0IHtlZGl0VG9vbGJhckFwcCwgZWRpdFRvb2xiYXJXaWtpfSBmcm9tICcuL2VkaXRUb29sYmFyJztcclxuZXhwb3J0IGRlZmF1bHQgW1xyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJUZW1wbGF0ZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkVkaXQgVGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkVkaXRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBhbnkgdGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRm9ybWF0IFRlbXBsYXRlIFBhcmFtc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b0Zvcm1hdFwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIkNvbnRlbnRcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkF1dG9tYXRlZCBjb3JyZWN0aW9uc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b1VwZGF0ZVwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIk1pc2NcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkhlbHBcIiwgY2FsbDogZWRpdFRvb2xiYXJXaWtpLCBwYXJhbXM6IHsgd2lraTogXCJTcGFjZTpXaWtpVHJlZV9QbHVzX0Nocm9tZV9FeHRlbnNpb24jT25fT3RoZXJfcGFnZXNcIiB9IH1cclxuXHRcdF1cclxuXHR9XHJcbl07XHJcbiIsImltcG9ydCB7d3RQbHVzfSBmcm9tICcuLi9mZWF0dXJlcy93dCsvY29udGVudEVkaXQnO1xyXG5pbXBvcnQge2VkaXRUb29sYmFyQXBwLCBlZGl0VG9vbGJhcldpa2l9IGZyb20gJy4vZWRpdFRvb2xiYXInO1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIlNvdXJjZXNcIixcclxuXHRcdGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJQYXN0ZSBzb3VyY2VzXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJQYXN0ZVNvdXJjZVwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sIHtcclxuXHRcdGJ1dHRvbjogXCJUZW1wbGF0ZXNcIixcclxuXHRcdGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJFZGl0IFRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJFZGl0VGVtcGxhdGVcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgYW55IHRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBQcm9qZWN0IEJveFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQWRkVGVtcGxhdGVcIiwgZGF0YTogXCJQcm9qZWN0IEJveFwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBTdGlja2VyXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiLCBkYXRhOiBcIlN0aWNrZXJcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgUmVzZWFyY2ggTm90ZSBCb3hcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIsIGRhdGE6IFwiUHJvZmlsZSBCb3hcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgRXh0ZXJuYWwgbGlua3NcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIsIGRhdGE6IFwiRXh0ZXJuYWwgTGlua1wiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkZvcm1hdCBUZW1wbGF0ZSBQYXJhbXNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9Gb3JtYXRcIiB9IH1cclxuXHRcdF1cclxuXHR9LCB7XHJcblx0XHRidXR0b246IFwiQmlvZ3JhcGh5XCIsXHJcblx0XHRpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQXV0b21hdGVkIGNvcnJlY3Rpb25zXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBdXRvVXBkYXRlXCIgfSB9XHJcblx0XHRdXHJcblx0fSwge1xyXG5cdFx0YnV0dG9uOiBcIk1pc2NcIixcclxuXHRcdGl0ZW1zOiBbXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aXRsZTogXCJXaWtpVHJlZSBBcHBzXCIsXHJcblx0XHRcdFx0aXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJETkEgQ29uZmlybWF0aW9uXCIsIGhpbnQ6IFwiRE5BIENvbmZpcm1hdGlvbiBieSBHcmVnIENsYXJrZVwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJjbGFya2UxMTAwNy9ETkFjb25mLnBocFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBbmNlc3RyeSBDaXRhdGlvblwiLCBoaW50OiBcIkFuY2VzdHJ5IENpdGF0aW9uIGJ5IEdyZWcgQ2xhcmtlXCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcImNsYXJrZTExMDA3L2FuY2l0ZS5waHBcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRHJvdWluIENpdGVyXCIsIGhpbnQ6IFwiRHJvdWluIENpdGVyIGJ5IEdyZWcgQ2xhcmtlXCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcImNsYXJrZTExMDA3L2Ryb3VpbkNpdGUucGhwXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlN1cm5hbWVzIEdlbmVyYXRvclwiLCBoaW50OiBcIlN1cm5hbWVzIEdlbmVyYXRvciBieSBHcmVnIENsYXJrZVwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJjbGFya2UxMTAwNy9zdXJuYW1lcy5waHBcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiUmlrc2Fya2l2ZXQgU1ZBUiBzb3VyY2VzXCIsIGhpbnQ6IFwiUmlrc2Fya2l2ZXQgU1ZBUiBzb3VyY2VzIGJ5IE1hcmlhIEx1bmRob2xtXCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcImx1bmRob2xtMjQvcmVmLW1ha2luZy9yYS1yZWYucGhwXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFya2l2IERpZ2l0YWwgc291cmNlc1wiLCBoaW50OiBcIkFya2l2IERpZ2l0YWwgc291cmNlcyBieSBNYXJpYSBMdW5kaG9sbVwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJsdW5kaG9sbTI0L3JlZi1tYWtpbmcvYWQtcmVmLnBocFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJTdmVyaWdlcyBEw7ZkYm9rIHNvdXJjZXNcIiwgaGludDogXCJTdmVyaWdlcyBEw7ZkYm9rIHNvdXJjZXMgYnkgTWFyaWEgTHVuZGhvbG1cIiwgY2FsbDogZWRpdFRvb2xiYXJBcHAsIHBhcmFtczogeyBhcHA6IFwibHVuZGhvbG0yNC9yZWYtbWFraW5nL3NkYi1yZWYucGhwXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkJpb2dyYXBoeSBHZW5lcmF0b3JcIiwgaGludDogXCJCaW9ncmFwaHkgR2VuZXJhdG9yIChmb3IgT3BlbiBwci4pIGJ5IEdyZWcgU2hpcGxleVwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJzaGlwbGV5MTIyMy9CaW8uaHRtbFwiIH0gfSxcclxuXHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0dGl0bGU6IFwiT3RoZXIgQXBwc1wiLFxyXG5cdFx0XHRcdFx0XHRpdGVtczogW1xyXG5cdFx0XHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJCaW8gQ2hlY2tcIiwgaGludDogXCJCaW8gQ2hlY2sgYnkgS2F5IEtuaWdodFwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJzYW5kczE4NjUvYmlvY2hlY2svXCIgfSB9LFxyXG5cdFx0XHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJGYW4gQ2hhcnRcIiwgaGludDogXCJGYW4gQ2hhcnQgYnkgR3JlZyBDbGFya2VcIiwgY2FsbDogZWRpdFRvb2xiYXJBcHAsIHBhcmFtczogeyBhcHA6IFwiY2xhcmtlMTEwMDcvZmFuLnBocFwiIH0gfVxyXG5cdFx0XHRcdFx0XHRdXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiSGVscFwiLCBjYWxsOiBlZGl0VG9vbGJhcldpa2ksIHBhcmFtczogeyB3aWtpOiBcIlNwYWNlOldpa2lUcmVlX1BsdXNfQ2hyb21lX0V4dGVuc2lvbiNPbl9Qcm9maWxlX3BhZ2VzXCIgfSB9XHJcblx0XHRdXHJcblx0fVxyXG5dO1xyXG4iLCJpbXBvcnQge3d0UGx1c30gZnJvbSAnLi4vZmVhdHVyZXMvd3QrL2NvbnRlbnRFZGl0JztcclxuaW1wb3J0IHtlZGl0VG9vbGJhckFwcCwgZWRpdFRvb2xiYXJXaWtpfSBmcm9tICcuL2VkaXRUb29sYmFyJztcclxuZXhwb3J0IGRlZmF1bHQgW1xyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJUZW1wbGF0ZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkVkaXQgVGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkVkaXRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBhbnkgdGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRm9ybWF0IFRlbXBsYXRlIFBhcmFtc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b0Zvcm1hdFwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIkNvbnRlbnRcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkF1dG9tYXRlZCBjb3JyZWN0aW9uc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b1VwZGF0ZVwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIk1pc2NcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkhlbHBcIiwgY2FsbDogZWRpdFRvb2xiYXJXaWtpLCBwYXJhbXM6IHsgd2lraTogXCJTcGFjZTpXaWtpVHJlZV9QbHVzX0Nocm9tZV9FeHRlbnNpb24jT25fT3RoZXJfcGFnZXNcIiB9IH1cclxuXHRcdF1cclxuXHR9XHJcbl07XHJcbiIsImltcG9ydCB7d3RQbHVzfSBmcm9tICcuLi9mZWF0dXJlcy93dCsvY29udGVudEVkaXQnO1xyXG5pbXBvcnQge2VkaXRUb29sYmFyQXBwLCBlZGl0VG9vbGJhcldpa2l9IGZyb20gJy4vZWRpdFRvb2xiYXInO1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIlRlbXBsYXRlc1wiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRm9ybWF0IFBhcmFtZXRlcnNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9Gb3JtYXRcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJFZGl0IFRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJFZGl0VGVtcGxhdGVcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgVGVtcGxhdGVQYXJhbVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJUZW1wbGF0ZVBhcmFtXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQWRkIERvY3VtZW50YXRpb25cIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiRG9jdW1lbnRhdGlvblwiIH0gfSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIkFkZCBCYXNlIFRlbXBsYXRlc1wiLCBpdGVtczogW1xyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlByb2plY3QgQm94XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIlByb2plY3QgQm94XCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlN0aWNrZXJcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiU3RpY2tlclwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJSZXNlYXJjaCBOb3RlIEJveFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJSZXNlYXJjaCBOb3RlIEJveFwiIH0gfVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIkFkZCBPdGhlciBUZW1wbGF0ZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJQcm9qZWN0IEJveCBJbnN0cnVjdGlvbnNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiUHJvamVjdCBCb3ggSW5zdHJ1Y3Rpb25zXCIgfSB9XHJcblx0XHRcdFx0XVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQWRkIGFueSB0ZW1wbGF0ZVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQWRkVGVtcGxhdGVcIiB9IH1cclxuXHRcdF1cclxuXHR9LFxyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJNaXNjXCIsIGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJIZWxwXCIsIGNhbGw6IGVkaXRUb29sYmFyV2lraSwgcGFyYW1zOiB7IHdpa2k6IFwiU3BhY2U6V2lraVRyZWVfUGx1c19DaHJvbWVfRXh0ZW5zaW9uI09uX1RlbXBsYXRlX3BhZ2VzXCIgfSB9XHJcblx0XHRdXHJcblx0fVxyXG5dO1xyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQge3BhZ2VQcm9maWxlfSBmcm9tICcuLi8uLi9jb3JlL2NvbW1vbic7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBha2FOYW1lcygpe1xyXG4vLyBNYWtlIEFLQSBsYXN0IG5hbWVzIGNsaWNrYWJsZVxyXG4gICAgaWYgKCQoXCJib2R5LnByb2ZpbGVcIikubGVuZ3RoKXtcclxuICAgICAgICBjb25zdCBuYW1lQml0ID0gJChcIi5WSVRBTFNcIikuZXEoMCkuZmluZChcIi5sYXJnZVwiKTtcclxuICAgICAgICBjb25zdCBuYW1lVGV4dCA9IG5hbWVCaXQudGV4dCgpO1xyXG4gICAgICAgIGlmIChuYW1lVGV4dC5tYXRjaChcImFrYSBcIikpe1xyXG4gICAgICAgICAgICBjb25zdCBzdHJvbmdzID0gbmFtZUJpdC5maW5kKFwic3Ryb25nXCIpO1xyXG4gICAgICAgICAgICBjb25zdCBsYXN0U3Ryb25nID0gc3Ryb25ncy5lcShzdHJvbmdzLmxlbmd0aC0xKTtcclxuICAgICAgICAgICAgY29uc3QgYWthVGV4dCA9IGxhc3RTdHJvbmcudGV4dCgpO1xyXG4gICAgICAgICAgICBjb25zdCBvQWthTmFtZXMgPSBha2FUZXh0LnNwbGl0KFwiLFwiKTtcclxuICAgICAgICAgICAgbGFzdFN0cm9uZy50ZXh0KFwiXCIpO1xyXG4gICAgICAgICAgICBvQWthTmFtZXMuZm9yRWFjaChmdW5jdGlvbihha2FOYW1lLGkpe1xyXG4gICAgICAgICAgICAgICAgJChcIjxhIGhyZWY9J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9nZW5lYWxvZ3kvXCIrYWthTmFtZS50cmltKCkrXCInPlwiK2FrYU5hbWUudHJpbSgpK1wiPC9hPlwiKS5hcHBlbmRUbyhsYXN0U3Ryb25nKTtcclxuICAgICAgICAgICAgICAgIGlmIChpKzE8b0FrYU5hbWVzLmxlbmd0aCl7XHJcbiAgICAgICAgICAgICAgICAgICAgJChcIjxzcGFuPiwgPC9zcGFuPlwiKS5hcHBlbmRUbyhsYXN0U3Ryb25nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCdha2FOYW1lTGlua3MnLCAocmVzdWx0KSA9PiB7XHJcblx0aWYgKHJlc3VsdC5ha2FOYW1lTGlua3MgJiYgcGFnZVByb2ZpbGUgPT0gdHJ1ZSkgeyBcclxuICAgICAgICBha2FOYW1lcygpO1xyXG4gICAgfVxyXG59KSIsImltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCBDb29raWVzIGZyb20gJ2pzLWNvb2tpZSc7XHJcbmltcG9ydCAnLi9hcHBzTWVudS5jc3MnO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoJ2FwcHNNZW51JywgKHJlc3VsdCkgPT4ge1xyXG5cdGlmIChyZXN1bHQuYXBwc01lbnUpIHtcclxuXHRcdC8vIEFkZCBhIG1lbnUgaWYgV2lraVRyZWUgQkVFIGhhc24ndCBhbHJlYWR5IGRvbmUgc28uIFxyXG5cdFx0aWYgKCQoXCIjYXBwc1N1Yk1lbnVcIikubGVuZ3RoPT0wKXtcclxuICAgICAgICAgICAgYWRkQXBwc01lbnUoKTtcclxuICAgICAgICB9XHJcblx0fVxyXG59KTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldEFwcHNNZW51KCl7XHJcblx0dHJ5e1xyXG5cdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgJC5hamF4KHt1cmw6IFwiaHR0cHM6Ly93aWtpdHJlZWJlZS5jb20vQkVFLnBocD9xPWFwcHNfbWVudVwiLCBjcm9zc0RvbWFpbjogdHJ1ZSwgdHlwZTogJ1BPU1QnLCBkYXRhVHlwZTogJ2pzb24nfSlcclxuXHRcdHJldHVybiByZXN1bHQuYXBwc19tZW51O1xyXG5cdH0gY2F0Y2ggKGVycm9yKSB7XHJcblx0XHRjb25zb2xlLmVycm9yKGVycm9yKTtcclxuXHR9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGF0dGFjaEFwcHNNZW51KG1lbnUpe1xyXG5cdGNvbnN0IG1XVElEID0gQ29va2llcy5nZXQoXCJ3aWtpdHJlZV93dGJfVXNlck5hbWVcIik7XHJcblx0Y29uc3QgYXBwc0xpc3QgPSAkKFwiPG1lbnUgY2xhc3M9J3N1Yk1lbnUnIGlkPSdhcHBzU3ViTWVudSc+PC9tZW51PlwiKTtcclxuXHRtZW51LmZvckVhY2goZnVuY3Rpb24oYXBwKXtcclxuXHRcdGNvbnN0IGFwcHNMaSA9ICQoXCI8YSBjbGFzcz0ncHVyZUNzc01lbnVpJyBocmVmPSdcIithcHAuVVJMLnJlcGxhY2UoL21XVElELyxtV1RJRCkrXCInPlwiK2FwcC50aXRsZStcIjwvYT5cIik7XHJcblx0XHRhcHBzTGkuYXBwZW5kVG8oYXBwc0xpc3QpO1xyXG5cdH0pXHJcblx0YXBwc0xpc3QuYXBwZW5kVG8oJChcInVsLnB1cmVDc3NNZW51LnB1cmVDc3NNZW51bSBhW2hyZWY9Jy93aWtpL0hlbHA6QXBwcyddXCIpLnBhcmVudCgpKTtcclxuXHRjb25zdCBhcHBzTGluayA9ICQoXCJ1bC5wdXJlQ3NzTWVudS5wdXJlQ3NzTWVudW0gYVtocmVmPScvd2lraS9IZWxwOkFwcHMnXVwiKS5wYXJlbnQoKTtcclxuXHQkKFwidWwucHVyZUNzc01lbnUucHVyZUNzc01lbnVtIGFbaHJlZj0nL3dpa2kvSGVscDpBcHBzJ11cIikudGV4dChcIsKrIEFwcHNcIik7XHJcblx0YXBwc0xpbmsuaG92ZXIoZnVuY3Rpb24oKXthcHBzTGlzdC5zaG93KCk7fSxmdW5jdGlvbigpe2FwcHNMaXN0LmhpZGUoKTt9KVxyXG59XHJcblxyXG5mdW5jdGlvbiBhZGRBcHBzTWVudSgpe1x0XHJcblx0Y29uc3QgZCA9IG5ldyBEYXRlKCk7XHJcblx0bGV0IGRheSA9IGQuZ2V0VVRDRGF0ZSgpO1xyXG5cdGxldCBnZXRNZW51ID0gZmFsc2U7XHJcblx0Ly8gU3RvcmUgdGhlIGRhdGUgaWYgaXQgaGFzbid0IGJlZW4gc3RvcmVkXHJcblx0aWYgKCFsb2NhbFN0b3JhZ2UuYXBwc01lbnVDaGVjayl7XHJcblx0XHRsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImFwcHNNZW51Q2hlY2tcIixkYXkpO1xyXG5cdH1cclxuXHQvLyBTdG9yZSB0aGUgZGF0ZSBhbmQgdXBkYXRlIHRoZSBtZW51IGlmIGl0J3MgYSBuZXcgZGF5LlxyXG5cdGVsc2UgaWYgKGRheSE9bG9jYWxTdG9yYWdlLmFwcHNNZW51Q2hlY2spe1xyXG5cdFx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJhcHBzTWVudUNoZWNrXCIsZGF5KTtcclxuXHRcdGdldE1lbnUgPSB0cnVlO1xyXG5cdH1cclxuXHRpZiAoIWxvY2FsU3RvcmFnZS5hcHBzTWVudSB8fCBnZXRNZW51ID09IHRydWUpe1xyXG5cdFx0Z2V0QXBwc01lbnUoKS50aGVuKChtZW51KT0+e1xyXG5cdFx0XHRhdHRhY2hBcHBzTWVudShtZW51KTtcclxuXHRcdFx0Ly8gU3RvcmUgdGhlIG1lbnUuXHJcblx0XHRcdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYXBwc01lbnVcIixKU09OLnN0cmluZ2lmeShtZW51KSk7XHJcblx0XHR9KVxyXG5cdH0gZWxzZSB7ICAvLyBPciB1c2UgdGhlIHN0b3JlZCBtZW51LlxyXG5cdFx0YXR0YWNoQXBwc01lbnUoSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuYXBwc01lbnUpKTtcclxuXHR9XHJcbn0iLCIvKlxyXG5UaGUgTUlUIExpY2Vuc2UgKE1JVClcclxuXHJcbkNvcHlyaWdodCAoYykgMjAyMiBLYXRocnluIEogS25pZ2h0XHJcblxyXG5QZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mXHJcbnRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW5cclxudGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0b1xyXG51c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZlxyXG50aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sXHJcbnN1YmplY3QgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb25zOlxyXG5cclxuVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4gYWxsXHJcbmNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXHJcblxyXG5USEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SXHJcbklNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTXHJcbkZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUlxyXG5DT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVJcclxuSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU5cclxuQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cclxuKi9cclxuLyoqXHJcbiAqIFBhcnNlIGFuZCB2YWxpZGF0ZSBhIFdpa2lUcmVlIGJpb2dyYXBoeVxyXG4gKiBHYXRoZXIgaW5mb3JtYXRpb24gYWJvdXQgc3R5bGUgYW5kIHRoZSBwYXJ0cyBuZWVkZWQgdG8gdmFsaWRhdGVcclxuICogYWxvbmcgd2l0aCBpbmZvcm1hdGlvbiBhYm91dCB0aGUgYmlvIGFuZCBtZXRob2RzIHRvIHBhcnNlIGFuZCB2YWxpZGF0ZVxyXG4gKi9cclxuaW1wb3J0IHsgQmlvZ3JhcGh5UmVzdWx0cyB9IGZyb20gXCIuL0Jpb2dyYXBoeVJlc3VsdHMuanNcIlxyXG5leHBvcnQgY2xhc3MgQmlvZ3JhcGh5IGV4dGVuZHMgQmlvZ3JhcGh5UmVzdWx0cyB7XHJcblxyXG4gIHNvdXJjZVJ1bGVzID0gbnVsbDsgICAgICAgICAgICAgLy8gcnVsZXMgZm9yIHRlc3Rpbmcgc291cmNlc1xyXG4gIGJpb0xpbmVzID0gKFtdKTsgICAgICAgICAgICAgICAgLy8gbGluZXMgaW4gdGhlIGJpb2dyYXBoeVxyXG4gIGJpb0hlYWRpbmdzRm91bmQgPSBbXTsgICAgICAgICAgLy8gYmlvZ3JhcGh5IGhlYWRpbmdzIGZvdW5kIChtdWx0aSBsYW5nKVxyXG4gIHNvdXJjZXNIZWFkaW5nc0ZvdW5kID0gW107ICAgICAgLy8gc291cmNlcyBoZWFkaW5ncyBmb3VuZCAobXVsdGkgbGFuZylcclxuICBpbnZhbGlkU3BhblRhcmdldExpc3QgPSAoW10pOyAgIC8vIHRhcmdldCBvZiBhIHNwYW4gdGhhdCBhcmUgbm90IHZhbGlkXHJcbiAgcmVmU3RyaW5nTGlzdCA9IChbXSk7ICAgICAgICAgICAvLyBhbGwgdGhlIDxyZWY+IHRoaXMgPC9yZWY+IGxpbmVzXHJcbiAgbmFtZWRSZWZTdHJpbmdMaXN0ID0gKFtdKTsgICAgICAvLyBhbGwgdGhlIDxyZWY+IHdpdGggbmFtZXNcclxuXHJcbiAgYmlvSW5wdXRTdHJpbmcgPSBcIlwiOyAgICAgICAgICAgIC8vIGlucHV0IHN0cmluZyBtYXkgYmUgbW9kaWZpZWQgYnkgcHJvY2Vzc2luZ1xyXG4gIGJpb2dyYXBoeUluZGV4ID0gLTE7ICAgICAgICAgICAgLy8gZmlyc3QgbGluZSBvZiBiaW9ncmFwaHlcclxuICBhY2tub3dsZWRnZW1lbnRzRW5kSW5kZXggPSAtMTsgIC8vIG5leHQgaGVhZGluZyBvciBlbmQgb2YgYmlvXHJcbiAgc291cmNlc0luZGV4ID0gLTE7ICAgICAgICAgICAgICAvLyBmaXJzdCBsaW5lIG9mIHNvdXJjZXNcclxuICByZWZlcmVuY2VzSW5kZXggPSAtMTsgICAgICAgICAgIC8vIGluZGV4IGludG8gdmVjdG9yIGZvciA8cmVmZXJlbmNlcyB0YWdcclxuICBhY2tub3dsZWRnZW1lbnRzSW5kZXggPSAtMTsgICAgIC8vIGZpcnN0IGxpbmUgb2YgYWNrbm93bGVkZ2VtZW50c1xyXG4gIHJlc2VhcmNoTm90ZXNJbmRleCA9IC0xOyAgICAgICAgLy8gZmlyc3QgbGluZSBvZiByZXNlYXJjaE5vdGVzXHJcbiAgcmVzZWFyY2hOb3Rlc0VuZEluZGV4ID0gLTE7ICAgICAvLyBsYXN0IGxpbmUgb2YgcmVzZWFyY2ggbm90ZXMgaXMgbmV4dCBoZWFkaW5nXHJcblxyXG4gIGlzUHJlMTcwMCA9IGZhbHNlOyAgICAgICAgICAgICAgLy8gaXMgdGhpcyBhIHByZTE3MDAgcHJvZmlsZVxyXG4gIGlzUHJlMTUwMCA9IGZhbHNlOyAgICAgICAgICAgICAgLy8gaXMgdGhpcyBhIHByZTE1MDAgcHJvZmlsZVxyXG4gIHRvb09sZFRvUmVtZW1iZXIgPSBmYWxzZTsgICAgICAgLy8gaXMgdGhpcyBwcm9maWxlIHRvIG9sZCB0byByZW1lbWJlclxyXG4gIHRyZWF0QXNQcmUxNzAwID0gZmFsc2U7ICAgICAgICAgLy8gdHJlYXQgYWxsIHByb2ZpbGVzIGFzIHByZTE3MDBcclxuXHJcbiAgc3RhdGljIFNUQVJUX09GX0NPTU1FTlQgPSBcIjwhLS1cIjtcclxuICBzdGF0aWMgRU5EX09GX0NPTU1FTlQgPSBcIi0tPlwiO1xyXG4gIHN0YXRpYyBTVEFSVF9PRl9CUiA9IFwiPGJyXCI7XHJcbiAgc3RhdGljIFJFRl9TVEFSVCA9IFwiPHJlZj5cIjtcclxuICBzdGF0aWMgUkVGX0VORCA9IFwiPC9yZWY+XCI7XHJcbiAgc3RhdGljIEVORF9CUkFDS0VUID0gXCI+XCI7XHJcbiAgc3RhdGljIFJFRl9TVEFSVF9OQU1FRCA9IFwiPHJlZiBuYW1lXCI7XHJcbiAgc3RhdGljIFJFRl9FTkRfTkFNRUQgPSBcIi8+XCI7XHJcbiAgc3RhdGljIEhFQURJTkdfU1RBUlQgPSBcIj09XCI7XHJcbiAgc3RhdGljIENBVEVHT1JZX1NUQVJUID0gXCJbW2NhdGVnb3J5XCI7XHJcbiAgc3RhdGljIFJFRkVSRU5DRVNfVEFHID0gXCI8cmVmZXJlbmNlc1wiO1xyXG4gIHN0YXRpYyBVTlNPVVJDRUQgPSBcInVuc291cmNlZFwiO1xyXG4gIHN0YXRpYyBVTlNPVVJDRURfVEFHID0gXCJ7e3Vuc291cmNlZFwiO1xyXG4gIHN0YXRpYyBVTlNPVVJDRURfVEFHMiA9IFwie3sgdW5zb3VyY2VkXCI7XHJcbiAgc3RhdGljIFFVRVNUSU9OQUJMRV9UQUcgPSBcInt7dGVtcGxhdGU6cXVlc3Rpb25hYmxlXCI7XHJcbiAgc3RhdGljIFVOQ0VSVEFJTl9UQUcgPSBcInt7dW5jZXJ0YWluIGV4aXN0ZW5jZVwiO1xyXG4gIHN0YXRpYyBESVNQUk9WRU5fVEFHID0gXCJ7e2Rpc3Byb3ZlbiBleGlzdGVuY2VcIjtcclxuICBzdGF0aWMgRElTUFJPVkVOMl9UQUcgPSBcInt7ZGlzcHJvdmVuIGV4aXN0ZW5jZSBwcm9qZWN0XCI7XHJcbiAgc3RhdGljIEFVVE9fR0VORVJBVEVEID0gXCJhdXRvLWdlbmVyYXRlZCBieSBhIGdlZGNvbSBpbXBvcnRcIjtcclxuICBzdGF0aWMgU1BBTl9UQVJHRVRfU1RBUlQgPSBcIjxzcGFuIGlkPVwiO1xyXG4gIHN0YXRpYyBTUEFOX1RBUkdFVF9FTkQgPSBcIjwvc3Bhbj5cIjtcclxuICBzdGF0aWMgU1BBTl9SRUZFUkVOQ0VfU1RBUlQgPSBcIltbI1wiO1xyXG4gIHN0YXRpYyBTUEFOX1JFRkVSRU5DRV9FTkQgPSBcIl1dXCI7XHJcbiAgc3RhdGljIE1JTl9TT1VSQ0VfTEVOID0gMTU7ICAgICAgIC8vIG1pbmltdW0gbGVuZ3RoIGZvciB2YWxpZCBzb3VyY2VcclxuICBzdGF0aWMgU09VUkNFX1NUQVJUID0gXCJzb3VyY2U6XCI7XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnN0cnVjdG9yXHJcbiAgICogQHBhcmFtIHNvdXJjZVJ1bGVzIHNvdXJjZSBydWxlcyBmb3IgdmFsaWRhdGluZyBzb3VyY2VzXHJcbiAgICogQHBhcmFtIGJpb1Jlc3VsdHMgY29udGFpbmVyIGZvciBCaW9ncmFwaHlSZXN1bHRzXHJcbiAgICovIFxyXG4gIGNvbnN0cnVjdG9yKHRoZVNvdXJjZVJ1bGVzKSB7XHJcbiAgICBzdXBlcigpO1xyXG4gICAgIHRoaXMuc291cmNlUnVsZXMgPSB0aGVTb3VyY2VSdWxlcztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFBhcnNlIGNvbnRlbnRzIG9mIHRoZSBiaW9cclxuICAgKiBAcGFyYW0gaW5TdHIgYmlvIHN0cmluZyBhcyByZXR1cm5lZCBmcm9tIHNlcnZlclxyXG4gICAqIEBwYXJhbSBpc1ByZTE1MDAgdHJ1ZSBpZiBwcm9maWxlIGlzIHRyZWF0ZWQgYXMgUHJlMTUwMFxyXG4gICAqIEBwYXJhbSBpc1ByZTE3MDAgdHJ1ZSBpZiBwcm9maWxlIGlzIHRyZWF0ZWQgYXMgUHJlMTcwMFxyXG4gICAqIEBwYXJhbSBtdXN0QmVPcGVuIHRydWUgaWYgcHJvZmlsZSBpcyB0cmVhdGVkIGFzIHRvbyBvbGQgdG8gcmVtZW1iZXJcclxuICAgKiBAcGFyYW0gYmlvVW5kYXRlZCB0cnVlIGlmIHByb2ZpbGUgaGFzIG5vIGRhdGVzXHJcbiAgICogQHBhcmFtIGNoZWNrQXV0b0dlbmVyYXRlZCB0cnVlIHRvIHJlcG9ydCBwcm9maWxlcyB3aXRoIGF1dG8tZ2VuZXJhdGVkICogc3RyaW5nXHJcbiAgICogU2lkZSBlZmZlY3RzIC0gc2V0IHN0YXRpc3RpY3MgYW5kIHN0eWxlXHJcbiAgICovXHJcbiAgcGFyc2UoaW5TdHIsIGlzUHJlMTUwMCwgaXNQcmUxNzAwLCBtdXN0QmVPcGVuLCBiaW9VbmRhdGVkLCBjaGVja0F1dG9HZW5lcmF0ZWQpIHtcclxuXHJcbiAgICB0aGlzLmlzUHJlMTUwMCA9IGlzUHJlMTUwMDtcclxuICAgIHRoaXMuaXNQcmUxNzAwID0gaXNQcmUxNzAwO1xyXG4gICAgdGhpcy50b29PbGRUb1JlbWVtYmVyID0gbXVzdEJlT3BlbjtcclxuICAgIHRoaXMuYmlvUmVzdWx0cy5zdGF0cy5iaW9Jc1VuZGF0ZWQgPSBiaW9VbmRhdGVkO1xyXG5cclxuICAgIHRoaXMuYmlvSW5wdXRTdHJpbmcgPSBpblN0cjtcclxuICAgIC8vIENoZWNrIGZvciBlbXB0eSBiaW9cclxuICAgIGlmICh0aGlzLmJpb0lucHV0U3RyaW5nLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuYmlvSXNFbXB0eSA9IHRydWU7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIC8vIGNoZWNrIGZvciBlbmRsZXNzIGNvbW1lbnRcclxuICAgIHRoaXMuYmlvSW5wdXRTdHJpbmcgPSB0aGlzLnN3YWxsb3dDb21tZW50cyh0aGlzLmJpb0lucHV0U3RyaW5nKTtcclxuICAgIGlmICh0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuaGFzRW5kbGVzc0NvbW1lbnQpIHtcclxuICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1N0eWxlSXNzdWVzID0gdHJ1ZTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgLy8gYXNzdW1lIG5vIHN0eWxlIGlzc3Vlc1xyXG4gICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1N0eWxlSXNzdWVzID0gZmFsc2U7XHJcblxyXG4gICAgLy8gc3dhbGxvdyBhbnkgPGJyPlxyXG4gICAgdGhpcy5iaW9JbnB1dFN0cmluZyA9IHRoaXMuc3dhbGxvd0JyKHRoaXMuYmlvSW5wdXRTdHJpbmcpO1xyXG5cclxuICAgIC8vIGlmIGF1dG8gZ2VuZXJhdGVkIGZyb20gR0VEQ09NIGFuZCB0ZXN0aW5nIHRoaXMsIHJlcG9ydCBhcyBzdHlsZSBpc3N1ZVxyXG4gICAgaWYgKGNoZWNrQXV0b0dlbmVyYXRlZCkge1xyXG4gICAgICBsZXQgdG1wTGluZSA9IHRoaXMuYmlvSW5wdXRTdHJpbmcudG9Mb3dlckNhc2UoKTtcclxuICAgICAgaWYgKCh0bXBMaW5lLmluZGV4T2YoQmlvZ3JhcGh5LkFVVE9fR0VORVJBVEVEKSkgPiAwKSB7XHJcbiAgICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1N0eWxlSXNzdWVzID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSXNBdXRvR2VuZXJhdGVkID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIGJ1aWxkIGEgdmVjdG9yIG9mIGVhY2ggbGluZSBpbiB0aGUgYmlvIHRoZW4gaXRlcmF0ZVxyXG4gICAgdGhpcy5nZXRMaW5lcyh0aGlzLmJpb0lucHV0U3RyaW5nKTtcclxuICAgIGxldCBsaW5lQ291bnQgPSB0aGlzLmJpb0xpbmVzLmxlbmd0aDtcclxuICAgIGxldCBjdXJyZW50SW5kZXggPSAwO1xyXG4gICAgd2hpbGUgKGN1cnJlbnRJbmRleCA8IGxpbmVDb3VudCkge1xyXG4gICAgICBsZXQgbGluZSA9IHRoaXMuYmlvTGluZXNbY3VycmVudEluZGV4XS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAvLyBoYW5kbGUgdGhlIGNhc2Ugd2hlcmUgdGhlcmUgaXMgbm8gc3BhY2UgYmVmb3JlIGVuZGluZyAvXHJcbiAgICAgIC8vIHNvIGl0IG1pZ2h0IHN0YXJ0IHdpdGggYSBibGFua1xyXG4gICAgICAvLyBUT0RPIG1heWJlIHJlcG9ydCBzdGFydGluZyB3aXRoIGEgYmxhbmsgYXMgYSBzdHlsZSBpc3N1ZT9cclxuICAgICAgaWYgKGxpbmUuaW5kZXhPZihCaW9ncmFwaHkuUkVGRVJFTkNFU19UQUcpID49IDApIHtcclxuICAgICAgICB0aGlzLnJlZmVyZW5jZXNJbmRleCA9IGN1cnJlbnRJbmRleDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAobGluZS5zdGFydHNXaXRoKEJpb2dyYXBoeS5DQVRFR09SWV9TVEFSVCkpIHtcclxuICAgICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdGF0cy5iaW9IYXNDYXRlZ29yaWVzID0gdHJ1ZTtcclxuICAgICAgICAgIGlmIChsaW5lLmluY2x1ZGVzKEJpb2dyYXBoeS5VTlNPVVJDRUQpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdGF0cy5iaW9Jc01hcmtlZFVuc291cmNlZCA9IHRydWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgoQmlvZ3JhcGh5LkhFQURJTkdfU1RBUlQpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZXZhbHVhdGVIZWFkaW5nTGluZShsaW5lLCBjdXJyZW50SW5kZXgpO1xyXG4gICAgICAgICAgfSAgICAgICAvLyBlbmQgaWYgYSBoZWFkaW5nIGxpbmVcclxuICAgICAgICB9ICAgICAgICAgLy8gZW5kIGlmIGEgY2F0ZWdvcnkgbGluZVxyXG4gICAgICB9ICAgICAgICAgICAvLyBlbmQgaWYgcmVmZXJlbmNlcyB0YWdcclxuICAgICAgY3VycmVudEluZGV4Kys7XHJcbiAgICB9XHJcbiAgICAvLyBhY2tub3dsZWdlbWVudHMgbWF5IGdvIHRvIGVuZCBvZiBiaW9cclxuICAgIGlmICh0aGlzLmFja25vd2xlZGdlbWVudHNFbmRJbmRleCA8IDApIHtcclxuICAgICAgdGhpcy5hY2tub3dsZWRnZW1lbnRzRW5kSW5kZXggPSBsaW5lQ291bnQ7XHJcbiAgICB9XHJcbiAgICBsZXQgbGluZSA9IHRoaXMuYmlvSW5wdXRTdHJpbmcudG9Mb3dlckNhc2UoKTtcclxuICAgIGlmICgobGluZS5pbmNsdWRlcyhCaW9ncmFwaHkuVU5TT1VSQ0VEX1RBRykpIHx8XHJcbiAgICAgICAgICAobGluZS5pbmNsdWRlcyhCaW9ncmFwaHkuVU5TT1VSQ0VEX1RBRzIpKSkge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuYmlvSXNNYXJrZWRVbnNvdXJjZWQgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKGxpbmUuaW5jbHVkZXMoQmlvZ3JhcGh5LlFVRVNUSU9OQUJMRV9UQUcpIHx8XHJcbiAgICAgICAgIChsaW5lLmluY2x1ZGVzKEJpb2dyYXBoeS5VTkNFUlRBSU5fVEFHKSkgfHxcclxuICAgICAgICAgKGxpbmUuaW5jbHVkZXMoQmlvZ3JhcGh5LkRJU1BST1ZFTjJfVEFHKSkgfHxcclxuICAgICAgICAgKGxpbmUuaW5jbHVkZXMoQmlvZ3JhcGh5LkRJU1BST1ZFTl9UQUcpKSkge1xyXG4gICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuYmlvSXNVbmNlcnRhaW5FeGlzdGFuY2UgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEdldCB0aGUgc3RyaW5nIHRoYXQgbWlnaHQgY29udGFpbiA8cmVmPnh4eDwvcmVmPiBwYWlyc1xyXG4gICAgbGV0IGJpb0xpbmVTdHJpbmcgPSB0aGlzLmdldEJpb0xpbmVTdHJpbmcoKTtcclxuICAgIHRoaXMuZmluZFJlZihiaW9MaW5lU3RyaW5nKTtcclxuICAgIHRoaXMuZmluZE5hbWVkUmVmKGJpb0xpbmVTdHJpbmcpO1xyXG5cclxuICAgIHRoaXMuc2V0QmlvU3RhdGlzdGljc0FuZFN0eWxlKCk7XHJcblxyXG4gICAgLy8gTG9zZSBiaW8gbGluZXMgbm90IGNvbnNpZGVyZWQgdG8gY29udGFpbiBzb3VyY2VzXHJcbiAgICB0aGlzLnJlbW92ZVJlc2VhcmNoTm90ZXMoKTtcclxuICAgIHRoaXMucmVtb3ZlQWNrbm93bGVkZ2VtZW50cygpO1xyXG5cclxuICAgIGlmICh0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzUmVmV2l0aG91dEVuZCkge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVmFsaWRhdGUgY29udGVudHMgb2YgYmlvXHJcbiAgICogQHJldHVybiB0cnVlIGlmIHByb2JhYmx5IHZhbGlkIHNvdXJjZXMgYW5kIG5vIHN0eWxlIGlzc3VlcywgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIHZhbGlkYXRlKCkge1xyXG5cclxuICAgIGxldCBpc1ZhbGlkID0gZmFsc2U7XHJcbiAgICAvKlxyXG4gICAgICogRG9uJ3QgYm90aGVyIGZvciBlbXB0eSBiaW8sIG9uZSBhbHJlYWR5IG1hcmtlZCB1bnNvdXJjZWQsIHVuY2VydGFpbiBleGlzdGFuY2VcclxuICAgICAqIG9yIHRoZSBtYW5hZ2VyJ3Mgb3duIHByb2ZpbGVcclxuICAgICAqL1xyXG4gICAgaWYgKCF0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuYmlvSXNFbXB0eSAmJiBcclxuICAgICAgICAhdGhpcy5iaW9SZXN1bHRzLnN0YXRzLmJpb0lzTWFya2VkVW5zb3VyY2VkICYmXHJcbiAgICAgICAgIXRoaXMuYmlvUmVzdWx0cy5zdGF0cy5iaW9Jc1VuY2VydGFpbkV4aXN0YW5jZSAmJlxyXG4gICAgICAgICF0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuYmlvSXNVbmRhdGVkKSB7XHJcblxyXG4gICAgICAvLyBMb29rIGZvciBhIHBhcnRpYWwgc3RyaW5nIHRoYXQgbWFrZXMgaXQgdmFsaWRcclxuICAgICAgaXNWYWxpZCA9IHRoaXMuY29udGFpbnNWYWxpZFBhcnRpYWxTb3VyY2UodGhpcy5iaW9JbnB1dFN0cmluZy50b0xvd2VyQ2FzZSgpKTtcclxuXHJcbiAgICAgIC8qXHJcbiAgICAgICAqIEZpcnN0IHZhbGlkYXRlIHN0cmluZ3MgYWZ0ZXIgcmVmZXJlbmNlcy4gVGhpcyB3aWxsIGJ1aWxkIGEgc2lkZSBlZmZlY3Qgb2ZcclxuICAgICAgICogYSBsaXN0IG9mIGludmFsaWQgc3BhbiB0YWdzLlxyXG4gICAgICAgKiBOZXh0IHZhbGlkYXRlIHN0cmluZ3MgYmV0d2VlbiBTb3VyY2VzIGFuZCA8cmVmZXJlbmNlcyAvPi4gVGhpcyB3aWxsIHVwZGF0ZS9idWlsZFxyXG4gICAgICAgKiBhIHNpZGUgZWZmZWN0IGxpc3Qgb2YgaW52YWxpZCBzcGFuIHRhZ3MuXHJcbiAgICAgICAqIEZpbmFsbHkgdmFsaWRhdGUgdGhlIHJlZmVyZW5jZXMsIGxvb2tpbmcgYXQgaW52YWxpZCBzcGFuIHRhZ3MgaWYgbmVlZGVkLlxyXG4gICAgICAgKlxyXG4gICAgICAgKiBTdHJpbmdzIGFmdGVyIHJlZmVyZW5jZXMgYW5kIHdpdGhpbiBuYW1lZCBhbmQgdW5uYW1lZCByZWYgdGFncyBhcmVcclxuICAgICAgICogdmFsaWRhdGVkIHRvIGFkZCB0aG9zZSB0byB0aGUgbGlzdCBvZiB2YWxpZC9pbnZhbGlkIHNvdXJjZXNcclxuICAgICAgICovXHJcbiAgICAgIGlmICghaXNWYWxpZCkge1xyXG4gICAgICAgIGlzVmFsaWQgPSB0aGlzLnZhbGlkYXRlUmVmZXJlbmNlU3RyaW5ncygpO1xyXG4gICAgICAgIGlmICh0aGlzLnZhbGlkYXRlUmVmU3RyaW5ncyh0aGlzLnJlZlN0cmluZ0xpc3QpKSB7XHJcbiAgICAgICAgICBpZiAoIWlzVmFsaWQpIHtcclxuICAgICAgICAgICAgaXNWYWxpZCA9IHRydWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLnZhbGlkYXRlUmVmU3RyaW5ncyh0aGlzLm5hbWVkUmVmU3RyaW5nTGlzdCkpIHtcclxuICAgICAgICAgIGlmICghaXNWYWxpZCkge1xyXG4gICAgICAgICAgICBpc1ZhbGlkID0gdHJ1ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCFpc1ZhbGlkKSB7XHJcbiAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc291cmNlcy5zb3VyY2VzRm91bmQgPSBmYWxzZTtcclxuICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zb3VyY2VzLnNvdXJjZXNGb3VuZCA9IHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNWYWxpZDtcclxuICB9XHJcblxyXG4gIC8qICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAqICoqKioqKioqKioqKioqKioqKiogUFJJVkFURSBNRVRIT0RTICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAqICoqKioqKioqKioqKioqKioqKiogdXNlZCBieSBQYXJzZXIgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAqL1xyXG5cclxuICAvKlxyXG4gICAqIFN3YWxsb3cgY29tbWVudHNcclxuICAgKiBzaWRlIGVmZmVjdCBzZXQgc3R5bGUgaWYgZW5kbGVzcyBjb21tZW50IGZvdW5kXHJcbiAgICogQHBhcmFtIGluU3RyXHJcbiAgICogQHJldHVybiBzdHJpbmcgd2l0aCBjb21tZW50cyByZW1vdmVkXHJcbiAgKi9cclxuICBzd2FsbG93Q29tbWVudHMoaW5TdHIpIHtcclxuICAgIGxldCBvdXRTdHIgPSBcIlwiO1xyXG4gICAgLypcclxuICAgICAqIEZpbmQgc3RhcnQgb2YgY29tbWVudFxyXG4gICAgICogUHV0IGV2ZXJ5dGhpbmcgYmVmb3JlIHN0YXJ0IGluIG91dHB1dCBzdHJpbmdcclxuICAgICAqIEZpbmQgZW5kIG9mIGNvbW1lbnQsIHNraXAgcGFzdCB0aGUgZW5kaW5nIGFuZCBzdGFydCBsb29raW5nIHRoZXJlXHJcbiAgICAqL1xyXG4gICAgbGV0IHBvcyA9IDA7ICAgICAgICAgICAgICAgLy8gc3RhcnRpbmcgcG9zaXRpb24gb2YgdGhlIGNvbW1lbnRcclxuICAgIGxldCBlbmRQb3MgPSAwOyAgICAgICAgICAgIC8vIGVuZCBwb3NpdGlvbiBvZiB0aGUgY29tbWVudFxyXG4gICAgbGV0IGxlbiA9IGluU3RyLmxlbmd0aDsgICAgLy8gbGVuZ3RoIG9mIGlucHV0IHN0cmluZ1xyXG4gICAgcG9zID0gaW5TdHIuaW5kZXhPZihCaW9ncmFwaHkuU1RBUlRfT0ZfQ09NTUVOVCk7XHJcbiAgICBpZiAocG9zIDwgMCkge1xyXG4gICAgICBvdXRTdHIgPSBpblN0cjsgICAgICAgICAvLyBubyBjb21tZW50c1xyXG4gICAgfVxyXG4gICAgd2hpbGUgKChwb3MgPCBsZW4pICYmIChwb3MgPj0gMCkpIHtcclxuICAgICAgLy8gZ2V0IGV2ZXJ5dGhpbmcgdG8gc3RhcnQgb2YgY29tbWVudCB1bmxlc3MgY29tbWVudCBpcyBmaXJzdCBsaW5lIGluIGJpb1xyXG4gICAgICBpZiAocG9zID4gMCkge1xyXG4gICAgICAgIG91dFN0ciA9IG91dFN0ciArIGluU3RyLnN1YnN0cmluZyhlbmRQb3MsIHBvcyAtIDEpO1xyXG4gICAgICB9XHJcbiAgICAgIC8vIEZpbmQgZW5kIG9mIGNvbW1lbnRcclxuICAgICAgZW5kUG9zID0gaW5TdHIuaW5kZXhPZihCaW9ncmFwaHkuRU5EX09GX0NPTU1FTlQsIHBvcyk7XHJcbiAgICAgIGlmIChlbmRQb3MgPiAwKSB7XHJcbiAgICAgICAgcG9zID0gZW5kUG9zICsgMzsgICAgLy8gc2tpcCB0aGUgLS0+IGFuZCBtb3ZlIHN0YXJ0aW5nIHBvc2l0aW9uIHRoZXJlXHJcbiAgICAgICAgaWYgKHBvcyA8PSBsZW4pIHtcclxuICAgICAgICAgIHBvcyA9IGluU3RyLmluZGV4T2YoQmlvZ3JhcGh5LlNUQVJUX09GX0NPTU1FTlQsIHBvcyk7ICAvLyBmaW5kIG5leHQgY29tbWVudFxyXG4gICAgICAgICAgaWYgKHBvcyA8IDEpIHtcclxuICAgICAgICAgICAgb3V0U3RyICs9IGluU3RyLnN1YnN0cmluZyhlbmRQb3MgKyAzKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmhhc0VuZGxlc3NDb21tZW50ID0gdHJ1ZTtcclxuICAgICAgICBwb3MgPSBpblN0ci5sZW5ndGggKyAxOyAgLy8gaXRzIGFuIGVuZGxlc3MgY29tbWVudCwganVzdCBiYWlsXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBvdXRTdHI7XHJcbiAgfVxyXG4gIC8qIFxyXG4gICAqIFN3YWxsb3cgQlIgXHJcbiAgICogY291bGQgYmUgaW4gdGhlIGZvcm0gPGJyPiBvciA8YnIvPiBvciA8YnIgLz5cclxuICAgKiBAcGFyYW0gaW5TdHJcclxuICAgKiBAcmV0dXJuIHN0cmluZyB3aXRoIGJyIHJlbW92ZWRcclxuICAgKi9cclxuICBzd2FsbG93QnIoaW5TdHIpIHtcclxuICAgIGxldCBvdXRTdHIgPSBcIlwiO1xyXG4gICAgbGV0IHBvcyA9IDA7XHJcbiAgICBsZXQgZW5kUG9zID0gMDtcclxuICAgIGxldCBsZW4gPSBpblN0ci5sZW5ndGg7XHJcbiAgICBwb3MgPSBpblN0ci5pbmRleE9mKEJpb2dyYXBoeS5TVEFSVF9PRl9CUik7XHJcbiAgICBpZiAocG9zIDwgMCkge1xyXG4gICAgICAgb3V0U3RyID0gaW5TdHI7ICAgICAgICAgLy8gbm8gYnJcclxuICAgIH0gXHJcbiAgICB3aGlsZSAoKHBvcyA8IGxlbikgJiYgKHBvcyA+PSAwKSkge1xyXG4gICAgICBpZiAocG9zID4gMCkge1xyXG4gICAgICAgIG91dFN0ciA9IG91dFN0ciArIGluU3RyLnN1YnN0cmluZyhlbmRQb3MsIHBvcyk7XHJcbiAgICAgIH1cclxuICAgICAgZW5kUG9zID0gaW5TdHIuaW5kZXhPZihCaW9ncmFwaHkuRU5EX0JSQUNLRVQsIHBvcyk7XHJcbiAgICAgIGlmIChlbmRQb3MgPiAwKSB7XHJcbiAgICAgICAgcG9zID0gZW5kUG9zICsgMTsgICAgLy8gc2tpcCB0aGUgLz4gYW5kIG1vdmUgc3RhcnRpbmcgcG9zaXRpb24gdGhlcmVcclxuICAgICAgICBpZiAocG9zIDw9IGxlbikge1xyXG4gICAgICAgICAgcG9zID0gaW5TdHIuaW5kZXhPZihCaW9ncmFwaHkuU1RBUlRfT0ZfQlIsIHBvcyk7ICAvLyBmaW5kIG5leHQgY29tbWVudFxyXG4gICAgICAgICAgaWYgKHBvcyA8IDEpIHtcclxuICAgICAgICAgICAgb3V0U3RyICs9IGluU3RyLnN1YnN0cmluZyhlbmRQb3MgKyAxKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBvdXRTdHI7XHJcbiAgfVxyXG5cclxuICAvKlxyXG4gICAqIEJ1aWxkIGFuIGFycmF5IG9mIGVhY2ggbGluZSBpbiB0aGUgYmlvXHJcbiAgICogbGluZXMgYXJlIGRlbGltaXRlZCBieSBhIG5ld2xpbmVcclxuICAgKiBlbXB0eSBsaW5lcyBvciB0aG9zZSB3aXRoIG9ubHkgd2hpdGVzcGFjZSBhcmUgZWxpbWluYXRlZFxyXG4gICAqIEBwYXJhbSBpblN0ciBiaW8gc3RyaW5nIHN0cmlwcGVkIG9mIGNvbW1lbnRzXHJcbiAgICovXHJcbiAgZ2V0TGluZXMoaW5TdHIpIHtcclxuICAgIGxldCBzcGxpdFN0cmluZyA9IGluU3RyLnNwbGl0KFwiXFxuXCIpO1xyXG4gICAgbGV0IGxpbmUgPSBcIlwiO1xyXG4gICAgbGV0IHRtcFN0cmluZyA9IFwiXCI7XHJcbiAgICBsZXQgbGVuID0gc3BsaXRTdHJpbmcubGVuZ3RoO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICBsaW5lID0gc3BsaXRTdHJpbmdbaV07XHJcbiAgICAgIC8vIGxpbmUgaXMgbm90aGluZyBidXQgLS0tLSBpZ25vcmUgaXQgYnkgcmVwbGFjaW5nIHdpdGggc3BhY2VzIHRoZW5cclxuICAgICAgLy8gdHJpbW1pbmdcclxuICAgICAgdG1wU3RyaW5nID0gbGluZS5yZXBsYWNlKCctJywgJyAnKTtcclxuICAgICAgdG1wU3RyaW5nID0gdG1wU3RyaW5nLnRyaW0oKTtcclxuICAgICAgLy8gU2FuaXR5IGNoZWNrIGlmIHRoZSBsaW5lIHdpdGggPHJlZmVyZW5jZXMgLz4gYWxzbyBoYXMgdGV4dCBmb2xsb3dpbmcgb24gc2FtZSBsaW5lXHJcbiAgICAgIGlmICh0bXBTdHJpbmcuaW5kZXhPZihCaW9ncmFwaHkuUkVGRVJFTkNFU19UQUcpID49IDApIHtcclxuICAgICAgICBsZXQgZW5kT2ZSZWZlcmVuY2VzVGFnID0gdG1wU3RyaW5nLmluZGV4T2YoQmlvZ3JhcGh5LkVORF9CUkFDS0VUKTtcclxuICAgICAgICBpZiAoZW5kT2ZSZWZlcmVuY2VzVGFnICsgMSA8IHRtcFN0cmluZy5sZW5ndGgpIHtcclxuICAgICAgICAgIC8vIE9vcHNpZS4gQWRkIGEgbGluZSBmb3IgcmVmZXJlbmNlcyBhbmQgYW5vdGhlciBmb3IgdGhlIGxpbmVcclxuICAgICAgICAgIC8vIGFuZCByZXBvcnQgYSBzdHlsZSBpc3N1ZT9cclxuICAgICAgICAgIGxldCBhbm90aGVyTGluZSA9IHRtcFN0cmluZy5zdWJzdHJpbmcoMCwgZW5kT2ZSZWZlcmVuY2VzVGFnICsgMSk7XHJcbiAgICAgICAgICB0aGlzLmJpb0xpbmVzLnB1c2goYW5vdGhlckxpbmUpO1xyXG4gICAgICAgICAgbGluZSA9IHRtcFN0cmluZy5zdWJzdHJpbmcoZW5kT2ZSZWZlcmVuY2VzVGFnICsgMik7XHJcbiAgICAgICAgICBpZiAoIWxpbmUubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYmlvTGluZXMucHVzaCh0bXBTdHJpbmcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLmJpb0xpbmVzLnB1c2godG1wU3RyaW5nKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5iaW9MaW5lcy5wdXNoKGxpbmUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvKiBcclxuICAgKiBQcm9jZXNzIGhlYWRpbmcgbGluZSB0byBmaW5kIEJpb2dyYXBoeSwgU291cmNlcywgQWNrbm93bGVkZ2VtZW50c1xyXG4gICAqIHNldCBpbmRleCB0byBlYWNoIHNlY3Rpb25cclxuICAgKiBNZXRob2RzIGFyZSB1c2VkIHRvIGZpbmQgc2VjdGlvbnMgc28gdGhhdCBydWxlcyBjYW4gc3BlY2lmeSBcclxuICAgKiBhbHRlcm5hdGUgbGFuZ3VhZ2VzXHJcbiAgICogQHBhcmFtIGluU3RyIHN0YXJ0aW5nIHdpdGggPT1cclxuICAgKiBAcGFyYW0gY3VycmVudEluZGV4IGludG8gbWFzdGVyIGxpc3Qgb2Ygc3RyaW5nc1xyXG4gICAqL1xyXG4gIGV2YWx1YXRlSGVhZGluZ0xpbmUoaW5TdHIsIGN1cnJlbnRJbmRleCkge1xyXG5cclxuICAgIGxldCBoZWFkaW5nVGV4dCA9IFwiXCI7XHJcbiAgICBsZXQgaGVhZGluZ1N0YXJ0UG9zID0gMDtcclxuICAgIGxldCBoZWFkaW5nTGV2ZWwgPSAwO1xyXG4gICAgLypcclxuICAgICAqIHRoZSBiaW9MaW5lU3RyaW5nIHNob3VsZCBzdGFydCB3aXRoIHRoZSBsYXJnZXIgb2YgdGhlIHN0YXJ0IG9mIHRoZSBsaW5lXHJcbiAgICAgKiBhZnRlciB0aGUgYmlvZ3JhcGh5IGhlYWRpbmcgb3IgMFxyXG4gICAgICogaXQgc2hvdWxkIGVuZCB3aXRoIHRoZSBzbWFsbGVzdCBvZiB0aGUgbGVuZ3RoIG9mIHRoZSBiaW8gc3RyaW5nIG9yXHJcbiAgICAgKiB0aGUgZmlyc3QgaGVhZGluZyBmb3VuZCBhZnRlciB0aGUgYmlvZ3JhcGh5IGhlYWRpbmdcclxuICAgICovXHJcbiAgICBsZXQgbGVuID0gaW5TdHIubGVuZ3RoO1xyXG4gICAgd2hpbGUgKChoZWFkaW5nU3RhcnRQb3MgPCBsZW4pICYmIChoZWFkaW5nTGV2ZWwgPCA0KSkge1xyXG4gICAgICBpZiAoaW5TdHIuY2hhckF0KGhlYWRpbmdTdGFydFBvcykgPT09ICc9Jykge1xyXG4gICAgICAgIGhlYWRpbmdTdGFydFBvcysrO1xyXG4gICAgICAgIGhlYWRpbmdMZXZlbCsrOyAgICAgICAgICAgICAgICAvLyBudW1iZXIgb2YgPVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIGxvc2UgYW55IGxlYWRpbmcgJyBmb3IgYm9sZCBvciBpdGFsaWNzXHJcbiAgICAgICAgbGV0IGkgPSBoZWFkaW5nTGV2ZWw7XHJcbiAgICAgICAgd2hpbGUgKChpIDwgbGVuKSAmJiAoaW5TdHIuY2hhckF0KGkpID09PSBcIidcIikpIHtcclxuICAgICAgICAgIGkrKztcclxuICAgICAgICB9XHJcbiAgICAgICAgaGVhZGluZ1RleHQgPSAoaW5TdHIuc3Vic3RyaW5nKGkpKS50cmltKCk7XHJcbiAgICAgICAgaGVhZGluZ1N0YXJ0UG9zID0gbGVuICsgMTsgICAgICAgLy8gYnJlYWsgb3V0IG9mIGxvb3BcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8gU2F2ZSBpbmRleCBmb3IgdGhpcyBoZWFkaW5nICAgXHJcbiAgICBpZiAodGhpcy5pc0Jpb2dyYXBoeUhlYWRpbmcoaGVhZGluZ1RleHQpKSB7XHJcbiAgICAgIGlmICh0aGlzLmJpb2dyYXBoeUluZGV4IDwgMCkge1xyXG4gICAgICAgIHRoaXMuYmlvZ3JhcGh5SW5kZXggPSBjdXJyZW50SW5kZXg7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHRoaXMucmVzZWFyY2hOb3Rlc0luZGV4ID4gMCkge1xyXG4gICAgICAgICAgdGhpcy5yZXNlYXJjaE5vdGVzRW5kSW5kZXggPSBjdXJyZW50SW5kZXggLSAxO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKHRoaXMuaXNSZXNlYXJjaE5vdGVzSGVhZGluZyhoZWFkaW5nVGV4dCkpIHtcclxuICAgICAgICAgICAgdGhpcy5yZXNlYXJjaE5vdGVzSW5kZXggPSBjdXJyZW50SW5kZXg7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNTb3VyY2VzSGVhZGluZyhoZWFkaW5nVGV4dCkpIHtcclxuICAgICAgICAgIGlmIChoZWFkaW5nTGV2ZWwgPiAyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLnNvdXJjZXNIZWFkaW5nSGFzRXh0cmFFcXVhbCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1N0eWxlSXNzdWVzID0gdHJ1ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmICh0aGlzLnNvdXJjZXNJbmRleCA8IDApIHtcclxuICAgICAgICAgICAgdGhpcy5zb3VyY2VzSW5kZXggPSBjdXJyZW50SW5kZXg7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLnJlc2VhcmNoTm90ZXNJbmRleCA+IDApIHtcclxuICAgICAgICAgICAgICB0aGlzLnJlc2VhcmNoTm90ZXNFbmRJbmRleCA9IGN1cnJlbnRJbmRleCAtIDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMuYWNrbm93bGVkZ2VtZW50c0luZGV4ID4gMCkge1xyXG4gICAgICAgICAgICAgIHRoaXMuYWNrbm93bGVkZ2VtZW50c0VuZEluZGV4ID0gY3VycmVudEluZGV4IC0gMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAvL3RoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNNdWx0aXBsZVNvdXJjZUhlYWRpbmdzID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAvL3RoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICh0aGlzLmlzQWNrSGVhZGluZyhoZWFkaW5nVGV4dCkpIHtcclxuICAgICAgICAgICAgaWYgKGhlYWRpbmdMZXZlbCA+IDIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYWNrbm93bGVkZ2VtZW50c0hlYWRpbmdIYXNFeHRyYUVxdWFsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLnNvdXJjZXNJbmRleCA8IDApIHtcclxuICAgICAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzQWNrbm93bGVkZ2VtZW50c0JlZm9yZVNvdXJjZXMgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5hY2tub3dsZWRnZW1lbnRzSW5kZXggPSBjdXJyZW50SW5kZXg7XHJcbiAgICAgICAgICAgIGlmICgodGhpcy5yZXNlYXJjaE5vdGVzSW5kZXggPiAwKSAmJiAodGhpcy5yZXNlYXJjaE5vdGVzRW5kSW5kZXggPCAwKSkge1xyXG4gICAgICAgICAgICAgICB0aGlzLnJlc2VhcmNoTm90ZXNFbmRJbmRleCA9IGN1cnJlbnRJbmRleCAtIDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIFRPRE8gaWYgdGhpcyBpcyBiZWZvcmUgYmlvZ3JhcGh5LCBhZGQgYSBzdHlsZSBpc3N1ZSBIZWFkaW5nXHJcbiAgICAgICAgICAgIC8vIGJlZm9yZSBCaW9ncmFwaHkgKGFrYSBiaW9ncmFwaHlJbmRleCA8IDApXHJcbiAgICAgICAgICAgIC8vIGp1c3QgYSBsaW5lXHJcbiAgICAgICAgICB9IC8vIGVuZGlmIEFja25vd2xlZGdlbWVudHNcclxuICAgICAgICB9IC8vIGVuZGlmIFNvdXJjZXNcclxuICAgICAgfSAvLyBlbmRpZiBSZXNlYXJjaCBOb3Rlc1xyXG4gICAgfSAvLyBlbmRpZiBCaW9ncmFwaHlcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogR2V0IHN0cmluZyBmcm9tIGJpbyB0byBiZSBzZWFyY2hlZCBmb3IgYW55IGlubGluZSA8cmVmXHJcbiAgICogdGhlIGJpb0xpbmVTdHJpbmcgc2hvdWxkIHN0YXJ0IHdpdGggdGhlIGJlZ2lubmluZyBvZiB0aGUgYmlvZ3JhcGh5XHJcbiAgICogb3IgdGhlIGxpbmUgYWZ0ZXIgdGhlIEJpb2dyYXBoeSBoZWFkaW5nIHdoaWNoZXZlciBpcyBsYXN0XHJcbiAgICogaXQgc2hvdWxkIGVuZCB3aXRoIHRoZSBzbWFsbGVzdCBvZiB0aGUgbGVuZ3RoIG9mIHRoZSBiaW8gc3RyaW5nIG9yXHJcbiAgICogdGhlIGZpcnN0IGhlYWRpbmcgZm91bmQgYWZ0ZXIgdGhlIGJpb2dyYXBoeSBoZWFkaW5nXHJcbiAgICovXHJcbiAgZ2V0QmlvTGluZVN0cmluZygpIHtcclxuXHJcbiAgICBsZXQgYmlvTGluZXNTdHJpbmcgPSBcIlwiO1xyXG4gICAgbGV0IHN0YXJ0SW5kZXggPSAwO1xyXG4gICAgLy8gSnVtcCB0byB0aGUgc3RhcnQgb2YgPT0gQmlvZ3JhcGh5XHJcbiAgICBpZiAodGhpcy5iaW9ncmFwaHlJbmRleCA+IDAgKSB7XHJcbiAgICAgICAgc3RhcnRJbmRleCA9IHRoaXMuYmlvZ3JhcGh5SW5kZXg7XHJcbiAgICB9XHJcbiAgICAvLyBhc3N1bWUgaXQgZW5kcyBhdCBlbmQgb2YgYmlvIHRoZW4gcGljayBzbWFsbGVzdFxyXG4gICAgLy8gb2YgUmVzZWFyY2ggTm90ZXMsIFNvdXJjZXMsIHJlZmVyZW5jZXMsIGFja25vd2xlZGdlbWVudHNcclxuICAgIC8vIHdoaWNoIGlzIGFsc28gYWZ0ZXIgdGhlIHN0YXJ0IG9mIHRoZSBiaW9ncmFwaHlcclxuICAgIGxldCBlbmRJbmRleCA9IHRoaXMuYmlvTGluZXMubGVuZ3RoO1xyXG4gICAgaWYgKCh0aGlzLnJlc2VhcmNoTm90ZXNJbmRleCA+IDApICYmICh0aGlzLnJlc2VhcmNoTm90ZXNJbmRleCA+IHN0YXJ0SW5kZXgpKSB7XHJcbiAgICAgIGVuZEluZGV4ID0gdGhpcy5yZXNlYXJjaE5vdGVzSW5kZXg7XHJcbiAgICB9XHJcbiAgICBpZiAoKHRoaXMuc291cmNlc0luZGV4ID4gMCkgJiYgKHRoaXMuc291cmNlc0luZGV4IDwgZW5kSW5kZXgpKSB7XHJcbiAgICAgIGVuZEluZGV4ID0gdGhpcy5zb3VyY2VzSW5kZXg7XHJcbiAgICB9XHJcbiAgICBpZiAoKHRoaXMucmVmZXJlbmNlc0luZGV4ID4gMCkgJiZcclxuICAgICAgICAodGhpcy5yZWZlcmVuY2VzSW5kZXggPCBlbmRJbmRleCkpIHtcclxuICAgICAgZW5kSW5kZXggPSB0aGlzLnJlZmVyZW5jZXNJbmRleDtcclxuICAgIH1cclxuICAgIGlmICgodGhpcy5hY2tub3dsZWRnZW1lbnRzSW5kZXggPiAwKSAmJlxyXG4gICAgICAgICh0aGlzLmFja25vd2xlZGdlbWVudHNJbmRleCA8IGVuZEluZGV4KSkge1xyXG4gICAgICBlbmRJbmRleCA9IHRoaXMuYWNrbm93bGVkZ2VtZW50c0luZGV4O1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aGlzLmJpb2dyYXBoeUluZGV4ID09PSBlbmRJbmRleCkge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGVhZGluZ1dpdGhOb0xpbmVzRm9sbG93aW5nID0gdHJ1ZTtcclxuICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1N0eWxlSXNzdWVzID0gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmIChlbmRJbmRleCA+PSAwKSB7XHJcbiAgICAgICAgd2hpbGUgKHN0YXJ0SW5kZXggPCBlbmRJbmRleCkge1xyXG4gICAgICAgICAgYmlvTGluZXNTdHJpbmcgKz0gdGhpcy5iaW9MaW5lc1tzdGFydEluZGV4XTtcclxuICAgICAgICAgIHN0YXJ0SW5kZXgrKztcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBiaW9MaW5lc1N0cmluZztcclxuICB9XHJcblxyXG4gIC8qIFxyXG4gICAqIEZpbmQgPHJlZj4gPC9yZWY+IHBhaXJzIHRoYXQgZG9uJ3QgaGF2ZSBhIG5hbWVcclxuICAgKiBAcGFyYW0gYmlvTGluZVN0cmluZyBzdHJpbmcgdG8gbG9vayBpbiBmb3IgcGFpcnNcclxuICAgKiBhZGRzIGNvbnRlbnRzIG9mIHJlZiB0byByZWZTdHJpbmdMaXN0XHJcbiAgICovXHJcbiAgZmluZFJlZihiaW9MaW5lU3RyaW5nKSB7XHJcblxyXG4gICAgbGV0IHN0YXJ0T2ZSZWYgPSBiaW9MaW5lU3RyaW5nLmluZGV4T2YoQmlvZ3JhcGh5LlJFRl9TVEFSVCk7XHJcbiAgICBsZXQgZW5kT2ZSZWYgPSBiaW9MaW5lU3RyaW5nLmluZGV4T2YoQmlvZ3JhcGh5LlJFRl9FTkQsIHN0YXJ0T2ZSZWYpOyAgICAgXHJcbiAgICB3aGlsZSAoKHN0YXJ0T2ZSZWYgPj0gMCkgJiYgKCF0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzUmVmV2l0aG91dEVuZCkpIHtcclxuICAgICAgaWYgKGVuZE9mUmVmIDwgMCkge1xyXG4gICAgICAgIC8vIE9vcHNpZSwgc3RhcnRpbmcgPHJlZj4gd2l0aG91dCBhbiBlbmRpbmcgPlxyXG4gICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNSZWZXaXRob3V0RW5kID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE5vdyB3ZSBzaG91bGQgaGF2ZSB0aGUgd2hvbGUgcmVmIGxvc2UgdGhlIDxyZWY+IGFuZCBtb3ZlIHBhc3QgaXRcclxuICAgICAgICBpZiAoKHN0YXJ0T2ZSZWYgKyA1KSA8IGVuZE9mUmVmKSB7XHJcbiAgICAgICAgICBzdGFydE9mUmVmID0gc3RhcnRPZlJlZiArIDU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBsaW5lID0gYmlvTGluZVN0cmluZy5zdWJzdHJpbmcoc3RhcnRPZlJlZiwgZW5kT2ZSZWYpO1xyXG4gICAgICAgIHRoaXMucmVmU3RyaW5nTGlzdC5wdXNoKGxpbmUpO1xyXG4gICAgICAgIGVuZE9mUmVmKys7XHJcbiAgICAgICAgaWYgKGVuZE9mUmVmIDwgYmlvTGluZVN0cmluZy5sZW5ndGgpIHtcclxuICAgICAgICAgIHN0YXJ0T2ZSZWYgPSBiaW9MaW5lU3RyaW5nLmluZGV4T2YoQmlvZ3JhcGh5LlJFRl9TVEFSVCwgZW5kT2ZSZWYpO1xyXG4gICAgICAgICAgaWYgKHN0YXJ0T2ZSZWYgPiAwKSB7XHJcbiAgICAgICAgICAgIGVuZE9mUmVmID0gYmlvTGluZVN0cmluZy5pbmRleE9mKEJpb2dyYXBoeS5SRUZfRU5ELCBzdGFydE9mUmVmKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8qIFxyXG4gICAqIEZpbmQgbmFtZWQgcmVmXHJcbiAgICogd2hpY2ggYXJlIHBhaXJzIGluIHRoZSBmb3JtIDxyZWYgbmFtZT0gPjwvcmVmPlxyXG4gICAqIG9yIGluIHRoZSBmb3JtIDxyZWYgbmFtZT14eHh4IC8+XHJcbiAgICogQHBhcmFtIGJpb0xpbmVTdHJpbmcgc3RyaW5nIHRvIGxvb2sgaW4gZm9yIHBhaXJzXHJcbiAgICogYWRkcyBjb250ZW50cyBvZiByZWYgdG8gbmFtZWRSZWZTdHJpbmdMaXN0XHJcbiAgICovXHJcbiAgZmluZE5hbWVkUmVmKGJpb0xpbmVTdHJpbmcpIHtcclxuXHJcbiAgICBsZXQgZW5kT2ZSZWZOYW1lZCA9IC0xO1xyXG4gICAgbGV0IGVuZE9mUmVmID0gLTE7XHJcbiAgICBsZXQgZW5kID0gLTE7XHJcbiAgICBsZXQgYmlvTGVuZ3RoID0gYmlvTGluZVN0cmluZy5sZW5ndGg7XHJcbiAgICBsZXQgc3RhcnRPZlJlZiA9IGJpb0xpbmVTdHJpbmcuaW5kZXhPZihCaW9ncmFwaHkuUkVGX1NUQVJUX05BTUVEKTtcclxuICAgIHdoaWxlIChzdGFydE9mUmVmID49IDApIHtcclxuICAgICAgZW5kT2ZSZWYgPSBiaW9MaW5lU3RyaW5nLmluZGV4T2YoQmlvZ3JhcGh5LlJFRl9FTkQsIHN0YXJ0T2ZSZWYpO1xyXG4gICAgICBlbmRPZlJlZk5hbWVkID0gYmlvTGluZVN0cmluZy5pbmRleE9mKEJpb2dyYXBoeS5SRUZfRU5EX05BTUVELCBzdGFydE9mUmVmKTtcclxuICAgICAgaWYgKGVuZE9mUmVmIDwgMCkge1xyXG4gICAgICAgIGVuZE9mUmVmID0gYmlvTGVuZ3RoO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChlbmRPZlJlZk5hbWVkIDwgMCkge1xyXG4gICAgICAgIGVuZE9mUmVmTmFtZWQgPSBiaW9MZW5ndGg7XHJcbiAgICAgIH1cclxuICAgICAgLy8gbG9zZSB0aGUgPHJlZj4gcG9ydGlvbiBhbmQgdXNlIGZpcnN0IGVuZGluZyBmb3VuZFxyXG4gICAgICBpZiAoKHN0YXJ0T2ZSZWYgKyA1KSA8IGVuZE9mUmVmKSB7XHJcbiAgICAgICAgc3RhcnRPZlJlZiA9IHN0YXJ0T2ZSZWYgKyA1O1xyXG4gICAgICB9XHJcbiAgICAgIGVuZCA9IGVuZE9mUmVmO1xyXG4gICAgICBpZiAoZW5kT2ZSZWYgPiBlbmRPZlJlZk5hbWVkKSB7XHJcbiAgICAgICAgZW5kID0gZW5kT2ZSZWZOYW1lZDtcclxuICAgICAgfVxyXG4gICAgICAvLyBzYXZlIGp1c3QgdGhlIHBhcnQgb2YgdGhlIGxpbmUgYWZ0ZXIgdGhlIG5hbWVcclxuICAgICAgbGV0IGxpbmUgPSBiaW9MaW5lU3RyaW5nLnN1YnN0cmluZyhzdGFydE9mUmVmLCBlbmQpO1xyXG4gICAgICBsZXQgcmVmU3RhcnQgPSBsaW5lLmluZGV4T2YoQmlvZ3JhcGh5LkVORF9CUkFDS0VUKTtcclxuICAgICAgaWYgKHJlZlN0YXJ0ID4gMCkge1xyXG4gICAgICAgIHJlZlN0YXJ0Kys7XHJcbiAgICAgICAgdGhpcy5uYW1lZFJlZlN0cmluZ0xpc3QucHVzaChsaW5lLnN1YnN0cmluZyhyZWZTdGFydCkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBtb3ZlIHBhc3QgdGhlIHJlZlxyXG4gICAgICBlbmQrKztcclxuICAgICAgZW5kT2ZSZWYrKztcclxuICAgICAgaWYgKGVuZCA8PSBiaW9MZW5ndGgpIHtcclxuICAgICAgICBzdGFydE9mUmVmID0gYmlvTGluZVN0cmluZy5pbmRleE9mKEJpb2dyYXBoeS5SRUZfU1RBUlRfTkFNRUQsIGVuZCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKGVuZCA+IGJpb0xlbmd0aCkge1xyXG4gICAgICAgICAgc3RhcnRPZlJlZiA9IC0xOyAgICAgICAgLy8gd2UgYXJlIGRvbmVcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogR2F0aGVyIGJpbyBzdGF0aXN0aWNzIGFuZCBzdHlsZSBpc3N1ZXNcclxuICAgKiBvbmx5IGV4YW1pbmVzIGl0ZW1zIG5vdCBjb25zaWRlcmVkIGluIHRoZSBwYXJzaW5nXHJcbiAgICogQmFzaWMgY2hlY2tzIGZvciB0aGUgaGVhZGluZ3MgYW5kIGNvbnRlbnQgZXhwZWN0ZWQgaW4gdGhlIGJpb2dyYXBoeVxyXG4gICAqIFVwZGF0ZSByZXN1bHRzIHN0eWxlXHJcbiAgICovXHJcbiAgc2V0QmlvU3RhdGlzdGljc0FuZFN0eWxlKCkge1xyXG4gICAgdGhpcy5iaW9SZXN1bHRzLnN0YXRzLnRvdGFsQmlvTGluZXMgPSB0aGlzLmJpb0xpbmVzLmxlbmd0aDtcclxuICAgIGlmICgodGhpcy5iaW9ncmFwaHlJbmRleCA+IDEpICYmICF0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuYmlvSGFzQ2F0ZWdvcmllcykge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzTm9uQ2F0ZWdvcnlUZXN0QmVmb3JlQmlvZ3JhcGh5SGVhZGluZyA9IHRydWU7ICAgICAgLy8gTk9UIGEgc3R5bGUgaXNzdWVcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmJpb2dyYXBoeUluZGV4IDwgMCkge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSXNNaXNzaW5nQmlvZ3JhcGh5SGVhZGluZyA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5zb3VyY2VzSW5kZXggPCAwKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9Jc01pc3NpbmdTb3VyY2VzSGVhZGluZyA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5yZWZlcmVuY2VzSW5kZXggPCAwKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9Jc01pc3NpbmdSZWZlcmVuY2VzVGFnID0gdHJ1ZTtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzTXVsdGlwbGVSZWZlcmVuY2VzVGFncykge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5taXNwbGFjZWRMaW5lQ291bnQgPCAwKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5taXNwbGFjZWRMaW5lQ291bnQgPSAwO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5taXNwbGFjZWRMaW5lQ291bnQgPiAwKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICB9XHJcbiAgICB0aGlzLmJpb1Jlc3VsdHMuc3RhdHMuaW5saW5lUmVmZXJlbmNlc0NvdW50ID1cclxuICAgICAgICAgdGhpcy5yZWZTdHJpbmdMaXN0Lmxlbmd0aCArIHRoaXMubmFtZWRSZWZTdHJpbmdMaXN0Lmxlbmd0aDtcclxuXHJcbiAgICB0aGlzLmJpb1Jlc3VsdHMuc3RhdHMucG9zc2libGVTb3VyY2VzTGluZUNvdW50ID0gdGhpcy5hY2tub3dsZWRnZW1lbnRzSW5kZXggLSAxO1xyXG4gICAgaWYgKHRoaXMuYmlvUmVzdWx0cy5zdGF0cy5wb3NzaWJsZVNvdXJjZXNMaW5lQ291bnQgPCAwKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdGF0cy5wb3NzaWJsZVNvdXJjZXNMaW5lQ291bnQgPSB0aGlzLmJpb0xpbmVzLmxlbmd0aDtcclxuICAgIH1cclxuICAgIHRoaXMuYmlvUmVzdWx0cy5zdGF0cy5wb3NzaWJsZVNvdXJjZXNMaW5lQ291bnQgPSB0aGlzLmJpb1Jlc3VsdHMuc3RhdHMucG9zc2libGVTb3VyY2VzTGluZUNvdW50IC1cclxuICAgIHRoaXMucmVmZXJlbmNlc0luZGV4ICsgMSArIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5taXNwbGFjZWRMaW5lQ291bnQ7XHJcbiAgICBpZiAodGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc0Fja25vd2xlZGdlbWVudHNCZWZvcmVTb3VyY2VzKSB7XHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKlxyXG4gICAqIERldGVybWluZSBpZiBCaW9ncmFwaHkgaGVhZGluZ1xyXG4gICAqIFVzZXMgcnVsZXMgdG8gY2hlY2sgZm9yIG11bHRpcGxlIGxhbmd1YWdlc1xyXG4gICAqIEFkZHMgYmlvIGhlYWRpbmdzIHRvIGFycmF5IG9mIGJpbyBoZWFkaW5ncyBmb3VuZFxyXG4gICAqIEBwYXJhbSBsaW5lIHRvIHRlc3RcclxuICAgKiBAcmV0dXJuIHRydWUgaWYgYmlvZ3JhcGh5IGhlYWRpbmcgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGlzQmlvZ3JhcGh5SGVhZGluZyhsaW5lKSB7XHJcbiAgICBsZXQgaXNCaW9IZWFkaW5nID0gZmFsc2U7XHJcbiAgICBsZXQgaSA9IDA7XHJcbiAgICB3aGlsZSAoKCFpc0Jpb0hlYWRpbmcpICYmIChpIDwgdGhpcy5zb3VyY2VSdWxlcy5iaW9ncmFwaHlIZWFkaW5ncy5sZW5ndGgpKSB7XHJcbiAgICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgodGhpcy5zb3VyY2VSdWxlcy5iaW9ncmFwaHlIZWFkaW5nc1tpXSkpIHtcclxuICAgICAgICBpc0Jpb0hlYWRpbmcgPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLmJpb0hlYWRpbmdzRm91bmQuaW5jbHVkZXMobGluZSkpIHtcclxuICAgICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzTXVsdGlwbGVCaW9IZWFkaW5ncyA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHRoaXMuYmlvSGVhZGluZ3NGb3VuZC5wdXNoKGxpbmUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpKys7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNCaW9IZWFkaW5nO1xyXG4gIH1cclxuICAvKlxyXG4gICAqIERldGVybWluZSBpZiBSZXNlYXJjaCBOb3RlcyBoZWFkaW5nXHJcbiAgICogVXNlcyBydWxlcyB0byBjaGVjayBmb3IgbXVsdGlwbGUgbGFuZ3VhZ2VzXHJcbiAgICogQHBhcmFtIGxpbmUgdG8gdGVzdFxyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiByZXNlYXJjaCBub3RlcyBoZWFkaW5nIGVsc2UgZmFsc2VcclxuICAgKi9cclxuICBpc1Jlc2VhcmNoTm90ZXNIZWFkaW5nKGxpbmUpIHtcclxuICAgIGxldCBpc1Jlc2VhcmNoTm90ZXNIZWFkaW5nID0gZmFsc2U7XHJcbiAgICBsZXQgaSA9IDA7XHJcbiAgICB3aGlsZSAoKCFpc1Jlc2VhcmNoTm90ZXNIZWFkaW5nKSAmJiAoaSA8IHRoaXMuc291cmNlUnVsZXMucmVzZWFyY2hOb3Rlc0hlYWRpbmdzLmxlbmd0aCkpIHtcclxuICAgICAgaWYgKGxpbmUuc3RhcnRzV2l0aCh0aGlzLnNvdXJjZVJ1bGVzLnJlc2VhcmNoTm90ZXNIZWFkaW5nc1tpXSkpIHtcclxuICAgICAgICBpc1Jlc2VhcmNoTm90ZXNIZWFkaW5nID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgICBpKys7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNSZXNlYXJjaE5vdGVzSGVhZGluZztcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogRGV0ZXJtaW5lIGlmIFNvdXJjZXMgaGVhZGluZ1xyXG4gICAqIFVzZXMgcnVsZXMgdG8gY2hlY2sgZm9yIG11bHRpcGxlIGxhbmd1YWdlc1xyXG4gICAqIEFkZHMgc291cmNlcyBoZWFkaW5ncyB0byBhcnJheSBvZiBzb3VyY2VzIGhlYWRpbmdzIGZvdW5kXHJcbiAgICogQHBhcmFtIGxpbmUgdG8gdGVzdFxyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiBzb3VyY2VzIGhlYWRpbmcgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGlzU291cmNlc0hlYWRpbmcobGluZSkge1xyXG4gICAgbGV0IGlzU291cmNlc0hlYWRpbmcgPSBmYWxzZTtcclxuICAgIGxldCBpID0gMDtcclxuICAgIHdoaWxlICgoIWlzU291cmNlc0hlYWRpbmcpICYmIChpIDwgdGhpcy5zb3VyY2VSdWxlcy5zb3VyY2VzSGVhZGluZ3MubGVuZ3RoKSkge1xyXG4gICAgICBpZiAobGluZS5zdGFydHNXaXRoKHRoaXMuc291cmNlUnVsZXMuc291cmNlc0hlYWRpbmdzW2ldKSkge1xyXG4gICAgICAgIGlzU291cmNlc0hlYWRpbmcgPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLnNvdXJjZXNIZWFkaW5nc0ZvdW5kLmluY2x1ZGVzKGxpbmUpKSB7XHJcbiAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgICAgICAgdGhpcy5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc011bHRpcGxlU291cmNlSGVhZGluZ3MgPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLnNvdXJjZXNIZWFkaW5nc0ZvdW5kLnB1c2gobGluZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGkrKztcclxuICAgIH1cclxuICAgIHJldHVybiBpc1NvdXJjZXNIZWFkaW5nO1xyXG4gIH1cclxuXHJcbiAgLypcclxuICAgKiBEZXRlcm1pbmUgaWYgQWNrbm93bGVkZ2VtZW50cyBoZWFkaW5nXHJcbiAgICogVXNlcyBydWxlcyB0byBjaGVjayBmb3IgbXVsdGlwbGUgbGFuZ3VhZ2VzXHJcbiAgICogQHBhcmFtIGxpbmUgdG8gdGVzdFxyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiBhY2tub3dsZWRnZW1lbnRzIGhlYWRpbmcgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGlzQWNrSGVhZGluZyhsaW5lKSB7XHJcbiAgICBsZXQgaXNBY2tIZWFkaW5nID0gZmFsc2U7XHJcbiAgICBsZXQgaSA9IDA7XHJcbiAgICB3aGlsZSAoKCFpc0Fja0hlYWRpbmcpICYmIChpIDwgdGhpcy5zb3VyY2VSdWxlcy5hY2tub3dsZWRnbWVudHNIZWFkaW5ncy5sZW5ndGgpKSB7XHJcbiAgICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgodGhpcy5zb3VyY2VSdWxlcy5hY2tub3dsZWRnbWVudHNIZWFkaW5nc1tpXSkpIHtcclxuICAgICAgICBpc0Fja0hlYWRpbmcgPSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICAgIGkrKztcclxuICAgIH1cclxuICAgIHJldHVybiBpc0Fja0hlYWRpbmc7XHJcbiAgfVxyXG5cclxuICAvKlxyXG4gICAqIFJlbW92ZSBSZXNlYXJjaCBOb3RlcyBmcm9tIGJpbyBsaW5lc1xyXG4gICAqIFJlbW92ZSBsaW5lcyBiZXR3ZWVuIHN0YXJ0IG9mIFJlc2VhcmNoIE5vdGVzXHJcbiAgICogYW5kIGVuZCBvZiBSZXNlYXJjaCBOb3Rlc1xyXG4gICAqIEFueSBjb250ZW50IG9mIFJlc2VhcmNoIE5vdGVzIGlzIG5vdCBjb25zaWRlcmVkXHJcbiAgICogYXMgYSBzb3VyY2VcclxuICAgKiBSZXNlYXJjaCBOb3RlcyBlbmQgd2hlbiBhIEJpb2dyYXBoeSBoZWFkaW5nIGlzIGZvdW5kXHJcbiAgICogb3IgYXQgdGhlIGZpcnN0IFNvdXJjZXMgb3IgQWNrbm93bGVkZ2VtZW50cyBoZWFkaW5nXHJcbiAgICovXHJcbiAgcmVtb3ZlUmVzZWFyY2hOb3RlcygpIHtcclxuICAgIGxldCBpID0gdGhpcy5yZXNlYXJjaE5vdGVzSW5kZXg7XHJcbiAgICBsZXQgZW5kSW5kZXggPSB0aGlzLnJlc2VhcmNoTm90ZXNFbmRJbmRleDtcclxuICAgIGlmIChlbmRJbmRleCA8IDApIHtcclxuICAgICAgZW5kSW5kZXggPSB0aGlzLmJpb0xpbmVzLmxlbmd0aDtcclxuICAgIH1cclxuICAgIGlmIChpID4gMCkge1xyXG4gICAgICB3aGlsZSAoaSA8PSBlbmRJbmRleCkge1xyXG4gICAgICAgIHRoaXMuYmlvTGluZXNbaV0gPSBcIlwiO1xyXG4gICAgICAgIGkrKztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLypcclxuICAgKiBSZW1vdmUgYWNrbm93bGVkZ2VtZW50cyBmcm9tIGJpbyBsaW5lc1xyXG4gICAqIFJlbW92ZSBsaW5lcyBiZXR3ZWVuIHN0YXJ0IG9mIEFja25vd2xlZGdlbWVudHNcclxuICAgKiBhbmQgZW5kIG9mIEFja25vd2xlZGdlbWVudHNcclxuICAgKiBBbnkgY29udGVudCBvZiBBY2tub3dsZWRnZW1lbnRzIGlzIG5vdCBjb25zaWRlcmVkXHJcbiAgICogYXMgYSBzb3VyY2VcclxuICAgKiBBY2tub3dsZWRnZW1lbnRzIGVuZCB3aGVuIGEgaGVhZGluZyBpcyBmb3VuZFxyXG4gICAqIG9yIGF0IHRoZSBlbmQgb2YgdGhlIGJpb2dyYXBoeVxyXG4gICAqL1xyXG4gIHJlbW92ZUFja25vd2xlZGdlbWVudHMoKSB7XHJcbiAgICBsZXQgaSA9IHRoaXMuYWNrbm93bGVkZ2VtZW50c0luZGV4O1xyXG4gICAgbGV0IGVuZEluZGV4ID0gdGhpcy5hY2tub3dsZWRnZW1lbnRzRW5kSW5kZXg7XHJcbiAgICBpZiAoZW5kSW5kZXggPCAwKSB7XHJcbiAgICAgICAgIGVuZEluZGV4ID0gdGhpcy5iaW9MaW5lcy5sZW5ndGg7XHJcbiAgICB9XHJcbiAgICBpZiAoaSA+IDApIHtcclxuICAgICAgd2hpbGUgKGkgPD0gZW5kSW5kZXgpIHtcclxuICAgICAgICB0aGlzLmJpb0xpbmVzW2ldID0gXCJcIjtcclxuICAgICAgICBpKys7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICAvKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgKiAqKioqKioqKioqKioqKioqKioqIFBSSVZBVEUgTUVUSE9EUyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgKiAqKioqKioqKioqKioqKioqKioqIHVzZWQgYnkgVmFsaWRhdG9yICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgKi9cclxuXHJcbiAgLypcclxuICAgKiBFeGFtaW5lIGEgc2luZ2xlIGxpbmUgdG8gc2VlIGlmIGl0IGlzIGEgdmFsaWQgc291cmNlXHJcbiAgICogQWRkcyBsaW5lIHRvIGFycmF5IG9mIHZhbGlkIG9yIGludmFsaWQgc291cmNlc1xyXG4gICAqIEBwYXJhbSBtaXhlZENhc2VMaW5lIGxpbmUgdG8gdGVzdCAoYW5kIHJlcG9ydClcclxuICAgKiBAcmV0dXJuIHRydWUgaWYgdmFsaWQgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGlzVmFsaWRTb3VyY2UobWl4ZWRDYXNlTGluZSkge1xyXG5cclxuICAgIGxldCBpc1ZhbGlkID0gZmFsc2U7ICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhc3N1bWUgZ3VpbHR5IFxyXG5cclxuICAgIC8vIGp1c3QgaWdub3JlIHN0YXJ0aW5nICpcclxuICAgIGlmIChtaXhlZENhc2VMaW5lLnN0YXJ0c1dpdGgoXCIqXCIpKSB7XHJcbiAgICAgICAgIG1peGVkQ2FzZUxpbmUgPSBtaXhlZENhc2VMaW5lLnN1YnN0cmluZygxKTtcclxuICAgIH1cclxuICAgIG1peGVkQ2FzZUxpbmUgPSBtaXhlZENhc2VMaW5lLnRyaW0oKTtcclxuICAgIFxyXG4gICAgLy8gcGVyZm9ybSB0ZXN0cyBvbiBsb3dlciBjYXNlIGxpbmVcclxuICAgIGxldCBsaW5lID0gbWl4ZWRDYXNlTGluZS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuICAgXHJcbiAgICAvLyBpZ25vcmUgc3RhcnRpbmcgc291cmNlOlxyXG4gICAgaWYgKChsaW5lLmxlbmd0aCA+IDApICYmIChsaW5lLnN0YXJ0c1dpdGgoQmlvZ3JhcGh5LlNPVVJDRV9TVEFSVCkpKSB7XHJcbiAgICAgICAgbGluZSA9IGxpbmUuc3Vic3RyaW5nKDcpO1xyXG4gICAgICAgIGxpbmUgPSBsaW5lLnRyaW0oKTtcclxuICAgIH1cclxuICAgIC8vIEl0IHRha2VzIGEgbWluaW11bSBudW1iZXIgb2YgY2hhcmFjdGVycyB0byBiZSB2YWxpZFxyXG4gICAgaWYgKGxpbmUubGVuZ3RoID49IEJpb2dyYXBoeS5NSU5fU09VUkNFX0xFTikge1xyXG5cclxuICAgICAgaWYgKCF0aGlzLmlzSW52YWxpZFN0YW5kQWxvbmVTb3VyY2UobGluZSkpIHtcclxuICAgICAgICBsaW5lID0gbGluZS50cmltKCk7XHJcbiAgICAgICAgLy8gRmluZEFHcmF2ZSBjaXRhdGlvbnMgbWF5IGhhdmUgcGFydGlhbCBzdHJpbmdzIHRoYXRcclxuICAgICAgICAvLyB3b3VsZCBvdGhlcndpc2Ugc2hvdyB1cCBhcyBpbnZhbGlkXHJcbiAgICAgICAgaWYgKHRoaXMuaXNGaW5kQUdyYXZlQ2l0YXRpb24obGluZSkpIHtcclxuICAgICAgICAgIGlzVmFsaWQgPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcblxyXG4gICAgICAgICAgLy8gRG9lcyBsaW5lIGNvbnRhaW4gYSBwaHJhc2Ugb24gdGhlIGludmFsaWQgcGFydGlhbCBzb3VyY2UgbGlzdD9cclxuICAgICAgICAgIGxldCBpbnZhbGlkU291cmNlU3RyaW5nID0gdGhpcy5vblBhcnRpYWxTb3VyY2VMaXN0KGxpbmUpO1xyXG4gICAgICAgICAgaWYgKGludmFsaWRTb3VyY2VTdHJpbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBpc1ZhbGlkID0gZmFsc2U7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBDaGVjayBmb3IgbGluZSB0aGF0IHN0YXJ0cyB3aXRoIHNvbWV0aGluZyBvbiB0aGUgaW52YWxpZCBzdGFydCBwYXJ0aWFsIGxpc3RcclxuICAgICAgICAgICAgbGV0IHBhcnRpYWxTb3VyY2VMaW5lID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGZvdW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGxldCBtYXggPSB0aGlzLnNvdXJjZVJ1bGVzLmludmFsaWRTdGFydFBhcnRpYWxTb3VyY2VMaXN0Lmxlbmd0aDtcclxuICAgICAgICAgICAgbGV0IGkgPSAwO1xyXG4gICAgICAgICAgICB3aGlsZSAoIWZvdW5kICYmIChpIDwgbWF4KSkge1xyXG4gICAgICAgICAgICAgIHBhcnRpYWxTb3VyY2VMaW5lID0gdGhpcy5zb3VyY2VSdWxlcy5pbnZhbGlkU3RhcnRQYXJ0aWFsU291cmNlTGlzdFtpXTtcclxuICAgICAgICAgICAgICBpZiAobGluZS5zdGFydHNXaXRoKHBhcnRpYWxTb3VyY2VMaW5lKSkge1xyXG4gICAgICAgICAgICAgICAgZm91bmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBpKys7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGZvdW5kKSB7XHJcbiAgICAgICAgICAgICAgaXNWYWxpZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAgICAgICAvLyBUT0RPIGNhbiB5b3UgcmVmYWN0b3Igc28gdGhpcyB1c2VzIGEgcGx1Z2luIGFyY2hpdGVjdHVyZT9cclxuXHJcbiAgICAgICAgICAgICAgLy8gU29tZSBvdGhlciB0aGluZ3MgdG8gY2hlY2tcclxuICAgICAgICAgICAgICBpZiAoIXRoaXMuaXNKdXN0Q2Vuc3VzKGxpbmUpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuaW52YWxpZEZhbWlseVRyZWUobGluZSkpIHtcclxuICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLmlzSnVzdFJlcG9zaXRvcnkobGluZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuaXNKdXN0R2VkY29tQ3J1ZChsaW5lKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gVE9ETyBhZGQgbW9yZSBsb2dpYyB0byBlbGltaW5hdGUgc291cmNlcyBhcyB2YWxpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gVE9ETyBpcyB0aGUgbWFuYWdlcidzIG5hbWUgYSB2YWxpZCBzb3VyY2UgKHRoaXMgaXMgaGFyZClcclxuICAgICAgICAgICAgICAgICAgICAgIC8vIFRPRE8gYWRkIGxvZ2ljIHRvIGNoZWNrIGZvciBqdXN0IHRoZSBuYW1lIGZvbGxvd2VkIGJ5IGdyYXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gICAgIC8vIGVuZGlmIHN0YXJ0cyB3aXRoIGludmFsaWQgcGhyYXNlXHJcbiAgICAgICAgICB9ICAgICAgIC8vIGVuZGlmIGNvbnRhaW5zIGEgcGhyYXNlIG9uIGludmFsaWQgcGFydGlhbCBzb3VyY2UgbGlzdFxyXG4gICAgICAgIH0gICAgICAgICAvLyBlbmRpZiBhIGZpbmRhZ3JhdmUgY2l0YXRpb25cclxuICAgICAgfSAgICAgICAgICAgLy8gZW5kaWYgb24gdGhlIGxpc3Qgb2YgaW52YWxpZCBzb3VyY2VzXHJcbiAgICB9ICAgICAgICAgICAgIC8vIGVuZGlmIHRvbyBzaG9ydCB3aGVuIHN0cmlwcGVkIG9mIHdoaXRlc3BhY2VcclxuXHJcbiAgICAvLyBTYXZlIGxpbmUgZm9yIHJlcG9ydGluZ1xyXG4gICAgaWYgKGlzVmFsaWQpIHsgXHJcbiAgICAgIHRoaXMuYmlvUmVzdWx0cy5zb3VyY2VzLnZhbGlkU291cmNlLnB1c2gobWl4ZWRDYXNlTGluZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc291cmNlcy5pbnZhbGlkU291cmNlLnB1c2gobWl4ZWRDYXNlTGluZSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNWYWxpZDtcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogRGV0ZXJtaW5lIGlmIHZhbGlkIHN0YW5kYWxvbmUgc291cmNlXHJcbiAgICogQHBhcmFtIGxpbmUgaW5wdXQgc291cmNlIHN0cmluZ1xyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiBvbiB0aGUgc3RhbmRhbG9uZSBsaXN0IG9mIGludmFsaWQgc291cmNlc1xyXG4gICAqL1xyXG4gIGlzSW52YWxpZFN0YW5kQWxvbmVTb3VyY2UobGluZSkge1xyXG5cclxuLy8gVE9ETyByZXZlcnNlIHRoaXMgYmFja3dhcmQgbG9naWMgdG8gY2hlY2sgaXNWYWxpZFN0YW5kQWxvbmVTb3VyY2VcclxuXHJcbiAgICBsZXQgaXNJbnZhbGlkU3RhbmRBbG9uZVNvdXJjZSA9IGZhbHNlO1xyXG4gICAgaWYgKHRoaXMuc291cmNlUnVsZXMuaW52YWxpZFNvdXJjZUxpc3QuaW5jbHVkZXMobGluZSkpIHtcclxuICAgICAgaXNJbnZhbGlkU3RhbmRBbG9uZVNvdXJjZSA9IHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAodGhpcy50b29PbGRUb1JlbWVtYmVyICYmICFpc0ludmFsaWRTdGFuZEFsb25lU291cmNlKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuc291cmNlUnVsZXMudG9vT2xkVG9SZW1lbWJlclNvdXJjZUxpc3QuaW5jbHVkZXMobGluZSkpIHtcclxuICAgICAgICAgIGlzSW52YWxpZFN0YW5kQWxvbmVTb3VyY2UgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZiAoKHRoaXMuaXNQcmUxNzAwIHx8IHRoaXMudHJlYXRBc1ByZTE3MDApXHJcbiAgICAgICAgICAgJiYgIWlzSW52YWxpZFN0YW5kQWxvbmVTb3VyY2UpIHtcclxuICAgICAgICBpZiAodGhpcy5zb3VyY2VSdWxlcy5pbnZhbGlkU291cmNlTGlzdFByZTE3MDAuaW5jbHVkZXMobGluZSkpIHtcclxuICAgICAgICAgIGlzSW52YWxpZFN0YW5kQWxvbmVTb3VyY2UgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZiAodGhpcy5iaW9SZXN1bHRzLmlzUHJlMTUwMCAmJiAhaXNJbnZhbGlkU3RhbmRBbG9uZVNvdXJjZSkge1xyXG4gICAgICAgIC8vIFRPRE8gYWRkIG1vcmUgcHJlMTUwMCB2YWxpZGF0aW9uXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpc0ludmFsaWRTdGFuZEFsb25lU291cmNlO1xyXG4gIH1cclxuXHJcbiAgLypcclxuICAgKiBEZXRlcm1pbmUgaWYgZm91bmQgb24gcGFydGlhbCBzb3VyY2UgbGlzdFxyXG4gICAqIEBwYXJhbSBsaW5lIGlucHV0IHNvdXJjZSBzdHJpbmdcclxuICAgKiBAcmV0dXJuIHN0cmluZyBpZiBvbiB0aGUgcGFydGlhbCBzb3VyY2UgbGlzdFxyXG4gICAqL1xyXG4gIG9uUGFydGlhbFNvdXJjZUxpc3QobGluZSkge1xyXG5cclxuICAgIGxldCBmb3VuZE9uUGFydGlhbFNvdXJjZUxpc3QgPSBmYWxzZTtcclxuICAgIGxldCBpbnZhbGlkU291cmNlU3RyaW5nID0gXCJcIjtcclxuICAgIGxldCBwYXJ0aWFsU291cmNlTGluZSA9IFwiXCI7XHJcbiAgICBsZXQgaSA9IDA7XHJcbiAgICB3aGlsZSAoIWZvdW5kT25QYXJ0aWFsU291cmNlTGlzdCAmJiAoaSA8IHRoaXMuc291cmNlUnVsZXMuaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0Lmxlbmd0aCkpIHtcclxuICAgICAgcGFydGlhbFNvdXJjZUxpbmUgPSB0aGlzLnNvdXJjZVJ1bGVzLmludmFsaWRQYXJ0aWFsU291cmNlTGlzdFtpXTtcclxuICAgICAgaWYgKGxpbmUuaW5jbHVkZXMocGFydGlhbFNvdXJjZUxpbmUpKSB7XHJcbiAgICAgICAgZm91bmRPblBhcnRpYWxTb3VyY2VMaXN0ID0gdHJ1ZTtcclxuICAgICAgICBpbnZhbGlkU291cmNlU3RyaW5nID0gcGFydGlhbFNvdXJjZUxpbmU7XHJcbiAgICAgIH1cclxuICAgICAgaSsrO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMudG9vT2xkVG9SZW1lbWJlciAmJiAhZm91bmRPblBhcnRpYWxTb3VyY2VMaXN0KSB7XHJcbiAgICAgIGkgPSAwO1xyXG4gICAgICB3aGlsZSAoIWZvdW5kT25QYXJ0aWFsU291cmNlTGlzdCAmJiAoaSA8IHRoaXMuc291cmNlUnVsZXMuaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0VG9vT2xkLmxlbmd0aCkpIHtcclxuICAgICAgICBwYXJ0aWFsU291cmNlTGluZSA9IHRoaXMuc291cmNlUnVsZXMuaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0VG9vT2xkW2ldO1xyXG4gICAgICAgIGlmIChsaW5lLmluY2x1ZGVzKHBhcnRpYWxTb3VyY2VMaW5lKSkge1xyXG4gICAgICAgICAgZm91bmRPblBhcnRpYWxTb3VyY2VMaXN0ID0gdHJ1ZTtcclxuICAgICAgICAgIGludmFsaWRTb3VyY2VTdHJpbmcgPSBwYXJ0aWFsU291cmNlTGluZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaSsrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoKHRoaXMuaXNQcmUxNzAwIHx8IHRoaXMudHJlYXRBc1ByZTE3MDApXHJcbiAgICAgICAgICYmICFmb3VuZE9uUGFydGlhbFNvdXJjZUxpc3QpIHtcclxuICAgICAgaSA9IDA7XHJcbiAgICAgIHdoaWxlICghZm91bmRPblBhcnRpYWxTb3VyY2VMaXN0ICYmIChpIDwgdGhpcy5zb3VyY2VSdWxlcy5pbnZhbGlkUGFydGlhbFNvdXJjZUxpc3RQcmUxNzAwLmxlbmd0aCkpIHtcclxuICAgICAgICBwYXJ0aWFsU291cmNlTGluZSA9IHRoaXMuc291cmNlUnVsZXMuaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0UHJlMTcwMFtpXTtcclxuICAgICAgICBpZiAobGluZS5pbmNsdWRlcyhwYXJ0aWFsU291cmNlTGluZSkpIHtcclxuICAgICAgICAgIGZvdW5kT25QYXJ0aWFsU291cmNlTGlzdCA9IHRydWU7XHJcbiAgICAgICAgICBpbnZhbGlkU291cmNlU3RyaW5nID0gcGFydGlhbFNvdXJjZUxpbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGkrKztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGludmFsaWRTb3VyY2VTdHJpbmc7XHJcbiAgfVxyXG5cclxuICAvKlxyXG4gICAqIERvZXMgc3RyaW5nIGNvbnRhaW4gYSBwaHJhc2Ugb24gdGhlIHZhbGlkIHBhcnRpYWwgc291cmNlIGxpc3RcclxuICAgKiBUaGlzIGlzIGEgdGVzdCBjYXNlIGZvciBzdHJpbmdzIHRoYXQgaWYgZm91bmQgbWVhbiB0aGUgcHJvZmlsZSBpcyBzb3VyY2VkXHJcbiAgICogKHRoYW5rcyB0byBEYXZpZCBTIGZvciB0aGUgdGVzdCBjYXNlKVxyXG4gICAqIEBwYXJhbSBzdHIgc3RyaW5nIHRvIGV2YWx1YXRlXHJcbiAgICogQHJldHVybiB0cnVlIGlmIHN0cmluZyBmb3VuZCwgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGNvbnRhaW5zVmFsaWRQYXJ0aWFsU291cmNlKHN0cikge1xyXG4gICAgbGV0IGZvdW5kID0gZmFsc2U7XHJcbiAgICBsZXQgcGFydGlhbFNvdXJjZUxpbmUgPSBcIlwiO1xyXG4gICAgbGV0IGkgPSAwO1xyXG4gICAgd2hpbGUgKCFmb3VuZCAmJiAoaSA8IHRoaXMuc291cmNlUnVsZXMudmFsaWRQYXJ0aWFsU291cmNlTGlzdC5sZW5ndGgpKSB7XHJcbiAgICAgIHBhcnRpYWxTb3VyY2VMaW5lID0gdGhpcy5zb3VyY2VSdWxlcy52YWxpZFBhcnRpYWxTb3VyY2VMaXN0W2ldO1xyXG4gICAgICBpZiAoc3RyLmluY2x1ZGVzKHBhcnRpYWxTb3VyY2VMaW5lKSkge1xyXG4gICAgICAgIGZvdW5kID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgICBpKys7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZm91bmQ7XHJcbiAgfVxyXG5cclxuICAvKiBcclxuICAgKiBWYWxpZGF0ZSBjb250ZW50IGluIDxyZWY+IHRhZ3NcclxuICAgKiBpbnZhbGlkU3BhblRhcmdldExpc3QgaXMgdXNlZCBpZiBsaW5lIGNvbnRhaW5zIGEgc3BhbiByZWZlcmVuY2VcclxuICAgKiBAcGFyYW0gcmVmU3RyaW5ncyBhcnJheSBvZiBzdHJpbmcgZm91bmQgd2l0aGluIHJlZiB0YWdcclxuICAgKiBAcmV0dXJuIHRydWUgaWYgYXQgbGVhc3Qgb25lIGlzIHZhbGlkIGVsc2UgZmFsc2VcclxuICAgKi9cclxuICB2YWxpZGF0ZVJlZlN0cmluZ3MocmVmU3RyaW5ncykge1xyXG5cclxuICAgIGxldCBpc1ZhbGlkID0gZmFsc2U7ICAgICAgICAgICAgICAgICAgLy8gZ3VpbHR5IHVudGlsIHByb3ZlbiBpbm5ub2NlbnRcclxuICAgIGxldCBsaW5lID0gXCJcIjtcclxuICAgIGxldCBpID0gMDtcclxuICAgIHdoaWxlIChpIDwgcmVmU3RyaW5ncy5sZW5ndGgpIHtcclxuICAgICAgbGluZSA9IHJlZlN0cmluZ3NbaV07XHJcbiAgICAgIGlmIChsaW5lLmxlbmd0aCA+IDApIHtcclxuXHJcbiAgICAgICAgLy8gQ2hlY2sgc3BhbiB0YXJnZXQgaWYgcmVmIGNvbnRhaW5zIGEgc3BhbiByZWZlcmVuY2VcclxuICAgICAgICBsZXQgc3RhcnRQb3MgPSBsaW5lLmluZGV4T2YoQmlvZ3JhcGh5LlNQQU5fUkVGRVJFTkNFX1NUQVJUKTtcclxuICAgICAgICBpZiAoc3RhcnRQb3MgPj0gMCkge1xyXG4gICAgICAgICAgc3RhcnRQb3MgPSBzdGFydFBvcyArIDM7XHJcbiAgICAgICAgICBsZXQgZW5kUG9zID0gbGluZS5pbmRleE9mKFwifFwiKTtcclxuICAgICAgICAgIGlmIChlbmRQb3MgPCAwKSB7XHJcbiAgICAgICAgICAgIGVuZFBvcyA9IGxpbmUuaW5kZXhPZihCaW9ncmFwaHkuU1BBTl9SRUZFUkVOQ0VfRU5EKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmICgoZW5kUG9zID4gMCkgJiYgKHN0YXJ0UG9zIDwgZW5kUG9zKSkge1xyXG4gICAgICAgICAgICBsZXQgc3BhbklkID0gbGluZS5zdWJzdHJpbmcoc3RhcnRQb3MsIGVuZFBvcyk7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5pbnZhbGlkU3BhblRhcmdldExpc3QuaW5jbHVkZXMoc3BhbklkKSkge1xyXG4gICAgICAgICAgICAgIGlzVmFsaWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICh0aGlzLmlzVmFsaWRTb3VyY2UobGluZSkpIHtcclxuICAgICAgICAgICAgaWYgKCFpc1ZhbGlkKSB7ICAgICAgICAgIC8vIGZpcnN0IG9uZSBmb3VuZD9cclxuICAgICAgICAgICAgICBpc1ZhbGlkID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpKys7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNWYWxpZDtcclxuICB9XHJcblxyXG4gIC8qIFxyXG4gICAqIFZhbGlkYXRlIGFsbCB0aGUgc3RyaW5ncyBhZnRlciB0aGUgPT0gU291cmNlcyBoZWFkaW5nXHJcbiAgICogYnV0IGJlZm9yZSBBY2tub3dsZWRnZW1lbnRzIG9yIHRoZSBlbmQgb2YgdGhlIGJpb2dyYXBoeVxyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiBhdCBsZWFzZSBvbmUgdmFsaWQgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIHZhbGlkYXRlUmVmZXJlbmNlU3RyaW5ncygpIHtcclxuICAgIGxldCBpc1ZhbGlkID0gZmFsc2U7XHJcblxyXG4gICAgLy8gc3RhcnQgYXQgdGhlIGZpcnN0IG9mIFNvdXJjZXMgb3IgPHJlZmVyZW5jZXMgLz4gaWYgbmVpdGhlciwgbm90aGluZyB0byBkb1xyXG4gICAgLy8gYXNzdW1lIGl0IGlzIHNvIG1lc3NlZCB1cCBub3RoaW5nIHRvIHByb2Nlc3NcclxuICAgIGxldCBpbmRleCA9IHRoaXMuc291cmNlc0luZGV4ICsgMTtcclxuICAgIGlmIChpbmRleCA8PSAwKSB7XHJcbiAgICAgIGluZGV4ID0gdGhpcy5yZWZlcmVuY2VzSW5kZXggKyAxO1xyXG4gICAgfVxyXG4gICAgaWYgKGluZGV4IDw9IDApIHtcclxuICAgICAgaW5kZXggPSB0aGlzLmJpb0xpbmVzLmxlbmd0aDtcclxuICAgIH1cclxuICAgIGxldCBsYXN0SW5kZXggPSB0aGlzLmJpb0xpbmVzLmxlbmd0aDtcclxuICAgIGxldCBsaW5lID0gXCJcIjtcclxuICAgIGxldCBuZXh0SW5kZXggPSBpbmRleCArIDE7XHJcbiAgICB3aGlsZSAoaW5kZXggPCBsYXN0SW5kZXgpIHtcclxuICAgICAgbGV0IG1peGVkQ2FzZUxpbmUgPSB0aGlzLmJpb0xpbmVzW2luZGV4XTtcclxuICAgICAgbGluZSA9IG1peGVkQ2FzZUxpbmUudG9Mb3dlckNhc2UoKTtcclxuICAgICAgLy8gaWYgbGluZSBub3RoaW5nIGJ1dCAtLS0gaWdub3JlIGl0XHJcbiAgICAgIGxldCB0bXBTdHJpbmcgPSBsaW5lLnJlcGxhY2VBbGwoJy0nLCAnICcpO1xyXG4gICAgICB0bXBTdHJpbmcgPSB0bXBTdHJpbmcudHJpbSgpO1xyXG4gICAgICBpZiAodG1wU3RyaW5nLmxlbmd0aCA8PSAwKSB7XHJcbiAgICAgICAgICBsaW5lID0gdG1wU3RyaW5nO1xyXG4gICAgICB9XHJcbiAgICAgIG5leHRJbmRleCA9IGluZGV4ICsgMTtcclxuICAgICAgLy8gU2tpcCB0aGUgPHJlZmVyZW5jZXMgbGluZSBhbmQgYW55IGhlYWRpbmcgbGluZSBvciBlbXB0eSBsaW5lXHJcbiAgICAgIGlmICgoIWxpbmUuc3RhcnRzV2l0aChCaW9ncmFwaHkuUkVGRVJFTkNFU19UQUcpKSAmJlxyXG4gICAgICAgICAgKCFsaW5lLnN0YXJ0c1dpdGgoQmlvZ3JhcGh5LkhFQURJTkdfU1RBUlQpKSAmJlxyXG4gICAgICAgICAgKGxpbmUubGVuZ3RoID4gMCkpIHtcclxuXHJcbiAgICAgICAgLy8gTm93IGdhdGhlciBhbGwgbGluZXMgZnJvbSB0aGlzIGxpbmUgdW50aWwgYW4gZW1wdHkgbGluZVxyXG4gICAgICAgIC8vIG9yIGEgbGluZSB0aGF0IHN0YXJ0cyB3aXRoICogdG8gdGVzdCBhcyB0aGUgc291cmNlXHJcbiAgICAgICAgbGV0IGNvbWJpbmVkTGluZSA9IG1peGVkQ2FzZUxpbmU7XHJcbiAgICAgICAgbGV0IGZvdW5kRW5kT2ZTb3VyY2UgPSBmYWxzZTtcclxuICAgICAgICB3aGlsZSAoKCFmb3VuZEVuZE9mU291cmNlKSAmJiAobmV4dEluZGV4IDwgbGFzdEluZGV4KSkge1xyXG4gICAgICAgICAgaWYgKG5leHRJbmRleCA8IGxhc3RJbmRleCkge1xyXG4gICAgICAgICAgICAvLyBjaGVjayBuZXh0IGxpbmVcclxuICAgICAgICAgICAgbGV0IG5leHRMaW5lID0gdGhpcy5iaW9MaW5lc1tuZXh0SW5kZXhdO1xyXG4gICAgICAgICAgICBpZiAobmV4dExpbmUubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgZm91bmRFbmRPZlNvdXJjZSA9IHRydWU7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgaWYgKChuZXh0TGluZS5zdGFydHNXaXRoKFwiKlwiKSkgfHwgKG5leHRMaW5lLnN0YXJ0c1dpdGgoXCItLVwiKSkgfHxcclxuICAgICAgICAgICAgICAgICAgKG5leHRMaW5lLnN0YXJ0c1dpdGgoXCIjXCIpKSB8fFxyXG4gICAgICAgICAgICAgICAgICAobmV4dExpbmUuc3RhcnRzV2l0aChCaW9ncmFwaHkuUkVGRVJFTkNFU19UQUcpKSB8fFxyXG4gICAgICAgICAgICAgICAgICAobmV4dExpbmUuc3RhcnRzV2l0aChCaW9ncmFwaHkuSEVBRElOR19TVEFSVCkpKSB7XHJcbiAgICAgICAgICAgICAgICBmb3VuZEVuZE9mU291cmNlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29tYmluZWRMaW5lID0gY29tYmluZWRMaW5lICsgXCIgXCIgKyBuZXh0TGluZTtcclxuICAgICAgICAgICAgICAgIG5leHRJbmRleCsrO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBtaXhlZENhc2VMaW5lID0gY29tYmluZWRMaW5lO1xyXG5cclxuICAgICAgICAvLyBBdCB0aGlzIHBvaW50LCB0aGUgbGluZSBzaG91bGQgbm90IGNvbnRhaW4gYW4gaW5saW5lIDxyZWZcclxuICAgICAgICAvLyBVbmxlc3MgYWxsIHRoZSByZWYgYXJlIGJldHdlZW4gU291cmNlcyBhbmQgcmVmZXJlbmNlc1xyXG4gICAgICAgIGlmICgobGluZS5pbmRleE9mKFwiPHJlZlwiKSA+PSAwKSAmJiAoaW5kZXggPiB0aGlzLnJlZmVyZW5jZXNJbmRleCkpIHtcclxuICAgICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTdHlsZUlzc3VlcyA9IHRydWU7XHJcbiAgICAgICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzUmVmQWZ0ZXJSZWZlcmVuY2VzID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKChpbmRleCA8IHRoaXMucmVmZXJlbmNlc0luZGV4KSB8fCBcclxuICAgICAgICAgICAgKHRoaXMucmVmZXJlbmNlc0luZGV4IDwgMCkpIHtcclxuICAgICAgICAgIHRoaXMuYmlvUmVzdWx0cy5zdHlsZS5taXNwbGFjZWRMaW5lQ291bnQrKztcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHNwYW5UYXJnZXRTdGFydFBvcyA9IG1peGVkQ2FzZUxpbmUuaW5kZXhPZihCaW9ncmFwaHkuU1BBTl9UQVJHRVRfU1RBUlQpO1xyXG4gICAgICAgIGlmIChzcGFuVGFyZ2V0U3RhcnRQb3MgPCAwKSB7XHJcbiAgICAgICAgICBpZiAodGhpcy5pc1ZhbGlkU291cmNlKG1peGVkQ2FzZUxpbmUpKSB7XHJcbiAgICAgICAgICAgIGlmICghaXNWYWxpZCkge1xyXG4gICAgICAgICAgICAgIGlzVmFsaWQgPSB0cnVlOyAgICAgICAvLyBmaXJzdCBvbmUgZm91bmRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBpZiAodGhpcy5pc1ZhbGlkU3BhblRhcmdldChtaXhlZENhc2VMaW5lKSkge1xyXG4gICAgICAgICAgICBpZiAoIWlzVmFsaWQpIHtcclxuICAgICAgICAgICAgICBpc1ZhbGlkID0gdHJ1ZTsgICAgICAgLy8gZmlyc3Qgb25lIGZvdW5kXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgaW5kZXggPSBuZXh0SW5kZXg7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNWYWxpZDtcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogVmFsaWRhdGUgc3RyaW5nIHRoYXQgaXMgYSBzcGFuIHRhcmdldFxyXG4gICAqIFNpZGUgZWZmZWN0OiBhZGQgdG8gaW52YWxpZFNwYW5UYXJnZXRMaXN0IGZvciBpbnZhbGlkIHRhcmdldFxyXG4gICAqIEBwYXJhbSBsaW5lIGxpbmUgdG8gYmUgZXZhbHVhdGVkXHJcbiAgICogQHBhcmFtIHN0YXJ0UG9zIHN0YXJ0aW5nIHBvc2l0aW9uIGluIGxpbmVcclxuICAgKiBAcmV0dXJuIHRydWUgaWYgdmFsaWQgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGlzVmFsaWRTcGFuVGFyZ2V0KG1peGVkQ2FzZUxpbmUpIHtcclxuICAgIGxldCBpc1ZhbGlkID0gZmFsc2U7XHJcbiAgICBsZXQgc3BhblRhcmdldFN0YXJ0UG9zID0gbWl4ZWRDYXNlTGluZS5pbmRleE9mKEJpb2dyYXBoeS5TUEFOX1RBUkdFVF9TVEFSVCk7XHJcbiAgICBsZXQgYmVmb3JlU3BhbiA9IG1peGVkQ2FzZUxpbmUuc3Vic3RyaW5nKDAsIHNwYW5UYXJnZXRTdGFydFBvcyAtIDEpO1xyXG5cclxuICAgIC8vIGV4dHJhY3QgdGFyZ2V0IGlkIGZvdW5kIGhlcmUgPHNwYW4gaWQ9J0lEJz5cclxuICAgIGxldCBwb3MgPSBtaXhlZENhc2VMaW5lLmluZGV4T2YoXCI9XCIpO1xyXG4gICAgcG9zKys7IC8vIHNraXAgdGhlID1cclxuICAgIHBvcysrOyAvLyBza2lwIHRoZSAnXHJcbiAgICBsZXQgZW5kUG9zID0gbWl4ZWRDYXNlTGluZS5pbmRleE9mKFwiJ1wiLCBwb3MpO1xyXG4gICAgbGV0IHNwYW5JZCA9IG1peGVkQ2FzZUxpbmUuc3Vic3RyaW5nKHBvcywgZW5kUG9zKTtcclxuXHJcbiAgICAvLyBQcm9jZXNzIHRoZSBsaW5lIHN0YXJ0aW5nIGFmdGVyIHRoZSBlbmQgb2YgdGhlIHNwYW4gdGFyZ2V0XHJcbiAgICAvLyBidXQgaXQgbWlnaHQgaGF2ZSBzb3VyY2Ugb3IgcmVwb3NpdG9yeSBiZWZvcmUgdGhlIDxzcGFuPlxyXG4gICAgcG9zID0gbWl4ZWRDYXNlTGluZS5pbmRleE9mKEJpb2dyYXBoeS5TUEFOX1RBUkdFVF9FTkQpO1xyXG4gICAgaWYgKHBvcyA+IDApIHtcclxuICAgICAgcG9zID0gcG9zICsgQmlvZ3JhcGh5LlNQQU5fVEFSR0VUX0VORC5sZW5ndGg7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3R5bGVJc3N1ZXMgPSB0cnVlO1xyXG4gICAgICB0aGlzLmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzU3BhbldpdGhvdXRFbmRpbmdTcGFuID0gdHJ1ZTtcclxuICAgICAgcG9zID0gbWl4ZWRDYXNlTGluZS5sZW5ndGg7XHJcbiAgICB9XHJcbiAgICBpZiAocG9zIDwgbWl4ZWRDYXNlTGluZS5sZW5ndGgpIHtcclxuICAgICAgLy8gc29tZXRoaW5nIGFmdGVyIGVuZGluZyBzcGFuXHJcbiAgICAgIG1peGVkQ2FzZUxpbmUgPSBiZWZvcmVTcGFuICsgXCIgXCIgKyBtaXhlZENhc2VMaW5lLnN1YnN0cmluZyhwb3MpLnRyaW0oKTtcclxuICAgICAgaXNWYWxpZCA9IHRoaXMuaXNWYWxpZFNvdXJjZShtaXhlZENhc2VMaW5lKTtcclxuICAgIH1cclxuICAgIGlmICghaXNWYWxpZCkge1xyXG4gICAgICAgIHRoaXMuaW52YWxpZFNwYW5UYXJnZXRMaXN0LnB1c2goc3BhbklkKTtcclxuICAgIH1cclxuICAgIHJldHVybiBpc1ZhbGlkO1xyXG4gIH1cclxuXHJcbiAgLypcclxuICAgKiBDaGVjayBmb3IgYSBsaW5lIHRoYXQgaXMganVzdFxyXG4gICAqIHNvbWUgY29sbGVjdGlvbiBvZiBudW1iZXJzIGFuZCBkaWdpdHMgdGhlbiBjZW5zdXNcclxuICAgKiBAcGFyYW0gbGluZSB0byBjaGVja1xyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiBqdXN0IGEgY2Vuc3VzIGxpbmUgZWxzZSBmYWxzZVxyXG4gICAqL1xyXG4gIGlzSnVzdENlbnN1cyhsaW5lKSB7XHJcblxyXG4gICAgbGV0IGlzQ2Vuc3VzID0gZmFsc2U7XHJcbiAgICBsaW5lID0gbGluZS5yZXBsYWNlKC9bXmEteiBdL2csIFwiXCIpO1xyXG4gICAgbGluZSA9IGxpbmUudHJpbSgpO1xyXG4gICAgaWYgKHRoaXMuc291cmNlUnVsZXMuY2Vuc3VzU3RyaW5ncy5pbmNsdWRlcyhsaW5lKSkge1xyXG4gICAgICBpc0NlbnN1cyA9IHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBnZXQgdGhlIGNlbnN1cyBzdHJpbmcgcG9ydGlvbiBvZiB0aGUgbGluZVxyXG4gICAgICBsZXQgdGhlU3RyID0gdGhpcy5oYXNDZW5zdXNTdHJpbmcobGluZSk7XHJcbiAgICAgIGlmICh0aGVTdHIubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIC8vIGxvc2UgY2Vuc3VzLCBhdCwgb24gYW5kIGV2ZXJ5dGhpbmcgbm90IGFuIGFscGhhIGNoYXJcclxuICAgICAgICBsaW5lID0gbGluZS5yZXBsYWNlKHRoZVN0ciwgXCJcIik7XHJcbiAgICAgICAgbGluZSA9IGxpbmUucmVwbGFjZSgvYXQvZywgXCJcIik7XHJcbiAgICAgICAgbGluZSA9IGxpbmUucmVwbGFjZSgvb24vZywgXCJcIik7XHJcbiAgICAgICAgbGluZSA9IGxpbmUucmVwbGFjZSgvW15hLXpdL2csIFwiXCIpO1xyXG4gICAgICAgIGxpbmUgPSBsaW5lLnRyaW0oKTtcclxuICAgICAgICBpZiAobGluZS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgIGlzQ2Vuc3VzID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8gbG9zZSB0aGluZ3MgbGlrZSBhbmNlc3RyeSwgZmFtaWx5c2VhcmNoIGJ5IHRoZW1zZWx2ZXNcclxuICAgICAgICAgIGlmICh0aGlzLnNvdXJjZVJ1bGVzLmludmFsaWRTb3VyY2VMaXN0LmluY2x1ZGVzKGxpbmUpKSB7XHJcbiAgICAgICAgICAgIGlzQ2Vuc3VzID0gdHJ1ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmIChpc0NlbnN1cykge1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqIERvZXMgbGluZSBjb250YWluIGEgY2Vuc3VzXHJcbiAgKiBAcGFyYW0gbGluZSBsaW5lIHRvIHRlc3RcclxuICAqIEByZXR1cm4gY2Vuc3VzIHN0cmluZyBpZiBsaW5lIGNvbnRhaW5zIGNlbnN1cyBzdHJpbmdcclxuICAqL1xyXG4gIGhhc0NlbnN1c1N0cmluZyhsaW5lKSB7XHJcbiAgICBsZXQgdGhlU3RyID0gXCJcIjtcclxuICAgIGxldCBpc0NlbnN1c1N0cmluZyA9IGZhbHNlO1xyXG4gICAgbGV0IGkgPSAwO1xyXG4gICAgd2hpbGUgKCghaXNDZW5zdXNTdHJpbmcpICYmIChpIDwgdGhpcy5zb3VyY2VSdWxlcy5jZW5zdXNTdHJpbmdzLmxlbmd0aCkpIHtcclxuICAgICAgaWYgKGxpbmUuaW5jbHVkZXModGhpcy5zb3VyY2VSdWxlcy5jZW5zdXNTdHJpbmdzW2ldKSkge1xyXG4gICAgICAgIGlzQ2Vuc3VzU3RyaW5nID0gdHJ1ZTtcclxuICAgICAgICB0aGVTdHIgPSB0aGlzLnNvdXJjZVJ1bGVzLmNlbnN1c1N0cmluZ3NbaV07XHJcbiAgICAgIH1cclxuICAgICAgaSsrO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoZVN0cjtcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogQ2hlY2sgZm9yIGEgbGluZSB0aGF0IGNvbnRhaW5zIGJvdGggZmluZGFncmF2ZSBhbmQgY3JlYXRlZCBieVxyXG4gICAqIGNyZWF0ZWQgYnkgaXMgYW4gaW52YWxpZCBwYXJ0aWFsIHNvdXJjZSBzdHJpbmcgVU5MRVNTIHBhcnQgb2YgYSBmaW5kYWdyYXZlXHJcbiAgICogY2l0YXRpb25cclxuICAgKiBAcGFyYW0gbGluZSB0byB0ZXN0XHJcbiAgICogQHJldHVybiB0cnVlIGlmIGxpbmUgY29udGFpbnMgYm90aCBmaW5kYWdyYXZlIGFuZCBjcmVhdGVkIGJ5XHJcbiAgICovXHJcbiAgaXNGaW5kQUdyYXZlQ2l0YXRpb24obGluZSkge1xyXG4gICAgaWYgKCgobGluZS5pbmRleE9mKFwiZmluZGFncmF2ZVwiKSkgPj0gMCkgJiYgXHJcbiAgICAgICAgKChsaW5lLmluZGV4T2YoXCJjcmVhdGVkIGJ5XCIpKSA+PTApKSB7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLypcclxuICAgKiBDaGVjayBmb3IgQW5jZXN0cnkgRmFtaWx5IFRyZWVzIHdpdGhvdXQgYSB0cmVlIGlkIFxyXG4gICAqIG9yIGEgdHJlZSBpZCBsZXNzIHRoYW4gNCBjaGFyYWN0ZXJzLCBzdWNoIGFzIDBcclxuICAgKiBAcGFyYW0gbGluZSB0byB0ZXN0XHJcbiAgICogQHJldHVybiB0cnVlIGlmIEFuY2VzdHJ5IHRyZWUgc2VlbXMgdG8gaGF2ZSBhbiBpZFxyXG4gICAqL1xyXG4gIGludmFsaWRGYW1pbHlUcmVlKGxpbmUpIHtcclxuICAgIGxldCBpc0ludmFsaWRGYW1pbHlUcmVlID0gZmFsc2U7XHJcbiAgICBsZXQgc3RhcnRQb3MgPSBsaW5lLmluZGV4T2YoXCJhbmNlc3RyeSBmYW1pbHkgdHJlZVwiKTtcclxuICAgIGlmIChzdGFydFBvcyA8IDApIHtcclxuICAgICAgc3RhcnRQb3MgPSBsaW5lLmluZGV4T2YoXCJwdWJsaWMgbWVtYmVyIHRyZWVcIik7XHJcbiAgICAgIGlmIChzdGFydFBvcyA8IDApIHtcclxuICAgICAgICBzdGFydFBvcyA9IGxpbmUuaW5kZXhPZihcImFuY2VzdHJ5IG1lbWJlciBmYW1pbHkgdHJlZVwiKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoc3RhcnRQb3MgPCAwKSB7XHJcbiAgICAgICAgc3RhcnRQb3MgPSBsaW5lLmluZGV4T2YoXCJ7e2FuY2VzdHJ5IHRyZWVcIik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmIChzdGFydFBvcyA+PSAwKSB7XHJcbiAgICAgIGxpbmUgPSBsaW5lLnN1YnN0cmluZyhzdGFydFBvcyk7XHJcbiAgICAgIGxldCBoYXNJZCA9IGZhbHNlO1xyXG4gICAgICBsZXQgbWF0Y2hlcyA9IGxpbmUubWF0Y2goLyhcXGQrKS9nKTtcclxuICAgICAgaWYgKG1hdGNoZXMpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1hdGNoZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgIGlmIChtYXRjaGVzW2ldLmxlbmd0aCA+IDQpIHtcclxuICAgICAgICAgICAgaGFzSWQgPSB0cnVlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZiAoIWhhc0lkKSB7XHJcbiAgICAgICAgaXNJbnZhbGlkRmFtaWx5VHJlZSA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpc0ludmFsaWRGYW1pbHlUcmVlO1xyXG4gIH1cclxuXHJcbiAgLypcclxuICAgKiBDaGVjayBmb3IganVzdCBhIHJlcG9zaXRvcnlcclxuICAgKiBAcGFyYW0gbGluZSB0byB0ZXN0XHJcbiAgICogQHJldHVybiB0cnVlIGlmIHRoaXMgaXMganVzdCBhIHJlcG9zaXRvcnkgbGluZVxyXG4gICAqL1xyXG4gIGlzSnVzdFJlcG9zaXRvcnkobGluZSkge1xyXG4gICAgbGV0IGlzUmVwb3NpdG9yeSA9IGZhbHNlO1xyXG4gICAgaWYgKGxpbmUuaW5jbHVkZXMoXCJyZXBvc2l0b3J5XCIpKSB7XHJcbiAgICAgIGxldCByZXBvc2l0b3J5U3RyaW5ncyA9IFtcclxuICAgICAgICBcImFuY2VzdHJ5XCIsXHJcbiAgICAgICAgXCJjb21cIixcclxuICAgICAgICBcIm5hbWVcIixcclxuICAgICAgICBcImFkZHJlc3NcIixcclxuICAgICAgICBcImh0dHBcIixcclxuICAgICAgICBcInd3d1wiLFxyXG4gICAgICAgIFwidGhlIGNodXJjaCBvZiBqZXN1cyBjaHJpc3Qgb2YgbGF0dGVyLWRheSBzYWludHNcIixcclxuICAgICAgICBcIm5vdGVcIixcclxuICAgICAgICBcImZhbWlseSBoaXN0b3J5IGxpYnJhcnlcIixcclxuICAgICAgICBcIm4gd2VzdCB0ZW1wbGUgc3RyZWV0XCIsXHJcbiAgICAgICAgXCJzYWx0IGxha2UgY2l0eVwiLFxyXG4gICAgICAgIFwidXRhaFwiLFxyXG4gICAgICAgIFwidXNhXCIsXHJcbiAgICAgICAgXCIzNjAgd2VzdCA0ODAwIG5vcnRoXCIsXHJcbiAgICAgICAgXCJwcm92b1wiLFxyXG4gICAgICAgIFwidXRcIixcclxuICAgICAgICBcImNpdHlcIixcclxuICAgICAgICBcImNvdW50cnlcIiwgXHJcbiAgICAgICAgXCJub3QgZ2l2ZW5cIixcclxuICAgICAgICBcImUtbWFpbFwiLFxyXG4gICAgICAgIFwicGhvbmUgbnVtYmVyXCIsXHJcbiAgICAgICAgXCJpbnRlcm5ldFwiLFxyXG4gICAgICAgIFwiY29udFwiLFxyXG4gICAgICAgIFwidW5rbm93blwiLFxyXG4gICAgICBdO1xyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlcG9zaXRvcnlTdHJpbmdzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgbGV0IHN0ciA9IHJlcG9zaXRvcnlTdHJpbmdzW2ldO1xyXG4gICAgICAgIGxpbmUgPSBsaW5lLnJlcGxhY2VBbGwoc3RyLCBcIlwiKTtcclxuICAgICAgfVxyXG4gICAgICBsaW5lID0gbGluZS5yZXBsYWNlKC9yLS9nLCBcIlwiKTtcclxuICAgICAgbGluZSA9IGxpbmUucmVwbGFjZSgvI3IvZywgXCJcIik7XHJcbiAgICAgIGxpbmUgPSBsaW5lLnJlcGxhY2UoL1teYS16XS9nLCBcIlwiKTtcclxuICAgICAgbGluZSA9IGxpbmUudHJpbSgpO1xyXG4gICAgICBpZiAobGluZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgaWYgKGxpbmUgPT09IFwicmVwb3NpdG9yeVwiKSB7XHJcbiAgICAgICAgICBpc1JlcG9zaXRvcnkgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGlzUmVwb3NpdG9yeTtcclxuICB9XHJcblxyXG4gIC8qXHJcbiAgICogY2hlY2sgZm9yIEdFRENPTSBjcnVkIHNlZSBTdWdnZXN0aW9uIDg1M1xyXG4gICAqIGluIG1vc3QgY2FzZXMgdGhpcyBpcyBpbiB0aGUgQmlvIG5vdCBzb3VyY2VzLCBcclxuICAgKiBzbyB5b3UgZG9uJ3Qgc2VlIGl0XHJcbiAgICogQHBhcmFtIGxpbmUgbGluZSB0byB0ZXN0XHJcbiAgICogQHJldHVybiB0cnVlIGlmIGxpbmUgY29udGFpbnMgR0VEQ09NIGNydWQgYW5kIG5vdGhpbmcgZWxzZVxyXG4gICAqL1xyXG4gIGlzSnVzdEdlZGNvbUNydWQobGluZSkge1xyXG4gICAgbGV0IGlzR2VkY29tQ3J1ZCA9IGZhbHNlO1xyXG4gICAgbGV0IGNydWRTdHJpbmdzID0gW1xyXG4gICAgICBcInVzZXIgaWRcIixcclxuICAgICAgXCJkYXRhIGNoYW5nZWRcIixcclxuICAgICAgXCJsZHMgZW5kb3dtZW50XCIsXHJcbiAgICAgIFwibGRzIGJhcHRpc21cIixcclxuICAgICAgXCJyZWNvcmQgZmlsZSBudW1iZXJcIixcclxuICAgICAgXCJzdWJtaXR0ZXJcIixcclxuICAgICAgXCJvYmplY3RcIixcclxuICAgICAgXCJjb2xvclwiLFxyXG4gICAgICBcInVwZFwiLFxyXG4gICAgICBcInBwZXhjbHVkZVwiLFxyXG4gICAgXTtcclxuICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgoXCI6XCIpKSB7XHJcbiAgICAgIGxpbmUgPSBsaW5lLnN1YnN0cmluZygxKTtcclxuICAgIH1cclxuICAgIGxpbmUgPSBsaW5lLnRyaW0oKTtcclxuICAgIGxldCBpID0gMDtcclxuICAgIHdoaWxlICgoaSA8IGNydWRTdHJpbmdzLmxlbmd0aCkgJiYgKCFpc0dlZGNvbUNydWQpKSB7XHJcbiAgICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgoY3J1ZFN0cmluZ3NbaV0pKSB7XHJcbiAgICAgICAgaXNHZWRjb21DcnVkID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgICBpKys7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXNHZWRjb21DcnVkO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiLypcclxuVGhlIE1JVCBMaWNlbnNlIChNSVQpXHJcblxyXG5Db3B5cmlnaHQgKGMpIDIwMjIgS2F0aHJ5biBKIEtuaWdodFxyXG5cclxuUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluXHJcbnRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG9cclxudXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2ZcclxudGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLFxyXG5zdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczpcclxuXHJcblRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkIGluIGFsbFxyXG5jb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxyXG5cclxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUlxyXG5JTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTU1xyXG5GT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1JcclxuQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSXHJcbklOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOXHJcbkNPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXHJcbiovXHJcbi8qKlxyXG4gKiBIb2xkIHJlc3VsdHMgZm9yIHBhcnNlIGFuZCB2YWxpZGF0ZSBhIFdpa2lUcmVlIGJpb2dyYXBoeVxyXG4gKi9cclxuZXhwb3J0IGNsYXNzIEJpb2dyYXBoeVJlc3VsdHMge1xyXG5cclxuICAgYmlvUmVzdWx0cyA9IHtcclxuXHJcbiAgICAgIHN0YXRzOiB7XHJcbiAgICAgICAgIGJpb0lzRW1wdHk6IGZhbHNlLFxyXG4gICAgICAgICBiaW9IYXNDYXRlZ29yaWVzOiBmYWxzZSxcclxuICAgICAgICAgYmlvSXNNYXJrZWRVbnNvdXJjZWQ6IGZhbHNlLFxyXG4gICAgICAgICBiaW9Jc1VuY2VydGFpbkV4aXN0YW5jZTogZmFsc2UsXHJcbiAgICAgICAgIGJpb0lzVW5kYXRlZDogZmFsc2UsXHJcbiAgICAgICAgIHRvdGFsQmlvTGluZXM6IDAsXHJcbiAgICAgICAgIGlubGluZVJlZmVyZW5jZXNDb3VudDogMCwgICAgICAvLyBudW1iZXIgb2YgPHJlZj5cclxuICAgICAgICAgcG9zc2libGVTb3VyY2VzTGluZUNvdW50OiAwICAgLy8gbnVtYmVyIG9mIGxpbmVzIHRoYXQgbWlnaHQgY29udGFpbiBzb3VyY2VzXHJcbiAgICAgIH0sXHJcbiAgICAgIHN0eWxlOiB7XHJcbiAgICAgICAgIGJpb0hhc05vbkNhdGVnb3J5VGVzdEJlZm9yZUJpb2dyYXBoeUhlYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgICBiaW9IYXNTdHlsZUlzc3VlczogZmFsc2UsXHJcbiAgICAgICAgIGhhc0VuZGxlc3NDb21tZW50OiBmYWxzZSxcclxuICAgICAgICAgYmlvSXNNaXNzaW5nQmlvZ3JhcGh5SGVhZGluZzogZmFsc2UsXHJcbiAgICAgICAgIGJpb0hlYWRpbmdXaXRoTm9MaW5lc0ZvbGxvd2luZzogZmFsc2UsXHJcbiAgICAgICAgIGJpb0hhc011bHRpcGxlQmlvSGVhZGluZ3M6IGZhbHNlLFxyXG4gICAgICAgICBiaW9IYXNSZWZXaXRob3V0RW5kOiBmYWxzZSxcclxuICAgICAgICAgYmlvSGFzU3BhbldpdGhvdXRFbmRpbmdTcGFuOiBmYWxzZSxcclxuICAgICAgICAgYmlvSXNNaXNzaW5nU291cmNlc0hlYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgICBzb3VyY2VzSGVhZGluZ0hhc0V4dHJhRXF1YWw6IGZhbHNlLFxyXG4gICAgICAgICBiaW9IYXNNdWx0aXBsZVNvdXJjZUhlYWRpbmdzOiBmYWxzZSxcclxuICAgICAgICAgbWlzcGxhY2VkTGluZUNvdW50OiAwLCAgICAgIC8vIGJldHdlZW4gU291cmNlcyBhbmQgPHJlZmVyZW5jZXMgLz4gXHJcbiAgICAgICAgIGJpb0lzTWlzc2luZ1JlZmVyZW5jZXNUYWc6IGZhbHNlLFxyXG4gICAgICAgICBiaW9IYXNNdWx0aXBsZVJlZmVyZW5jZXNUYWdzOiBmYWxzZSxcclxuICAgICAgICAgYmlvSGFzUmVmQWZ0ZXJSZWZlcmVuY2VzOiBmYWxzZSxcclxuICAgICAgICAgYWNrbm93bGVkZ2VtZW50c0hlYWRpbmdIYXNFeHRyYUVxdWFsOiBmYWxzZSxcclxuICAgICAgICAgYmlvSGFzQWNrbm93bGVkZ2VtZW50c0JlZm9yZVNvdXJjZXM6IGZhbHNlLFxyXG4gICAgICAgICBiaW9Jc0F1dG9HZW5lcmF0ZWQ6IGZhbHNlXHJcbiAgICAgIH0sXHJcbiAgICAgIHNvdXJjZXM6IHtcclxuICAgICAgICAgc291cmNlc0ZvdW5kOiBmYWxzZSxcclxuXHJcbiAgICAgICAgIC8vIEludmFsaWQgc291cmNlcyB0aGF0IHdlcmUgZm91bmQgLSBlYWNoIGFuIGFycmF5XHJcbiAgICAgICAgIC8vIG1pZ2h0IG5vdCBuZWVkL3dhbnQgdGhlc2UsIGRlcGVuZHMgb24gcmVwb3J0aW5nXHJcbiAgICAgICAgIGludmFsaWRTb3VyY2U6IFtdLFxyXG4gICAgICAgICAvL2ludmFsaWRTdGFuZEFsb25lU291cmNlOiBbXSxcclxuICAgICAgICAgLy9pbnZhbGlkUGFydGlhbFNvdXJjZTogW10sXHJcbiAgICAgICAgIC8vaW52YWxpZFN0YXJ0UGFydGlhbFNvdXJjZTogW10sXHJcbiAgICAgICAgIC8vaW52YWxpZFNwYW5UYXJnZXRTb3VyY2U6IFtdLFxyXG4gICAgICAgICB2YWxpZFNvdXJjZTogW10sXHJcbiAgICAgIH1cclxuICAgfTtcclxuXHJcbiAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICB9XHJcblxyXG4gICBnZXRSZXN1bHRzKCkge1xyXG4gICAgIHJldHVybiB0aGlzLmJpb1Jlc3VsdHM7XHJcbiAgIH1cclxufVxyXG4iLCIvKlxyXG5UaGUgTUlUIExpY2Vuc2UgKE1JVClcclxuXHJcbkNvcHlyaWdodCAoYykgMjAyMiBLYXRocnluIEogS25pZ2h0XHJcblxyXG5QZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mXHJcbnRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW5cclxudGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0b1xyXG51c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZlxyXG50aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sXHJcbnN1YmplY3QgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb25zOlxyXG5cclxuVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4gYWxsXHJcbmNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXHJcblxyXG5USEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SXHJcbklNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTXHJcbkZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUlxyXG5DT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVJcclxuSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU5cclxuQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cclxuKi9cclxuLyoqXHJcbiAqIENvbnRhaW5zIGluZm9ybWF0aW9uIGFib3V0IGEgV2lraVRyZWUgUHJvZmlsZVxyXG4gKiBvbmx5IGNvbnRhaW5zIGEgc3Vic2V0IG9mIHRoZSBjb21wbGV0ZSBzZXQgb2YgZGF0YSBhdmFpbGFibGVcclxuICovXHJcbmV4cG9ydCBjbGFzcyBQZXJzb25EYXRlIHtcclxuXHJcbiAgc3RhdGljIFRPT19PTERfVE9fUkVNRU1CRVJfREVBVEggPSAxMDA7XHJcbiAgc3RhdGljIFRPT19PTERfVE9fUkVNRU1CRVJfQklSVEggPSAxNTA7XHJcblxyXG4gIHBlcnNvbkRhdGUgPSB7XHJcbiAgICBiaXJ0aERhdGU6IG51bGwsICAgICAgICAgICAgICAgIC8vIGJpcnRoIGRhdGUgYXMgRGF0ZVxyXG4gICAgZGVhdGhEYXRlOiBudWxsLCAgICAgICAgICAgICAgICAvLyBkZWF0aCBkYXRlIGFzIERhdGVcclxuICAgIGJpcnRoRGF0ZVN0cmluZzogXCJcIiwgICAgICAgICAgICAvLyBiaXJ0aCBkYXRlIHN0cmluZyBhcyBmcm9tIHNlcnZlclxyXG4gICAgZGVhdGhEYXRlU3RyaW5nOiBcIlwiLCAgICAgICAgICAgIC8vIGRlYXRoIGRhdGUgc3RyaW5nIGFzIGZyb20gc2VydmVyXHJcbiAgICBoYXNCaXJ0aERhdGU6IHRydWUsXHJcbiAgICBoYXNEZWF0aERhdGU6IHRydWUsXHJcbiAgICBsYXN0RGF0ZUNoZWNrZWRFbXB0eTogZmFsc2UsICAgLy8gSEFDS1xyXG4gICAgb25lWWVhckFnbzogbnVsbCxcclxuICAgIGlzUHJlMTcwMDogZmFsc2UsXHJcbiAgICBpc1ByZTE1MDA6IGZhbHNlLFxyXG4gICAgdG9vT2xkVG9SZW1lbWJlcjogZmFsc2UsXHJcbiAgICBwZXJzb25VbmRhdGVkOiBmYWxzZSxcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGNvbnN0cnVjdG9yXHJcbiAgICovXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBJbml0aWFsaXplIHBlcnNvbiBkYXRlcyBmcm9tIG51bGwsIDAwMDAgb3IgdmFyaW91cyBmb3Jtc1xyXG4gICAqIEBwYXJhbSBiRGF5IGJpcnRoIGRhdGVcclxuICAgKiBAcGFyYW0gZERheSBkZWF0aCBkYXRlXHJcbiAgICovXHJcbiAgaW5pdFdpdGhEYXRlcyhiRGF5LCBkRGF5KSB7XHJcbiAgICBpZiAoYkRheSAhPSBudWxsKSB7XHJcbiAgICAgIHRoaXMucGVyc29uRGF0ZS5iaXJ0aERhdGVTdHJpbmcgPSBiRGF5O1xyXG4gICAgICB0aGlzLnBlcnNvbkRhdGUuYmlydGhEYXRlID0gdGhpcy5nZXREYXRlKHRoaXMucGVyc29uRGF0ZS5iaXJ0aERhdGVTdHJpbmcpO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMubGFzdERhdGVDaGVja2VkRW1wdHkpIHtcclxuICAgICAgdGhpcy5wZXJzb25EYXRlLmhhc0JpcnRoRGF0ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgaWYgKGREYXkgIT0gbnVsbCkge1xyXG4gICAgICB0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlU3RyaW5nID0gZERheTtcclxuICAgICAgdGhpcy5wZXJzb25EYXRlLmRlYXRoRGF0ZSA9IHRoaXMuZ2V0RGF0ZSh0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlU3RyaW5nKTtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmxhc3REYXRlQ2hlY2tlZEVtcHR5KSB7XHJcbiAgICAgIHRoaXMucGVyc29uRGF0ZS5oYXNEZWF0aERhdGUgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBHbyBhaGVhZCBhbmQgc2VlIGlmIHByZTE1MDAsIHByZTE3MDAgb3IgdG9vIG9sZFxyXG4gICAgdGhpcy5pc1BlcnNvblByZTE1MDAoKTtcclxuICAgIHRoaXMuaXNQZXJzb25QcmUxNzAwKCk7XHJcbiAgICB0aGlzLm11c3RCZU9wZW4oKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEluaXRpYWxpemUgcGVyc29uIGRhdGVzXHJcbiAgICogQHBhcmFtIHByb2ZpbGVPYmogY29udGFpbmluZyB0aGUgcHJvZmlsZVxyXG4gICAqL1xyXG4gIGluaXQocHJvZmlsZU9iaikge1xyXG5cclxuICAgIGlmIChwcm9maWxlT2JqLkJpcnRoRGF0ZSAhPSBudWxsKSB7XHJcbiAgICAgIHRoaXMucGVyc29uRGF0ZS5iaXJ0aERhdGVTdHJpbmcgPSBwcm9maWxlT2JqLkJpcnRoRGF0ZTtcclxuICAgICAgdGhpcy5wZXJzb25EYXRlLmJpcnRoRGF0ZSA9IHRoaXMuZ2V0RGF0ZSh0aGlzLnBlcnNvbkRhdGUuYmlydGhEYXRlU3RyaW5nKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmIChwcm9maWxlT2JqLkJpcnRoRGF0ZURlY2FkZSAhPSBudWxsKSB7XHJcbiAgICAgICAgdGhpcy5wZXJzb25EYXRlLmJpcnRoRGF0ZVN0cmluZyA9IHByb2ZpbGVPYmouQmlydGhEYXRlRGVjYWRlLnNsaWNlKDAsIC0xKTtcclxuICAgICAgICB0aGlzLnBlcnNvbkRhdGUuYmlydGhEYXRlID0gdGhpcy5nZXREYXRlKHRoaXMucGVyc29uRGF0ZS5iaXJ0aERhdGVTdHJpbmcpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5sYXN0RGF0ZUNoZWNrZWRFbXB0eSkge1xyXG4gICAgICB0aGlzLnBlcnNvbkRhdGUuaGFzQmlydGhEYXRlID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBpZiAocHJvZmlsZU9iai5EZWF0aERhdGUgIT0gbnVsbCkge1xyXG4gICAgICB0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlU3RyaW5nID0gcHJvZmlsZU9iai5EZWF0aERhdGU7XHJcbiAgICAgIHRoaXMucGVyc29uRGF0ZS5kZWF0aERhdGUgPSB0aGlzLmdldERhdGUodGhpcy5wZXJzb25EYXRlLmRlYXRoRGF0ZVN0cmluZyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAocHJvZmlsZU9iai5EZWF0aERhdGVEZWNhZGUgIT0gbnVsbCkge1xyXG4gICAgICAgIHRoaXMucGVyc29uRGF0ZS5kZWF0aERhdGVTdHJpbmcgPSBwcm9maWxlT2JqLkRlYXRoRGF0ZURlY2FkZS5zbGljZSgwLCAtMSk7XHJcbiAgICAgICAgdGhpcy5wZXJzb25EYXRlLmRlYXRoRGF0ZSA9IHRoaXMuZ2V0RGF0ZSh0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlU3RyaW5nKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMubGFzdERhdGVDaGVja2VkRW1wdHkpIHtcclxuICAgICAgdGhpcy5wZXJzb25EYXRlLmhhc0RlYXRoRGF0ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEdvIGFoZWFkIGFuZCBzZWUgaWYgcHJlMTUwMCwgcHJlMTcwMCBvciB0b28gb2xkXHJcbiAgICB0aGlzLmlzUGVyc29uUHJlMTUwMCgpO1xyXG4gICAgdGhpcy5pc1BlcnNvblByZTE3MDAoKTtcclxuICAgIHRoaXMubXVzdEJlT3BlbigpO1xyXG5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnZlcnQgZGF0ZSBmcm9tIGZvcm0gcmV0dXJuZWQgYnkgc2VydmVyIHRvIGEgRGF0ZVxyXG4gICAqIFRoZSBzZXJ2ZXIgbWF5IGhhdmUgMDAgZm9yIGFueSB5ZWFyLCBtb250aCwgZGF5XHJcbiAgICogSW4gdGhhdCBjYXNlLCB0aGUgdmFsdWUgMSBpcyB1c2VkXHJcbiAgICogQHBhcmFtIGRhdGVTdHJpbmcgYXMgaW5wdXQgZnJvbSBzZXJ2ZXIgaW4gdGhlIGZvcm0gMDAwMC0wMC0wMFxyXG4gICAqIEByZXR1cm4gRGF0ZSBmb3IgdGhlIGlucHV0IHN0cmluZ1xyXG4gICAqL1xyXG4gIGdldERhdGUoZGF0ZVN0cmluZykge1xyXG4gICAgbGV0IHllYXIgPSAwOyAgICAgICAgICAgICAvLyBkZWZhdWx0IGluIGNhc2Ugb2YgMCB2YWx1ZXNcclxuICAgIGxldCBtb250aCA9IDA7XHJcbiAgICBsZXQgZGF5ID0gMDtcclxuICAgIHRoaXMubGFzdERhdGVDaGVja2VkRW1wdHkgPSBmYWxzZTsgICAgLy8gaGFjayBoYWNrXHJcbiAgICBsZXQgc3BsaXRTdHJpbmcgPSBkYXRlU3RyaW5nLnNwbGl0KFwiLVwiKTtcclxuICAgIGxldCBsZW4gPSBzcGxpdFN0cmluZy5sZW5ndGg7XHJcbiAgICBpZiAobGVuID4gMCkge1xyXG4gICAgICB5ZWFyID0gc3BsaXRTdHJpbmdbMF07XHJcbiAgICB9XHJcbiAgICBpZiAobGVuID4gMSkge1xyXG4gICAgICBtb250aCA9IHNwbGl0U3RyaW5nWzFdO1xyXG4gICAgfVxyXG4gICAgaWYgKGxlbiA+PSAyKSB7XHJcbiAgICAgIGRheSA9IHNwbGl0U3RyaW5nWzJdO1xyXG4gICAgfVxyXG4gICAgaWYgKCh5ZWFyICsgbW9udGggKyBkYXkpID09PSAwKSB7XHJcbiAgICAgIHRoaXMubGFzdERhdGVDaGVja2VkRW1wdHkgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKHllYXIgPT09IDApIHtcclxuICAgICAgeWVhciA9IDE7XHJcbiAgICB9XHJcbiAgICBpZiAobW9udGggPT09IDApIHtcclxuICAgICAgbW9udGggPSAxO1xyXG4gICAgfVxyXG4gICAgaWYgKGRheSA9PT0gMCkge1xyXG4gICAgICBkYXkgPSAxO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIChuZXcgRGF0ZSh5ZWFyLCBtb250aCwgZGF5KSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBJcyB0aGUgcGVyc29uIGJlZm9yZSAxNTAwXHJcbiAgICogQHJldHVybiB0cnVlIGlmIGVpdGhlciBiaXJ0aCBvciBkZWF0aCBkYXRlIGJlZm9yZSAxNTAwXHJcbiAgICovXHJcbiAgaXNQZXJzb25QcmUxNTAwKCkge1xyXG4gICAgbGV0IHRoZVllYXIxNTAwID0gbmV3IERhdGUoXCIxNTAwLTAxLTAxXCIpO1xyXG4gICAgaWYgKHRoaXMucGVyc29uRGF0ZS5iaXJ0aERhdGUgIT0gbnVsbCkge1xyXG4gICAgICBpZiAodGhpcy5wZXJzb25EYXRlLmJpcnRoRGF0ZSA8IHRoZVllYXIxNTAwKSB7XHJcbiAgICAgICAgdGhpcy5pc1ByZTE1MDAgPSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5wZXJzb25EYXRlLmRlYXRoRGF0ZSAhPSBudWxsKSB7XHJcbiAgICAgIGlmICh0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlIDwgdGhlWWVhcjE1MDApIHtcclxuICAgICAgICB0aGlzLmlzUHJlMTUwMCA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLmlzUHJlMTUwMCkge1xyXG4gICAgICB0aGlzLmlzUHJlMTUwMCA9IHRydWU7XHJcbiAgICAgIHRoaXMuaXNQcmUxNzAwID0gdHJ1ZTtcclxuICAgICAgdGhpcy50b29PbGRUb1JlbWVtYmVyID0gdHJ1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLmlzUHJlMTUwMDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIElzIHRoZSBwZXJzb24gYmVmb3JlIDE3MDBcclxuICAgKiBAcmV0dXJuIHRydWUgaWYgZWl0aGVyIGJpcnRoIG9yIGRlYXRoIGRhdGUgYmVmb3JlIDE3MDBcclxuICAgKi9cclxuICBpc1BlcnNvblByZTE3MDAoKSB7XHJcbiAgICBsZXQgdGhlWWVhcjE3MDAgPSBuZXcgRGF0ZShcIjE3MDAtMDEtMDFcIik7XHJcbiAgICBpZiAodGhpcy5wZXJzb25EYXRlLmJpcnRoRGF0ZSAhPSBudWxsKSB7XHJcbiAgICAgIGlmICh0aGlzLnBlcnNvbkRhdGUuYmlydGhEYXRlIDwgdGhlWWVhcjE3MDApIHtcclxuICAgICAgICB0aGlzLmlzUHJlMTcwMCA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlICE9IG51bGwpIHtcclxuICAgICAgaWYgKHRoaXMucGVyc29uRGF0ZS5kZWF0aERhdGUgPCB0aGVZZWFyMTcwMCkge1xyXG4gICAgICAgIHRoaXMuaXNQcmUxNzAwID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuaXNQcmUxNzAwKSB7XHJcbiAgICAgIHRoaXMudG9vT2xkVG9SZW1lbWJlciA9IHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5pc1ByZTE3MDA7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIElzIHRoZSBwZXJzb24gYm9ybiA+IDE1MCB5ZWFycyBhZ28gb3IgZGllZCA+IDEwMCB5ZWFycyBhZ29cclxuICAgKiBAcmV0dXJuIHRydWUgaWYgYm9ybiA+IDE1MCB5ZWFycyBhZ28gb3IgZGllZCA+IDEwMCB5ZWFycyBhZ29cclxuICAgKi9cclxuICBtdXN0QmVPcGVuKCkge1xyXG4gICAgbGV0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGxldCB5ZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAgIGxldCBtb250aCA9IHRvZGF5LmdldE1vbnRoKCk7XHJcbiAgICBsZXQgZGF5ID0gdG9kYXkuZ2V0RGF0ZSgpO1xyXG4gICAgbGV0IGVhcmxpZXN0TWVtb3J5QmVmb3JlRGVhdGggPSBuZXcgRGF0ZSh5ZWFyIC0gdGhpcy5UT09fT0xEX1RPX1JFTUVNQkVSX0RFQVRILCBtb250aCwgZGF5KTtcclxuICAgIGxldCBlYXJsaWVzdE1lbW9yeUJlZm9yZUJpcnRoID0gbmV3IERhdGUoeWVhciAtIHRoaXMuVE9PX09MRF9UT19SRU1FTUJFUl9CSVJUSCwgbW9udGgsIGRheSk7XHJcbiAgICBpZiAodGhpcy5wZXJzb25EYXRlLmJpcnRoRGF0ZSAhPSBudWxsKSB7XHJcbiAgICAgIGlmICh0aGlzLnBlcnNvbkRhdGUuYmlydGhEYXRlIDwgZWFybGllc3RNZW1vcnlCZWZvcmVCaXJ0aCkge1xyXG4gICAgICAgIHRoaXMudG9vT2xkVG9SZW1lbWJlciA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLnBlcnNvbkRhdGUuZGVhdGhEYXRlICE9IG51bGwpIHtcclxuICAgICAgaWYgKHRoaXMucGVyc29uRGF0ZS5kZWF0aERhdGUgPCBlYXJsaWVzdE1lbW9yeUJlZm9yZURlYXRoKSB7XHJcbiAgICAgICAgdGhpcy50b29PbGRUb1JlbWVtYmVyID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLypcclxuICAgICAqIFNpbmNlIHlvdSBhbHJlYWR5IGhhdmUgdG9kYXksIHBpY2sgdXAgdGhlIGRhdGUgdG8gdXNlIGZvclxyXG4gICAgICogYSBzb3VyY2Ugd2lsbCBiZSBlbnRlcmVkIGJ5IHh4eHggdGVzdHNcclxuICAgICovXHJcbiAgICB0aGlzLnBlcnNvbkRhdGUub25lWWVhckFnbyA9IG5ldyBEYXRlKHllYXIgLSAxLCBtb250aCwgZGF5KTtcclxuICAgIFxyXG4gICAgcmV0dXJuIHRoaXMudG9vT2xkVG9SZW1lbWJlcjtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIERvZXMgdGhlIHByb2ZpbGUgbGFjayBkYXRlc1xyXG4gICAqIEByZXR1cm4gdHJ1ZSBpZiBwcm9maWxlIGhhcyBuZWl0aGVyIGJpcnRoIG5vciBkZWF0aCBkYXRlXHJcbiAgICovXHJcbiAgaXNVbmRhdGVkKCkge1xyXG4gICAgaWYgKCF0aGlzLnBlcnNvbkRhdGUuaGFzQmlydGhEYXRlICYmICF0aGlzLnBlcnNvbkRhdGUuaGFzRGVhdGhEYXRlKSB7XHJcbiAgICAgIHRoaXMuaXNQcmUxNTAwID0gdHJ1ZTtcclxuICAgICAgdGhpcy5pc1ByZTE3MDAgPSB0cnVlO1xyXG4gICAgICB0aGlzLnRvb09sZFRvUmVtZW1iZXIgPSB0cnVlO1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldCBiaXJ0aCBkYXRlXHJcbiAgICogQHJldHVybiBiaXJ0aCBkYXRlIGFzIERhdGVcclxuICAqL1xyXG4gIGdldEJpcnRoRGF0ZSgpIHtcclxuICAgIHJldHVybiB0aGlzLnBlcnNvbkRhdGUuYmlydGhEYXRlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBHZXQgZGVhdGggZGF0ZVxyXG4gICAqIEByZXR1cm4gZGVhdGggZGF0ZSBhcyBEYXRlXHJcbiAgKi9cclxuICBnZXREZWF0aERhdGUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wZXJzb25EYXRlLmRlYXRoRGF0ZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnZlcnQgZGF0ZSB0byBhIGRpc3BsYXkgZm9ybWF0XHJcbiAgICogQHBhcmFtIHRydWUgdG8gZ2V0IGJpcnRoIGRhdGUsIGVsc2UgZGVhdGggZGF0ZVxyXG4gICAqIEByZXR1cm4gc3RyaW5nIGluIHRoZSBmb3JtIHl5eXkgbW9uIGRkXHJcbiAgICovXHJcbiAgZ2V0UmVwb3J0RGF0ZShpc0JpcnRoKSB7XHJcblxyXG4gICAgLy8gaGFuZGxlIGNhc2VzIHdpdGhvdXQgYW55IGRhdGUuIHNpZ2guXHJcbiAgICBsZXQgZGF0ZVN0cmluZyA9IFwiXCI7XHJcbiAgICBsZXQgaGFzRGF0ZSA9IHRoaXMucGVyc29uRGF0ZS5oYXNEZWF0aERhdGU7XHJcbiAgICBpZiAoaXNCaXJ0aCkge1xyXG4gICAgICBoYXNEYXRlID0gdGhpcy5wZXJzb25EYXRlLmhhc0JpcnRoRGF0ZTtcclxuICAgICAgaWYgKGhhc0RhdGUpIHtcclxuICAgICAgICBkYXRlU3RyaW5nID0gdGhpcy5wZXJzb25EYXRlLmJpcnRoRGF0ZVN0cmluZztcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKGhhc0RhdGUpIHtcclxuICAgICAgICBkYXRlU3RyaW5nID0gdGhpcy5wZXJzb25EYXRlLmRlYXRoRGF0ZVN0cmluZztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgbGV0IGRpc3BsYXlEYXRlID0gXCJcIjtcclxuICAgIGlmIChoYXNEYXRlKSB7XHJcbiAgICAgIGxldCB5ZWFyID0gMDsgICAgICAgICAgICAgLy8gZGVmYXVsdCBpbiBjYXNlIG9mIDAgdmFsdWVzXHJcbiAgICAgIGxldCBtb250aCA9IDA7XHJcbiAgICAgIGxldCBkYXkgPSAwO1xyXG4gICAgICBsZXQgc3BsaXRTdHJpbmcgPSBkYXRlU3RyaW5nLnNwbGl0KFwiLVwiKTtcclxuICAgICAgbGV0IGxlbiA9IHNwbGl0U3RyaW5nLmxlbmd0aDtcclxuICAgICAgaWYgKGxlbiA+IDApIHtcclxuICAgICAgICB5ZWFyID0gc3BsaXRTdHJpbmdbMF07XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGxlbiA+IDEpIHtcclxuICAgICAgICBtb250aCA9IHNwbGl0U3RyaW5nWzFdO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChsZW4gPj0gMikge1xyXG4gICAgICAgIGRheSA9IHNwbGl0U3RyaW5nWzJdO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChkYXkgPiAwKSB7XHJcbiAgICAgICAgZGlzcGxheURhdGUgPSBkYXkgKyBcIiBcIjtcclxuICAgICAgfVxyXG4gICAgICBpZiAobW9udGggPiAwKSB7XHJcbiAgICAgICAgbGV0IG1vbnRocyA9IFsnSmFuJywgJ0ZlYicsICdNYXInLCAnQXByJywgJ01heScsICdKdW4nLCAnSnVsJywgJ0F1ZycsICdTZXAnLCAnT2N0JywgJ05vdicsICdEZWMnXTtcclxuICAgICAgICBsZXQgbW9udGhOdW1iZXIgPSBwYXJzZUludChtb250aCk7XHJcbiAgICAgICAgbGV0IG1vbnRoTmFtZSA9IG1vbnRoc1ttb250aE51bWJlci0xXTtcclxuICAgICAgICBkaXNwbGF5RGF0ZSArPSBtb250aE5hbWUgKyBcIiBcIjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoeWVhciA+IDApIHtcclxuICAgICAgICBkaXNwbGF5RGF0ZSArPSB5ZWFyO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZGlzcGxheURhdGU7XHJcbiAgfVxyXG5cclxufVxyXG4iLCIvKlxyXG5UaGUgTUlUIExpY2Vuc2UgKE1JVClcclxuXHJcbkNvcHlyaWdodCAoYykgMjAyMiBLYXRocnluIEogS25pZ2h0XHJcblxyXG5QZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mXHJcbnRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW5cclxudGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0b1xyXG51c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZlxyXG50aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sXHJcbnN1YmplY3QgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb25zOlxyXG5cclxuVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4gYWxsXHJcbmNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXHJcblxyXG5USEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SXHJcbklNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTXHJcbkZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUlxyXG5DT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVJcclxuSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU5cclxuQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cclxuKi9cclxuLyoqXHJcbiogUnVsZXMgZm9yIGlkZW50aWZ5aW5nIHNvdXJjZXMgaW4gYSBiaW9ncmFwaHkgdGhhdCBhcmUgbm90IHZhbGlkXHJcbiogSW50ZW5kZWQgdG8gYmUgYSBzaW5nbGV0b24gYW5kIGltbXV0YWJsZVxyXG4qIGFuZCBsb29rIGxpa2Ugd2hhdCBjb3VsZCBiZSByZWFkIGZyb20gZGF0YWJhc2UgdGFibGVzXHJcbiovXHJcbmV4cG9ydCBjbGFzcyBTb3VyY2VSdWxlcyB7XHJcblxyXG4gIC8vIFZhbGlkIHRleHQgZm9yIGJpb2dyYXBoeSBoZWFkaW5nXHJcbiAgYmlvZ3JhcGh5SGVhZGluZ3MgPSBbXHJcbiAgICBcImJpb2dyYXBoeVwiLFxyXG4gICAgXCJiaW9ncmFwaGllXCIsXHJcbiAgICBcImJpb2dyYWZpYVwiLFxyXG4gICAgXCJiaW9ncmFmaWVcIixcclxuICAgIFwiYmlvZ3JhZmlcIixcclxuICAgIFwiZWzDpG3DpG50YXJpbmFcIixcclxuICAgIFwiw4Z2aXNrcsOhXCIsXHJcbiAgICBcImJvZ3JhcGhpZVwiLFxyXG4gICAgXCJiaW9ncmFmaWpvXCIsXHJcbiAgICBcImJpb2dyYWbDrWFcIixcclxuICBdO1xyXG4gIC8vIFZhbGlkIHRleHQgZm9yIHNvdXJjZXMgaGVhZGluZ1xyXG4gIHNvdXJjZXNIZWFkaW5ncyA9IFtcclxuICAgIFwic291cmNlc1wiLFxyXG4gICAgXCJxdWVsbGVuXCIsXHJcbiAgICBcImJyb25uZW5cIixcclxuICAgIFwiZnVlbnRlc1wiLFxyXG4gICAgXCJsw6RodGVldFwiLFxyXG4gICAgXCJmb250aVwiLFxyXG4gICAgXCJrYWxsb3JcIixcclxuICAgIFwiaGVpbWlsZGlyXCIsXHJcbiAgICBcImvDpGxsb3JcIixcclxuICAgIFwiZm9udGVzXCIsXHJcbiAgICBcImtpbGRlclwiLFxyXG4gICAgXCLFunLDs2TFgmFcIixcclxuICAgIFwiaXp2b3JcIixcclxuICBdO1xyXG4gIC8vIFZhbGlkIHRleHQgZm9yIHJlc2VhcmNoIG5vdGVzIGhlYWRpbmdcclxuICByZXNlYXJjaE5vdGVzSGVhZGluZ3MgPSBbXHJcbiAgICBcInJlc2VhcmNoIG5vdGVzXCIsXHJcbiAgICBcIm5vdGVzIGRlIHJlY2hlcmNoZVwiLFxyXG4gICAgXCJvbmRlcnpvZWtzbm90aXRpZXNcIixcclxuICAgIFwib3BtZXJraW5nZW5cIixcclxuICAgIFwiYmVtZXJrdW5nZW4genVyIG5hY2hmb3JzY2h1bmdcIixcclxuICAgIFwiZm9yc2NodW5nc25vdGl6ZW5cIixcclxuICAgIFwibm90YXMgZGUgaW52ZXN0aWdhY2nDs25cIixcclxuICAgIFwibm90ZSBkaSByaWNlcmNhXCIsXHJcbiAgICBcImZvcnNrbmluZ3NhbnRlY2tuaW5nYXJcIixcclxuICAgIFwiZm9yc2tuaW5nc25vdGF0ZXJcIixcclxuICAgIFwibm90YXMgZGUgcGVzcXVpc2FcIixcclxuICAgIFwiZm9yc2tuaW5nc25vdGF0ZXJcIixcclxuICAgIFwidHV0a2ltdXN0aWVkb3RcIixcclxuICAgIFwibm90YXRraSBiYWRhd2N6ZVwiLFxyXG4gICAgXCJyYXppc2tvdmFsbmUgb3BvbWJlXCIsXHJcbiAgICBcInZpaXR0YXVrc2V0XCIsXHJcbiAgICBcInJhbm5zw7NrbmFybsOzdHVyXCIsXHJcbiAgXTtcclxuICAvLyBWYWxpZCB0ZXh0IGZvciBhY2tub3dsZWRnZW1lbnRzIGhlYWRpbmdcclxuICBhY2tub3dsZWRnbWVudHNIZWFkaW5ncyA9IFtcclxuICAgIFwiYWNrbm93bGVkZ2VtZW50c1wiLFxyXG4gICAgXCJhY2tub3dsZWRnbWVudHNcIixcclxuICAgIFwiYWNrbm93bGVkZ2VtZW50XCIsXHJcbiAgICBcImFja25vd2xlZGdtZW50XCIsXHJcbiAgICBcInJlbWVyY2llbWVudHNcIixcclxuICAgIFwiZGFua2JldHVpZ2luZ1wiLFxyXG4gICAgXCJhbmVya2VubnVuZ1wiLFxyXG4gICAgXCJkYW5rc2FndW5nZW5cIixcclxuICAgIFwiYWdyYWRlY2ltaWVudG9zXCIsXHJcbiAgICBcInJpbmdyYXppYW1lbnRpXCIsXHJcbiAgICBcImRhbmt3b29yZFwiLFxyXG4gICAgXCJlcmvDpG5uYW5kZW5cIixcclxuICAgIFwicmVjb25oZWNpbWVudG9zXCIsXHJcbiAgICBcInJpY29ub3NjaW1lbnRpXCIsXHJcbiAgICBcImFuZXJrZW5kZWxzZXJcIixcclxuICAgIFwiYW5lcmtqZW5uZWxzZXJcIixcclxuICAgIFwiYmVrcsOkZnRlbHNlclwiLFxyXG4gICAgXCJ0dW5udXN0dWtzZXRcIixcclxuICAgIFwicG9kemnEmWtvd2FuaWVcIixcclxuICAgIFwicHJpem5hbmphXCIsXHJcbiAgXTtcclxuICAvLyBzdHJpbmdzIHRoYXQgaWRlbnRpZnkgYSBjZW5zdXMgc291cmNlXHJcbiAgLy8gd2hlbiB1c2VkIGJ5IGl0c2VsZiBvciB3aXRoIG5vdGhpbmcgb3RoZXIgdGhhblxyXG4gIC8vIGRhdGUgYXJlIG5vdCBhIHZhbGlkIHNvdXJjZVxyXG4gIGNlbnN1c1N0cmluZ3MgPSBbXHJcbiAgICBcImNlbnN1c1wiLFxyXG4gICAgXCJyZWNlbnNlbWVudFwiLFxyXG4gICAgXCJiZXZvbGtpbmdzcmVnaXN0ZXJcIixcclxuICAgIFwidm9sa3N6w6RobHVuZ1wiLFxyXG4gICAgXCJjZW5zb1wiLFxyXG4gICAgXCJjZW5zaW1lbnRvXCIsXHJcbiAgICBcInZvbGtzdGVsbGluZ1wiLFxyXG4gICAgXCJmb2xrZXTDpmxsaW5nXCIsXHJcbiAgICBcInRlbGxpbmdcIixcclxuICAgIFwiZm9sa3LDpGtuaW5nXCIsXHJcbiAgICBcInbDpGVzdMO2bmxhc2tlbnRhXCIsXHJcbiAgICBcInNwaXNcIixcclxuICAgIFwibHVkbm/Fm2NpXCIsXHJcbiAgICBcInBvcGlzXCIsXHJcbiAgICBcInbDpGVzdMO2bmxhc2tlbnRhXCIsXHJcbiAgICBcIm1hbm50YWxcIixcclxuICAgIFwiZm9sa2V0ZWxsaW5nXCIsXHJcbiAgICBcImZvbGtyw6RrbmluZ1wiLFxyXG4gICAgXCJ1cyBmZWRlcmFsIGNlbnN1c1wiLFxyXG4gICAgXCJ1bml0ZWQgc3RhdGVzIGZlZGVyYWwgY2Vuc3VzXCIsXHJcbiAgICBcInVuaXRlZCBzdGF0ZXMgY2Vuc3VzXCIsXHJcbiAgICBcInVzIGNlbnN1c1wiLFxyXG4gICAgXCJ1LnMuIGNlbnN1c1wiLFxyXG4gICAgXCJ1cyBjZW5zdXMgcmV0dXJuc1wiLFxyXG4gICAgXCJmZWRlcmFsIGNlbnN1c1wiLFxyXG4gICAgXCJzd2VkaXNoIGNlbnN1c1wiLFxyXG4gICAgXCJjYW5hZGEgY2Vuc3VzXCIsXHJcbiAgICBcImNlbnN1cyBvZiBjYW5hZGFcIixcclxuICAgIFwiY2FuYWRpYW4gY2Vuc3VzXCIsXHJcbiAgICBcImVuZ2xhbmQgY2Vuc3VzXCIsXHJcbiAgICBcImlyaXNoIGNlbnN1c1wiLFxyXG4gICAgXCJpcmVsYW5kIGNlbnN1c1wiLFxyXG4gICAgXCJjZW5zdXMgaW5mb3JtYXRpb25cIixcclxuICAgIFwibmV3IHlvcmsgc3RhdGUgY2Vuc3VzXCIsXHJcbiAgICBcImlvd2Egc3RhdGUgY2Vuc3VzXCIsXHJcbiAgICBcInNjb3RsYW5kIGNlbnN1c1wiLFxyXG4gIF07XHJcblxyXG4gIC8qIG9yZGVyIGJ5IGxlbmd0aCB0aGVuIGFscGhhLCBidXQgZm9yIGVmZmljaWVuY3lcclxuICAgKiBzaW5jZSBtb3N0IHByb2ZpbGVzIGFyZSBFbmdsaXNoLCB0aGF0IGlzIGZpcnN0XHJcbiAgICogTm90ZTogbG9naWMgY2hlY2tzIGZvciBhdCBsZWFzdCAxNSBjaGFyYWN0ZXJzIHNvXHJcbiAgICogc2hvcnRlciBhcmUgY29tbWVudGVkIG91dCwgYnV0IGtlcHQgaW4gY2FzZSBcclxuICAgKiB0aGlzIGlzIHRvbyBhZ2dyZXNzaXZlXHJcbiAgICogaW52YWxpZFNvdXJjZUxpc3QgYXJlIHN0cmluZ3Mgb24gYSBsaW5lIGJ5IHRoZW1zZWx2ZXNcclxuICAgKi9cclxuICBpbnZhbGlkU291cmNlTGlzdCA9IFtcclxuICAvKlxyXG4gICAgXCIuXCIsXHJcbiAgICBcIipcIixcclxuICAgIFwiYm1kXCIsXHJcbiAgICBcIi0tLVwiLFxyXG4gICAgXCJpYmlkXCIsXHJcbiAgICBcIi0tLS1cIixcclxuICAgIFwiYmlibGVcIixcclxuICAgIFwiY2Vuc3VzXCIsXHJcbiAgICBcImZhbWlseVwiLFxyXG4gICAgXCJmcmVlYm1kXCIsXHJcbiAgICBcImhpbnNoYXdcIixcclxuICAgIFwiYW5jZXN0cnlcIixcclxuICAgIFwiZm9vdG5vdGVcIixcclxuICAgIFwiZ2VuZWFuZXRcIixcclxuICAgIFwicmVzZWFyY2hcIixcclxuICAgIFwic2VlIGFsc29cIixcclxuICAgIFwiZm9vdG5vdGVzXCIsXHJcbiAgICBcInNlZSBhbHNvOlwiLFxyXG4gICAgXCJ3ZSByZWxhdGVcIixcclxuICAgIFwiZmluZGFncmF2ZVwiLFxyXG4gICAgXCJmb290bm90ZXM6XCIsXHJcbiAgICBcIm15aGVyaXRhZ2VcIixcclxuICAgIFwiYW5jZXN0cnljb21cIixcclxuICAgIFwiYW5jZXN0cnkudWtcIixcclxuICAgIFwiYW5jZXN0cnkuY2FcIixcclxuICAgIFwiYmRtIHJlY29yZHNcIixcclxuICAgIFwibXkgaGVyaXRhZ2VcIixcclxuICAgIFwibXkgcmVzZWFyY2hcIixcclxuICAgIFwid2lsbCBmb2xsb3dcIixcclxuICAgIFwiYW5jZXN0cnkuY29tXCIsXHJcbiAgICBcImZhbWlseXNlYXJjaFwiLFxyXG4gICAgXCJmYW1pbHkgYmlibGVcIixcclxuICAgIFwiZmFtaWx5IHRyZWVzXCIsXHJcbiAgICBcImZpbmQgYSBncmF2ZVwiLFxyXG4gICAgXCJmaW5kLWEtZ3JhdmVcIixcclxuICAgIFwiZmluZCBteSBwYXN0XCIsXHJcbiAgICBcInNvdXJjZSBsaXN0OlwiLFxyXG4gICAgXCJhbmNlc3RyeS5jb206XCIsXHJcbiAgICBcImJpbGxpb25ncmF2ZXNcIixcclxuICAgIFwiZmFtaWx5IG1lbWJlclwiLFxyXG4gICAgXCJmYW1pbHkgcGFwZXJzXCIsXHJcbiAgICBcImZhbWlseSBzZWFyY2hcIixcclxuICAgIFwibmVlZHMgc291cmNlc1wiLFxyXG4gICAgXCI6c291cmNlIGxpc3Q6XCIsXHJcbiAgICBcInNvdXJjZSBuZWVkZWRcIixcclxuICAgIFwid2UgcmVsYXRlIHdlYlwiLFxyXG4gICAgXCJhbmNlc3RyeS5jby51a1wiLFxyXG4gICAgXCJhbmNlc3RyeWRvdGNvbVwiLFxyXG4gICAgXCJiaWxsaW9uIGdyYXZlc1wiLFxyXG4gICAgXCJjZW5zdXMgcmVjb3Jkc1wiLFxyXG4gICAgXCJjaHVyY2ggcmVjb3Jkc1wiLFxyXG4gICAgXCJmYW1pbHkgaGlzdG9yeVwiLFxyXG4gICAgXCJmYW1pbHkgcmVjb3Jkc1wiLFxyXG4gICAgXCJmaW5kYWdyYXZlLmNvbVwiLFxyXG4gICAgXCJmcmVlYm1kLm9yZy51a1wiLFxyXG4gICAgXCJpbnRlcm5ldCBmaWxlc1wiLFxyXG4gICAgXCJteSBmYW1pbHkgdHJlZVwiLFxyXG4gICAgXCJteWhlcml0YWdlLmNvbVwiLFxyXG4gICAgXCJwYXJpc2ggcmVjb3Jkc1wiLFxyXG4gICAgXCJwYXNzZW5nZXIgbGlzdFwiLFxyXG4gICAgXCInJydzZWUgYWxzbycnJ1wiLFxyXG4gICAgKi9cclxuICAgIFwiYW5jZXN0cnkgc291cmNlXCIsXHJcbiAgICBcImNlbnN1cyByZWNvcmRzLlwiLFxyXG4gICAgXCJmYW1pbHlzZWFyY2hvcmdcIixcclxuICAgIFwiZmFtaWx5IGFjY291bnRzXCIsXHJcbiAgICBcImZhbWlseSByZXNlYXJjaFwiLFxyXG4gICAgXCJvbmxpbmUgcmVzZWFyY2hcIixcclxuICAgIFwib3duIGZhbWlseSB0cmVlXCIsXHJcbiAgICBcInRpdGxlOiBtYXJyaWFnZVwiLFxyXG4gICAgXCInJydzZWUgYWxzbzonJydcIixcclxuICAgIFwid3d3LmFuY2VzdHJ5LmNhXCIsXHJcbiAgICBcInd3dy5ibXMyMDAwLm9yZ1wiLFxyXG4gICAgXCJmYW1pbHlzZWFyY2gub3JnXCIsXHJcbiAgICBcImZhbWlseSBkb2N1bWVudHNcIixcclxuICAgIFwiZmFtaWx5IGtub3dsZWRnZVwiLFxyXG4gICAgXCJmaW5kbXlwYXN0LmNvLnVrXCIsXHJcbiAgICBcIicnJ2Zvb3Rub3RlczonJydcIixcclxuICAgIFwiaW50ZXJuZXQgcmVjb3Jkc1wiLFxyXG4gICAgXCJwZXJzb25hbCByZWNvcmRzXCIsXHJcbiAgICBcInJlc2VhcmNoIHJlY29yZHNcIixcclxuICAgIFwid3d3LmFuY2VzdHJ5LmNvbVwiLFxyXG4gICAgXCJhY2tub3dsZWRnZW1lbnRzOlwiLFxyXG4gICAgXCJhbmNlc3RyeSByZXNlYXJjaFwiLFxyXG4gICAgXCJmYW1pbHlzZWFyY2ggdHJlZVwiLFxyXG4gICAgXCJmYW1pbHkgY29sbGVjdGlvblwiLFxyXG4gICAgXCJmYW1pbHkgdHJlZSBmaWxlc1wiLFxyXG4gICAgXCJmZWxsb3cgcmVzZWFyY2hlclwiLFxyXG4gICAgXCJzY290bGFuZCdzIHBlb3BsZVwiLFxyXG4gICAgXCJ3aWtpLCBmYW1pbHkgdHJlZVwiLFxyXG4gICAgXCI6JycnZm9vdG5vdGVzOicnJ1wiLFxyXG4gICAgXCJwZXJzb25hbCByZXNlYXJjaFwiLFxyXG4gICAgXCJwcml2YXRlIGdlbmVhbG9neVwiLFxyXG4gICAgXCInJydzb3VyY2UgbGlzdCcnJ1wiLFxyXG4gICAgXCI6Jycnc291cmNlIGxpc3QnJydcIixcclxuICAgIFwiJycnc291cmNlIGxpc3Q6JycnXCIsXHJcbiAgICBcImNlbWV0ZXJ5IGhlYWRzdG9uZVwiLFxyXG4gICAgXCJjaXRpbmcgdGhpcyByZWNvcmRcIixcclxuICAgIFwiZmFtaWx5IGluZm9ybWF0aW9uXCIsXHJcbiAgICBcIm5ld3NwYXBlciBvYml0dWFyeVwiLFxyXG4gICAgXCJzb3VyY2UgaW5mb3JtYXRpb25cIixcclxuICAgIFwidGl0bGU6IGRlYXRoIGluZGV4XCIsXHJcbiAgICBcInd3d2ZhbWlseXNlYXJjaG9yZ1wiLFxyXG4gICAgXCJ3d3cuYW5jZXN0cnkuY28udWtcIixcclxuICAgIFwid3d3LmdlbmNpcmNsZXMuY29tXCIsXHJcbiAgICBcInd3dy5teWhlcml0YWdlLmNvbVwiLFxyXG4gICAgXCJ7e2NpdGF0aW9uIG5lZWRlZH19XCIsXHJcbiAgICBcImNpdGluZyB0aGlzIHJlY29yZDpcIixcclxuICAgIFwiZmFtaWx5c2VhcmNoIHNlYXJjaFwiLFxyXG4gICAgXCJteSBoZXJpdGFnZSByZWNvcmRzXCIsXHJcbiAgICBcIm15IHRyZWUgb24gYW5jZXN0cnlcIixcclxuICAgIFwiOicnJ3NvdXJjZSBsaXN0OicnJ1wiLFxyXG4gICAgXCJyZWFsIGVzdGF0ZSByZWNvcmRzXCIsXHJcbiAgICBcImFuY2VzdHJ5IGZhbWlseSB0cmVlXCIsXHJcbiAgICBcImZyb20gZmFtaWx5IHJlY29yZHMuXCIsXHJcbiAgICBcInBlcnNvbmFsIGZhbWlseSB0cmVlXCIsXHJcbiAgICBcInBlcnNvbmFsIGluZm9ybWF0aW9uXCIsXHJcbiAgICBcInVrIGNlbnN1czsgYm1kIGluZGV4XCIsIFxyXG4gICAgXCJ3d3cuZmFtaWx5c2VhcmNoLm9yZ1wiLFxyXG4gICAgXCJhbmNlc3RyeSBmYW1pbHkgdHJlZXNcIixcclxuICAgIFwiYW5jZXN0cnkgZmFtaWx5IHNpdGUuXCIsXHJcbiAgICBcImZhbWlseSBzZWFyY2ggcmVjb3Jkc1wiLFxyXG4gICAgXCJtb3Jtb24gY2h1cmNoIHJlY29yZHNcIixcclxuICAgIFwicmVwbGFjZSB0aGlzIGNpdGF0aW9uXCIsXHJcbiAgICBcImFuY2VzdHJ5IGFuZCBkb2N1bWVudHNcIixcclxuICAgIFwic2NvdGxhbmRzcGVvcGxlLmdvdi51a1wiLFxyXG4gICAgXCJhbmNlc3RyeSB0cmVlICYgc291cmNlc1wiLFxyXG4gICAgXCJmYW1pbHkgdHJlZSBvbiBhbmNlc3RyeVwiLFxyXG4gICAgXCJwZXJzb25hbCBmYW1pbHkgcmVjb3Jkc1wiLFxyXG4gICAgXCJubyBzb3VyY2VzIGF0IHRoaXMgdGltZVwiLFxyXG4gICAgXCJmYW1pbHkgc2VhcmNoIGZhbWlseSB0cmVlXCIsXHJcbiAgICBcInNjb3RsYW5kJ3MgcGVvcGxlIHdlYnNpdGVcIixcclxuICAgIFwiYW5jZXN0cnkgYW5kIGZhbWlseSBzZWFyY2hcIixcclxuICAgIFwid3d3LnNjb3RsYW5kc3Blb3BsZS5nb3YudWtcIixcclxuICAgIFwidXMgY2Vuc3VzLCBwdWJsaWMgcmVjb3Jkcy5cIixcclxuICAgIFwiZmFtaWx5IHRyZWUgb24gZmFtaWx5c2VhcmNoXCIsXHJcbiAgICBcInNvY2lhbCBzZWN1cml0eSBkZWF0aCBpbmRleFwiLFxyXG4gICAgXCJzb3VyY2VzIGFyZSBvbiBteSBmYW1pbHkgdHJlZVwiLFxyXG4gICAgXCJmYW1pbHlzZWFyY2gub3JnIGFuY2VzdHJ5LmNvbVwiLFxyXG4gICAgXCJhbmNlc3RyeS5jb20gZmFtaWx5c2VhcmNoLm9yZ1wiLFxyXG4gICAgXCInJydmb290bm90ZXMgYW5kIGNpdGF0aW9uczonJydcIixcclxuICAgIFwiOicnJ2Zvb3Rub3RlcyBhbmQgY2l0YXRpb25zOicnJ1wiLFxyXG4gICAgXCJmYW1pbHkgc2VhcmNoIGZpbGVzIG9uIGludGVybmV0XCIsXHJcbiAgICBcIm9ubGluZSB0cmVlcy4gd2lsbCBhZGQgc291cmNlcy5cIixcclxuICAgIFwicGVyc29uYWwga25vd2xlZGdlICwgY2Vuc3VzIHJlcG9ydHNcIixcclxuICAgIFwiYSBzb3VyY2UgaXMgc3RpbGwgbmVlZGVkIGZvciB0aGlzIGRhdGEuXCIsXHJcbiAgICBcInNvY2lhbCBzZWN1cml0eSBhcHBsaWNhdGlvbnMgYW5kIGNsYWltc1wiLFxyXG4gICAgXCJhIHNvdXJjZSBmb3IgdGhpcyBpbmZvcm1hdGlvbiBpcyBuZWVkZWRcIixcclxuICAgIFwiYSBzb3VyY2UgZm9yIHRoaXMgaW5mb3JtYXRpb24gaXMgbmVlZGVkLlwiLFxyXG4gICAgXCJyZXBsYWNlIHRoaXMgY2l0YXRpb24gaWYgdGhlcmUgaXMgYW5vdGhlciBzb3VyY2VcIixcclxuICAgIFwicGVyc29uYWwgcmVjb2xsZWN0aW9uLCBhcyB0b2xkIHRvIG1lIGJ5IHRoZWlyIHJlbGF0aXZlLiBub3RlcyBhbmQgc291cmNlcyBpbiB0aGVpciBwb3NzZXNzaW9uLlwiLFxyXG4gICAgXCJtaWNoYWVsIGxlY2huZXIsXCIsXHJcbiAgICBcInZpcmdpbmlhIGhhbmtzXCIsXHJcbiAgICBcInRlcmVzYSBhLiB0aGVvZG9yZVwiLFxyXG4gICAgXCJtaWNoYWVsIGVuZXJpaXNcIixcclxuICAgIC8qXHJcbiAgICBcInNwaXNcIixcclxuICAgIFwiY2Vuc29cIixcclxuICAgIFwicG9waXNcIixcclxuICAgIFwiYmFkYW5pYVwiLFxyXG4gICAgXCJyaWNlcmNhXCIsXHJcbiAgICBcInNlIGF2ZW5cIixcclxuICAgIFwic2Ugw6R2ZW5cIixcclxuICAgIFwic2Ugb2dzw6VcIixcclxuICAgIFwic3VrdXB1dVwiLFxyXG4gICAgXCJ0ZWxsaW5nXCIsXHJcbiAgICBcInppZSBvb2tcIixcclxuICAgIFwiw6Z0dGFydHLDqVwiLFxyXG4gICAgXCJsdWRub8WbY2lcIixcclxuICAgIFwicGVzcXVpc2FcIixcclxuICAgIFwic2Ugb2Nrc8OlXCIsXHJcbiAgICBcInN0YW1ib29tXCIsXHJcbiAgICBcInR1dGtpbXVzXCIsXHJcbiAgICBcImZvcnNjaHVuZ1wiLFxyXG4gICAgXCJmb3Jza25pbmdcIixcclxuICAgIFwib25kZXJ6b2VrXCIsXHJcbiAgICBcInJlY2hlcmNoZVwiLFxyXG4gICAgXCJzbMOmZ3RzdHLDplwiLFxyXG4gICAgXCJzbGVrdHN0cmVcIixcclxuICAgIFwic2zDpGt0dHLDpGRcIixcclxuICAgIFwidm9sZ3Qgbm9nXCIsXHJcbiAgICBcImJyb24gbm9kaWdcIixcclxuICAgIFwiY2Vuc2ltZW50b1wiLFxyXG4gICAgXCJmYW1pbGlldHJlXCIsXHJcbiAgICBcImthdHNvIG15w7ZzXCIsXHJcbiAgICBcImthdHNvIG15w7ZzXCIsXHJcbiAgICBcInJhbm5zw7NrbmlyXCIsXHJcbiAgICBcInNqw6EgZWlubmlnXCIsXHJcbiAgICBcInNpZWhlIGF1Y2hcIixcclxuICAgIFwidm9pciBhdXNzaVwiLFxyXG4gICAgXCJ6b2JhY3ogdGXFvFwiLFxyXG4gICAgXCJmYW1pbGllIHRyw6ZcIixcclxuICAgIFwiZm9sa3LDpGtuaW5nXCIsXHJcbiAgICBcInBvZ2xlaiB0dWRpXCIsXHJcbiAgICBcInJlY2Vuc2VtZW50XCIsXHJcbiAgICBcInZlamEgdGFtYsOpbVwiLFxyXG4gICAgXCJ2ZXIgdGFtYmllblwiLFxyXG4gICAgXCJmYW1pbGllYmliZWxcIixcclxuICAgIFwiZm9sa2V0w6ZsbGluZ1wiLFxyXG4gICAgXCJndWFyZGEgYW5jaGVcIixcclxuICAgIFwia8OkbGxhIGJlaMO2dnNcIixcclxuICAgIFwicG90cmViZW4gdmlyXCIsXHJcbiAgICBcInJhemlza292YW5qZVwiLFxyXG4gICAgXCJ2b2xrc3rDpGhsdW5nXCIsXHJcbiAgICBcInZvbGtzdGVsbGluZ1wiLFxyXG4gICAgXCJicm9ubmVuIG5vZGlnXCIsXHJcbiAgICBcImZhbWlsaWVuYmliZWxcIixcclxuICAgIFwiZmFtaWxpZSBiaWJlbFwiLFxyXG4gICAgXCJpbnZlc3RpZ2FjacOzblwiLFxyXG4gICAgXCJuYWNoZm9yc2NodW5nXCIsXHJcbiAgICBcInBlcmhlcmFhbWF0dHVcIixcclxuICAgIFwic291cmNlIHJlcXVpc2VcIixcclxuICAgIFwidm9pciDDqWdhbGVtZW50XCIsXHJcbiAgICBcImRydcW+aW5za28gZHJldm9cIixcclxuICAgIFwiZHJ6ZXdvIHJvZHppbm5lXCIsXHJcbiAgICBcImZhbWlsaWVzdGFtYm9vbVwiLFxyXG4gICAgXCJraWxkZSBuw7hkdmVuZGlnXCIsXHJcbiAgICBcImzDpGhkZSB0YXJ2aXRhYW5cIixcclxuICAgIFwidGFydml0YWFuIGzDpGhkZVwiLFxyXG4gICAgXCJxdWVsbGUgYmVuw7Z0aWd0XCIsXHJcbiAgICBcInbDpGVzdMO2bmxhc2tlbnRhXCIsXHJcbiAgICAqL1xyXG4gICAgXCLDoXJib2wgZGUgZmFtaWxpYVwiLFxyXG4gICAgXCJiaWJsZSBkZSBmYW1pbGxlXCIsXHJcbiAgICBcImZqw7Zsc2t5bGR1YmlibMOtYVwiLFxyXG4gICAgXCJmb250ZSBuZWNlc3PDoXJpYVwiLFxyXG4gICAgXCJmdWVudGUgbmVjZXNhcmlhXCIsXHJcbiAgICBcInBvdHJ6ZWJuZSDFunLDs2TFgm9cIixcclxuICAgIFwicXVlbGxlIG5vdHdlbmRpZ1wiLFxyXG4gICAgXCJmYW1pbGllbnN0YW1tYmF1bVwiLFxyXG4gICAgXCJoZWltaWxkYXIgZXIgw77DtnJmXCIsXHJcbiAgICBcImtvcnZhYSB0w6Rtw6QgdmlpdGVcIixcclxuICAgIFwic291cmNlIG7DqWNlc3NhaXJlXCIsXHJcbiAgICBcImFsYmVybyBnZW5lYWxvZ2ljb1wiLFxyXG4gICAgXCJhcmJyZSBnw6luw6lhbG9naXF1ZVwiLFxyXG4gICAgXCJiZXZvbGtpbmdzcmVnaXN0ZXJcIixcclxuICAgIFwiZXJzw6R0dCBkZXR0YSBjaXRhdFwiLFxyXG4gICAgXCJoZWltaWxkIG5hdcOwc3lubGVnXCIsXHJcbiAgICBcImtpbGRlIGVyIG7DuGR2ZW5kaWdcIixcclxuICAgIFwibmFkb21lc3RpIHRhIGNpdGF0XCIsXHJcbiAgICBcInNraXB0acOwIMO6dCBoZWltaWxkXCIsXHJcbiAgICBcInphc3TEhXBpxIcgdGVuIGN5dGF0XCIsXHJcbiAgICBcImVyc3RhdCBoZW52aXNuaW5nZW5cIixcclxuICAgIFwia29ydmFhIHTDpG3DpCBsYWluYXVzXCIsXHJcbiAgICBcInVkc2tpZnQgZGV0dGUgY2l0YXRcIixcclxuICAgIFwiZXJzZXR6ZSBkaWVzZXMgeml0YXRcIixcclxuICAgIFwicmVlbXBsYXphciBlc3RhIGNpdGFcIixcclxuICAgIFwidmVydmFuZyBkZXplIGNpdGF0aWVcIixcclxuICAgIFwiZXJzdGF0dCBkZXR0ZSBzaXRhdGV0XCIsXHJcbiAgICBcInN1YnN0aXR1YSBlc3RhIGNpdGHDp8Ojb1wiLFxyXG4gICAgXCJlcnPDpHR0IGRlbm5hIGjDpG52aXNuaW5nXCIsXHJcbiAgICBcInJlbXBsYWNleiBjZXR0ZSBjaXRhdGlvblwiLFxyXG4gICAgXCJlcnN0YXR0IGRlbm5lIGhlbnZpc25pbmdlblwiLFxyXG4gICAgXCJzb3N0aXR1aXJlIHF1ZXN0YSBjaXRhemlvbmVcIixcclxuICBdO1xyXG5cclxuICAvLyBhbnl3aGVyZSBpbiBhIGxpbmUgbm90IGEgdmFsaWQgc291cmNlXHJcbiAgaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0ID0gW1xyXG4gICAgXCJ0aHJvdWdoIHRoZSBpbXBvcnQgb2ZcIixcclxuICAgIFwiYWRkIHNvdXJjZXMgaGVyZVwiLFxyXG4gICAgXCJhZGQgW1tzb3VyY2VzXV0gaGVyZVwiLFxyXG4gICAgXCJmYW1pbHkgdHJlZSBtYWtlclwiLFxyXG4gICAgXCIuZnR3XCIsXHJcbiAgICBcInJlcGxhY2UgdGhpcyBjaXRhdGlvbiBpZiB0aGVyZSBpcyBhbm90aGVyIHNvdXJjZVwiLFxyXG4gICAgXCJyZXBsYWNlIHRoaXMgY2l0YXRpb25cIixcclxuICBdO1xyXG5cclxuICAvLyBhbnl3aGVyZSBvbiBhIGxpbmUgaXMgYSB2YWxpZCBzb3VyY2VcclxuICB2YWxpZFBhcnRpYWxTb3VyY2VMaXN0ID0gW1xyXG4gICAgXCJzb3VyY2VzIGFyZSBoaWRkZW4gdG8gcHJvdGVjdFwiLFxyXG4gICAgXCJzb3VyY2VzIGhpZGRlbiB0byBwcm90ZWN0XCIsXHJcbiAgICBcInNvdXJjZSBoaWRkZW4gdG8gcHJvdGVjdFwiXHJcbiAgXTtcclxuXHJcbiAgLy8gb24gdGhlIHN0YXJ0IG9mIGEgbGluZSBub3QgYSB2YWxpZCBzb3VyY2VcclxuICBpbnZhbGlkU3RhcnRQYXJ0aWFsU291cmNlTGlzdCA9IFtcclxuICAgIFwiZW50ZXJlZCBieVwiLFxyXG4gICAgXCJubyBzb3VyY2VzLlwiLFxyXG4gICAgXCJubyByZXBvIHJlY29yZCBmb3VuZFwiLFxyXG4gICAgXCJzb3VyY2Ugd2lsbCBiZSBhZGRlZCBieVwiLFxyXG4gICAgXCJubyBzb3VyIHJlY29yZCBmb3VuZFwiLFxyXG4gICAgXCJubyBub3RlIHJlY29yZCBmb3VuZFwiLFxyXG4gIF07XHJcblxyXG4gIC8vIG9uIGEgbGluZSBieSBpdHNlbGZcclxuICAvLyBub3QgYSB2YWxpZCBzb3VyY2UgZm9yXHJcbiAgLy8gcHJvZmlsZSBib3JuID4gMTUwIG9yIGRpZWQgPiAxMDBcclxuICB0b29PbGRUb1JlbWVtYmVyU291cmNlTGlzdCA9IFtcclxuICAgIFwicGVyc29uYWwgcmVjb2xsZWN0aW9uIG9mIGV2ZW50cyB3aXRuZXNzZWQgYnlcIixcclxuICAgIFwicGVyc29uYWwgcmVjb2xsZWN0aW9uIG9mXCIsXHJcbiAgICBcInBlcnNvbmFsIGtub3dsZWRnZVwiLFxyXG4gICAgXCJmaXJzdCBoYW5kIGtub3dsZWRnZVwiLFxyXG4gICAgXCJmaXJzdGhhbmQga25vd2xlZGdlXCIsXHJcbiAgICBcImbDuHJzdGVow6VuZHMga2VuZHNrYWJcIixcclxuICAgIFwiZW5zaSBrw6RkZW4gdGlldG9cIixcclxuICAgIFwiYWYgZnlyc3R1IGhlbmRpXCIsXHJcbiAgICBcImbDuHJzdGVow6VuZHNramVubnNrYXBcIixcclxuICAgIFwiZsO2cnN0YWhhbmRza8OkbGxhXCIsXHJcbiAgICBcImbDtnJzdGFoYW5kcyBrw6RubmVkb21cIixcclxuICAgIFwiYXMgcmVtZW1iZXJlZCBieVwiLFxyXG4gICAgXCJzZWxvbiBsYSBtw6ltb2lyZSBkZVwiLFxyXG4gICAgXCJ6b2FscyBoZXJpbm5lcmQgZG9vclwiLFxyXG4gICAgXCJlaWdlbiBrZW5uaXNcIixcclxuICAgIFwid2llIGVyaW5uZXJ0IHZvblwiLFxyXG4gICAgXCJ3aXNzZW4gYXVzIGVyc3RlciBoYW5kXCIsXHJcbiAgICBcImNvbW8gbG8gcmVjdWVyZGFcIixcclxuICAgIFwiY29tbyBsZW1icmFkbyBwb3JcIixcclxuICAgIFwiY29tZSByaWNvcmRhdG8gZGFcIixcclxuICAgIFwid2llIGVyaW5uZXJ0XCIsXHJcbiAgICBcImNvbW1lIHJhcHBlbMOpIHBhclwiLFxyXG4gICAgXCJzb20gaHVza2V0IGF2XCIsXHJcbiAgICBcInNvbSBtaW5ucyBhdlwiLFxyXG4gICAgXCJrdXRlbiBtdWlzdGFhXCIsXHJcbiAgICBcImphayB6YXBhbWnEmXRhxYJcIixcclxuICAgIFwia290IHNlIHNwb21pbmphXCIsXHJcbiAgICBcInNvbSBodXNrZXQgYWZcIixcclxuICAgIFwia3V0ZW4gbm4gbXVpc3RhYVwiLFxyXG4gICAgXCJubm4gbXVrYWFuXCIsXHJcbiAgICBcInNhbWt2w6ZtdCBtaW5uaVwiLFxyXG4gICAgXCJodXNrZXQgYXZcIixcclxuICAgIFwiaWjDpWdrb21tZXQgYXZcIixcclxuICBdO1xyXG5cclxuICAvLyBhbnl3aGVyZSBpbiBhIGxpbmVcclxuICAvLyBub3QgYSB2YWxpZCBzb3VyY2UgZm9yXHJcbiAgLy8gcHJvZmlsZSBib3JuID4gMTUwIG9yIGRpZWQgPiAxMDBcclxuICBpbnZhbGlkUGFydGlhbFNvdXJjZUxpc3RUb29PbGQgPSBbXHJcbiAgICBcImZpcnN0IGhhbmQga25vd2xlZGdlXCIsXHJcbiAgICBcImZpcnN0aGFuZCBrbm93bGVkZ2VcIixcclxuICAgIFwicGVyc29uYWwgcmVjb2xsZWN0aW9uXCIsXHJcbiAgICBcImFzIHJlbWVtYmVyZWQgYnlcIixcclxuICAgIFwic2Vsb24gbGEgbcOpbW9pcmUgZGVcIixcclxuICAgIFwiem9hbHMgaGVyaW5uZXJkIGRvb3JcIixcclxuICAgIFwiZWlnZW4ga2VubmlzXCIsXHJcbiAgICBcIndpZSBlcmlubmVydCB2b25cIixcclxuICAgIFwid2lzc2VuIGF1cyBlcnN0ZXIgaGFuZFwiLFxyXG4gICAgXCJjb21vIGxvIHJlY3VlcmRhXCIsXHJcbiAgICBcImNvbW8gbGVtYnJhZG8gcG9yXCIsXHJcbiAgICBcImNvbWUgcmljb3JkYXRvIGRhXCIsXHJcbiAgICBcIndpZSBlcmlubmVydFwiLFxyXG4gICAgXCJjb21tZSByYXBwZWzDqSBwYXJcIixcclxuICAgIFwic29tIGh1c2tldCBhdlwiLFxyXG4gICAgXCJzb20gbWlubnMgYXZcIixcclxuICAgIFwia3V0ZW4gbXVpc3RhYVwiLFxyXG4gICAgXCJqYWsgemFwYW1pxJl0YcWCXCIsXHJcbiAgICBcImtvdCBzZSBzcG9taW5qYVwiLFxyXG4gICAgXCJzb20gaHVza2V0IGFmXCIsXHJcbiAgICBcImt1dGVuIG5uIG11aXN0YWFcIixcclxuICAgIFwibm5uIG11a2FhblwiLFxyXG4gICAgXCJzYW1rdsOmbXQgbWlubmlcIixcclxuICAgIFwiaHVza2V0IGF2XCIsXHJcbiAgICBcImZpcnN0LWhhbmQgaW5mb3JtYXRpb25cIixcclxuICAgIFwiZWlnZW4ga2VubmlzXCIsXHJcbiAgICBcInVuc291cmNlZCBmYW1pbHkgdHJlZSBoYW5kZWQgZG93blwiLFxyXG4gIF07XHJcblxyXG4gIC8vIGxpbmUgYnkgaXRzZWxmXHJcbiAgLy8gbm90IGEgdmFsaWQgc291cmNlIGZvciBQcmUxNzAwXHJcbiAgaW52YWxpZFNvdXJjZUxpc3RQcmUxNzAwID0gW1xyXG4gICAgXCJiaXJ0aCBjZXJ0aWZpY2F0ZVwiLFxyXG4gICAgXCJiaXJ0aCByZWNvcmRcIixcclxuICAgIFwibWFycmlhZ2UgY2VydGlmaWNhdGVcIixcclxuICAgIFwibWFycmlhZ2UgcmVjb3JkXCIsXHJcbiAgICBcImRlYXRoIGNlcnRpZmljYXRlXCIsXHJcbiAgICBcImRlYXRoIHJlY29yZFwiLFxyXG4gICAgXCJpZ2lcIixcclxuICAgIFwiZmFtaWx5IGRhdGFcIixcclxuICAgIFwiY2VydGlmaWNhdCBkZSBuYWlzc2FuY2VcIixcclxuICAgIFwicmVnaXN0cmUgZGUgbmFpc3NhbmNlXCIsXHJcbiAgICBcImNlcnRpZmljYXQgZGUgZMOpY8Ooc1wiLFxyXG4gICAgXCJyZWdpc3RyZSBkZSBkw6ljw6hzXCIsXHJcbiAgICBcInJlZ2lzdHJlIGRlIG1hcmlhZ2VcIixcclxuICAgIFwiZ2Vib29ydGVha3RlXCIsXHJcbiAgICBcImdlYm9vcnRlIGFrdGVcIixcclxuICAgIFwib3ZlcmxpamRlbnNha3RlXCIsXHJcbiAgICBcIm92ZXJsaWpkZW5zIGFjdGVcIixcclxuICAgIFwib3ZlcmxpamRlbnMgYWt0ZVwiLFxyXG4gICAgXCJ0cm91d2FrdGVcIixcclxuICAgIFwidHJvdXdhY3RlXCIsXHJcbiAgICBcInRyb3V3IG9vcmtvbmRlXCIsXHJcbiAgICBcImdlYnVydHN1cmt1bmRlXCIsXHJcbiAgICBcInN0ZXJiZXVya3VuZGVcIixcclxuICAgIFwiaGVpcmF0c3Vya3VuZGVcIixcclxuICAgIFwiYWN0YSBkZSBuYWNpbWllbnRvXCIsXHJcbiAgICBcImFjdGUgZGUgbmFpc3NhbmNlXCIsXHJcbiAgICBcImFrdCB1cm9kemVuaWFcIixcclxuICAgIFwiY2VydGlkw6NvIGRlIG5hc2NpbWVudG9cIixcclxuICAgIFwiY2VydGlmaWNhZG8gZGUgbmFjaW1pZW50b1wiLFxyXG4gICAgXCJjZXJ0aWZpY2F0byBkaSBuYXNjaXRhXCIsXHJcbiAgICBcImbDtmRlbHNlYmV2aXNcIixcclxuICAgIFwiZsO2ZGVsc2Vkb2t1bWVudFwiLFxyXG4gICAgXCJmw7hkc2Vsc2F0dGVzdFwiLFxyXG4gICAgXCJmw7hkc2Vsc3Jla29yZFwiLFxyXG4gICAgXCJyZWdpc3RybyBkZSBuYXNjaW1lbnRvXCIsXHJcbiAgICBcInJvanN0bmkgbGlzdFwiLFxyXG4gICAgXCJyb2pzdG5pIHphcGlzXCIsXHJcbiAgICBcInN5bnR5bcOkdGllZG90IGFrdCB1cm9kemVuaWFcIixcclxuICAgIFwic3ludHltw6R0b2Rpc3R1c1wiLFxyXG4gICAgXCJjZXJ0aWTDo28gZGUgw7NiaXRvXCIsXHJcbiAgICBcImNlcnRpZmljYWRvIGRlIGRlZnVuY2nDs25cIixcclxuICAgIFwiY2VydGlmaWNhdG8gZGkgbW9ydGVcIixcclxuICAgIFwiY2VydHlmaWthdCDFm21pZXJjaVwiLFxyXG4gICAgXCJkw7hkcyBzZXJ0aWZpa2F0XCIsXHJcbiAgICBcImTDuGRzYXR0ZXN0XCIsXHJcbiAgICBcImTDtmRzY2VydGlmaWthdFwiLFxyXG4gICAgXCJrdW9saW50b2Rpc3R1c1wiLFxyXG4gICAgXCJtcmxpxaFraSBsaXN0XCIsXHJcbiAgICBcImFjdGEgZGUgZGVmdW5jacOzblwiLFxyXG4gICAgXCJhY3RlIGRlIGTDqWPDqHNcIixcclxuICAgIFwiYWt0IHpnb251XCIsXHJcbiAgICBcImTDtmRzcmVrb3JkXCIsXHJcbiAgICBcImt1b2xlbWFudGllZG90XCIsXHJcbiAgICBcInJlZ2lzdHJvIGRlIG1vcnRlXCIsXHJcbiAgICBcInJlZ2lzdHJvIGRlZ2xpIGF0dGkgZGkgbW9ydGVcIixcclxuICAgIFwic21ydG5pIHphcGlzXCIsXHJcbiAgICBcImFrdCBtYcWCxbxlxYRzdHdhXCIsXHJcbiAgICBcImNlcnRpZMOjbyBkZSBjYXNhbWVudG9cIixcclxuICAgIFwiY2VydGlmaWNhZG8gZGUgbWF0cmltb25pb1wiLFxyXG4gICAgXCJjZXJ0aWZpY2F0IGRlIG1hcmlhZ2VcIixcclxuICAgIFwiY2VydGlmaWNhdG8gZGkgbWF0cmltb25pb1wiLFxyXG4gICAgXCJlaGV1cmt1bmRlIHRyYXVzY2hlaW5cIixcclxuICAgIFwiaHV3ZWxpamtzYWt0ZVwiLFxyXG4gICAgXCJwb3JvxI1uaSBsaXN0XCIsXHJcbiAgICBcInZpZWxzZXNhdHRlc3RcIixcclxuICAgIFwidmlnc2VsYmV2aXNcIixcclxuICAgIFwidmlnc2Vsc2F0dGVzdFwiLFxyXG4gICAgXCJ2aWhraXRvZGlzdHVzXCIsXHJcbiAgICBcImFjdGUgZGUgbWFyaWFnZVwiLFxyXG4gICAgXCLDpmd0ZXNrYWJzb3B0ZWduZWxzZVwiLFxyXG4gICAgXCLDpGt0ZW5za2FwIHJla29yZFwiLFxyXG4gICAgXCJhdmlvbGlpdHRvIGVubsOkdHlzXCIsXHJcbiAgICBcImVrdGVza2Fwc3Jla29yZFwiLFxyXG4gICAgXCJwb3JvxI1uaSB6YXBpc1wiLFxyXG4gICAgXCJyZWNvcmQgZGkgbWF0cmltb25pb1wiLFxyXG4gICAgXCJyZWdpc3RybyBkZSBjYXNhbWVudG9cIixcclxuICAgIFwicmVnaXN0cm8gZGUgbWF0cmltb25pb1wiLFxyXG4gICAgXCJkw6Vic2F0dGVzdFwiLFxyXG4gICAgXCJkw6FuYXJza3LDoVwiLFxyXG4gICAgXCJkw6FuYXJ2b3R0b3LDsFwiLFxyXG4gICAgXCJkw7Zkc2F0dGVzdFwiLFxyXG4gICAgXCJkw7Zkc2ZhbGxzaW50eWdcIixcclxuICAgIFwiZMO2ZHNub3Rpc1wiLFxyXG4gICAgXCJkw7hkc3JlZ2lzdHJlcmluZ1wiLFxyXG4gICAgXCJkw7hkc3JlZ2lzdHJlcmluZ1wiLFxyXG4gICAgXCJmw6bDsGluZ2Fyc2tyw6FcIixcclxuICAgIFwiZsOmw7BpbmdhcnZvdHRvcsOwXCIsXHJcbiAgICBcImbDtmRlbHNlbm90aXNcIixcclxuICAgIFwiZsO4ZHNlbHNyZWdpc3RyZXJpbmdcIixcclxuICAgIFwiaGrDunNrYXBhcnNrcsOhXCIsXHJcbiAgICBcImhqw7pza2FwYXJ2b3R0b3LDsFwiLFxyXG4gICAgXCJrdW9saW5raXJqYXVzXCIsXHJcbiAgICBcImt1b2xpbm1lcmtpbnTDpFwiLFxyXG4gICAgXCJuYXZuZWF0dGVzdFwiLFxyXG4gICAgXCJzeW50eW3DpGtpcmphdXNcIixcclxuICAgIFwic3ludHltw6RtZXJraW50w6RcIixcclxuICAgIFwidmllbHNlbHNhdHRlc3QgZWwuIHZpZ3NlbHNhdHRlc3RcIixcclxuICAgIFwidmllbHNlcmVnaXN0cmVyaW5nXCIsXHJcbiAgICBcInZpZ3NlbG5vdGlzXCIsXHJcbiAgICBcInZpaGtpbWlzbWVya2ludMOkXCIsXHJcbiAgXTtcclxuXHJcbiAgLy8gYW55d2hlcmUgb24gYSBsaW5lXHJcbiAgLy8gbm90IGEgdmFsaWQgc291cmNlIGZvciBQcmUxNzAwXHJcbiAgaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0UHJlMTcwMCA9IFtcclxuICAgIFwiYW5jZXN0cnkgdHJlZVwiLFxyXG4gICAgXCJwdWJsaWMgbWVtYmVyIHRyZWVcIixcclxuICAgIFwiZmFtaWx5IHRyZWVcIixcclxuICAgIFwiYXJicmUgZ8OpbsOpYWxvZ2lxdWVcIixcclxuICAgIFwiZmFtaWxpZW5zdGFtbWJhdW1cIixcclxuICAgIFwic3RhbWJvb21cIixcclxuICAgIFwiw6FyYm9sIGRlIGZhbWlsaWFcIixcclxuICAgIFwiZHJ1xb5pbnNrbyBkcmV2b1wiLFxyXG4gICAgXCJhbGJlcm8gZ2VuZWFsb2dpY29cIixcclxuICAgIFwiZmFtaWxpZXN0YW1ib29tXCIsXHJcbiAgICBcImZhbWlsaWUgdHLDplwiLFxyXG4gICAgXCJmYW1pbGlldHJlXCIsXHJcbiAgICBcInNsw6RrdHRyw6RkXCIsXHJcbiAgICBcInN1a3VwdXVcIixcclxuICAgIFwiZHJ6ZXdvIHJvZHppbm5lXCIsXHJcbiAgICBcImZhbWlseS10cmVlXCIsXHJcbiAgICBcImZhbWlseXNlYXJjaC5vcmcvdHJlZVwiLFxyXG4gICAgXCJ0cmVlcy5hbmNlc3RyeS5jb21cIixcclxuICAgIFwiZ2VuaSB0cmVlXCIsXHJcbiAgICBcImFuY2VzdHJhbCBmaWxlXCIsXHJcbiAgICBcImJ1cmtlJ3MgcGVlcmFnZVwiLFxyXG4gICAgXCJidXJrZeKAmXMgZG9ybWFudCBhbmQgZXh0aW5jdCBwZWVyYWdlc1wiLFxyXG4gICAgXCJidXJrZeKAmXMgZXh0aW5jdCBhbmQgZG9ybWFudCBiYXJvbmV0Y2llc1wiLFxyXG4gICAgXCJidXJrZeKAmXMgcGVlcmFnZSBhbmQgYmFyb25ldGFnZVwiLFxyXG4gICAgXCJjYXBlZGlhXCIsXHJcbiAgICBcImRpY3Rpb25uYWlyZSB1bml2ZXJzZWwgZGUgbGEgbm9ibGVzc2UgZGUgZnJhbmNlXCIsXHJcbiAgICBcImZhYnBlZGlncmVlLmNvbVwiLFxyXG4gICAgXCJmYW1pbHkgZGF0YSBjb2xsZWN0aW9uXCIsXHJcbiAgICBcImdlbmVhbG9naWUucXVlYmVjXCIsXHJcbiAgICBcImdlbmVhbG9naWVvbmxpbmVcIixcclxuICAgIFwiZ2VuZWFsb2d5IG9mIHRoZSB3aXZlcyBvZiB0aGUgYW1lcmljYW4gcHJlc2lkZW50c1wiLFxyXG4gICAgXCJnZW5lYW5ldCB0cmVlXCIsXHJcbiAgICBcImhpc3Rvcmlza2UgZWZ0ZXJyZXRuaW5nZXIgb20gdmVyZm9ydGllbnRlIGRhbnNrZSBhZGVsc21hZW5kXCIsXHJcbiAgICBcImh0dHBzOi8va2luZHJlZC5zdGFuZm9yZC5lZHVcIixcclxuICAgIFwiaW50ZXJuYXRpb25hbCBnZW5lYWxvZ2ljYWwgaW5kZXhcIixcclxuICAgIFwiamVhbi1iYXB0aXN0ZS1waWVycmUganVsbGllbiBkZSBjb3VyY2VsbGVzXCIsXHJcbiAgICBcImtpbmRyZWQgYnJpdGFpblwiLFxyXG4gICAgXCJtaWxsZW5uaXVtIGZpbGVcIixcclxuICAgIFwibXloZXJpdGFnZSB0cmVlXCIsXHJcbiAgICBcIm5pY29sYXMgdml0b24gZGUgc2FpbnQtYWxsYWlzXCIsXHJcbiAgICBcIm5vYmlsaWFpcmUgdW5pdmVyc2VsIGRlIGZyYW5jZVwiLFxyXG4gICAgXCJub3NvcmlnaW5lc1wiLFxyXG4gICAgXCJub3Mgb3JpZ2luZXNcIixcclxuICAgIFwibm9zIG9yaWdpbmVzLlwiLFxyXG4gICAgXCJvdXIgY29tbW9uIGFuY2VzdG9yc1wiLFxyXG4gICAgXCJvdXIgcm95YWwsIHRpdGxlZCwgbm9ibGUsIGFuZCBjb21tb25lciBhbmNlc3RvcnNcIixcclxuICAgIFwib3VyLXJveWFsLXRpdGxlZC1ub2JsZS1hbmQtY29tbW9uZXItYW5jZXN0b3JzLmNvbVwiLFxyXG4gICAgXCJwZWRpZ3JlZSByZXNvdXJjZSBmaWxlXCIsXHJcbiAgICBcInJvZ2xvXCIsXHJcbiAgICBcInJvb3Rzd2ViIHRyZWVcIixcclxuICAgIFwic3Rpcm5ldC5jb21cIixcclxuICAgIFwidGhlIHBlZXJhZ2VcIixcclxuICAgIFwidGhlcGVlcmFnZS5jb21cIixcclxuICAgIFwidHVkb3IgcGxhY2VcIixcclxuICAgIFwidS5zLiBhbmQgaW50ZXJuYXRpb25hbCBtYXJyaWFnZSByZWNvcmRzLCAxNTYwLTE5MDBcIixcclxuICAgIFwidXMgYW5kIGludGVybmF0aW9uYWwgbWFycmlhZ2VzIEluZGV4XCIsXHJcbiAgICBcInZvcmUgZsOmbGxlcyBhaG5lclwiLFxyXG4gICAgXCJ3d3cuZ2VuZWFsb2dpZW9ubGluZS5ubFwiLFxyXG4gICAgXCJ3d3cudHVkb3JwbGFjZS5jb20uYXJcIixcclxuICAgIFwiYW5jZXN0cnkuY29tLW9uZXdvcmxkIHRyZWVcIixcclxuICAgIFwib25lIHdvcmxkIHRyZWVcIixcclxuICAgIFwiZmFtaWx5IGdyb3VwIHNoZWV0XCIsXHJcbiAgICBcImFkZGVkIGJ5IGNvbmZpcm1pbmcgYSBzbWFydCBtYXRjaFwiLFxyXG4gICAgXCJ3b3JsZCBmYW1pbHkgdHJlZVwiLFxyXG4gICAgXCJkZXJidW5kIHdmdFwiLFxyXG4gICAgXCJ3d3cuZ2VuY2lyY2xlcy5jb21cIixcclxuICBdO1xyXG5cclxuICBzb3VyY2VSdWxlc0xpc3QgPSBbXHJcbiAgICB0aGlzLmJpb2dyYXBoeUhlYWRpbmdzLFxyXG4gICAgdGhpcy5zb3VyY2VzSGVhZGluZ3MsXHJcbiAgICB0aGlzLnJlc2VhcmNoTm90ZXNIZWFkaW5ncyxcclxuICAgIHRoaXMuYWNrbm93bGVkZ21lbnRzSGVhZGluZ3MsXHJcbiAgICB0aGlzLmNlbnN1c1N0cmluZ3MsXHJcbiAgICB0aGlzLmludmFsaWRTb3VyY2VMaXN0LFxyXG4gICAgdGhpcy5pbnZhbGlkUGFydGlhbFNvdXJjZUxpc3QsXHJcbiAgICB0aGlzLnZhbGlkUGFydGlhbFNvdXJjZUxpc3QsXHJcbiAgICB0aGlzLmludmFsaWRTdGFydFBhcnRpYWxTb3VyY2VMaXN0LFxyXG4gICAgdGhpcy50b29PbGRUb1JlbWVtYmVyU291cmNlTGlzdCxcclxuICAgIHRoaXMuaW52YWxpZFBhcnRpYWxTb3VyY2VMaXN0VG9vT2xkLFxyXG4gICAgdGhpcy5pbnZhbGlkU291cmNlTGlzdFByZTE3MDAsXHJcbiAgICB0aGlzLmludmFsaWRQYXJ0aWFsU291cmNlTGlzdFByZTE3MDBcclxuICBdO1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgU291cmNlUnVsZXMgfSBmcm9tIFwiLi9Tb3VyY2VSdWxlcy5qc1wiXHJcbmltcG9ydCB7IFBlcnNvbkRhdGUgfSBmcm9tIFwiLi9QZXJzb25EYXRlLmpzXCJcclxuaW1wb3J0IHsgQmlvZ3JhcGh5IH0gZnJvbSBcIi4vQmlvZ3JhcGh5LmpzXCJcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCdiaW9DaGVjaycsIChyZXN1bHQpID0+IHtcclxuXHRpZiAocmVzdWx0LmJpb0NoZWNrKSB7XHJcblxyXG4gICAgLy8gd2FudCB0byBjaGVjayBvbiBzdGFydCwgb24gZHJhZnQgc2F2ZSwgYW5kXHJcbiAgICAvLyBvbiBhIHNjaGVkdWxlZCBpbnRlcnZhbFxyXG5cclxuICAgIC8vIE9ubHkgZG8gdGhpcyBpZiBvbiB0aGUgZWRpdCBwYWdlIGZvciBhIHBlcnNvblxyXG4gICAgLy8gQW5kIEFTU1VNRSB0aGF0IGlmIHRoZXJlIGlzIGEgbUJpcnRoRGF0ZSBpdCdzIGEgcGVyc29uIGVkaXQgcGFnZVxyXG4gICAgLy8gcHJldmlvdXMgY29kZSB0cmllZCBpZiAoJChcImJvZHkucGFnZS1TcGVjaWFsX0VkaXRQZXJzb25cIikubGVuZ3RoKSB7XHJcbiAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtQmlydGhEYXRlXCIpKSB7XHJcbiAgICAgIGxldCB0aGVTb3VyY2VSdWxlcyA9IG5ldyBTb3VyY2VSdWxlcygpO1xyXG4gICAgICBjaGVja0Jpbyh0aGVTb3VyY2VSdWxlcyk7XHJcblxyXG5cclxuICAgICAgbGV0IHNhdmVEcmFmdEJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwid3BTYXZlRHJhZnRcIik7XHJcbiAgICAgIHNhdmVEcmFmdEJ1dHRvbi5vbmNsaWNrID0gZnVuY3Rpb24oKXtjaGVja0Jpbyh0aGVTb3VyY2VSdWxlcyl9O1xyXG5cclxuICAgICAgLy8gYW5kIGFsc28gb25jZSBhIG1pbnV0ZVxyXG4gICAgICBzZXRJbnRlcnZhbChjaGVja0F0SW50ZXJ2YWwsIDYwMDAwLCB0aGVTb3VyY2VSdWxlcyk7XHJcblxyXG4gICAgfVxyXG4gIH1cclxufSk7XHJcblxyXG4vLyBDaGVjayBhdCBhbiBpbnRlcnZhbFxyXG5mdW5jdGlvbiBjaGVja0F0SW50ZXJ2YWwodGhlU291cmNlUnVsZXMpIHtcclxuICBjaGVja0Jpbyh0aGVTb3VyY2VSdWxlcyk7XHJcbn1cclxuXHJcbi8qXHJcbiAqIE5vdGVzIGFib3V0IHBhY2thZ2luZyBhbmQgZGlmZmVyZW5jZXMgZnJvbSB0aGUgQmlvQ2hlY2sgYXBwXHJcbiAqXHJcbiAqIENvcGllZCB0aGUgZm9sbG93aW5nIGZpbGVzOlxyXG4gKiAgIGJpb2dyYXBoeS5qc1xyXG4gKiAgIGJpb2dyYXBoeVJlc3VsdHMuanNcclxuICogICBwZXJzb25EYXRlLmpzXHJcbiAqICAgc291cmNlUnVsZXMuanNcclxuICogYW5kIGNoYW5nZWQgZWFjaCB0byByZW1vdmUgdGhlIGV4cG9ydFxyXG4gKiBhbmQgY2hhbmdlIGJpb2dyYXBoeSB0byByZW1vdmUgdGhlIGltcG9ydFxyXG4gKiBcclxuICogdGhlbiBwdXQgZWFjaCBvZiB0aG9zZSBmaWxlcyBpbnRvIGZlYXR1cmVzL2Jpb2NoZWNrXHJcbiAqIGFkZCBlYWNoIHRvIHRoZSBtYW5pZmVzdC5qc29uXHJcbiAqIGFkZCBlYWNoIHRvIGNvcmUvb3B0aW9ucy5odG1sIHdpdGggYSBzY3JpcHQgdHlwZT1tb2R1bGVcclxuICpcclxuICogV2hlbiBjaGVja2luZyBhIGJpb2dyYXBoeSB0aGVyZSBpcyBubyBjaGVjayBmb3IgcHJpdmFjeVxyXG4gKiB0byBhc3N1bWUgYW4gdW5kYXRlZCBwcm9maWxlIGlzIHVuc291cmNlZCBhbmRcclxuICogbmV2ZXIgY2hlY2sgZm9yIHRoZSBiaW9ncmFwaHkgaXMgYXV0by1nZW5lcmF0ZWQgc3RyaW5nXHJcbiAqL1xyXG5cclxuZnVuY3Rpb24gY2hlY2tCaW8odGhlU291cmNlUnVsZXMpIHtcclxuICBsZXQgdGhlUGVyc29uID0gbmV3IFBlcnNvbkRhdGUoKTtcclxuXHJcbiAgLy8gZ2V0IHRoZSBiaW8gdGV4dCBhbmQgcGVyc29uIGRhdGVzIHRvIGNoZWNrXHJcbiAgbGV0IGJpb1N0cmluZyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwid3BUZXh0Ym94MVwiKS52YWx1ZTtcclxuICBsZXQgYmlydGhEYXRlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtQmlydGhEYXRlXCIpLnZhbHVlO1xyXG4gIGxldCBkZWF0aERhdGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1EZWF0aERhdGVcIikudmFsdWU7XHJcblxyXG4gIHRoZVBlcnNvbi5pbml0V2l0aERhdGVzKGJpcnRoRGF0ZSwgZGVhdGhEYXRlKTtcclxuICBsZXQgYmlvZ3JhcGh5ID0gbmV3IEJpb2dyYXBoeSh0aGVTb3VyY2VSdWxlcyk7XHJcbiAgYmlvZ3JhcGh5LnBhcnNlKGJpb1N0cmluZywgdGhlUGVyc29uLmlzUGVyc29uUHJlMTUwMCgpLCB0aGVQZXJzb24uaXNQZXJzb25QcmUxNzAwKCksIHRoZVBlcnNvbi5tdXN0QmVPcGVuKCksIHRoZVBlcnNvbi5pc1VuZGF0ZWQoKSwgZmFsc2UpO1xyXG4gIGJpb2dyYXBoeS52YWxpZGF0ZSgpO1xyXG5cclxuICAvLyBub3cgcmVwb3J0IGZyb20gYmlvZ3JhcGh5LmJpb1Jlc3VsdHNcclxuICAvLyB1c2UgSFRNTCBlc2NhcGUgY29kZXMgZm9yIHNwZWNpYWwgY2hhcmFjdGVyc1xyXG4gIGxldCByZWYgPSBcIiYjNjByZWYmIzYyXCI7XHJcbiAgbGV0IHJlZkVuZCA9IFwiJiM2MCYjNDdyZWYmIzYyXCI7XHJcbiAgbGV0IHJlZmVyZW5jZXNUYWcgPSBcIiYjNjByZWZlcmVuY2VzICYjNDcmIzYyXCI7XHJcblxyXG4gIGxldCBwcm9maWxlUmVwb3J0TGluZXMgPSAoW10pO1xyXG4gIGxldCBwcm9maWxlU3RhdHVzID0gXCJQcm9maWxlIGFwcGVhcnMgdG8gaGF2ZSBzb3VyY2VzLlwiO1xyXG4gIGlmIChiaW9ncmFwaHkuYmlvUmVzdWx0cy5zdGF0cy5iaW9Jc01hcmtlZFVuc291cmNlZCkge1xyXG4gICAgcHJvZmlsZVN0YXR1cyA9IFwiUHJvZmlsZSBpcyBtYXJrZWQgdW5zb3VyY2VkLlwiO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBpZiAoIWJpb2dyYXBoeS5iaW9SZXN1bHRzLnNvdXJjZXMuc291cmNlc0ZvdW5kKSB7XHJcbiAgICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgbWF5IGJlIHVuc291cmNlZC5cIjtcclxuICAgIH1cclxuICB9XHJcbiAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcblxyXG4gIGlmIChiaW9ncmFwaHkuYmlvUmVzdWx0cy5zdGF0cy5iaW9Jc0VtcHR5KSB7XHJcbiAgICBwcm9maWxlU3RhdHVzID0gXCJQcm9maWxlIGlzIGVtcHR5XCI7XHJcbiAgICBwcm9maWxlUmVwb3J0TGluZXMucHVzaChwcm9maWxlU3RhdHVzKTtcclxuICB9XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLm1pc3BsYWNlZExpbmVDb3VudCA+IDApIHtcclxuICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgaGFzIFwiICsgYmlvZ3JhcGh5LmJpb1Jlc3VsdHMuc3R5bGUubWlzcGxhY2VkTGluZUNvdW50O1xyXG4gICAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLm1pc3BsYWNlZExpbmVDb3VudCA9PT0gMSkge1xyXG4gICAgICBwcm9maWxlU3RhdHVzICs9IFwiIGxpbmVcIjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHByb2ZpbGVTdGF0dXMgKz0gXCIgbGluZXNcIjtcclxuICAgIH1cclxuICAgIHByb2ZpbGVTdGF0dXMgKz0gXCIgYmV0d2VlbiBTb3VyY2VzIGFuZCBcIiArIHJlZmVyZW5jZXNUYWc7XHJcbiAgICBwcm9maWxlUmVwb3J0TGluZXMucHVzaChwcm9maWxlU3RhdHVzKTtcclxuICB9XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLmhhc0VuZGxlc3NDb21tZW50KSB7XHJcbiAgICBwcm9maWxlU3RhdHVzID0gXCJQcm9maWxlIGhhcyBjb21tZW50IHdpdGggbm8gZW5kXCI7XHJcbiAgICBwcm9maWxlUmVwb3J0TGluZXMucHVzaChwcm9maWxlU3RhdHVzKTtcclxuICB9XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1JlZldpdGhvdXRFbmQpIHtcclxuICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgaGFzIGlubGluZSBcIiArIHJlZiArIFwiIHdpdGggbm8gZW5kaW5nIFwiICsgcmVmRW5kO1xyXG4gICAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcbiAgfVxyXG4gIGlmIChiaW9ncmFwaHkuYmlvUmVzdWx0cy5zdHlsZS5iaW9IYXNTcGFuV2l0aG91dEVuZGluZ1NwYW4pIHtcclxuICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgaGFzIHNwYW4gd2l0aCBubyBlbmRpbmcgc3BhblwiO1xyXG4gICAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcbiAgfVxyXG4gIGlmIChiaW9ncmFwaHkuYmlvUmVzdWx0cy5zdHlsZS5iaW9Jc01pc3NpbmdCaW9ncmFwaHlIZWFkaW5nKSB7XHJcbiAgICBwcm9maWxlU3RhdHVzID0gXCJQcm9maWxlIGlzIG1pc3NpbmcgQmlvZ3JhcGh5IGhlYWRpbmdcIjtcclxuICAgIHByb2ZpbGVSZXBvcnRMaW5lcy5wdXNoKHByb2ZpbGVTdGF0dXMpO1xyXG4gIH1cclxuICBpZiAoYmlvZ3JhcGh5LmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzTXVsdGlwbGVCaW9IZWFkaW5ncykge1xyXG4gICAgcHJvZmlsZVN0YXR1cyA9IFwiUHJvZmlsZSBoYXMgbW9yZSB0aGFuIG9uZSBCaW9ncmFwaHkgaGVhZGluZ1wiO1xyXG4gICAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcbiAgfVxyXG4gIGlmIChiaW9ncmFwaHkuYmlvUmVzdWx0cy5zdHlsZS5iaW9IZWFkaW5nV2l0aE5vTGluZXNGb2xsb3dpbmcpIHtcclxuICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgaGFzIGVtcHR5ICBCaW9ncmFwaHkgc2VjdGlvblwiO1xyXG4gICAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcbiAgfVxyXG4gIGxldCBzb3VyY2VzSGVhZGluZyA9IChbXSk7XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLmJpb0lzTWlzc2luZ1NvdXJjZXNIZWFkaW5nKSB7XHJcbiAgICBwcm9maWxlU3RhdHVzID0gXCJQcm9maWxlIGlzIG1pc3NpbmcgU291cmNlcyBoZWFkaW5nXCI7XHJcbiAgICBwcm9maWxlUmVwb3J0TGluZXMucHVzaChwcm9maWxlU3RhdHVzKTtcclxuICB9XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc011bHRpcGxlU291cmNlSGVhZGluZ3MpIHtcclxuICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgaGFzIG1vcmUgdGhhbiBvbmUgU291cmNlcyBoZWFkaW5nXCI7XHJcbiAgICBwcm9maWxlUmVwb3J0TGluZXMucHVzaChwcm9maWxlU3RhdHVzKTtcclxuICB9XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLnNvdXJjZXNIZWFkaW5nSGFzRXh0cmFFcXVhbCkge1xyXG4gICAgcHJvZmlsZVN0YXR1cyA9IFwiUHJvZmlsZSBTb3VyY2VzIGhlYWRpbmcgaGFzIGV4dHJhID1cIjtcclxuICAgIHByb2ZpbGVSZXBvcnRMaW5lcy5wdXNoKHByb2ZpbGVTdGF0dXMpO1xyXG4gIH1cclxuICBpZiAoYmlvZ3JhcGh5LmJpb1Jlc3VsdHMuc3R5bGUuYmlvSXNNaXNzaW5nUmVmZXJlbmNlc1RhZykge1xyXG4gICAgcHJvZmlsZVN0YXR1cyA9IFwiUHJvZmlsZSBpcyBtaXNzaW5nIFwiICsgcmVmZXJlbmNlc1RhZztcclxuICAgIHByb2ZpbGVSZXBvcnRMaW5lcy5wdXNoKHByb2ZpbGVTdGF0dXMpO1xyXG4gIH1cclxuICBpZiAoYmlvZ3JhcGh5LmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzTXVsdGlwbGVSZWZlcmVuY2VzVGFncykge1xyXG4gICAgcHJvZmlsZVN0YXR1cyA9IFwiUHJvZmlsZSBoYXMgbW9yZSB0aGFuIG9uZSBcIiArIHJlZmVyZW5jZXNUYWc7XHJcbiAgICBwcm9maWxlUmVwb3J0TGluZXMucHVzaChwcm9maWxlU3RhdHVzKTtcclxuICB9XHJcbiAgaWYgKGJpb2dyYXBoeS5iaW9SZXN1bHRzLnN0eWxlLmJpb0hhc1JlZkFmdGVyUmVmZXJlbmNlcykge1xyXG4gICAgcHJvZmlsZVN0YXR1cyA9IFwiUHJvZmlsZSBoYXMgaW5saW5lIFwiICsgcmVmICsgXCIgdGFnIGFmdGVyIFwiICtcclxuICAgICAgICByZWZlcmVuY2VzVGFnO1xyXG4gICAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcbiAgfVxyXG4gIGxldCBhY2tub3dsZWRnZW1lbnRzID0gKFtdKTtcclxuICBpZiAoYmlvZ3JhcGh5LmJpb1Jlc3VsdHMuc3R5bGUuYWNrbm93bGVkZ2VtZW50c0hlYWRpbmdIYXNFeHRyYUVxdWFsKSB7XHJcbiAgICBwcm9maWxlU3RhdHVzID0gXCJQcm9maWxlIEFja25vd2xlZGdlbWVudHMgaGFzIGV4dHJhID1cIjtcclxuICAgIHByb2ZpbGVSZXBvcnRMaW5lcy5wdXNoKHByb2ZpbGVTdGF0dXMpO1xyXG4gIH1cclxuICBpZiAoYmlvZ3JhcGh5LmJpb1Jlc3VsdHMuc3R5bGUuYmlvSGFzQWNrbm93bGVkZ2VtZW50c0JlZm9yZVNvdXJjZXMpIHtcclxuICAgIHByb2ZpbGVTdGF0dXMgPSBcIlByb2ZpbGUgaGFzIEFja25vd2xlZGdlbWVudHMgYmVmb3JlIFNvdXJjZXMgaGVhZGluZ1wiO1xyXG4gICAgcHJvZmlsZVJlcG9ydExpbmVzLnB1c2gocHJvZmlsZVN0YXR1cyk7XHJcbiAgfVxyXG5cclxuICAvL2NvbnNvbGUubG9nKHByb2ZpbGVSZXBvcnRMaW5lcyk7XHJcblxyXG4gIC8vIGFkZCBhIGxpc3QgdG8gdGhlIHBhZ2VcclxuICByZXBvcnRSZXN1bHRzKHByb2ZpbGVSZXBvcnRMaW5lcyk7XHJcbiAgXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlcG9ydFJlc3VsdHMocmVwb3J0TGluZXMpIHtcclxuXHJcbiAgLy8gSWYgeW91IGhhdmUgYmVlbiBoZXJlIGJlZm9yZSBnZXQgYW5kIHJlbW92ZSB0aGUgb2xkIGxpc3Qgb2YgcmVzdWx0c1xyXG4gIGxldCBwcmV2aW91c1Jlc3VsdHMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYmlvQ2hlY2tSZXN1bHRzTGlzdCcpO1xyXG4gIGxldCBiaW9DaGVja1Jlc3VsdHNDb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYmlvQ2hlY2tSZXN1bHRzQ29udGFpbmVyJyk7XHJcbiAgaWYgKCFiaW9DaGVja1Jlc3VsdHNDb250YWluZXIpIHtcclxuICAgIGJpb0NoZWNrUmVzdWx0c0NvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgYmlvQ2hlY2tSZXN1bHRzQ29udGFpbmVyLnNldEF0dHJpYnV0ZSgnaWQnLCAnYmlvY2hlY2tDb250YWluZXInKTtcclxuXHJcbiAgICBsZXQgYmlvQ2hlY2tUaXRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2InKTtcclxuICAgIGJpb0NoZWNrVGl0bGUuaW5uZXJUZXh0ID0gXCJCaW9DaGVjayByZXN1bHRzXCI7XHJcbiAgICBiaW9DaGVja1Jlc3VsdHNDb250YWluZXIuYXBwZW5kQ2hpbGQoYmlvQ2hlY2tUaXRsZSk7XHJcbiAgfVxyXG4gICAgXHJcbiAgLy8gbmVlZCBhIG5ldyBzZXQgb2YgcmVzdWx0c1xyXG4gIGxldCBiaW9SZXN1bHRzTGlzdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3VsJyk7XHJcbiAgYmlvUmVzdWx0c0xpc3Quc2V0QXR0cmlidXRlKCdpZCcsICdiaW9DaGVja1Jlc3VsdHNMaXN0Jyk7XHJcblxyXG4gIGxldCBudW1MaW5lcyA9IHJlcG9ydExpbmVzLmxlbmd0aDtcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IG51bUxpbmVzOyArK2kpIHtcclxuICAgIGxldCBiaW9SZXN1bHRJdGVtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGJpb1Jlc3VsdEl0ZW0uaW5uZXJIVE1MID0gcmVwb3J0TGluZXNbaV07XHJcbiAgICBiaW9SZXN1bHRzTGlzdC5hcHBlbmRDaGlsZChiaW9SZXN1bHRJdGVtKTtcclxuICB9XHJcbiAgLy8gQWRkIG9yIHJlcGxhY2UgdGhlIHJlc3VsdHNcclxuICBpZiAocHJldmlvdXNSZXN1bHRzKSB7XHJcbiAgICBwcmV2aW91c1Jlc3VsdHMucmVwbGFjZVdpdGgoYmlvUmVzdWx0c0xpc3QpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBiaW9DaGVja1Jlc3VsdHNDb250YWluZXIuYXBwZW5kQ2hpbGQoYmlvUmVzdWx0c0xpc3QpO1xyXG5cclxuICAgIGxldCBsYXN0Q29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3N1Z2dlc3Rpb25Db250YWluZXInKTtcclxuICAgIGlmICghbGFzdENvbnRhaW5lcikge1xyXG4gICAgICBsYXN0Q29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ZhbGlkYXRpb25Db250YWluZXInKTtcclxuICAgIH1cclxuICAgIGxhc3RDb250YWluZXIuYWZ0ZXIoYmlvQ2hlY2tSZXN1bHRzQ29udGFpbmVyKTtcclxuICB9XHJcbn1cclxuXHJcbiIsImltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCB7cGFnZVByb2ZpbGV9IGZyb20gJy4uLy4uL2NvcmUvY29tbW9uJztcclxuaW1wb3J0ICcuL2NvbGxhcHNpYmxlRGVzY2VuZGFudHNUcmVlLmNzcyc7XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldCgnY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUnLCAocmVzdWx0KSA9PiB7XHJcblx0aWYgKHJlc3VsdC5jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZSAmJiBwYWdlUHJvZmlsZSA9PSB0cnVlKSB7IFxyXG5cclxuICAgIC8vIExvb2sgb3V0IGZvciB0aGUgYXBwZWFyYW5jZSBvZiBuZXcgbGlzdCBpdGVtcyBpbiB0aGUgZGVzY2VuZGFudHNDb250YWluZXJcclxuICAgIGNvbnN0IGRlc2NlbmRhbnRzT2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihmdW5jdGlvbiAobXV0YXRpb25zX2xpc3QpIHtcclxuICAgICAgbXV0YXRpb25zX2xpc3QuZm9yRWFjaChmdW5jdGlvbiAobXV0YXRpb24pIHtcclxuICAgICAgbXV0YXRpb24uYWRkZWROb2Rlcy5mb3JFYWNoKGZ1bmN0aW9uIChhZGRlZF9ub2RlKSB7XHJcbiAgICAgICAgaWYgKGFkZGVkX25vZGUudGFnTmFtZSA9PSBcIk9MXCIpIHtcclxuICAgICAgICB0aGVMSVMgPSAkKGFkZGVkX25vZGUpLmZpbmQoXCJsaVwiKTtcclxuICAgICAgICB0aGVMSVMuZWFjaChmdW5jdGlvbiAoaW5kZXgsIHRoaW5nKSB7XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBjcmVhdGVEZXNjZW5kYW50c0J1dHRvbihpbmRleCwgdGhpbmcpO1xyXG4gICAgICAgICAgICAgIH0sIDEwKTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoJChcIiNkZXNjZW5kYW50c0NvbnRhaW5lclwiKS5sZW5ndGgpIHtcclxuICAgICAgICBkZXNjZW5kYW50c09ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNkZXNjZW5kYW50c0NvbnRhaW5lclwiKSxcclxuICAgICAgICB7IHN1YnRyZWU6IHRydWUsIGNoaWxkTGlzdDogdHJ1ZSB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBBZGQgYnV0dG9uc1xyXG4gICAgaWYgKCQoXCJib2R5LnBhZ2UtU3BlY2lhbF9EZXNjZW5kYW50c1wiKS5sZW5ndGgpIHtcclxuICAgICAgaWYgKCQoXCJvbFwiKS5sZW5ndGgpIHtcclxuICAgICAgICAkKFwib2wgbGlcIikuZWFjaChmdW5jdGlvbiAoaW5kZXgsIHRoaW5nKSB7XHJcbiAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgY3JlYXRlRGVzY2VuZGFudHNCdXR0b24oaW5kZXgsIHRoaW5nKTtcclxuICAgICAgICAgIH0sIDEwKTtcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlRGVzY2VuZGFudHNCdXR0b24obiwgbGkpIHtcclxuICAgIC8vIEF0dGFjaCBjbGFzcyB0byBhdm9pZCBhZGRpbmcgYnV0dG9uIG1vcmUgdGhhbiBvbmNlXHJcbiAgICAgIGlmIChsaS5jbGFzc0xpc3QuY29udGFpbnMoJ2NvbGxhcHNlJykpIHtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgaWYgKCFpc05leHRTaWJsaW5nRGl2KGxpKSkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICAkKGxpKS5hZGRDbGFzcygnY29sbGFwc2UnKTtcclxuICAgICAgY29uc3QgYnV0dG9uID0gJChcIjxidXR0b24gY2xhc3M9J3dpa2l0cmVldHVyYm8nPi08L2J1dHRvbj5cIik7XHJcbiAgICAgICQoYnV0dG9uKS5jbGljayh0b2dnbGVDb2xsYXBzZSk7XHJcbiAgICAgICQobGkpLnByZXBlbmQoYnV0dG9uKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpc05leHRTaWJsaW5nRGl2KGVsKSB7XHJcbiAgICAgIGlmKGVsLm5leHRFbGVtZW50U2libGluZykge1xyXG4gICAgICAgIGlmIChlbC5uZXh0RWxlbWVudFNpYmxpbmcudGFnTmFtZT09XCJESVZcIikge1xyXG4gICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB0b2dnbGVDb2xsYXBzZShlKSB7XHJcbiAgICAgIGNvbnN0IHMgPSAkKGUudGFyZ2V0KS50ZXh0KCk7XHJcbiAgICAgICQoZS50YXJnZXQpLnRleHQocz09Jy0nID8gJysnIDogJy0nKTtcclxuICAgICAgJChlLnRhcmdldC5wYXJlbnRFbGVtZW50Lm5leHRFbGVtZW50U2libGluZykudG9nZ2xlKCk7XHJcbiAgICB9XHJcbiAgICBcclxuICB9XHJcbn0pO1xyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQgJy4vZGFya01vZGUuY3NzJztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwiZGFya01vZGVcIiwgKHJlc3VsdCkgPT4ge1xyXG4gIGlmIChyZXN1bHQuZGFya01vZGUpIHtcclxuICAgICQoXCJib2R5XCIpLmFkZENsYXNzKFwiZGFya01vZGVcIik7XHJcbiAgICAkKFwiaW1nW3NyYyo9J3dpa2l0cmVlLWxvZ28ucG5nJ11cIikuYXR0cihcclxuICAgICAgXCJzcmNcIixcclxuICAgICAgY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwiaW1hZ2VzL3dpa2l0cmVlLWxvZ28td2hpdGUucG5nXCIpXHJcbiAgICApO1xyXG4gICAgJChcImltZ1tzcmMqPSd3aWtpdHJlZS1zbWFsbC5wbmcnXVwiKS5hdHRyKFxyXG4gICAgICBcInNyY1wiLFxyXG4gICAgICBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWFnZXMvd2lraXRyZWUtbG9nby1zbWFsbC13aGl0ZS5wbmdcIilcclxuICAgICk7XHJcbiAgICAkKFwiaW1nW3NyYyo9J1dpa2ktVHJlZS5naWYnXVwiKS5hdHRyKFxyXG4gICAgICBcInNyY1wiLFxyXG4gICAgICBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWFnZXMvd2lraXRyZWUtbG9nby13aGl0ZS1HMkcucG5nXCIpXHJcbiAgICApO1xyXG4gICAgJChcImltZ1tzcmMqPSdHMkcuZ2lmJ11cIikuYXR0cihcclxuICAgICAgXCJzcmNcIixcclxuICAgICAgY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwiaW1hZ2VzL0cyRy10cmFuc3BhcmVudC5wbmdcIilcclxuICAgICk7XHJcbiAgICAkKFwiaDE6Y29udGFpbnMoQ29ubmVjdGlvbiBGaW5kZXIpXCIpLnBhcmVudCgpLmNzcyhcImJhY2tncm91bmQtaW1hZ2VcIiwgXCJcIik7XHJcbiAgICAkKFwiYm9keS5kYXJrTW9kZS5wYWdlLU1haW5fUGFnZSBkaXYuc2l4dGVlbi5jb2x1bW5zLnRvcFwiKS5jc3MoXHJcbiAgICAgIFwiYmFja2dyb3VuZC1pbWFnZVwiLFxyXG4gICAgICBcInVybChcIiArIGNocm9tZS5ydW50aW1lLmdldFVSTChcImltYWdlcy90cmVlLXdoaXRlLnBuZ1wiKSArIFwiKVwiXHJcbiAgICApO1xyXG5cclxuICAgIC8vIEFkZCBjb2RlIHRvIGlmcmFtZXMgb24gbWVyZ2luZyBjb21wYXJpc29uIHBhZ2UuXHJcbiAgICBpZiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goXCJTcGVjaWFsOk1lcmdlUGVyc29uXCIpKSB7XHJcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBpZnJhbWVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImlmcmFtZVwiKTtcclxuICAgICAgICBpZnJhbWVzLmZvckVhY2goZnVuY3Rpb24gKGZyYW1lKSB7XHJcbiAgICAgICAgICBsZXQgbGlua0VsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpbmtcIik7XHJcbiAgICAgICAgICBsaW5rRWwucmVsID0gXCJzdHlsZXNoZWV0XCI7XHJcbiAgICAgICAgICBsaW5rRWwuaHJlZiA9IGNocm9tZS5ydW50aW1lLmdldFVSTChcImZlYXR1cmVzL2RhcmtNb2RlL2RhcmtNb2RlLmNzc1wiKTtcclxuICAgICAgICAgIGxpbmtFbC50eXBlID0gXCJ0ZXh0L2Nzc1wiO1xyXG4gICAgICAgICAgbGV0IG9Eb2N1bWVudCA9IGZyYW1lLmNvbnRlbnRXaW5kb3cuZG9jdW1lbnQ7XHJcbiAgICAgICAgICBsZXQgdGhlSGVhZCA9IG9Eb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImhlYWRcIilbMF07XHJcbiAgICAgICAgICB0aGVIZWFkLmFwcGVuZENoaWxkKGxpbmtFbCk7XHJcbiAgICAgICAgICBvRG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJib2R5XCIpWzBdLmNsYXNzTGlzdC5hZGQoXCJkYXJrTW9kZVwiKTtcclxuICAgICAgICAgIGxldCBsb2dvID0gb0RvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJpbWdbc3JjKj0nd2lraXRyZWUtc21hbGwucG5nJ11cIik7XHJcbiAgICAgICAgICBpZiAobG9nbykge1xyXG4gICAgICAgICAgICBsb2dvLnNldEF0dHJpYnV0ZShcclxuICAgICAgICAgICAgICBcInNyY1wiLFxyXG4gICAgICAgICAgICAgIGNocm9tZS5ydW50aW1lLmdldFVSTChcImltYWdlcy93aWtpdHJlZS1sb2dvLXNtYWxsLXdoaXRlLnBuZ1wiKVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LCA3MDApO1xyXG4gICAgfVxyXG4gIH1cclxufSk7XHJcbiIsImltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCBDb29raWVzIGZyb20gJ2pzLWNvb2tpZSc7XHJcbmltcG9ydCBEZXhpZSBmcm9tICdkZXhpZSc7XHJcbmltcG9ydCAnLi9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC5jc3MnO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJkaXN0YW5jZUFuZFJlbGF0aW9uc2hpcFwiLCAocmVzdWx0KSA9PiB7XHJcbiAgaWYgKFxyXG4gICAgcmVzdWx0LmRpc3RhbmNlQW5kUmVsYXRpb25zaGlwICYmXHJcbiAgICAkKFwiYm9keS5CRUVcIikubGVuZ3RoID09IDAgJiZcclxuICAgICQoXCJib2R5LnByb2ZpbGVcIikubGVuZ3RoICYmXHJcbiAgICB3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaChcIlNwYWNlOlwiKSA9PSBudWxsXHJcbiAgKSB7XHJcbiAgICBjb25zdCBwcm9maWxlSUQgPSAkKFwiYS5wdXJlQ3NzTWVudWkwIHNwYW4ucGVyc29uXCIpLnRleHQoKTtcclxuICAgIGNvbnN0IHVzZXJJRCA9IENvb2tpZXMuZ2V0KFwid2lraXRyZWVfd3RiX1VzZXJOYW1lXCIpO1xyXG4gICAgdmFyIGRiID0gbmV3IERleGllKFwiQ29ubmVjdGlvbkZpbmRlclJlc3VsdHNcIik7XHJcbiAgICBkYi52ZXJzaW9uKDEpLnN0b3Jlcyh7XHJcbiAgICAgIGRpc3RhbmNlOiBcIlt1c2VySWQraWRdXCIsXHJcbiAgICAgIGNvbm5lY3Rpb246IFwiW3VzZXJJZCtpZF1cIixcclxuICAgIH0pO1xyXG4gICAgZGIub3BlbigpLnRoZW4oZnVuY3Rpb24gKGRiKSB7XHJcbiAgICAgIGRiLmRpc3RhbmNlXHJcbiAgICAgICAgLmdldCh7IHVzZXJJZDogdXNlcklELCBpZDogcHJvZmlsZUlEIH0pXHJcbiAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xyXG4gICAgICAgICAgaWYgKHJlc3VsdCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgaW5pdERpc3RhbmNlQW5kUmVsYXRpb25zaGlwKHVzZXJJRCwgcHJvZmlsZUlEKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICgkKFwiI2Rpc3RhbmNlRnJvbVlvdVwiKS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHByb2ZpbGVOYW1lID0gJChcImgxIHNwYW5baXRlbXByb3A9J25hbWUnXVwiKS50ZXh0KCk7XHJcbiAgICAgICAgICAgICAgJChcImgxXCIpLmFwcGVuZChcclxuICAgICAgICAgICAgICAgICQoXHJcbiAgICAgICAgICAgICAgICAgIGA8c3BhbiBpZD0nZGlzdGFuY2VGcm9tWW91JyB0aXRsZT0nJHtwcm9maWxlTmFtZX0gaXMgJHtyZXN1bHQuZGlzdGFuY2V9IGRlZ3JlZXMgZnJvbSB5b3UuIFxcbkNsaWNrIHRvIHJlZnJlc2guJz4ke3Jlc3VsdC5kaXN0YW5jZX3CsDwvc3Bhbj5gXHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgJChcIiNkaXN0YW5jZUZyb21Zb3VcIikuY2xpY2soZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICQodGhpcykuZmFkZU91dChcInNsb3dcIikucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLmZhZGVPdXQoXCJzbG93XCIpLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgaW5pdERpc3RhbmNlQW5kUmVsYXRpb25zaGlwKHVzZXJJRCwgcHJvZmlsZUlEKTtcclxuICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgdmFyIHJkYiA9IG5ldyBEZXhpZShcIlJlbGF0aW9uc2hpcEZpbmRlclJlc3VsdHNcIik7XHJcbiAgICAgICAgICAgICAgcmRiLnZlcnNpb24oMSkuc3RvcmVzKHtcclxuICAgICAgICAgICAgICAgIHJlbGF0aW9uc2hpcDogXCJbdXNlcklkK2lkXVwiLFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIHJkYi5vcGVuKCkudGhlbihmdW5jdGlvbiAocmRiKSB7XHJcbiAgICAgICAgICAgICAgICByZGIucmVsYXRpb25zaGlwXHJcbiAgICAgICAgICAgICAgICAgIC5nZXQoeyB1c2VySWQ6IHVzZXJJRCwgaWQ6IHByb2ZpbGVJRCB9KVxyXG4gICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQucmVsYXRpb25zaGlwICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICQoXCIjeW91clJlbGF0aW9uc2hpcFRleHRcIikubGVuZ3RoID09IDAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAkKFwiLmFuY2VzdG9yVGV4dFRleHRcIikubGVuZ3RoID09IDAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAkKFwiI2FuY2VzdG9yTGlzdEJveFwiKS5sZW5ndGggPT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZFJlbGF0aW9uc2hpcFRleHQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucmVsYXRpb25zaGlwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LmNvbW1vbkFuY2VzdG9yc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgZG9SZWxhdGlvbnNoaXBUZXh0KHVzZXJJRCwgcHJvZmlsZUlEKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbn0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZmlsZShpZCwgZmllbGRzID0gXCIqXCIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgJC5hamF4KHtcclxuICAgICAgdXJsOiBcImh0dHBzOi8vYXBpLndpa2l0cmVlLmNvbS9hcGkucGhwXCIsXHJcbiAgICAgIGNyb3NzRG9tYWluOiB0cnVlLFxyXG4gICAgICB4aHJGaWVsZHM6IHsgd2l0aENyZWRlbnRpYWxzOiB0cnVlIH0sXHJcbiAgICAgIHR5cGU6IFwiUE9TVFwiLFxyXG4gICAgICBkYXRhVHlwZTogXCJqc29uXCIsXHJcbiAgICAgIGRhdGE6IHsgYWN0aW9uOiBcImdldFByb2ZpbGVcIiwga2V5OiBpZCwgZmllbGRzOiBmaWVsZHMgfSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlc3VsdFswXS5wcm9maWxlO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb25GaW5kZXJSZXN1bHQoaWQxLCBpZDIsIHJlbGF0aXZlcyA9IDApIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgJC5hamF4KHtcclxuICAgICAgdXJsOiBcImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbmRleC5waHBcIixcclxuICAgICAgY3Jvc3NEb21haW46IHRydWUsXHJcbiAgICAgIHhockZpZWxkczogeyB3aXRoQ3JlZGVudGlhbHM6IHRydWUgfSxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIHRpdGxlOiBcIlNwZWNpYWw6Q29ubmVjdGlvblwiLFxyXG4gICAgICAgIGFjdGlvbjogXCJjb25uZWN0XCIsXHJcbiAgICAgICAgcGVyc29uMU5hbWU6IGlkMSxcclxuICAgICAgICBwZXJzb24yTmFtZTogaWQyLFxyXG4gICAgICAgIHJlbGF0aW9uOiByZWxhdGl2ZXMsXHJcbiAgICAgICAgaWdub3JlSWRzOiBcIlwiLFxyXG4gICAgICB9LFxyXG4gICAgICB0eXBlOiBcIlBPU1RcIixcclxuICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbiAoZGF0YSkge30sXHJcbiAgICAgIGVycm9yOiBmdW5jdGlvbiAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0UmVsYXRpb25zaGlwRmluZGVyUmVzdWx0KGlkMSwgaWQyKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0ICQuYWpheCh7XHJcbiAgICAgIHVybDogXCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vaW5kZXgucGhwXCIsXHJcbiAgICAgIGNyb3NzRG9tYWluOiB0cnVlLFxyXG4gICAgICB4aHJGaWVsZHM6IHsgd2l0aENyZWRlbnRpYWxzOiB0cnVlIH0sXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICB0aXRsZTogXCJTcGVjaWFsOlJlbGF0aW9uc2hpcFwiLFxyXG4gICAgICAgIGFjdGlvbjogXCJnZXRSZWxhdGlvbnNoaXBcIixcclxuICAgICAgICBwZXJzb24xX25hbWU6IGlkMSxcclxuICAgICAgICBwZXJzb24yX25hbWU6IGlkMixcclxuICAgICAgfSxcclxuICAgICAgdHlwZTogXCJQT1NUXCIsXHJcbiAgICAgIGRhdGFUeXBlOiBcImpzb25cIixcclxuICAgICAgc3VjY2VzczogZnVuY3Rpb24gKGRhdGEpIHt9LFxyXG4gICAgICBlcnJvcjogZnVuY3Rpb24gKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFkZFJlbGF0aW9uc2hpcFRleHQob1RleHQsIGNvbW1vbkFuY2VzdG9ycykge1xyXG4gIGNvbnN0IGNvbW1vbkFuY2VzdG9yVGV4dE91dCA9IGNvbW1vbkFuY2VzdG9yVGV4dChjb21tb25BbmNlc3RvcnMpO1xyXG4gIGNvbnN0IGNvdXNpblRleHQgPSAkKFxyXG4gICAgXCI8ZGl2IGlkPSd5b3VyUmVsYXRpb25zaGlwVGV4dCcgdGl0bGU9J0NsaWNrIHRvIHJlZnJlc2gnIGNsYXNzPSdyZWxhdGlvbnNoaXBGaW5kZXInPllvdXIgXCIgK1xyXG4gICAgICBvVGV4dCArXHJcbiAgICAgIFwiPHVsIGlkPSd5b3VyQ29tbW9uQW5jZXN0b3InIHN0eWxlPSd3aGl0ZS1zcGFjZTpub3dyYXAnPlwiICtcclxuICAgICAgY29tbW9uQW5jZXN0b3JUZXh0T3V0ICtcclxuICAgICAgXCI8L3VsPjwvZGl2PlwiXHJcbiAgKTtcclxuICAkKFwiaDFcIikuYWZ0ZXIoY291c2luVGV4dCk7XHJcbiAgJChcIiN5b3VyUmVsYXRpb25zaGlwVGV4dFwiKS5jbGljayhmdW5jdGlvbiAoZSkge1xyXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIGxldCBpZDEgPSBDb29raWVzLmdldChcIndpa2l0cmVlX3d0Yl9Vc2VyTmFtZVwiKTtcclxuICAgIGxldCBpZDIgPSAkKFwiYS5wdXJlQ3NzTWVudWkwIHNwYW4ucGVyc29uXCIpLnRleHQoKTtcclxuICAgIGluaXREaXN0YW5jZUFuZFJlbGF0aW9uc2hpcChpZDEsIGlkMik7XHJcbiAgfSk7XHJcbiAgaWYgKGNvbW1vbkFuY2VzdG9ycy5sZW5ndGggPiAyKSB7XHJcbiAgICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLmFwcGVuZChcclxuICAgICAgJChcIjxidXR0b24gY2xhc3M9J3NtYWxsJyBpZD0nc2hvd01vcmVBbmNlc3RvcnMnPk1vcmU8L2J1dHRvbj5cIilcclxuICAgICk7XHJcbiAgICAkKFwiI3Nob3dNb3JlQW5jZXN0b3JzXCIpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgJChcIiN5b3VyQ29tbW9uQW5jZXN0b3IgbGk6bnRoLWNoaWxkKG4rMylcIikudG9nZ2xlKCk7XHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNvbW1vbkFuY2VzdG9yVGV4dChjb21tb25BbmNlc3RvcnMpIHtcclxuICBsZXQgYW5jZXN0b3JUZXh0T3V0ID0gXCJcIjtcclxuICBjb25zdCBwcm9maWxlR2VuZGVyID0gJChcImJvZHlcIilcclxuICAgIC5maW5kKFwibWV0YVtpdGVtcHJvcD0nZ2VuZGVyJ11cIilcclxuICAgIC5hdHRyKFwiY29udGVudFwiKTtcclxuICBsZXQgcG9zc2Vzc2l2ZUFkaiA9IFwidGhlaXJcIjtcclxuICBpZiAocHJvZmlsZUdlbmRlciA9PSBcIm1hbGVcIikge1xyXG4gICAgcG9zc2Vzc2l2ZUFkaiA9IFwiaGlzXCI7XHJcbiAgfVxyXG4gIGlmIChwcm9maWxlR2VuZGVyID09IFwiZmVtYWxlXCIpIHtcclxuICAgIHBvc3Nlc3NpdmVBZGogPSBcImhlclwiO1xyXG4gIH1cclxuICBjb21tb25BbmNlc3RvcnMuZm9yRWFjaChmdW5jdGlvbiAoY29tbW9uQW5jZXN0b3IpIHtcclxuICAgIGNvbnN0IHRoaXNBbmNlc3RvclR5cGUgPSBhbmNlc3RvclR5cGUoXHJcbiAgICAgIGNvbW1vbkFuY2VzdG9yLnBhdGgyTGVuZ3RoIC0gMSxcclxuICAgICAgY29tbW9uQW5jZXN0b3IuYW5jZXN0b3IubUdlbmRlclxyXG4gICAgKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgYW5jZXN0b3JUZXh0T3V0ICs9XHJcbiAgICAgICc8bGk+WW91ciBjb21tb24gYW5jZXN0b3IsIDxhIGhyZWY9XCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS8nICtcclxuICAgICAgY29tbW9uQW5jZXN0b3IuYW5jZXN0b3IubU5hbWUgK1xyXG4gICAgICAnXCI+JyArXHJcbiAgICAgIGNvbW1vbkFuY2VzdG9yLmFuY2VzdG9yLm1EZXJpdmVkLkxvbmdOYW1lV2l0aERhdGVzICtcclxuICAgICAgXCI8L2E+LCBpcyBcIiArXHJcbiAgICAgIHBvc3Nlc3NpdmVBZGogK1xyXG4gICAgICBcIiBcIiArXHJcbiAgICAgIHRoaXNBbmNlc3RvclR5cGUgK1xyXG4gICAgICBcIi48L2xpPlwiO1xyXG4gIH0pO1xyXG4gIHJldHVybiBhbmNlc3RvclRleHRPdXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRvUmVsYXRpb25zaGlwVGV4dCh1c2VySUQsIHByb2ZpbGVJRCkge1xyXG4gIGdldFJlbGF0aW9uc2hpcEZpbmRlclJlc3VsdCh1c2VySUQsIHByb2ZpbGVJRCkudGhlbihmdW5jdGlvbiAoZGF0YSkge1xyXG4gICAgaWYgKGRhdGEpIHtcclxuICAgICAgbGV0IG91dCA9IFwiXCI7XHJcbiAgICAgIHZhciBhUmVsYXRpb25zaGlwID0gdHJ1ZTtcclxuICAgICAgY29uc3QgY29tbW9uQW5jZXN0b3JzID0gW107XHJcbiAgICAgIGxldCByZWFsT3V0ID0gXCJcIjtcclxuICAgICAgbGV0IGR1bW15ID0gJChcIjxodG1sPjwvaHRtbD5cIik7XHJcbiAgICAgIGR1bW15LmFwcGVuZCgkKGRhdGEuaHRtbCkpO1xyXG4gICAgICBpZiAoZHVtbXkuZmluZChcImgxXCIpLmxlbmd0aCkge1xyXG4gICAgICAgIGlmIChkdW1teS5maW5kKFwiaDFcIikuZXEoMCkudGV4dCgpID09IFwiTm8gUmVsYXRpb25zaGlwIEZvdW5kXCIpIHtcclxuICAgICAgICAgIGFSZWxhdGlvbnNoaXAgPSBmYWxzZTtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiTm8gUmVsYXRpb25zaGlwIEZvdW5kXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZiAoZHVtbXkuZmluZChcImgyXCIpLmxlbmd0aCAmJiBhUmVsYXRpb25zaGlwID09IHRydWUpIHtcclxuICAgICAgICBsZXQgb2gyID0gZHVtbXlcclxuICAgICAgICAgIC5maW5kKFwiaDJcIilcclxuICAgICAgICAgIC5lcSgwKVxyXG4gICAgICAgICAgLnRleHQoKVxyXG4gICAgICAgICAgLnJlcGxhY2VBbGwoL1tcXHRcXG5dL2csIFwiXCIpO1xyXG4gICAgICAgIGlmIChkYXRhLmNvbW1vbkFuY2VzdG9ycy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgb3V0ID0gZHVtbXkuZmluZChcImJcIikudGV4dCgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjb25zdCBwcm9maWxlR2VuZGVyID0gJChcImJvZHlcIilcclxuICAgICAgICAgICAgLmZpbmQoXCJtZXRhW2l0ZW1wcm9wPSdnZW5kZXInXVwiKVxyXG4gICAgICAgICAgICAuYXR0cihcImNvbnRlbnRcIik7XHJcbiAgICAgICAgICBpZiAob2gyLm1hdGNoKFwiaXMgdGhlXCIpKSB7XHJcbiAgICAgICAgICAgIG91dCA9IG9oMi5zcGxpdChcImlzIHRoZSBcIilbMV0uc3BsaXQoXCIgb2ZcIilbMF07XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKG9oMi5tYXRjaChcIiBhcmUgXCIpKSB7XHJcbiAgICAgICAgICAgIG91dCA9IG9oMi5zcGxpdChcImFyZSBcIilbMV0ucmVwbGFjZSgvY291c2lucy8sIFwiY291c2luXCIpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaWYgKG91dC5tYXRjaCgvbmVwaGV3fG5pZWNlLykpIHtcclxuICAgICAgICAgICAgaWYgKHByb2ZpbGVHZW5kZXIgPT0gXCJtYWxlXCIpIHtcclxuICAgICAgICAgICAgICBvdXQgPSBvdXQucmVwbGFjZSgvbmVwaGV3fG5pZWNlLywgXCJ1bmNsZVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAocHJvZmlsZUdlbmRlciA9PSBcImZlbWFsZVwiKSB7XHJcbiAgICAgICAgICAgICAgb3V0ID0gb3V0LnJlcGxhY2UoL25lcGhld3xuaWVjZS8sIFwiYXVudFwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgb3V0U3BsaXQgPSBvdXQuc3BsaXQoXCIgXCIpO1xyXG4gICAgICAgIG91dFNwbGl0WzBdID0gb3JkaW5hbFdvcmRUb051bWJlckFuZFN1ZmZpeChvdXRTcGxpdFswXSk7XHJcbiAgICAgICAgb3V0ID0gb3V0U3BsaXQuam9pbihcIiBcIik7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgJChcIiN5b3VyUmVsYXRpb25zaGlwVGV4dFwiKS5sZW5ndGggPT0gMCAmJlxyXG4gICAgICAgICAgJChcIi5hbmNlc3RvclRleHRUZXh0XCIpLmxlbmd0aCA9PSAwICYmXHJcbiAgICAgICAgICAkKFwiI2FuY2VzdG9yTGlzdEJveFwiKS5sZW5ndGggPT0gMFxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgJChcIiN5b3VyUmVsYXRpb25zaGlwVGV4dFwiKS5yZW1vdmUoKTtcclxuICAgICAgICAgIGFkZFJlbGF0aW9uc2hpcFRleHQob3V0LCBkYXRhLmNvbW1vbkFuY2VzdG9ycyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICB2YXIgcmRiID0gbmV3IERleGllKFwiUmVsYXRpb25zaGlwRmluZGVyUmVzdWx0c1wiKTtcclxuICAgICAgcmRiLnZlcnNpb24oMSkuc3RvcmVzKHtcclxuICAgICAgICByZWxhdGlvbnNoaXA6IFwiW3VzZXJJZCtpZF1cIixcclxuICAgICAgfSk7XHJcbiAgICAgIHJkYlxyXG4gICAgICAgIC5vcGVuKClcclxuICAgICAgICAudGhlbihmdW5jdGlvbiAocmRiKSB7XHJcbiAgICAgICAgICByZGIucmVsYXRpb25zaGlwLnB1dCh7XHJcbiAgICAgICAgICAgIHVzZXJJZDogdXNlcklELFxyXG4gICAgICAgICAgICBpZDogcHJvZmlsZUlELFxyXG4gICAgICAgICAgICByZWxhdGlvbnNoaXA6IG91dCxcclxuICAgICAgICAgICAgY29tbW9uQW5jZXN0b3JzOiBkYXRhLmNvbW1vbkFuY2VzdG9ycyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgLy8gRGF0YWJhc2Ugb3BlbmVkIHN1Y2Nlc3NmdWxseVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICAgIC8vIEVycm9yIG9jY3VycmVkXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGFkZERpc3RhbmNlKGRhdGEpIHtcclxuICBpZiAoJChcIiNkZWdyZWVzRnJvbVlvdVwiKS5sZW5ndGggPT0gMCkge1xyXG4gICAgd2luZG93LmRpc3RhbmNlID0gZGF0YS5wYXRoLmxlbmd0aDtcclxuICAgIGNvbnN0IHByb2ZpbGVOYW1lID0gJChcImgxIHNwYW5baXRlbXByb3A9J25hbWUnXVwiKS50ZXh0KCk7XHJcbiAgICAkKFwiaDFcIikuYXBwZW5kKFxyXG4gICAgICAkKFxyXG4gICAgICAgIGA8c3BhbiBpZD0nZGlzdGFuY2VGcm9tWW91JyB0aXRsZT0nJHtwcm9maWxlTmFtZX0gaXMgJHt3aW5kb3cuZGlzdGFuY2V9IGRlZ3JlZXMgZnJvbSB5b3UuJz4ke3dpbmRvdy5kaXN0YW5jZX3CsDwvc3Bhbj5gXHJcbiAgICAgIClcclxuICAgICk7XHJcbiAgICB2YXIgZGIgPSBuZXcgRGV4aWUoXCJDb25uZWN0aW9uRmluZGVyUmVzdWx0c1wiKTtcclxuICAgIGRiLnZlcnNpb24oMSkuc3RvcmVzKHtcclxuICAgICAgZGlzdGFuY2U6IFwiW3VzZXJJZCtpZF1cIixcclxuICAgICAgY29ubmVjdGlvbjogXCJbdXNlcklkK2lkXVwiLFxyXG4gICAgfSk7XHJcbiAgICBkYi5vcGVuKClcclxuICAgICAgLnRoZW4oZnVuY3Rpb24gKGRiKSB7XHJcbiAgICAgICAgZGIuZGlzdGFuY2UucHV0KHtcclxuICAgICAgICAgIHVzZXJJZDogQ29va2llcy5nZXQoXCJ3aWtpdHJlZV93dGJfVXNlck5hbWVcIiksXHJcbiAgICAgICAgICBpZDogJChcImEucHVyZUNzc01lbnVpMCBzcGFuLnBlcnNvblwiKS50ZXh0KCksXHJcbiAgICAgICAgICBkaXN0YW5jZTogd2luZG93LmRpc3RhbmNlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIERhdGFiYXNlIG9wZW5lZCBzdWNjZXNzZnVsbHlcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICAvLyBFcnJvciBvY2N1cnJlZFxyXG4gICAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldERpc3RhbmNlKCkge1xyXG4gIGNvbnN0IGlkMSA9IENvb2tpZXMuZ2V0KFwid2lraXRyZWVfd3RiX1VzZXJOYW1lXCIpO1xyXG4gIGNvbnN0IGlkMiA9ICQoXCJhLnB1cmVDc3NNZW51aTAgc3Bhbi5wZXJzb25cIikudGV4dCgpO1xyXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRDb25uZWN0aW9uRmluZGVyUmVzdWx0KGlkMSwgaWQyKTtcclxuICBhZGREaXN0YW5jZShkYXRhKTtcclxufVxyXG5cclxuZnVuY3Rpb24gb3JkaW5hbChpKSB7XHJcbiAgdmFyIGogPSBpICUgMTAsXHJcbiAgICBrID0gaSAlIDEwMDtcclxuICBpZiAoaiA9PSAxICYmIGsgIT0gMTEpIHtcclxuICAgIHJldHVybiBpICsgXCJzdFwiO1xyXG4gIH1cclxuICBpZiAoaiA9PSAyICYmIGsgIT0gMTIpIHtcclxuICAgIHJldHVybiBpICsgXCJuZFwiO1xyXG4gIH1cclxuICBpZiAoaiA9PSAzICYmIGsgIT0gMTMpIHtcclxuICAgIHJldHVybiBpICsgXCJyZFwiO1xyXG4gIH1cclxuICByZXR1cm4gaSArIFwidGhcIjtcclxufVxyXG5cclxuZnVuY3Rpb24gYW5jZXN0b3JUeXBlKGdlbmVyYXRpb24sIGdlbmRlcikge1xyXG4gIGxldCByZWxUeXBlO1xyXG4gIGlmIChnZW5lcmF0aW9uID4gMCB8fCBnZW5lcmF0aW9uID09IDApIHtcclxuICAgIGlmIChnZW5kZXIgPT0gXCJGZW1hbGVcIikge1xyXG4gICAgICByZWxUeXBlID0gXCJNb3RoZXJcIjtcclxuICAgIH0gZWxzZSBpZiAoZ2VuZGVyID09IFwiTWFsZVwiKSB7XHJcbiAgICAgIHJlbFR5cGUgPSBcIkZhdGhlclwiO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVsVHlwZSA9IFwiUGFyZW50XCI7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChnZW5lcmF0aW9uID4gMSkge1xyXG4gICAgcmVsVHlwZSA9IFwiR3JhbmRcIiArIHJlbFR5cGUudG9Mb3dlckNhc2UoKTtcclxuICB9XHJcbiAgaWYgKGdlbmVyYXRpb24gPiAyKSB7XHJcbiAgICByZWxUeXBlID0gXCJHcmVhdC1cIiArIHJlbFR5cGUudG9Mb3dlckNhc2UoKTtcclxuICB9XHJcbiAgaWYgKGdlbmVyYXRpb24gPiAzKSB7XHJcbiAgICByZWxUeXBlID0gb3JkaW5hbChnZW5lcmF0aW9uIC0gMikgKyBcIiBcIiArIHJlbFR5cGU7XHJcbiAgfVxyXG4gIHJldHVybiByZWxUeXBlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvcmRpbmFsV29yZFRvTnVtYmVyQW5kU3VmZml4KHdvcmQpIHtcclxuICBjb25zdCBvcmRpbmFsc0FycmF5ID0gW1xyXG4gICAgW1wiZmlyc3RcIiwgXCIxc3RcIl0sXHJcbiAgICBbXCJzZWNvbmRcIiwgXCIybmRcIl0sXHJcbiAgICBbXCJ0aGlyZFwiLCBcIjNyZFwiXSxcclxuICAgIFtcImZvdXJ0aFwiLCBcIjR0aFwiXSxcclxuICAgIFtcImZpZnRoXCIsIFwiNXRoXCJdLFxyXG4gICAgW1wic2l4dGhcIiwgXCI2dGhcIl0sXHJcbiAgICBbXCJzZXZlbnRoXCIsIFwiN3RoXCJdLFxyXG4gICAgW1wiZWlndGhcIiwgXCI4dGhcIl0sXHJcbiAgICBbXCJuaW50aFwiLCBcIjl0aFwiXSxcclxuICAgIFtcInRlbnRoXCIsIFwiMTB0aFwiXSxcclxuICAgIFtcImVsZXZlbnRoXCIsIFwiMTF0aFwiXSxcclxuICAgIFtcInR3ZWxmdGhcIiwgXCIxMnRoXCJdLFxyXG4gICAgW1widGhpcnRlZW50aFwiLCBcIjEzdGhcIl0sXHJcbiAgICBbXCJmb3VydGVlbnRoXCIsIFwiMTR0aFwiXSxcclxuICAgIFtcImZpZnRlZW50aFwiLCBcIjE1dGhcIl0sXHJcbiAgICBbXCJzaXh0ZWVudGhcIiwgXCIxNnRoXCJdLFxyXG4gICAgW1wic2V2ZW50ZWVudGhcIiwgXCIxN3RoXCJdLFxyXG4gICAgW1wiZWlnaHRlZW50aFwiLCBcIjE4dGhcIl0sXHJcbiAgICBbXCJuaW5ldGVlbnRoXCIsIFwiMTl0aFwiXSxcclxuICAgIFtcInR3ZW50aWV0aFwiLCBcIjIwdGhcIl0sXHJcbiAgICBbXCJ0d2VudHktZmlyc3RcIiwgXCIyMXN0XCJdLFxyXG4gICAgW1widHdlbnR5LXNlY29uZFwiLCBcIjIybmRcIl0sXHJcbiAgICBbXCJ0d2VudHktdGhpcmRcIiwgXCIyM3JkXCJdLFxyXG4gICAgW1widHdlbnR5LWZvdXJ0aFwiLCBcIjI0dGhcIl0sXHJcbiAgICBbXCJ0d2VudHktZmlmdGhcIiwgXCIyNXRoXCJdLFxyXG4gIF07XHJcbiAgb3JkaW5hbHNBcnJheS5mb3JFYWNoKGZ1bmN0aW9uIChhcnIpIHtcclxuICAgIGlmICh3b3JkID09IGFyclswXSkge1xyXG4gICAgICB3b3JkID0gYXJyWzFdO1xyXG4gICAgICByZXR1cm4gYXJyWzFdO1xyXG4gICAgfVxyXG4gIH0pO1xyXG4gIHJldHVybiB3b3JkO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpbml0RGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAodXNlcklELCBwcm9maWxlSUQpIHtcclxuICAkKFwiI2Rpc3RhbmNlRnJvbVlvdVwiKS5mYWRlT3V0KCkucmVtb3ZlKCk7XHJcbiAgJChcIiN5b3VyUmVsYXRpb25zaGlwVGV4dFwiKS5mYWRlT3V0KCkucmVtb3ZlKCk7XHJcbiAgZ2V0UHJvZmlsZShwcm9maWxlSUQpLnRoZW4oKHBlcnNvbikgPT4ge1xyXG4gICAgY29uc3Qgbm93VGltZSA9IERhdGUucGFyc2UoRGF0ZSgpKTtcclxuICAgIGNvbnN0IGNyZWF0ZWQgPSBEYXRlLnBhcnNlKFxyXG4gICAgICBwZXJzb24uQ3JlYXRlZC5zdWJzdHIoMCwgOCkucmVwbGFjZSgvKC4uLi4pKC4uKSguLikvLCBcIiQxLSQyLSQzXCIpXHJcbiAgICApO1xyXG4gICAgY29uc3QgdGltZURpZmZlcmVuY2UgPSBub3dUaW1lIC0gY3JlYXRlZDtcclxuICAgIGNvbnN0IG5pbmVEYXlzID0gNzc3NjAwMDAwO1xyXG4gICAgaWYgKFxyXG4gICAgICBwZXJzb24uUHJpdmFjeSA+IDI5ICYmXHJcbiAgICAgIHBlcnNvbi5Db25uZWN0ZWQgPT0gMSAmJlxyXG4gICAgICB0aW1lRGlmZmVyZW5jZSA+IG5pbmVEYXlzXHJcbiAgICApIHtcclxuICAgICAgZ2V0RGlzdGFuY2UoKTtcclxuICAgICAgZG9SZWxhdGlvbnNoaXBUZXh0KHVzZXJJRCwgcHJvZmlsZUlEKTtcclxuICAgIH1cclxuICB9KTtcclxufVxyXG4iLCJpbXBvcnQgJCBmcm9tIFwianF1ZXJ5XCI7XHJcbmltcG9ydCB7IGlzT0sgfSBmcm9tIFwiLi4vLi4vY29yZS9jb21tb25cIjtcclxuaW1wb3J0IFwiLi9kcmFmdExpc3QuY3NzXCI7XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldChcImRyYWZ0TGlzdFwiLCAocmVzdWx0KSA9PiB7XHJcbiAgaWYgKHJlc3VsdC5kcmFmdExpc3QpIHtcclxuICAgIC8vIENoZWNrIHRoYXQgV2lraVRyZWUgQkVFIGhhc24ndCBhZGRlZCB0aGlzIGFscmVhZHlcclxuICAgIGlmICgkKFwiYS5kcmFmdHNcIikubGVuZ3RoID09IDApIHtcclxuICAgICAgYWRkRHJhZnRzVG9GaW5kTWVudSgpO1xyXG4gICAgfVxyXG4gICAgaWYgKCQoXCJib2R5LnBhZ2UtU3BlY2lhbF9FZGl0UGVyc29uXCIpLmxlbmd0aCAmJiAkKFwiYS5kcmFmdHNcIikubGVuZ3RoKSB7XHJcbiAgICAgIHNhdmVEcmFmdExpc3QoKTtcclxuICAgIH1cclxuICB9XHJcbn0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlRHJhZnRMaXN0KCkge1xyXG4gIGNvbnN0IHByb2ZpbGVXVElEID0gJChcImEucHVyZUNzc01lbnVpMCBzcGFuLnBlcnNvblwiKS50ZXh0KCk7XHJcbiAgbGV0IGFkZERyYWZ0ID0gZmFsc2U7XHJcbiAgbGV0IHRpbWVOb3cgPSBEYXRlLm5vdygpO1xyXG4gIGxldCBsYXN0V2VlayA9IHRpbWVOb3cgLSA2MDQ4MDAwMDA7XHJcbiAgbGV0IGlzRWRpdFBhZ2UgPSBmYWxzZTtcclxuICBsZXQgdGhlTmFtZSA9ICQoXCJoMVwiKVxyXG4gICAgLnRleHQoKVxyXG4gICAgLnJlcGxhY2UoXCJFZGl0IFByb2ZpbGUgb2YgXCIsIFwiXCIpXHJcbiAgICAucmVwbGFjZUFsbCgvXFwvL2csIFwiXCIpXHJcbiAgICAucmVwbGFjZUFsbCgvSUR8TElOS3xVUkwvZywgXCJcIik7XHJcbiAgaWYgKFxyXG4gICAgJChcIiNkcmFmdFN0YXR1czpjb250YWlucyhzYXZlZCksI3N0YXR1czpjb250YWlucyhTdGFydGluZyB3aXRoIHByZXZpb3VzKVwiKVxyXG4gICAgICAubGVuZ3RoXHJcbiAgKSB7XHJcbiAgICBhZGREcmFmdCA9IHRydWU7XHJcbiAgfSBlbHNlIGlmICgkKFwiYm9keS5wYWdlLVNwZWNpYWxfRWRpdFBlcnNvblwiKS5sZW5ndGgpIHtcclxuICAgIGlzRWRpdFBhZ2UgPSB0cnVlO1xyXG4gIH1cclxuICBpZiAobG9jYWxTdG9yYWdlLmRyYWZ0cykge1xyXG4gICAgbGV0IGRyYWZ0c0FyciA9IFtdO1xyXG4gICAgbGV0IGRyYWZ0c0FycklEcyA9IFtdO1xyXG4gICAgbGV0IGRyYWZ0cyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmRyYWZ0cyk7XHJcbiAgICBkcmFmdHMuZm9yRWFjaChmdW5jdGlvbiAoZHJhZnQpIHtcclxuICAgICAgaWYgKCFkcmFmdHNBcnJJRHMuaW5jbHVkZXMoZHJhZnRbMF0pKSB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgKGFkZERyYWZ0ID09IGZhbHNlIHx8IHdpbmRvdy5mdWxsU2F2ZSA9PSB0cnVlKSAmJlxyXG4gICAgICAgICAgZHJhZnRbMF0gPT0gcHJvZmlsZVdUSUQgJiZcclxuICAgICAgICAgIGlzRWRpdFBhZ2UgPT0gdHJ1ZVxyXG4gICAgICAgICkge1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBpZiAoZHJhZnRbMV0gPiBsYXN0V2Vlaykge1xyXG4gICAgICAgICAgICBkcmFmdHNBcnIucHVzaChkcmFmdCk7XHJcbiAgICAgICAgICAgIGRyYWZ0c0FycklEcy5wdXNoKGRyYWZ0WzBdKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIGlmICghZHJhZnRzQXJySURzLmluY2x1ZGVzKHByb2ZpbGVXVElEKSAmJiBhZGREcmFmdCA9PSB0cnVlKSB7XHJcbiAgICAgIGRyYWZ0c0Fyci5wdXNoKFtwcm9maWxlV1RJRCwgdGltZU5vdywgdGhlTmFtZV0pO1xyXG4gICAgfVxyXG5cclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiZHJhZnRzXCIsIEpTT04uc3RyaW5naWZ5KGRyYWZ0c0FycikpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBpZiAoYWRkRHJhZnQgPT0gdHJ1ZSAmJiB3aW5kb3cuZnVsbFNhdmUgIT0gdHJ1ZSkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcclxuICAgICAgICBcImRyYWZ0c1wiLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KFtbcHJvZmlsZVdUSUQsIHRpbWVOb3csIHRoZU5hbWVdXSlcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHRydWU7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNob3dEcmFmdExpc3QoKSB7XHJcbiAgaWYgKGxvY2FsU3RvcmFnZS5kcmFmdHMpIHtcclxuICAgIGF3YWl0IHVwZGF0ZURyYWZ0TGlzdCgpO1xyXG4gIH1cclxuICAkKFwiI215RHJhZnRzXCIpLnJlbW92ZSgpO1xyXG4gICQoXCJib2R5XCIpLmFwcGVuZChcclxuICAgICQoXCI8ZGl2IGlkPSdteURyYWZ0cyc+PGgyPk15IERyYWZ0czwvaDI+PHg+eDwveD48dGFibGU+PC90YWJsZT48L2Rpdj5cIilcclxuICApO1xyXG4gICQoXCIjbXlEcmFmdHNcIikuZGJsY2xpY2soZnVuY3Rpb24gKCkge1xyXG4gICAgJCh0aGlzKS5zbGlkZVVwKCk7XHJcbiAgfSk7XHJcbiAgJChcIiNteURyYWZ0cyB4XCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgICQodGhpcykucGFyZW50KCkuc2xpZGVVcCgpO1xyXG4gIH0pO1xyXG4gICQoXCIjbXlEcmFmdHNcIikuZHJhZ2dhYmxlKCk7XHJcblxyXG4gIGlmIChsb2NhbFN0b3JhZ2UuZHJhZnRzICE9IHVuZGVmaW5lZCAmJiBsb2NhbFN0b3JhZ2UuZHJhZnRzICE9IFwiW11cIikge1xyXG4gICAgd2luZG93LmRyYWZ0cyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmRyYWZ0cyk7XHJcbiAgICB3aW5kb3cuZHJhZnRDYWxscyA9IDA7XHJcbiAgICB3aW5kb3cudGVtcERyYWZ0QXJyID0gW107XHJcbiAgICB3aW5kb3cuZHJhZnRzLmZvckVhY2goZnVuY3Rpb24gKGRyYWZ0LCBpbmRleCkge1xyXG4gICAgICBjb25zdCB0aGVXVElEID0gZHJhZnRbMF07XHJcbiAgICAgIGlmICghaXNPSyh0aGVXVElEKSkge1xyXG4gICAgICAgIGRlbGV0ZSB3aW5kb3cuZHJhZnRzW2luZGV4XTtcclxuICAgICAgICB3aW5kb3cuZHJhZnRDYWxscysrO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgICQuYWpheCh7XHJcbiAgICAgICAgICB1cmw6XHJcbiAgICAgICAgICAgIFwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2luZGV4LnBocD90aXRsZT1cIiArXHJcbiAgICAgICAgICAgIHRoZVdUSUQgK1xyXG4gICAgICAgICAgICBcIiZkaXNwbGF5RHJhZnQ9MVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJHRVRcIixcclxuICAgICAgICAgIGRhdGFUeXBlOiBcImh0bWxcIiwgLy8gYWRkZWQgZGF0YSB0eXBlXHJcbiAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiAocmVzKSB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5kcmFmdENhbGxzKys7XHJcbiAgICAgICAgICAgIGNvbnN0IGR1bW15ID0gJChyZXMpO1xyXG4gICAgICAgICAgICBjb25zdCBhV1RJRCA9IGR1bW15LmZpbmQoXCJhLnB1cmVDc3NNZW51aTAgc3Bhbi5wZXJzb25cIikudGV4dCgpO1xyXG4gICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgZHVtbXkuZmluZChcImRpdi5zdGF0dXM6Y29udGFpbnMoJ1lvdSBoYXZlIGFuIHVuY29tbWl0dGVkJylcIilcclxuICAgICAgICAgICAgICAgIC5sZW5ndGhcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgd2luZG93LnRlbXBEcmFmdEFyci5wdXNoKGFXVElEKTtcclxuICAgICAgICAgICAgICBjb25zdCB1c2VMaW5rID0gZHVtbXlcclxuICAgICAgICAgICAgICAgIC5maW5kKFwiYTpjb250YWlucyhVc2UgdGhlIERyYWZ0KVwiKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoXCJocmVmXCIpO1xyXG4gICAgICAgICAgICAgIGlmICh1c2VMaW5rICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGVyc29uSUQgPSB1c2VMaW5rXHJcbiAgICAgICAgICAgICAgICAgIC5tYXRjaCgvJnU9WzAtOV0rLylbMF1cclxuICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoXCImdT1cIiwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkcmFmdElEID0gdXNlTGlua1xyXG4gICAgICAgICAgICAgICAgICAubWF0Y2goLyZ1ZD1bMC05XSsvKVswXVxyXG4gICAgICAgICAgICAgICAgICAucmVwbGFjZShcIiZ1ZD1cIiwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICB3aW5kb3cuZHJhZnRzLmZvckVhY2goZnVuY3Rpb24gKHlEcmFmdCkge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoeURyYWZ0WzBdID09IGFXVElEKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgeURyYWZ0WzNdID0gcGVyc29uSUQ7XHJcbiAgICAgICAgICAgICAgICAgICAgeURyYWZ0WzRdID0gZHJhZnRJRDtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh3aW5kb3cuZHJhZnRDYWxscyA9PSB3aW5kb3cuZHJhZnRzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgIHdpbmRvdy5uZXdEcmFmdEFyciA9IFtdO1xyXG4gICAgICAgICAgICAgIHdpbmRvdy5kcmFmdHMuZm9yRWFjaChmdW5jdGlvbiAoYURyYWZ0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgIHdpbmRvdy50ZW1wRHJhZnRBcnIuaW5jbHVkZXMoYURyYWZ0WzBdKSAmJlxyXG4gICAgICAgICAgICAgICAgICBpc09LKGFEcmFmdFswXSlcclxuICAgICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgICB3aW5kb3cubmV3RHJhZnRBcnIucHVzaChhRHJhZnQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICBuZXdEcmFmdEFyci5mb3JFYWNoKGZ1bmN0aW9uICh4RHJhZnQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBkQnV0dG9ucyA9IFwiPHRkPjwvdGQ+PHRkPjwvdGQ+XCI7XHJcbiAgICAgICAgICAgICAgICBpZiAoeERyYWZ0WzNdICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICBkQnV0dG9ucyA9XHJcbiAgICAgICAgICAgICAgICAgICAgXCI8dGQ+PGEgaHJlZj0naHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2luZGV4LnBocD90aXRsZT1TcGVjaWFsOkVkaXRQZXJzb24mdT1cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgeERyYWZ0WzNdICtcclxuICAgICAgICAgICAgICAgICAgICBcIiZ1ZD1cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgeERyYWZ0WzRdICtcclxuICAgICAgICAgICAgICAgICAgICBcIicgY2xhc3M9J3NtYWxsIGJ1dHRvbic+VVNFPC9hPjwvdGQ+PHRkPjxhIGhyZWY9J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbmRleC5waHA/dGl0bGU9U3BlY2lhbDpFZGl0UGVyc29uJnU9XCIgK1xyXG4gICAgICAgICAgICAgICAgICAgIHhEcmFmdFszXSArXHJcbiAgICAgICAgICAgICAgICAgICAgXCImZGQ9XCIgK1xyXG4gICAgICAgICAgICAgICAgICAgIHhEcmFmdFs0XSArXHJcbiAgICAgICAgICAgICAgICAgICAgXCInIGNsYXNzPSdzbWFsbCBidXR0b24nPkRJU0NBUkQ8L2E+PC90ZD5cIjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAkKFwiI215RHJhZnRzIHRhYmxlXCIpLmFwcGVuZChcclxuICAgICAgICAgICAgICAgICAgJChcclxuICAgICAgICAgICAgICAgICAgICBcIjx0cj48dGQ+PGEgaHJlZj0naHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2luZGV4LnBocD90aXRsZT1cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICB4RHJhZnRbMF0gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCImZGlzcGxheURyYWZ0PTEnPlwiICtcclxuICAgICAgICAgICAgICAgICAgICAgIHhEcmFmdFsyXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIjwvYT48L3RkPlwiICtcclxuICAgICAgICAgICAgICAgICAgICAgIGRCdXR0b25zICtcclxuICAgICAgICAgICAgICAgICAgICAgIFwiPC90cj5cIlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICQoXCIjbXlEcmFmdHNcIikuc2xpZGVEb3duKCk7XHJcbiAgICAgICAgICAgICAgaWYgKG5ld0RyYWZ0QXJyLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAkKFwiI215RHJhZnRzXCIpLmFwcGVuZCgkKFwiPHA+Tm8gZHJhZnRzITwvcD5cIikpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImRyYWZ0c1wiLCBKU09OLnN0cmluZ2lmeShuZXdEcmFmdEFycikpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZXJyb3I6IGZ1bmN0aW9uIChyZXMpIHt9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgJChcIiNteURyYWZ0c1wiKS5hcHBlbmQoJChcIjxwPk5vIGRyYWZ0cyE8L3A+XCIpKTtcclxuICAgICQoXCIjbXlEcmFmdHNcIikuc2xpZGVEb3duKCk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBzYXZlRHJhZnRMaXN0KCkge1xyXG4gIHdpbmRvdy5mdWxsU2F2ZSA9IGZhbHNlO1xyXG4gICQoXCIjd3BTYXZlXCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgIHdpbmRvdy5mdWxsU2F2ZSA9IHRydWU7XHJcbiAgfSk7XHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJiZWZvcmV1bmxvYWRcIiwgKGV2ZW50KSA9PiB7XHJcbiAgICB1cGRhdGVEcmFmdExpc3QoKTtcclxuICB9KTtcclxuICAkKFwiI3dwU2F2ZURyYWZ0XCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgIHVwZGF0ZURyYWZ0TGlzdCgpO1xyXG4gIH0pO1xyXG4gIHNldEludGVydmFsKHVwZGF0ZURyYWZ0TGlzdCwgNjAwMDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBhZGREcmFmdHNUb0ZpbmRNZW51KCkge1xyXG4gIGNvbnN0IGNvbm5lY3Rpb25MaSA9ICQoXCJsaSBhLnB1cmVDc3NNZW51aVtocmVmPScvd2lraS9TcGVjaWFsOkNvbm5lY3Rpb24nXVwiKTtcclxuICBjb25zdCBuZXdMaSA9ICQoXHJcbiAgICBcIjxsaT48YSBjbGFzcz0ncHVyZUNzc01lbnVpIGRyYWZ0cycgaWQ9J2RyYWZ0c0xpbmsnIHRpdGxlPSdTZWUgeW91ciB1bmNvbW1pdHRlZCBkcmFmdHMnPkRyYWZ0czwvbGk+XCJcclxuICApO1xyXG4gIG5ld0xpLmluc2VydEFmdGVyKGNvbm5lY3Rpb25MaS5wYXJlbnQoKSk7XHJcbiAgJChcImxpIGEuZHJhZnRzXCIpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzaG93RHJhZnRMaXN0KCk7XHJcbiAgfSk7XHJcbn1cclxuIiwiaW1wb3J0ICQgZnJvbSBcImpxdWVyeVwiO1xyXG5pbXBvcnQgXCJqcXVlcnktdWkvdWkvd2lkZ2V0cy9kcmFnZ2FibGVcIjtcclxuaW1wb3J0IHtcclxuICBjcmVhdGVQcm9maWxlU3VibWVudUxpbmssXHJcbiAgZmFtaWx5QXJyYXksXHJcbiAgZ2V0UmVsYXRpdmVzLFxyXG4gIGlzT0ssXHJcbn0gZnJvbSBcIi4uLy4uL2NvcmUvY29tbW9uXCI7XHJcbmltcG9ydCBcIi4uL2ZhbWlseVRpbWVsaW5lL2ZhbWlseVRpbWVsaW5lLmNzc1wiO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJmYW1pbHlHcm91cFwiLCAocmVzdWx0KSA9PiB7XHJcbiAgaWYgKFxyXG4gICAgcmVzdWx0LmZhbWlseUdyb3VwICYmXHJcbiAgICAkKFwiYm9keS5wcm9maWxlXCIpLmxlbmd0aCAmJlxyXG4gICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goXCJTcGFjZTpcIikgPT0gbnVsbFxyXG4gICkge1xyXG4gICAgLy8gQWRkIGEgbGluayB0byB0aGUgc2hvcnQgbGlzdCBvZiBsaW5rcyBiZWxvdyB0aGUgdGFic1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgdGl0bGU6IFwiRGlzcGxheSBmYW1pbHkgZ3JvdXAgZGF0ZXMgYW5kIGxvY2F0aW9uc1wiLFxyXG4gICAgICBpZDogXCJmYW1pbHlHcm91cEJ1dHRvblwiLFxyXG4gICAgICB0ZXh0OiBcIkZhbWlseSBHcm91cFwiLFxyXG4gICAgICB1cmw6IFwiI25cIixcclxuICAgIH07XHJcbiAgICBjcmVhdGVQcm9maWxlU3VibWVudUxpbmsob3B0aW9ucyk7XHJcbiAgICAkKFwiI1wiICsgb3B0aW9ucy5pZCkuY2xpY2soZnVuY3Rpb24gKGUpIHtcclxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICBjb25zdCBwcm9maWxlSUQgPSAkKFwiYS5wdXJlQ3NzTWVudWkwIHNwYW4ucGVyc29uXCIpLnRleHQoKTtcclxuICAgICAgc2hvd0ZhbWlseVNoZWV0KCQodGhpcylbMF0sIHByb2ZpbGVJRCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzaG93RmFtaWx5U2hlZXQodGhlQ2xpY2tlZCwgcHJvZmlsZUlEKSB7XHJcbiAgICAgIC8vIElmIHRoZSB0YWJsZSBhbHJlYWR5IGV4aXN0cyB0b2dnbGUgaXQuXHJcbiAgICAgIGlmICgkKFwiI1wiICsgcHJvZmlsZUlELnJlcGxhY2UoXCIgXCIsIFwiX1wiKSArIFwiX2ZhbWlseVwiKS5sZW5ndGgpIHtcclxuICAgICAgICAkKFwiI1wiICsgcHJvZmlsZUlELnJlcGxhY2UoXCIgXCIsIFwiX1wiKSArIFwiX2ZhbWlseVwiKS5mYWRlVG9nZ2xlKCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTWFrZSB0aGUgdGFibGUgYW5kIGRvIG90aGVyIHRoaW5nc1xyXG4gICAgICAgIGdldFJlbGF0aXZlcyhwcm9maWxlSUQpLnRoZW4oKHBlcnNvbikgPT4ge1xyXG4gICAgICAgICAgY29uc3QgdVBlb3BsZSA9IGZhbWlseUFycmF5KHBlcnNvbik7XHJcbiAgICAgICAgICAvLyBNYWtlIHRoZSB0YWJsZVxyXG4gICAgICAgICAgY29uc3QgZmFtaWx5VGFibGUgPSBwZW9wbGVUb1RhYmxlKHVQZW9wbGUpO1xyXG4gICAgICAgICAgLy8gQXR0YWNoIHRoZSB0YWJsZSB0byB0aGUgYm9keSwgcG9zaXRpb24gaXQgYW5kIG1ha2UgaXQgZHJhZ2dhYmxlIGFuZCB0b2dnbGVhYmxlXHJcbiAgICAgICAgICBmYW1pbHlUYWJsZS5wcmVwZW5kVG8oXCJib2R5XCIpO1xyXG4gICAgICAgICAgZmFtaWx5VGFibGUuYXR0cihcImlkXCIsIHByb2ZpbGVJRC5yZXBsYWNlKFwiIFwiLCBcIl9cIikgKyBcIl9mYW1pbHlcIik7XHJcbiAgICAgICAgICBmYW1pbHlUYWJsZS5kcmFnZ2FibGUoKTtcclxuICAgICAgICAgIGZhbWlseVRhYmxlLmZhZGVJbigpO1xyXG4gICAgICAgICAgZmFtaWx5VGFibGUub24oXCJkYmxjbGlja1wiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICQodGhpcykuZmFkZU91dCgpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBsZXQgdGhlTGVmdCA9IGdldE9mZnNldCgkKFwiZGl2LnRlbi5jb2x1bW5zXCIpWzBdKS5sZWZ0O1xyXG4gICAgICAgICAgZmFtaWx5VGFibGUuY3NzKHtcclxuICAgICAgICAgICAgdG9wOiBnZXRPZmZzZXQodGhlQ2xpY2tlZCkudG9wICsgNTAsXHJcbiAgICAgICAgICAgIGxlZnQ6IHRoZUxlZnQsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIC8vIEFkanVzdCB0aGUgcG9zaXRpb24gb2YgdGhlIHRhYmxlIG9uIHdpbmRvdyByZXNpemVcclxuICAgICAgICAgICQod2luZG93KS5yZXNpemUoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAoZmFtaWx5VGFibGUubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgdGhlTGVmdCA9IGdldE9mZnNldCgkKFwiZGl2LnRlbi5jb2x1bW5zXCIpWzBdKS5sZWZ0O1xyXG4gICAgICAgICAgICAgIGZhbWlseVRhYmxlLmNzcyh7XHJcbiAgICAgICAgICAgICAgICB0b3A6IGdldE9mZnNldCh0aGVDbGlja2VkKS50b3AgKyA1MCxcclxuICAgICAgICAgICAgICAgIGxlZnQ6IHRoZUxlZnQsXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICQoXCIuZmFtaWx5U2hlZXQgeFwiKS51bmJpbmQoKTtcclxuICAgICAgICAgICQoXCIuZmFtaWx5U2hlZXQgeFwiKS5jbGljayhmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICQodGhpcykucGFyZW50KCkuZmFkZU91dCgpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICAkKFwiLmZhbWlseVNoZWV0IHdcIikudW5iaW5kKCk7XHJcbiAgICAgICAgICAkKFwiLmZhbWlseVNoZWV0IHdcIikuY2xpY2soZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAkKHRoaXMpLnBhcmVudCgpLnRvZ2dsZUNsYXNzKFwid3JhcFwiKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUHV0IGEgZ3JvdXAgb2YgcGVvcGxlIGluIGEgdGFibGVcclxuICAgIGZ1bmN0aW9uIHBlb3BsZVRvVGFibGUoa1Blb3BsZSkge1xyXG4gICAgICBjb25zdCBrVGFibGUgPSAkKFxyXG4gICAgICAgIFwiPGRpdiBjbGFzcz0nZmFtaWx5U2hlZXQnPjx3PuKGlDwvdz48eD54PC94Pjx0YWJsZT48Y2FwdGlvbj48L2NhcHRpb24+PHRoZWFkPjx0cj48dGg+UmVsYXRpb248L3RoPjx0aD5OYW1lPC90aD48dGg+QmlydGggRGF0ZTwvdGg+PHRoPkJpcnRoIFBsYWNlPC90aD48dGg+RGVhdGggRGF0ZTwvdGg+PHRoPkRlYXRoIFBsYWNlPC90aD48L3RyPjwvdGhlYWQ+PHRib2R5PjwvdGJvZHk+PC90YWJsZT48L2Rpdj5cIlxyXG4gICAgICApO1xyXG4gICAgICBrUGVvcGxlLmZvckVhY2goZnVuY3Rpb24gKGtQZXJzKSB7XHJcbiAgICAgICAgbGV0IHJDbGFzcyA9IFwiXCI7XHJcbiAgICAgICAgbGV0IGlzRGVjYWRlcyA9IGZhbHNlO1xyXG4gICAgICAgIGtQZXJzLlJlbGF0aW9uU2hvdyA9IGtQZXJzLlJlbGF0aW9uO1xyXG4gICAgICAgIGlmIChrUGVycy5SZWxhdGlvbiA9PSB1bmRlZmluZWQgfHwga1BlcnMuQWN0aXZlKSB7XHJcbiAgICAgICAgICBrUGVycy5SZWxhdGlvbiA9IFwiU2libGluZ1wiO1xyXG4gICAgICAgICAga1BlcnMuUmVsYXRpb25TaG93ID0gXCJcIjtcclxuICAgICAgICAgIHJDbGFzcyA9IFwic2VsZlwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGJEYXRlO1xyXG4gICAgICAgIGlmIChrUGVycy5CaXJ0aERhdGUpIHtcclxuICAgICAgICAgIGJEYXRlID0ga1BlcnMuQmlydGhEYXRlO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoa1BlcnMuQmlydGhEYXRlRGVjYWRlKSB7XHJcbiAgICAgICAgICBiRGF0ZSA9IGtQZXJzLkJpcnRoRGF0ZURlY2FkZS5zbGljZSgwLCAtMSkgKyBcIi0wMC0wMFwiO1xyXG4gICAgICAgICAgaXNEZWNhZGVzID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgYkRhdGUgPSBcIjAwMDAtMDAtMDBcIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBkRGF0ZTtcclxuICAgICAgICBpZiAoa1BlcnMuRGVhdGhEYXRlKSB7XHJcbiAgICAgICAgICBkRGF0ZSA9IGtQZXJzLkRlYXRoRGF0ZTtcclxuICAgICAgICB9IGVsc2UgaWYgKGtQZXJzLkRlYXRoRGF0ZURlY2FkZSkge1xyXG4gICAgICAgICAgaWYgKGtQZXJzLkRlYXRoRGF0ZURlY2FkZSA9PSBcInVua25vd25cIikge1xyXG4gICAgICAgICAgICBkRGF0ZSA9IFwiMDAwMC0wMC0wMFwiO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZERhdGUgPSBrUGVycy5EZWF0aERhdGVEZWNhZGUuc2xpY2UoMCwgLTEpICsgXCItMDAtMDBcIjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgZERhdGUgPSBcIjAwMDAtMDAtMDBcIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChrUGVycy5CaXJ0aExvY2F0aW9uID09IG51bGwgfHwga1BlcnMuQmlydGhMb2NhdGlvbiA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgIGtQZXJzLkJpcnRoTG9jYXRpb24gPSBcIlwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGtQZXJzLkRlYXRoTG9jYXRpb24gPT0gbnVsbCB8fCBrUGVycy5EZWF0aExvY2F0aW9uID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAga1BlcnMuRGVhdGhMb2NhdGlvbiA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoa1BlcnMuTWlkZGxlTmFtZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICBrUGVycy5NaWRkbGVOYW1lID0gXCJcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3Qgb05hbWUgPSBkaXNwbGF5TmFtZShrUGVycylbMF07XHJcblxyXG4gICAgICAgIGlmIChrUGVycy5SZWxhdGlvbikge1xyXG4gICAgICAgICAgLy8gVGhlIHJlbGF0aW9uIGlzIHN0b3JlZCBhcyBcIlBhcmVudHNcIiwgXCJTcG91c2VzXCIsIGV0Yy4sIHNvLi4uXHJcbiAgICAgICAgICBrUGVycy5SZWxhdGlvbiA9IGtQZXJzLlJlbGF0aW9uLnJlcGxhY2UoL3MkLywgXCJcIikucmVwbGFjZSgvcmVuJC8sIFwiXCIpO1xyXG4gICAgICAgICAgaWYgKHJDbGFzcyAhPSBcInNlbGZcIikge1xyXG4gICAgICAgICAgICBrUGVycy5SZWxhdGlvblNob3cgPSBrUGVycy5SZWxhdGlvbjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG9OYW1lKSB7XHJcbiAgICAgICAgICBsZXQgb0JEYXRlID0geW1kRml4KGJEYXRlKTtcclxuICAgICAgICAgIGxldCBvRERhdGUgPSB5bWRGaXgoZERhdGUpO1xyXG4gICAgICAgICAgaWYgKGlzRGVjYWRlcyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIG9CRGF0ZSA9IGtQZXJzLkJpcnRoRGF0ZURlY2FkZTtcclxuICAgICAgICAgICAgaWYgKG9ERGF0ZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgb0REYXRlID0ga1BlcnMuRGVhdGhEYXRlRGVjYWRlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zdCBhTGluZSA9ICQoXHJcbiAgICAgICAgICAgIFwiPHRyIGRhdGEtbmFtZT0nXCIgK1xyXG4gICAgICAgICAgICAgIGtQZXJzLk5hbWUgK1xyXG4gICAgICAgICAgICAgIFwiJyBkYXRhLWJpcnRoZGF0ZT0nXCIgK1xyXG4gICAgICAgICAgICAgIGJEYXRlLnJlcGxhY2VBbGwoL1xcLS9nLCBcIlwiKSArXHJcbiAgICAgICAgICAgICAgXCInIGRhdGEtcmVsYXRpb249J1wiICtcclxuICAgICAgICAgICAgICBrUGVycy5SZWxhdGlvbiArXHJcbiAgICAgICAgICAgICAgXCInIGNsYXNzPSdcIiArXHJcbiAgICAgICAgICAgICAgckNsYXNzICtcclxuICAgICAgICAgICAgICBcIiBcIiArXHJcbiAgICAgICAgICAgICAga1BlcnMuR2VuZGVyICtcclxuICAgICAgICAgICAgICBcIic+PHRkPlwiICtcclxuICAgICAgICAgICAgICBrUGVycy5SZWxhdGlvblNob3cgK1xyXG4gICAgICAgICAgICAgIFwiPC90ZD48dGQ+PGEgaHJlZj0naHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvXCIgK1xyXG4gICAgICAgICAgICAgIGh0bWxFbnRpdGllcyhrUGVycy5OYW1lKSArXHJcbiAgICAgICAgICAgICAgXCInPlwiICtcclxuICAgICAgICAgICAgICBvTmFtZSArXHJcbiAgICAgICAgICAgICAgXCI8L3RkPjx0ZCBjbGFzcz0nYURhdGUnPlwiICtcclxuICAgICAgICAgICAgICBvQkRhdGUgK1xyXG4gICAgICAgICAgICAgIFwiPC90ZD48dGQ+XCIgK1xyXG4gICAgICAgICAgICAgIGtQZXJzLkJpcnRoTG9jYXRpb24gK1xyXG4gICAgICAgICAgICAgIFwiPC90ZD48dGQgY2xhc3M9J2FEYXRlJz5cIiArXHJcbiAgICAgICAgICAgICAgb0REYXRlICtcclxuICAgICAgICAgICAgICBcIjwvdGQ+PHRkPlwiICtcclxuICAgICAgICAgICAgICBrUGVycy5EZWF0aExvY2F0aW9uICtcclxuICAgICAgICAgICAgICBcIjwvdGQ+PC90cj5cIlxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBrVGFibGUuZmluZChcInRib2R5XCIpLmFwcGVuZChhTGluZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoa1BlcnMuUmVsYXRpb24gPT0gXCJTcG91c2VcIikge1xyXG4gICAgICAgICAgbGV0IG1hcnJpYWdlRGVldHMgPSBcIm0uXCI7XHJcbiAgICAgICAgICBjb25zdCBkTWRhdGUgPSB5bWRGaXgoa1BlcnMubWFycmlhZ2VfZGF0ZSk7XHJcbiAgICAgICAgICBpZiAoZE1kYXRlICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgbWFycmlhZ2VEZWV0cyArPSBcIiBcIiArIGRNZGF0ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmIChpc09LKGtQZXJzLm1hcnJpYWdlX2xvY2F0aW9uKSkge1xyXG4gICAgICAgICAgICBtYXJyaWFnZURlZXRzICs9IFwiIFwiICsga1BlcnMubWFycmlhZ2VfbG9jYXRpb247XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBpZiAobWFycmlhZ2VEZWV0cyAhPSBcIm0uXCIpIHtcclxuICAgICAgICAgICAgbGV0IGtHZW5kZXI7XHJcbiAgICAgICAgICAgIGlmIChrUGVycy5EYXRhU3RhdHVzLkdlbmRlciA9PSBcImJsYW5rXCIpIHtcclxuICAgICAgICAgICAgICBrR2VuZGVyID0gXCJcIjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICBrR2VuZGVyID0ga1BlcnMuR2VuZGVyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHNwb3VzZUxpbmUgPSAkKFxyXG4gICAgICAgICAgICAgIFwiPHRyIGNsYXNzPSdtYXJyaWFnZVJvdyBcIiArXHJcbiAgICAgICAgICAgICAgICBrR2VuZGVyICtcclxuICAgICAgICAgICAgICAgIFwiJyBkYXRhLXNwb3VzZT0nXCIgK1xyXG4gICAgICAgICAgICAgICAga1BlcnMuTmFtZSArXHJcbiAgICAgICAgICAgICAgICBcIic+PHRkPiZuYnNwOzwvdGQ+PHRkIGNvbHNwYW49JzMnPlwiICtcclxuICAgICAgICAgICAgICAgIG1hcnJpYWdlRGVldHMgK1xyXG4gICAgICAgICAgICAgICAgXCI8L3RkPjx0ZD48L3RkPjx0ZD48L3RkPjwvdHI+XCJcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAga1RhYmxlLmZpbmQoXCJ0Ym9keVwiKS5hcHBlbmQoc3BvdXNlTGluZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3Qgcm93cyA9IGtUYWJsZS5maW5kKFwidGJvZHkgdHJcIik7XHJcbiAgICAgIHJvd3Muc29ydCgoYSwgYikgPT5cclxuICAgICAgICAkKGIpLmRhdGEoXCJiaXJ0aGRhdGVcIikgPCAkKGEpLmRhdGEoXCJiaXJ0aGRhdGVcIikgPyAxIDogLTFcclxuICAgICAgKTtcclxuICAgICAga1RhYmxlLmZpbmQoXCJ0Ym9keVwiKS5hcHBlbmQocm93cyk7XHJcblxyXG4gICAgICBjb25zdCBmYW1pbHlPcmRlciA9IFtcIlBhcmVudFwiLCBcIlNpYmxpbmdcIiwgXCJTcG91c2VcIiwgXCJDaGlsZFwiXTtcclxuICAgICAgZmFtaWx5T3JkZXIuZm9yRWFjaChmdW5jdGlvbiAocmVsV29yZCkge1xyXG4gICAgICAgIGtUYWJsZS5maW5kKFwidHJbZGF0YS1yZWxhdGlvbj0nXCIgKyByZWxXb3JkICsgXCInXVwiKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICQodGhpcykuYXBwZW5kVG8oa1RhYmxlLmZpbmQoXCJ0Ym9keVwiKSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAga1RhYmxlLmZpbmQoXCIubWFycmlhZ2VSb3dcIikuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgJCh0aGlzKS5pbnNlcnRBZnRlcihcclxuICAgICAgICAgIGtUYWJsZS5maW5kKFwidHJbZGF0YS1uYW1lPSdcIiArICQodGhpcykuZGF0YShcInNwb3VzZVwiKSArIFwiJ11cIilcclxuICAgICAgICApO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHJldHVybiBrVGFibGU7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRmluZCBnb29kIG5hbWVzIHRvIGRpc3BsYXkgKGFzIHRoZSBBUEkgZG9lc24ndCByZXR1cm4gdGhlIHNhbWUgZmllbGRzIGFsbCBwcm9maWxlcylcclxuICAgIGZ1bmN0aW9uIGRpc3BsYXlOYW1lKGZQZXJzb24pIHtcclxuICAgICAgaWYgKGZQZXJzb24gIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgbGV0IGZOYW1lMSA9IFwiXCI7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBmUGVyc29uW1wiTG9uZ05hbWVcIl0gIT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgaWYgKGZQZXJzb25bXCJMb25nTmFtZVwiXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGZOYW1lMSA9IGZQZXJzb25bXCJMb25nTmFtZVwiXS5yZXBsYWNlKC9cXHNcXHMvLCBcIiBcIik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBmTmFtZTIgPSBcIlwiO1xyXG4gICAgICAgIGxldCBmTmFtZTQgPSBcIlwiO1xyXG4gICAgICAgIGlmICh0eXBlb2YgZlBlcnNvbltcIk1pZGRsZU5hbWVcIl0gIT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICBmUGVyc29uW1wiTWlkZGxlTmFtZVwiXSA9PSBcIlwiICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBmUGVyc29uW1wiTG9uZ05hbWVQcml2YXRlXCJdICE9IFwidW5kZWZpbmVkXCJcclxuICAgICAgICAgICkge1xyXG4gICAgICAgICAgICBpZiAoZlBlcnNvbltcIkxvbmdOYW1lUHJpdmF0ZVwiXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgZk5hbWUyID0gZlBlcnNvbltcIkxvbmdOYW1lUHJpdmF0ZVwiXS5yZXBsYWNlKC9cXHNcXHMvLCBcIiBcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgaWYgKHR5cGVvZiBmUGVyc29uW1wiTG9uZ05hbWVQcml2YXRlXCJdICE9IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgaWYgKGZQZXJzb25bXCJMb25nTmFtZVByaXZhdGVcIl0gIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgIGZOYW1lNCA9IGZQZXJzb25bXCJMb25nTmFtZVByaXZhdGVcIl0ucmVwbGFjZSgvXFxzXFxzLywgXCIgXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgZk5hbWUzID0gXCJcIjtcclxuICAgICAgICBjb25zdCBjaGVja3MgPSBbXHJcbiAgICAgICAgICBcIlByZWZpeFwiLFxyXG4gICAgICAgICAgXCJGaXJzdE5hbWVcIixcclxuICAgICAgICAgIFwiUmVhbE5hbWVcIixcclxuICAgICAgICAgIFwiTWlkZGxlTmFtZVwiLFxyXG4gICAgICAgICAgXCJMYXN0TmFtZUF0QmlydGhcIixcclxuICAgICAgICAgIFwiTGFzdE5hbWVDdXJyZW50XCIsXHJcbiAgICAgICAgICBcIlN1ZmZpeFwiLFxyXG4gICAgICAgIF07XHJcbiAgICAgICAgY2hlY2tzLmZvckVhY2goZnVuY3Rpb24gKGRDaGVjaykge1xyXG4gICAgICAgICAgaWYgKHR5cGVvZiBmUGVyc29uW1wiXCIgKyBkQ2hlY2sgKyBcIlwiXSAhPSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICBmUGVyc29uW1wiXCIgKyBkQ2hlY2sgKyBcIlwiXSAhPSBcIlwiICYmXHJcbiAgICAgICAgICAgICAgZlBlcnNvbltcIlwiICsgZENoZWNrICsgXCJcIl0gIT0gbnVsbFxyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICBpZiAoZENoZWNrID09IFwiTGFzdE5hbWVBdEJpcnRoXCIpIHtcclxuICAgICAgICAgICAgICAgIGlmIChmUGVyc29uW1wiTGFzdE5hbWVBdEJpcnRoXCJdICE9IGZQZXJzb24uTGFzdE5hbWVDdXJyZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgIGZOYW1lMyArPSBcIihcIiArIGZQZXJzb25bXCJMYXN0TmFtZUF0QmlydGhcIl0gKyBcIikgXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChkQ2hlY2sgPT0gXCJSZWFsTmFtZVwiKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGZQZXJzb25bXCJGaXJzdE5hbWVcIl0gIT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgZk5hbWUzICs9IGZQZXJzb25bXCJSZWFsTmFtZVwiXSArIFwiIFwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBmTmFtZTMgKz0gZlBlcnNvbltcIlwiICsgZENoZWNrICsgXCJcIl0gKyBcIiBcIjtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgYXJyID0gW2ZOYW1lMSwgZk5hbWUyLCBmTmFtZTMsIGZOYW1lNF07XHJcbiAgICAgICAgdmFyIGxvbmdlc3QgPSBhcnIucmVkdWNlKGZ1bmN0aW9uIChhLCBiKSB7XHJcbiAgICAgICAgICByZXR1cm4gYS5sZW5ndGggPiBiLmxlbmd0aCA/IGEgOiBiO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBmTmFtZSA9IGxvbmdlc3Q7XHJcblxyXG4gICAgICAgIGxldCBzTmFtZTtcclxuICAgICAgICBpZiAoZlBlcnNvbltcIlNob3J0TmFtZVwiXSkge1xyXG4gICAgICAgICAgc05hbWUgPSBmUGVyc29uW1wiU2hvcnROYW1lXCJdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzTmFtZSA9IGZOYW1lO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBmTmFtZSA9IGZ1bGwgbmFtZTsgc05hbWUgPSBzaG9ydCBuYW1lXHJcbiAgICAgICAgcmV0dXJuIFtmTmFtZS50cmltKCksIHNOYW1lLnRyaW0oKV07XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBDb252ZXJ0IGRhdGVzIHRvIElTTyBmb3JtYXQgKFlZWVktTU0tREQpXHJcbiAgICBmdW5jdGlvbiB5bWRGaXgoZGF0ZSkge1xyXG4gICAgICBsZXQgb3V0RGF0ZTtcclxuICAgICAgaWYgKGRhdGUgPT0gdW5kZWZpbmVkIHx8IGRhdGUgPT0gXCJcIikge1xyXG4gICAgICAgIG91dERhdGUgPSBcIlwiO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGRhdGVCaXRzMSA9IGRhdGUuc3BsaXQoXCIgXCIpO1xyXG4gICAgICAgIGlmIChkYXRlQml0czFbMl0pIHtcclxuICAgICAgICAgIGNvbnN0IHNNb250aHMgPSBbXHJcbiAgICAgICAgICAgIFwiSmFuXCIsXHJcbiAgICAgICAgICAgIFwiRmViXCIsXHJcbiAgICAgICAgICAgIFwiTWFyXCIsXHJcbiAgICAgICAgICAgIFwiQXByXCIsXHJcbiAgICAgICAgICAgIFwiTWF5XCIsXHJcbiAgICAgICAgICAgIFwiSnVuXCIsXHJcbiAgICAgICAgICAgIFwiSnVsXCIsXHJcbiAgICAgICAgICAgIFwiQXVnXCIsXHJcbiAgICAgICAgICAgIFwiU2VwXCIsXHJcbiAgICAgICAgICAgIFwiT2N0XCIsXHJcbiAgICAgICAgICAgIFwiTm92XCIsXHJcbiAgICAgICAgICAgIFwiRGVjXCIsXHJcbiAgICAgICAgICBdO1xyXG4gICAgICAgICAgY29uc3QgbE1vbnRocyA9IFtcclxuICAgICAgICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgICAgICAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgICAgICAgXCJNYXJjaFwiLFxyXG4gICAgICAgICAgICBcIkFwcmlsXCIsXHJcbiAgICAgICAgICAgIFwiTWF5XCIsXHJcbiAgICAgICAgICAgIFwiSnVuZVwiLFxyXG4gICAgICAgICAgICBcIkp1bHlcIixcclxuICAgICAgICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgICAgICAgXCJTZXB0ZW1iZXJcIixcclxuICAgICAgICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgICAgICAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgICAgICAgXCJEZWNlbWJlclwiLFxyXG4gICAgICAgICAgXTtcclxuICAgICAgICAgIGNvbnN0IGRNb250aCA9IGRhdGUubWF0Y2goL1tBLXpdKy9pKTtcclxuICAgICAgICAgIGxldCBkTW9udGhOdW07XHJcbiAgICAgICAgICBpZiAoZE1vbnRoICE9IG51bGwpIHtcclxuICAgICAgICAgICAgc01vbnRocy5mb3JFYWNoKGZ1bmN0aW9uIChhU00sIGkpIHtcclxuICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICBkTW9udGhbMF0udG9Mb3dlckNhc2UoKSA9PSBhU00udG9Mb3dlckNhc2UoKSB8fFxyXG4gICAgICAgICAgICAgICAgZE1vbnRoWzBdLnRvTG93ZXJDYXNlKCkgPT0gYVNNICsgXCIuXCIudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgZE1vbnRoTnVtID0gKGkgKyAxKS50b1N0cmluZygpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgY29uc3QgZERhdGUgPSBkYXRlLm1hdGNoKC9cXGJbMC05XXsxLDJ9XFxiLyk7XHJcbiAgICAgICAgICBjb25zdCBkRGF0ZU51bSA9IGREYXRlWzBdO1xyXG4gICAgICAgICAgY29uc3QgZFllYXIgPSBkYXRlLm1hdGNoKC9cXGJbMC05XXs0fVxcYi8pO1xyXG4gICAgICAgICAgY29uc3QgZFllYXJOdW0gPSBkWWVhclswXTtcclxuICAgICAgICAgIHJldHVybiBkWWVhck51bSArIFwiLVwiICsgZE1vbnRoTnVtICsgXCItXCIgKyBkRGF0ZU51bTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc3QgZGF0ZUJpdHMgPSBkYXRlLnNwbGl0KFwiLVwiKTtcclxuICAgICAgICAgIG91dERhdGUgPSBkYXRlO1xyXG4gICAgICAgICAgaWYgKGRhdGVCaXRzWzFdID09IFwiMDBcIiAmJiBkYXRlQml0c1syXSA9PSBcIjAwXCIpIHtcclxuICAgICAgICAgICAgaWYgKGRhdGVCaXRzWzBdID09IFwiMDAwMFwiKSB7XHJcbiAgICAgICAgICAgICAgb3V0RGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgb3V0RGF0ZSA9IGRhdGVCaXRzWzBdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBvdXREYXRlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFJlcGxhY2UgY2VydGFpbiBjaGFyYWN0ZXJzIHdpdGggSFRNTCBlbnRpdGllc1xyXG4gICAgZnVuY3Rpb24gaHRtbEVudGl0aWVzKHN0cikge1xyXG4gICAgICByZXR1cm4gU3RyaW5nKHN0cilcclxuICAgICAgICAucmVwbGFjZUFsbCgvJi9nLCBcIiZhbXA7XCIpXHJcbiAgICAgICAgLnJlcGxhY2VBbGwoLzwvZywgXCImbHQ7XCIpXHJcbiAgICAgICAgLnJlcGxhY2VBbGwoLz4vZywgXCImZ3Q7XCIpXHJcbiAgICAgICAgLnJlcGxhY2VBbGwoL1wiL2csIFwiJnF1b3Q7XCIpXHJcbiAgICAgICAgLnJlcGxhY2VBbGwoLycvZywgXCImYXBvcztcIik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gR2V0IHRoZSBwb3NpdGlvbiBvZiBhbiBlbGVtZW50XHJcbiAgICBmdW5jdGlvbiBnZXRPZmZzZXQoZWwpIHtcclxuICAgICAgY29uc3QgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGxlZnQ6IHJlY3QubGVmdCArIHdpbmRvdy5zY3JvbGxYLFxyXG4gICAgICAgIHRvcDogcmVjdC50b3AgKyB3aW5kb3cuc2Nyb2xsWSxcclxuICAgICAgfTtcclxuICAgIH1cclxuICB9XHJcbn0pO1xyXG4iLCJpbXBvcnQgKiBhcyAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCAnanF1ZXJ5LXVpL3VpL3dpZGdldHMvZHJhZ2dhYmxlJztcclxuaW1wb3J0IHtjcmVhdGVQcm9maWxlU3VibWVudUxpbmssIGV4dHJhY3RSZWxhdGl2ZXMsIGlzT0t9IGZyb20gJy4uLy4uL2NvcmUvY29tbW9uJztcclxuaW1wb3J0ICcuL2ZhbWlseVRpbWVsaW5lLmNzcyc7XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldChcImZhbWlseVRpbWVsaW5lXCIsIChyZXN1bHQpID0+IHtcclxuICBpZiAoXHJcbiAgICByZXN1bHQuZmFtaWx5VGltZWxpbmUgJiZcclxuICAgICQoXCJib2R5LnByb2ZpbGVcIikubGVuZ3RoICYmXHJcbiAgICB3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaChcIlNwYWNlOlwiKSA9PSBudWxsXHJcbiAgKSB7XHJcbiAgICAvLyBBZGQgYSBsaW5rIHRvIHRoZSBzaG9ydCBsaXN0IG9mIGxpbmtzIGJlbG93IHRoZSB0YWJzXHJcbiAgICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgICB0aXRsZTogXCJEaXNwbGF5IGEgZmFtaWx5IHRpbWVsaW5lXCIsXHJcbiAgICAgIGlkOiBcImZhbWlseVRpbWVMaW5lQnV0dG9uXCIsXHJcbiAgICAgIHRleHQ6IFwiRmFtaWx5IFRpbWVsaW5lXCIsXHJcbiAgICAgIHVybDogXCIjblwiLFxyXG4gICAgfTtcclxuICAgIGNyZWF0ZVByb2ZpbGVTdWJtZW51TGluayhvcHRpb25zKTtcclxuICAgICQoXCIjXCIgKyBvcHRpb25zLmlkKS5jbGljayhmdW5jdGlvbiAoZSkge1xyXG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgIHRpbWVsaW5lKCk7XHJcbiAgICB9KTtcclxuICB9XHJcbn0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0UmVsYXRpdmVzKGlkLCBmaWVsZHMgPSBcIipcIikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCAkLmFqYXgoe1xyXG4gICAgICB1cmw6IFwiaHR0cHM6Ly9hcGkud2lraXRyZWUuY29tL2FwaS5waHBcIixcclxuICAgICAgY3Jvc3NEb21haW46IHRydWUsXHJcbiAgICAgIHhockZpZWxkczogeyB3aXRoQ3JlZGVudGlhbHM6IHRydWUgfSxcclxuICAgICAgdHlwZTogXCJQT1NUXCIsXHJcbiAgICAgIGRhdGFUeXBlOiBcImpzb25cIixcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIGFjdGlvbjogXCJnZXRSZWxhdGl2ZXNcIixcclxuICAgICAgICBrZXlzOiBpZCxcclxuICAgICAgICBmaWVsZHM6IGZpZWxkcyxcclxuICAgICAgICBnZXRQYXJlbnRzOiAxLFxyXG4gICAgICAgIGdldFNpYmxpbmdzOiAxLFxyXG4gICAgICAgIGdldFNwb3VzZXM6IDEsXHJcbiAgICAgICAgZ2V0Q2hpbGRyZW46IDEsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIHJldHVybiByZXN1bHRbMF0uaXRlbXNbMF0ucGVyc29uO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIE1ha2UgdGhlIGZhbWlseSBtZW1iZXIgYXJyYXlzIGVhc2llciB0byBoYW5kbGVcclxuZnVuY3Rpb24gZ2V0UmVscyhyZWwsIHBlcnNvbiwgdGhlUmVsYXRpb24gPSBmYWxzZSkge1xyXG4gIGxldCBwZW9wbGUgPSBbXTtcclxuICBpZiAodHlwZW9mIHJlbCA9PSB1bmRlZmluZWQgfHwgcmVsID09IG51bGwpIHtcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcbiAgY29uc3QgcEtleXMgPSBPYmplY3Qua2V5cyhyZWwpO1xyXG4gIHBLZXlzLmZvckVhY2goZnVuY3Rpb24gKHBLZXkpIHtcclxuICAgIHZhciBhUGVyc29uID0gcmVsW3BLZXldO1xyXG4gICAgaWYgKHRoZVJlbGF0aW9uICE9IGZhbHNlKSB7XHJcbiAgICAgIGFQZXJzb24uUmVsYXRpb24gPSB0aGVSZWxhdGlvbjtcclxuICAgIH1cclxuICAgIHBlb3BsZS5wdXNoKGFQZXJzb24pO1xyXG4gIH0pO1xyXG4gIHJldHVybiBwZW9wbGU7XHJcbn1cclxuXHJcbi8vIEdldCBhIHllYXIgZnJvbSB0aGUgcGVyc29uJ3MgZGF0YVxyXG5mdW5jdGlvbiBnZXRUaGVZZWFyKHRoZURhdGUsIGV2LCBwZXJzb24pIHtcclxuICBpZiAoIWlzT0sodGhlRGF0ZSkpIHtcclxuICAgIGlmIChldiA9PSBcIkJpcnRoXCIgfHwgZXYgPT0gXCJEZWF0aFwiKSB7XHJcbiAgICAgIHRoZURhdGUgPSBwZXJzb25bZXYgKyBcIkRhdGVEZWNhZGVcIl07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHRoZURhdGVNID0gdGhlRGF0ZS5tYXRjaCgvWzAtOV17NH0vKTtcclxuICBpZiAoaXNPSyh0aGVEYXRlTSkpIHtcclxuICAgIHJldHVybiBwYXJzZUludCh0aGVEYXRlTVswXSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcbn1cclxuXHJcbi8vIENvbnZlcnQgYSBkYXRlIHRvIFlZWVktTU0tRERcclxuZnVuY3Rpb24gZGF0ZVRvWU1EKGVudGVyZWREYXRlKSB7XHJcbiAgbGV0IGVudGVyZWREO1xyXG4gIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvWzAtOV17Myw0fVxcLVswLTldezJ9XFwtWzAtOV17Mn0vKSkge1xyXG4gICAgZW50ZXJlZEQgPSBlbnRlcmVkRGF0ZTtcclxuICB9IGVsc2Uge1xyXG4gICAgbGV0IGVETW9udGggPSBcIjAwXCI7XHJcbiAgICBsZXQgZURZZWFyID0gZW50ZXJlZERhdGUubWF0Y2goL1swLTldezMsNH0vKTtcclxuICAgIGlmIChlRFllYXIgIT0gbnVsbCkge1xyXG4gICAgICBlRFllYXIgPSBlRFllYXJbMF07XHJcbiAgICB9XHJcbiAgICBsZXQgZUREYXRlID0gZW50ZXJlZERhdGUubWF0Y2goL1xcYlswLTldezEsMn1cXGIvKTtcclxuICAgIGlmIChlRERhdGUgIT0gbnVsbCkge1xyXG4gICAgICBlRERhdGUgPSBlRERhdGVbMF0ucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgfVxyXG4gICAgaWYgKGVERGF0ZSA9PSBudWxsKSB7XHJcbiAgICAgIGVERGF0ZSA9IFwiMDBcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvamFuL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDFcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvZmViL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDJcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvbWFyL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDNcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvYXByL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDRcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvbWF5L2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDVcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvanVuL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDZcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvanVsL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDdcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvYXVnL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDhcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvc2VwL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMDlcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvb2N0L2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMTBcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvbm92L2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMTFcIjtcclxuICAgIH1cclxuICAgIGlmIChlbnRlcmVkRGF0ZS5tYXRjaCgvZGVjL2kpICE9IG51bGwpIHtcclxuICAgICAgZURNb250aCA9IFwiMTJcIjtcclxuICAgIH1cclxuICAgIGVudGVyZWREID0gZURZZWFyICsgXCItXCIgKyBlRE1vbnRoICsgXCItXCIgKyBlRERhdGU7XHJcbiAgfVxyXG4gIHJldHVybiBlbnRlcmVkRDtcclxufVxyXG5cclxuLy8gVXNlIGFuIGFwcHJveGltYXRlIGRhdGUgaW5zdGVhZCBvZiBhc3N1bWluZyB0aGF0IGRhdGVzIGFyZSBKYW4gMSBvciB0aGUgMXN0IG9mIGEgbW9udGhcclxuZnVuY3Rpb24gZ2V0QXBwcm94RGF0ZSh0aGVEYXRlKSB7XHJcbiAgbGV0IGFwcHJveCA9IGZhbHNlO1xyXG4gIGxldCBhRGF0ZTtcclxuICBpZiAodGhlRGF0ZS5tYXRjaCgvMHMkLykgIT0gbnVsbCkge1xyXG4gICAgLy8gQ2hhbmdlIGEgZGVjYWRlIGRhdGUgdG8gYSB5ZWFyIGVuZGluZyBpbiAnNSdcclxuICAgIGFEYXRlID0gdGhlRGF0ZS5yZXBsYWNlKC8wcy8sIFwiNVwiKTtcclxuICAgIGFwcHJveCA9IHRydWU7XHJcbiAgfSBlbHNlIHtcclxuICAgIC8vIElmIHdlIG9ubHkgaGF2ZSB0aGUgeWVhciwgYXNzdW1lIHRoZSBkYXRlIHRvIGJlIEp1bHkgMiAodGhlIG1pZHdheSBkYXRlKVxyXG4gICAgY29uc3QgYml0cyA9IHRoZURhdGUuc3BsaXQoXCItXCIpO1xyXG4gICAgaWYgKHRoZURhdGUubWF0Y2goLzAwXFwtMDAkLykgIT0gbnVsbCkge1xyXG4gICAgICBhRGF0ZSA9IGJpdHNbMF0gKyBcIi0wNy0wMlwiO1xyXG4gICAgICBhcHByb3ggPSB0cnVlO1xyXG4gICAgfSBlbHNlIGlmICh0aGVEYXRlLm1hdGNoKC8tMDAkLykgIT0gbnVsbCkge1xyXG4gICAgICAvLyBJZiB3ZSBoYXZlIGEgbW9udGgsIGJ1dCBub3QgYSBkYXkvZGF0ZSwgYXNzdW1lIHRoZSBkYXRlIHRvIGJlIDE2ICh0aGUgbWlkd2F5IGRhdGUpXHJcbiAgICAgIGFEYXRlID0gYml0c1swXSArIFwiLVwiICsgYml0c1sxXSArIFwiLVwiICsgXCIxNlwiO1xyXG4gICAgICBhcHByb3ggPSB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYURhdGUgPSB0aGVEYXRlO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4geyBEYXRlOiBhRGF0ZSwgQXBwcm94OiBhcHByb3ggfTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0QWdlKGJpcnRoLCBkZWF0aCkge1xyXG4gIC8vIG11c3QgYmUgZGF0ZSBvYmplY3RzXHJcbiAgdmFyIGFnZSA9IGRlYXRoLmdldEZ1bGxZZWFyKCkgLSBiaXJ0aC5nZXRGdWxsWWVhcigpO1xyXG4gIHZhciBtID0gZGVhdGguZ2V0TW9udGgoKSAtIGJpcnRoLmdldE1vbnRoKCk7XHJcbiAgaWYgKG0gPCAwIHx8IChtID09PSAwICYmIGRlYXRoLmdldERhdGUoKSA8IGJpcnRoLmdldERhdGUoKSkpIHtcclxuICAgIGFnZS0tO1xyXG4gIH1cclxuICByZXR1cm4gYWdlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBjYXBpdGFsaXplRmlyc3RMZXR0ZXIoc3RyaW5nKSB7XHJcbiAgc3RyaW5nID0gc3RyaW5nLnRvTG93ZXJDYXNlKCk7XHJcbiAgY29uc3QgYml0cyA9IHN0cmluZy5zcGxpdChcIiBcIik7XHJcbiAgbGV0IG91dCA9IFwiXCI7XHJcbiAgYml0cy5mb3JFYWNoKGZ1bmN0aW9uIChhYml0KSB7XHJcbiAgICBvdXQgKz0gYWJpdC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIGFiaXQuc2xpY2UoMSkgKyBcIiBcIjtcclxuICB9KTtcclxuICBmdW5jdGlvbiByZXBsYWNlcihtYXRjaCwgcDEpIHtcclxuICAgIHJldHVybiBcIi1cIiArIHAxLnRvVXBwZXJDYXNlKCk7XHJcbiAgfVxyXG4gIG91dCA9IG91dC5yZXBsYWNlKC9cXC0oW2Etel0pLywgcmVwbGFjZXIpO1xyXG4gIHJldHVybiBvdXQudHJpbSgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiB0aW1lbGluZSgpIHtcclxuICAkKFwiI3RpbWVsaW5lXCIpLnJlbW92ZSgpO1xyXG4gIGNvbnN0IGZpZWxkcyA9XHJcbiAgICBcIkJpcnRoRGF0ZSxCaXJ0aExvY2F0aW9uLEJpcnRoTmFtZSxCaXJ0aERhdGVEZWNhZGUsRGVhdGhEYXRlLERlYXRoRGF0ZURlY2FkZSxEZWF0aExvY2F0aW9uLElzTGl2aW5nLEZhdGhlcixGaXJzdE5hbWUsR2VuZGVyLElkLExhc3ROYW1lQXRCaXJ0aCxMYXN0TmFtZUN1cnJlbnQsUHJlZml4LFN1ZmZpeCxMYXN0TmFtZU90aGVyLERlcml2ZWQuTG9uZ05hbWUsRGVyaXZlZC5Mb25nTmFtZVByaXZhdGUsTWFuYWdlcixNaWRkbGVOYW1lLE1vdGhlcixOYW1lLFBob3RvLFJlYWxOYW1lLFNob3J0TmFtZSxUb3VjaGVkLERhdGFTdGF0dXMsRGVyaXZlZC5CaXJ0aE5hbWUsQmlvXCI7XHJcbiAgY29uc3QgaWQgPSAkKFwiYS5wdXJlQ3NzTWVudWkwIHNwYW4ucGVyc29uXCIpLnRleHQoKTtcclxuICBnZXRSZWxhdGl2ZXMoaWQsIGZpZWxkcykudGhlbigocGVyc29uRGF0YSkgPT4ge1xyXG4gICAgdmFyIHBlcnNvbiA9IHBlcnNvbkRhdGE7XHJcbiAgICBjb25zdCBwYXJlbnRzID0gZXh0cmFjdFJlbGF0aXZlcyhwZXJzb24uUGFyZW50cywgXCJQYXJlbnRcIik7XHJcbiAgICBjb25zdCBzaWJsaW5ncyA9IGV4dHJhY3RSZWxhdGl2ZXMocGVyc29uLlNpYmxpbmdzLCBcIlNpYmxpbmdcIik7XHJcbiAgICBjb25zdCBzcG91c2VzID0gZXh0cmFjdFJlbGF0aXZlcyhwZXJzb24uU3BvdXNlcywgXCJTcG91c2VcIik7XHJcbiAgICBjb25zdCBjaGlsZHJlbiA9IGV4dHJhY3RSZWxhdGl2ZXMocGVyc29uLkNoaWxkcmVuLCBcIkNoaWxkXCIpO1xyXG4gICAgY29uc3QgZmFtaWx5ID0gW3BlcnNvbl07XHJcbiAgICBjb25zdCBmYW1pbHlBcnIgPSBbcGFyZW50cywgc2libGluZ3MsIHNwb3VzZXMsIGNoaWxkcmVuXTtcclxuICAgIC8vIE1ha2UgYW4gYXJyYXkgb2YgZmFtaWx5IG1lbWJlcnNcclxuICAgIGZhbWlseUFyci5mb3JFYWNoKGZ1bmN0aW9uIChhbkFycikge1xyXG4gICAgICBpZiAoYW5BcnIpIHtcclxuICAgICAgICBpZiAoYW5BcnIubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgZmFtaWx5LnB1c2goLi4uYW5BcnIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBsZXQgZmFtaWx5RmFjdHMgPSBbXTtcclxuICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IGdldFRoZVllYXIocGVyc29uLkJpcnRoRGF0ZSwgXCJCaXJ0aFwiLCBwZXJzb24pO1xyXG4gICAgLy8gR2V0IGFsbCBCTUQgZXZlbnRzIGZvciBlYWNoIGZhbWlseSBtZW1iZXJcclxuICAgIGZhbWlseS5mb3JFYWNoKGZ1bmN0aW9uIChhUGVyc29uKSB7XHJcbiAgICAgIGNvbnN0IGV2ZW50cyA9IFtcIkJpcnRoXCIsIFwiRGVhdGhcIiwgXCJtYXJyaWFnZVwiXTtcclxuICAgICAgZXZlbnRzLmZvckVhY2goZnVuY3Rpb24gKGV2KSB7XHJcbiAgICAgICAgbGV0IGV2RGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgbGV0IGV2TG9jYXRpb247XHJcbiAgICAgICAgaWYgKGFQZXJzb25bZXYgKyBcIkRhdGVcIl0pIHtcclxuICAgICAgICAgIGV2RGF0ZSA9IGFQZXJzb25bZXYgKyBcIkRhdGVcIl07XHJcbiAgICAgICAgICBldkxvY2F0aW9uID0gYVBlcnNvbltldiArIFwiTG9jYXRpb25cIl07XHJcbiAgICAgICAgfSBlbHNlIGlmIChhUGVyc29uW2V2ICsgXCJEYXRlRGVjYWRlXCJdKSB7XHJcbiAgICAgICAgICBldkRhdGUgPSBhUGVyc29uW2V2ICsgXCJEYXRlRGVjYWRlXCJdO1xyXG4gICAgICAgICAgZXZMb2NhdGlvbiA9IGFQZXJzb25bZXYgKyBcIkxvY2F0aW9uXCJdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZXYgPT0gXCJtYXJyaWFnZVwiKSB7XHJcbiAgICAgICAgICBpZiAoYVBlcnNvbltldiArIFwiX2RhdGVcIl0pIHtcclxuICAgICAgICAgICAgZXZEYXRlID0gYVBlcnNvbltldiArIFwiX2RhdGVcIl07XHJcbiAgICAgICAgICAgIGV2TG9jYXRpb24gPSBhUGVyc29uW2V2ICsgXCJfbG9jYXRpb25cIl07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChhUGVyc29uLlJlbGF0aW9uKSB7XHJcbiAgICAgICAgICBhUGVyc29uLlJlbGF0aW9uID0gYVBlcnNvbi5SZWxhdGlvbi5yZXBsYWNlKC9zJC8sIFwiXCIpLnJlcGxhY2UoXHJcbiAgICAgICAgICAgIC9yZW4kLyxcclxuICAgICAgICAgICAgXCJcIlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGV2RGF0ZSAhPSBcIlwiICYmIGV2RGF0ZSAhPSBcIjAwMDBcIiAmJiBpc09LKGV2RGF0ZSkpIHtcclxuICAgICAgICAgIGxldCBmTmFtZSA9IGFQZXJzb24uRmlyc3ROYW1lO1xyXG4gICAgICAgICAgaWYgKCFhUGVyc29uLkZpcnN0TmFtZSkge1xyXG4gICAgICAgICAgICBmTmFtZSA9IGFQZXJzb24uUmVhbE5hbWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBsZXQgYkRhdGUgPSBhUGVyc29uLkJpcnRoRGF0ZTtcclxuICAgICAgICAgIGlmICghYVBlcnNvbi5CaXJ0aERhdGUpIHtcclxuICAgICAgICAgICAgYkRhdGUgPSBhUGVyc29uLkJpcnRoRGF0ZURlY2FkZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGxldCBtQmlvID0gYVBlcnNvbi5iaW87XHJcbiAgICAgICAgICBpZiAoIWFQZXJzb24uYmlvKSB7XHJcbiAgICAgICAgICAgIG1CaW8gPSBcIlwiO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaWYgKGV2TG9jYXRpb24gPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGV2TG9jYXRpb24gPSBcIlwiO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgZmFtaWx5RmFjdHMucHVzaChbXHJcbiAgICAgICAgICAgIGV2RGF0ZSxcclxuICAgICAgICAgICAgZXZMb2NhdGlvbixcclxuICAgICAgICAgICAgZk5hbWUsXHJcbiAgICAgICAgICAgIGFQZXJzb24uTGFzdE5hbWVBdEJpcnRoLFxyXG4gICAgICAgICAgICBhUGVyc29uLkxhc3ROYW1lQ3VycmVudCxcclxuICAgICAgICAgICAgYkRhdGUsXHJcbiAgICAgICAgICAgIGFQZXJzb24uUmVsYXRpb24sXHJcbiAgICAgICAgICAgIG1CaW8sXHJcbiAgICAgICAgICAgIGV2LFxyXG4gICAgICAgICAgICBhUGVyc29uLk5hbWUsXHJcbiAgICAgICAgICBdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBMb29rIGZvciBtaWxpdGFyeSBldmVudHMgaW4gYmlvc1xyXG4gICAgICBpZiAoYVBlcnNvbi5iaW8pIHtcclxuICAgICAgICBjb25zdCB0bFRlbXBsYXRlcyA9IGFQZXJzb24uYmlvLm1hdGNoKC9cXHtcXHtbXl0qP1xcfVxcfS9nbSk7XHJcbiAgICAgICAgaWYgKHRsVGVtcGxhdGVzICE9IG51bGwpIHtcclxuICAgICAgICAgIGNvbnN0IHdhclRlbXBsYXRlcyA9IFtcclxuICAgICAgICAgICAgXCJUaGUgR3JlYXQgV2FyXCIsXHJcbiAgICAgICAgICAgIFwiS29yZWFuIFdhclwiLFxyXG4gICAgICAgICAgICBcIlZpZXRuYW0gV2FyXCIsXHJcbiAgICAgICAgICAgIFwiV29ybGQgV2FyIElJXCIsXHJcbiAgICAgICAgICAgIFwiVVMgQ2l2aWwgV2FyXCIsXHJcbiAgICAgICAgICAgIFwiV2FyIG9mIDE4MTJcIixcclxuICAgICAgICAgICAgXCJNZXhpY2FuLUFtZXJpY2FuIFdhclwiLFxyXG4gICAgICAgICAgICBcIkZyZW5jaCBhbmQgSW5kaWFuIFdhclwiLFxyXG4gICAgICAgICAgICBcIlNwYW5pc2gtQW1lcmljYW4gV2FyXCIsXHJcbiAgICAgICAgICBdO1xyXG4gICAgICAgICAgdGxUZW1wbGF0ZXMuZm9yRWFjaChmdW5jdGlvbiAoYVRlbXApIHtcclxuICAgICAgICAgICAgbGV0IGV2RGF0ZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIGxldCBldkxvY2F0aW9uID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGV2ID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGV2RGF0ZVN0YXJ0ID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGV2RGF0ZUVuZCA9IFwiXCI7XHJcbiAgICAgICAgICAgIGxldCBldlN0YXJ0O1xyXG4gICAgICAgICAgICBsZXQgZXZFbmQ7XHJcbiAgICAgICAgICAgIGFUZW1wID0gYVRlbXAucmVwbGFjZUFsbCgvW3t9XS9nLCBcIlwiKTtcclxuICAgICAgICAgICAgY29uc3QgYml0cyA9IGFUZW1wLnNwbGl0KFwifFwiKTtcclxuICAgICAgICAgICAgY29uc3QgdGVtcGxhdGVUaXRsZSA9IGJpdHNbMF0ucmVwbGFjZUFsbCgvXFxuL2csIFwiXCIpLnRyaW0oKTtcclxuICAgICAgICAgICAgYml0cy5mb3JFYWNoKGZ1bmN0aW9uIChhQml0KSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgYUJpdEJpdHMgPSBhQml0LnNwbGl0KFwiPVwiKTtcclxuICAgICAgICAgICAgICBjb25zdCBhQml0RmllbGQgPSBhQml0Qml0c1swXS50cmltKCk7XHJcbiAgICAgICAgICAgICAgaWYgKGFCaXRCaXRzWzFdKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBhQml0RmFjdCA9IGFCaXRCaXRzWzFdLnRyaW0oKS5yZXBsYWNlQWxsKC9cXG4vZywgXCJcIik7XHJcbiAgICAgICAgICAgICAgICBpZiAod2FyVGVtcGxhdGVzLmluY2x1ZGVzKHRlbXBsYXRlVGl0bGUpICYmIGlzT0soYUJpdEZhY3QpKSB7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChhQml0RmllbGQgPT0gXCJzdGFydGRhdGVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGV2RGF0ZVN0YXJ0ID0gZGF0ZVRvWU1EKGFCaXRGYWN0KTtcclxuICAgICAgICAgICAgICAgICAgICBldlN0YXJ0ID0gXCJKb2luZWQgXCIgKyB0ZW1wbGF0ZVRpdGxlO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGlmIChhQml0RmllbGQgPT0gXCJlbmRkYXRlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBldkRhdGVFbmQgPSBkYXRlVG9ZTUQoYUJpdEZhY3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIGV2RW5kID0gXCJMZWZ0IFwiICsgdGVtcGxhdGVUaXRsZTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpZiAoYUJpdEZpZWxkID09IFwiZW5saXN0ZWRcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGV2RGF0ZVN0YXJ0ID0gZGF0ZVRvWU1EKGFCaXRGYWN0KTtcclxuICAgICAgICAgICAgICAgICAgICBldlN0YXJ0ID1cclxuICAgICAgICAgICAgICAgICAgICAgIFwiRW5saXN0ZWQgZm9yIFwiICtcclxuICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVGl0bGUucmVwbGFjZShcImFtZXJpY2FuXCIsIFwiQW1lcmljYW5cIik7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgaWYgKGFCaXRGaWVsZCA9PSBcImRpc2NoYXJnZWRcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGV2RGF0ZUVuZCA9IGRhdGVUb1lNRChhQml0RmFjdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZFbmQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJEaXNjaGFyZ2VkIGZyb20gXCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVUaXRsZS5yZXBsYWNlKFwiYW1lcmljYW5cIiwgXCJBbWVyaWNhblwiKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpZiAoYUJpdEZpZWxkID09IFwiYnJhbmNoXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBldkxvY2F0aW9uID0gYUJpdEZhY3Q7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBpZiAoaXNPSyhldkRhdGVTdGFydCkpIHtcclxuICAgICAgICAgICAgICBldkRhdGUgPSBldkRhdGVTdGFydDtcclxuICAgICAgICAgICAgICBldiA9IGV2U3RhcnQ7XHJcbiAgICAgICAgICAgICAgZmFtaWx5RmFjdHMucHVzaChbXHJcbiAgICAgICAgICAgICAgICBldkRhdGUsXHJcbiAgICAgICAgICAgICAgICBldkxvY2F0aW9uLFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5GaXJzdE5hbWUsXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLkxhc3ROYW1lQXRCaXJ0aCxcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uTGFzdE5hbWVDdXJyZW50LFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5CaXJ0aERhdGUsXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLlJlbGF0aW9uLFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5iaW8sXHJcbiAgICAgICAgICAgICAgICBldixcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uTmFtZSxcclxuICAgICAgICAgICAgICBdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaXNPSyhldkRhdGVFbmQpKSB7XHJcbiAgICAgICAgICAgICAgZXZEYXRlID0gZXZEYXRlRW5kO1xyXG4gICAgICAgICAgICAgIGV2ID0gZXZFbmQ7XHJcbiAgICAgICAgICAgICAgZmFtaWx5RmFjdHMucHVzaChbXHJcbiAgICAgICAgICAgICAgICBldkRhdGUsXHJcbiAgICAgICAgICAgICAgICBldkxvY2F0aW9uLFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5GaXJzdE5hbWUsXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLkxhc3ROYW1lQXRCaXJ0aCxcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uTGFzdE5hbWVDdXJyZW50LFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5CaXJ0aERhdGUsXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLlJlbGF0aW9uLFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5iaW8sXHJcbiAgICAgICAgICAgICAgICBldixcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uTmFtZSxcclxuICAgICAgICAgICAgICBdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIC8vIFNvcnQgdGhlIGV2ZW50c1xyXG4gICAgZmFtaWx5RmFjdHMuc29ydCgpO1xyXG4gICAgaWYgKCFwZXJzb24uRmlyc3ROYW1lKSB7XHJcbiAgICAgIHBlcnNvbi5GaXJzdE5hbWUgPSBwZXJzb24uUmVhbE5hbWU7XHJcbiAgICB9XHJcbiAgICAvLyBNYWtlIGEgdGFibGVcclxuICAgIGNvbnN0IHRpbWVsaW5lVGFibGUgPSAkKFxyXG4gICAgICBgPGRpdiBjbGFzcz0nd3JhcCcgaWQ9J3RpbWVsaW5lJyBkYXRhLXd0aWQ9JyR7cGVyc29uLk5hbWV9Jz48dz7ihpQ8L3c+PHg+eDwveD48dGFibGUgaWQ9J3RpbWVsaW5lVGFibGUnPmAgK1xyXG4gICAgICAgIGA8Y2FwdGlvbj5FdmVudHMgaW4gdGhlIGxpZmUgb2YgJHtwZXJzb24uRmlyc3ROYW1lfSdzIGZhbWlseTwvY2FwdGlvbj48dGhlYWQ+PHRoIGNsYXNzPSd0bERhdGUnPkRhdGU8L3RoPjx0aCBjbGFzcz0ndGxCaW9BZ2UnPkFnZSAoJHtwZXJzb24uRmlyc3ROYW1lfSk8L3RoPmAgK1xyXG4gICAgICAgIGA8dGggY2xhc3M9J3RsUmVsYXRpb24nPlJlbGF0aW9uPC90aD48dGggY2xhc3M9J3RsTmFtZSc+TmFtZTwvdGg+PHRoIGNsYXNzPSd0bEFnZSc+QWdlPC90aD48dGggY2xhc3M9J3RsRXZlbnROYW1lJz5FdmVudDwvdGg+PHRoIGNsYXNzPSd0bEV2ZW50TG9jYXRpb24nPkxvY2F0aW9uPC90aD5gICtcclxuICAgICAgICBgPC90aGVhZD48L3RhYmxlPjwvZGl2PmBcclxuICAgICk7XHJcbiAgICAvLyBBdHRhY2ggdGhlIHRhYmxlIHRvIHRoZSBjb250YWluZXIgZGl2XHJcbiAgICB0aW1lbGluZVRhYmxlLnByZXBlbmRUbygkKFwiZGl2LmNvbnRhaW5lci5mdWxsLXdpZHRoXCIpKTtcclxuICAgIGlmICgkKFwiI2Nvbm5lY3Rpb25MaXN0XCIpLmxlbmd0aCkge1xyXG4gICAgICB0aW1lbGluZVRhYmxlLnByZXBlbmRUbygkKFwiI2NvbnRlbnRcIikpO1xyXG4gICAgICB0aW1lbGluZVRhYmxlLmNzcyh7IHRvcDogd2luZG93LnBvaW50ZXJZIC0gMzAsIGxlZnQ6IDEwIH0pO1xyXG4gICAgfVxyXG4gICAgbGV0IGJwRGVhZCA9IGZhbHNlO1xyXG4gICAgbGV0IGJwRGVhZEFnZTtcclxuXHJcbiAgICBmYW1pbHlGYWN0cy5mb3JFYWNoKGZ1bmN0aW9uIChhRmFjdCkge1xyXG4gICAgICAvLyBBZGQgZXZlbnRzIHRvIHRoZSB0YWJsZVxyXG4gICAgICBjb25zdCBzaG93RGF0ZSA9IGFGYWN0WzBdLnJlcGxhY2UoXCItMDAtMDBcIiwgXCJcIikucmVwbGFjZShcIi0wMFwiLCBcIlwiKTtcclxuICAgICAgY29uc3QgdGxEYXRlID0gXCI8dGQgY2xhc3M9J3RsRGF0ZSc+XCIgKyBzaG93RGF0ZSArIFwiPC90ZD5cIjtcclxuICAgICAgbGV0IGFib3V0QWdlID0gXCJcIjtcclxuICAgICAgbGV0IGJwQmRhdGUgPSBwZXJzb24uQmlydGhEYXRlO1xyXG4gICAgICBpZiAoIXBlcnNvbi5CaXJ0aERhdGUpIHtcclxuICAgICAgICBicEJkYXRlID0gcGVyc29uLkJpcnRoRGF0ZURlY2FkZS5yZXBsYWNlKC8wcy8sIFwiNVwiKTtcclxuICAgICAgfVxyXG4gICAgICBsZXQgaGFzQmRhdGUgPSB0cnVlO1xyXG4gICAgICBpZiAoYnBCZGF0ZSA9PSBcIjAwMDAtMDAtMDBcIikge1xyXG4gICAgICAgIGhhc0JkYXRlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgYnBCRCA9IGdldEFwcHJveERhdGUoYnBCZGF0ZSk7XHJcbiAgICAgIGNvbnN0IGV2RGF0ZSA9IGdldEFwcHJveERhdGUoYUZhY3RbMF0pO1xyXG4gICAgICBjb25zdCBhUGVyc29uQkQgPSBnZXRBcHByb3hEYXRlKGFGYWN0WzVdKTtcclxuICAgICAgaWYgKGJwQkQuQXBwcm94ID09IHRydWUpIHtcclxuICAgICAgICBhYm91dEFnZSA9IFwiflwiO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChldkRhdGUuQXBwcm94ID09IHRydWUpIHtcclxuICAgICAgICBhYm91dEFnZSA9IFwiflwiO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCBicEFnZSA9IGdldEFnZShuZXcgRGF0ZShicEJELkRhdGUpLCBuZXcgRGF0ZShldkRhdGUuRGF0ZSkpO1xyXG4gICAgICBpZiAoYnBBZ2UgPT0gMCkge1xyXG4gICAgICAgIGJwQWdlID0gXCJcIjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoYnBEZWFkID09IHRydWUpIHtcclxuICAgICAgICBjb25zdCB0aGVEaWZmID0gcGFyc2VJbnQoYnBBZ2UgLSBicERlYWRBZ2UpO1xyXG4gICAgICAgIGJwQWdlID0gYnBBZ2UgKyBcIiAoXCIgKyBicERlYWRBZ2UgKyBcIiArIFwiICsgdGhlRGlmZiArIFwiKVwiO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCB0aGVCUEFnZTtcclxuICAgICAgaWYgKGFib3V0QWdlICE9IFwiXCIgJiYgYnBBZ2UgIT0gXCJcIikge1xyXG4gICAgICAgIHRoZUJQQWdlID0gXCIoXCIgKyBicEFnZSArIFwiKVwiO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoZUJQQWdlID0gYnBBZ2U7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGhhc0JkYXRlID09IGZhbHNlKSB7XHJcbiAgICAgICAgdGhlQlBBZ2UgPSBcIlwiO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHRsQmlvQWdlID0gXCI8dGQgY2xhc3M9J3RsQmlvQWdlJz5cIiArIHRoZUJQQWdlICsgXCI8L3RkPlwiO1xyXG4gICAgICBpZiAoYUZhY3RbNl0gPT0gdW5kZWZpbmVkIHx8IGFGYWN0WzldID09IHBlcnNvbi5OYW1lKSB7XHJcbiAgICAgICAgYUZhY3RbNl0gPSBcIlwiO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHRsUmVsYXRpb24gPVxyXG4gICAgICAgIFwiPHRkIGNsYXNzPSd0bFJlbGF0aW9uJz5cIiArIGFGYWN0WzZdLnJlcGxhY2UoL3MkLywgXCJcIikgKyBcIjwvdGQ+XCI7XHJcbiAgICAgIGxldCBmTmFtZXMgPSBhRmFjdFsyXTtcclxuICAgICAgaWYgKGFGYWN0WzhdID09IFwibWFycmlhZ2VcIikge1xyXG4gICAgICAgIGZOYW1lcyA9IHBlcnNvbi5GaXJzdE5hbWUgKyBcIiBhbmQgXCIgKyBhRmFjdFsyXTtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCB0bEZpcnN0TmFtZSA9XHJcbiAgICAgICAgXCI8dGQgY2xhc3M9J3RsRmlyc3ROYW1lJz48YSBocmVmPSdodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9cIiArXHJcbiAgICAgICAgYUZhY3RbOV0gK1xyXG4gICAgICAgIFwiJz5cIiArXHJcbiAgICAgICAgZk5hbWVzICtcclxuICAgICAgICBcIjwvYT48L3RkPlwiO1xyXG4gICAgICBjb25zdCB0bEV2ZW50TmFtZSA9XHJcbiAgICAgICAgXCI8dGQgY2xhc3M9J3RsRXZlbnROYW1lJz5cIiArXHJcbiAgICAgICAgY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKGFGYWN0WzhdKVxyXG4gICAgICAgICAgLnJlcGxhY2VBbGwoL1VzXFxiL2csIFwiVVNcIilcclxuICAgICAgICAgIC5yZXBsYWNlQWxsKC9JaVxcYi9nLCBcIklJXCIpICtcclxuICAgICAgICBcIjwvdGQ+XCI7XHJcbiAgICAgIGNvbnN0IHRsRXZlbnRMb2NhdGlvbiA9IFwiPHRkIGNsYXNzPSd0bEV2ZW50TG9jYXRpb24nPlwiICsgYUZhY3RbMV0gKyBcIjwvdGQ+XCI7XHJcblxyXG4gICAgICBpZiAoYVBlcnNvbkJELkFwcHJveCA9PSB0cnVlKSB7XHJcbiAgICAgICAgYWJvdXRBZ2UgPSBcIn5cIjtcclxuICAgICAgfVxyXG4gICAgICBsZXQgYVBlcnNvbkFnZSA9IGdldEFnZShuZXcgRGF0ZShhUGVyc29uQkQuRGF0ZSksIG5ldyBEYXRlKGV2RGF0ZS5EYXRlKSk7XHJcbiAgICAgIGlmIChhUGVyc29uQWdlID09IDAgfHwgYVBlcnNvbkJELkRhdGUubWF0Y2goLzAwMDAvKSAhPSBudWxsKSB7XHJcbiAgICAgICAgYVBlcnNvbkFnZSA9IFwiXCI7XHJcbiAgICAgICAgYWJvdXRBZ2UgPSBcIlwiO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCB0aGVBZ2U7XHJcbiAgICAgIGlmIChhYm91dEFnZSAhPSBcIlwiICYmIGFQZXJzb25BZ2UgIT0gXCJcIikge1xyXG4gICAgICAgIHRoZUFnZSA9IFwiKFwiICsgYVBlcnNvbkFnZSArIFwiKVwiO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoZUFnZSA9IGFQZXJzb25BZ2U7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdGxBZ2UgPSBcIjx0ZCBjbGFzcz0ndGxBZ2UnPlwiICsgdGhlQWdlICsgXCI8L3RkPlwiO1xyXG4gICAgICBsZXQgY2xhc3NUZXh0ID0gXCJcIjtcclxuICAgICAgaWYgKGFGYWN0WzldID09IHBlcnNvbi5OYW1lKSB7XHJcbiAgICAgICAgY2xhc3NUZXh0ICs9IFwiQmlvUGVyc29uIFwiO1xyXG4gICAgICB9XHJcbiAgICAgIGNsYXNzVGV4dCArPSBhRmFjdFs4XSArIFwiIFwiO1xyXG4gICAgICBjb25zdCB0bFRSID0gJChcclxuICAgICAgICBcIjx0ciBjbGFzcz0nXCIgK1xyXG4gICAgICAgICAgY2xhc3NUZXh0ICtcclxuICAgICAgICAgIFwiJz5cIiArXHJcbiAgICAgICAgICB0bERhdGUgK1xyXG4gICAgICAgICAgdGxCaW9BZ2UgK1xyXG4gICAgICAgICAgdGxSZWxhdGlvbiArXHJcbiAgICAgICAgICB0bEZpcnN0TmFtZSArXHJcbiAgICAgICAgICB0bEFnZSArXHJcbiAgICAgICAgICB0bEV2ZW50TmFtZSArXHJcbiAgICAgICAgICB0bEV2ZW50TG9jYXRpb24gK1xyXG4gICAgICAgICAgXCI8L3RyPlwiXHJcbiAgICAgICk7XHJcbiAgICAgICQoXCIjdGltZWxpbmVUYWJsZVwiKS5hcHBlbmQodGxUUik7XHJcbiAgICAgIGlmIChhRmFjdFs4XSA9PSBcIkRlYXRoXCIgJiYgYUZhY3RbOV0gPT0gcGVyc29uLk5hbWUpIHtcclxuICAgICAgICBicERlYWQgPSB0cnVlO1xyXG4gICAgICAgIGJwRGVhZEFnZSA9IGJwQWdlO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICAkKFwiI3RpbWVsaW5lXCIpLnNsaWRlRG93bihcInNsb3dcIik7XHJcbiAgICAkKFwiI3RpbWVsaW5lIHhcIikuY2xpY2soZnVuY3Rpb24gKCkge1xyXG4gICAgICAkKFwiI3RpbWVsaW5lXCIpLnNsaWRlVXAoKTtcclxuICAgIH0pO1xyXG4gICAgJChcIiN0aW1lbGluZSB3XCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgICAgJChcIiN0aW1lbGluZVwiKS50b2dnbGVDbGFzcyhcIndyYXBcIik7XHJcbiAgICB9KTtcclxuICAgIC8vIFVzZSBqcXVlcnktdWkgdG8gbWFrZSB0aGUgdGFibGUgZHJhZ2dhYmxlXHJcbiAgICAkKFwiI3RpbWVsaW5lXCIpLmRyYWdnYWJsZSgpO1xyXG4gICAgJChcIiN0aW1lbGluZVwiKS5kYmxjbGljayhmdW5jdGlvbiAoKSB7XHJcbiAgICAgICQodGhpcykuc2xpZGVVcChcInN3aW5nXCIpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuIiwiaW1wb3J0ICQgZnJvbSBcImpxdWVyeVwiO1xyXG5pbXBvcnQgeyBleHRyYWN0UmVsYXRpdmVzLCBmYW1pbHlBcnJheSwgZ2V0UmVsYXRpdmVzIH0gZnJvbSBcIi4uLy4uL2NvcmUvY29tbW9uXCI7XHJcbmltcG9ydCBcIi4vbG9jYXRpb25zSGVscGVyLmNzc1wiO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJsb2NhdGlvbnNIZWxwZXJcIiwgKHJlc3VsdCkgPT4ge1xyXG4gIGlmIChcclxuICAgIHJlc3VsdC5sb2NhdGlvbnNIZWxwZXIgJiZcclxuICAgICQoXCJib2R5LkJFRVwiKS5sZW5ndGggPT0gMCAmJlxyXG4gICAgKCQoXCJib2R5LnBhZ2UtU3BlY2lhbF9FZGl0UGVyc29uXCIpLmxlbmd0aCB8fFxyXG4gICAgICAkKFwiYm9keS5wYWdlLVNwZWNpYWxfRWRpdEZhbWlseVwiKS5sZW5ndGgpXHJcbiAgKSB7XHJcbiAgICBmdW5jdGlvbiBhZGRSZWxBcnJheXNUb1BlcnNvbih6UGVyc29uKSB7XHJcbiAgICAgIGNvbnN0IHpTcG91c2VzID0gZXh0cmFjdFJlbGF0aXZlcyh6UGVyc29uLlNwb3VzZXMsIFwiU3BvdXNlXCIpO1xyXG4gICAgICB6UGVyc29uLlNwb3VzZSA9IHpTcG91c2VzO1xyXG4gICAgICBjb25zdCB6Q2hpbGRyZW4gPSBleHRyYWN0UmVsYXRpdmVzKHpQZXJzb24uQ2hpbGRyZW4sIFwiQ2hpbGRcIik7XHJcbiAgICAgIHpQZXJzb24uQ2hpbGQgPSB6Q2hpbGRyZW47XHJcbiAgICAgIGNvbnN0IHpTaWJsaW5ncyA9IGV4dHJhY3RSZWxhdGl2ZXMoelBlcnNvbi5TaWJsaW5ncywgXCJTaWJsaW5nXCIpO1xyXG4gICAgICB6UGVyc29uLlNpYmxpbmcgPSB6U2libGluZ3M7XHJcbiAgICAgIGNvbnN0IHpQYXJlbnRzID0gZXh0cmFjdFJlbGF0aXZlcyh6UGVyc29uLlBhcmVudHMsIFwiUGFyZW50XCIpO1xyXG4gICAgICB6UGVyc29uLlBhcmVudCA9IHpQYXJlbnRzO1xyXG4gICAgICByZXR1cm4gelBlcnNvbjtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBlZGl0RGlzdGFuY2UoczEsIHMyKSB7XHJcbiAgICAgIHMxID0gczEudG9Mb3dlckNhc2UoKTtcclxuICAgICAgczIgPSBzMi50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBsZXQgY29zdHMgPSBuZXcgQXJyYXkoKTtcclxuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPD0gczEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICB2YXIgbGFzdFZhbHVlID0gaTtcclxuICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8PSBzMi5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgaWYgKGkgPT0gMCkgY29zdHNbal0gPSBqO1xyXG4gICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChqID4gMCkge1xyXG4gICAgICAgICAgICAgIHZhciBuZXdWYWx1ZSA9IGNvc3RzW2ogLSAxXTtcclxuICAgICAgICAgICAgICBpZiAoczEuY2hhckF0KGkgLSAxKSAhPSBzMi5jaGFyQXQoaiAtIDEpKVxyXG4gICAgICAgICAgICAgICAgbmV3VmFsdWUgPVxyXG4gICAgICAgICAgICAgICAgICBNYXRoLm1pbihNYXRoLm1pbihuZXdWYWx1ZSwgbGFzdFZhbHVlKSwgY29zdHNbal0pICsgMTtcclxuICAgICAgICAgICAgICBjb3N0c1tqIC0gMV0gPSBsYXN0VmFsdWU7XHJcbiAgICAgICAgICAgICAgbGFzdFZhbHVlID0gbmV3VmFsdWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGkgPiAwKSBjb3N0c1tzMi5sZW5ndGhdID0gbGFzdFZhbHVlO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBjb3N0c1tzMi5sZW5ndGhdO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHNpbWlsYXJpdHkoczEsIHMyKSB7XHJcbiAgICAgIHMxID0gczEudG9Mb3dlckNhc2UoKTtcclxuICAgICAgczIgPSBzMi50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICB2YXIgbG9uZ2VyID0gczE7XHJcbiAgICAgIHZhciBzaG9ydGVyID0gczI7XHJcbiAgICAgIGlmIChzMS5sZW5ndGggPCBzMi5sZW5ndGgpIHtcclxuICAgICAgICBsb25nZXIgPSBzMjtcclxuICAgICAgICBzaG9ydGVyID0gczE7XHJcbiAgICAgIH1cclxuICAgICAgdmFyIGxvbmdlckxlbmd0aCA9IGxvbmdlci5sZW5ndGg7XHJcbiAgICAgIGlmIChsb25nZXJMZW5ndGggPT0gMCkge1xyXG4gICAgICAgIHJldHVybiAxLjA7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICAobG9uZ2VyTGVuZ3RoIC0gZWRpdERpc3RhbmNlKGxvbmdlciwgc2hvcnRlcikpIC9cclxuICAgICAgICBwYXJzZUZsb2F0KGxvbmdlckxlbmd0aClcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBsb2NhdGlvbnNIZWxwZXIoKSB7XHJcbiAgICAgIGxldCB0aGVJRDtcclxuICAgICAgaWYgKCQoXCJib2R5LnBhZ2UtU3BlY2lhbF9FZGl0RmFtaWx5XCIpLmxlbmd0aCkge1xyXG4gICAgICAgIHRoZUlEID0gJChcImEucHVyZUNzc01lbnVpMCBzcGFuLnBlcnNvblwiKS50ZXh0KCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhlSUQgPSAkKFwiYS5wdXJlQ3NzTWVudWk6Q29udGFpbnMoRWRpdClcIikuYXR0cihcImhyZWZcIikuc3BsaXQoXCJ1PVwiKVsxXTtcclxuICAgICAgfVxyXG4gICAgICBnZXRSZWxhdGl2ZXModGhlSUQpLnRoZW4oKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRoaXNGYW1pbHkgPSBmYW1pbHlBcnJheShyZXN1bHQpO1xyXG4gICAgICAgIHdpbmRvdy5iZExvY2F0aW9ucyA9IFtdO1xyXG4gICAgICAgIHRoaXNGYW1pbHkuZm9yRWFjaChmdW5jdGlvbiAoYVBlKSB7XHJcbiAgICAgICAgICBpZiAoYVBlLkJpcnRoTG9jYXRpb24pIHtcclxuICAgICAgICAgICAgd2luZG93LmJkTG9jYXRpb25zLnB1c2goYVBlLkJpcnRoTG9jYXRpb24pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaWYgKGFQZS5EZWF0aExvY2F0aW9uKSB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5iZExvY2F0aW9ucy5wdXNoKGFQZS5EZWF0aExvY2F0aW9uKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBvYnNlcnZlcjIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihmdW5jdGlvbiAobXV0YXRpb25zX2xpc3QpIHtcclxuICAgICAgICBtdXRhdGlvbnNfbGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChtdXRhdGlvbikge1xyXG4gICAgICAgICAgbXV0YXRpb24uYWRkZWROb2Rlcy5mb3JFYWNoKGZ1bmN0aW9uIChhZGRlZF9ub2RlKSB7XHJcbiAgICAgICAgICAgIGlmIChhZGRlZF9ub2RlLmNsYXNzTmFtZSA9PSBcImF1dG9jb21wbGV0ZS1zdWdnZXN0aW9uLWNvbnRhaW5lclwiKSB7XHJcbiAgICAgICAgICAgICAgbGV0IGFjdGl2ZUVsID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcclxuICAgICAgICAgICAgICBsZXQgd2hpY2hMb2NhdGlvbiA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgaWYgKGFjdGl2ZUVsLmlkID09IFwibUJpcnRoTG9jYXRpb25cIikge1xyXG4gICAgICAgICAgICAgICAgd2hpY2hMb2NhdGlvbiA9IFwiQmlydGhcIjtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgaWYgKGFjdGl2ZUVsLmlkID09IFwibURlYXRoTG9jYXRpb25cIikge1xyXG4gICAgICAgICAgICAgICAgd2hpY2hMb2NhdGlvbiA9IFwiRGVhdGhcIjtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgaWYgKGFjdGl2ZUVsLm5hbWUgPT0gXCJtTWFycmlhZ2VMb2NhdGlvblwiKSB7XHJcbiAgICAgICAgICAgICAgICB3aGljaExvY2F0aW9uID0gXCJNYXJyaWFnZVwiO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBsZXQgZFRleHQgPSBhZGRlZF9ub2RlLnRleHRDb250ZW50O1xyXG4gICAgICAgICAgICAgIGxldCBjdXJyZW50QmlydGhZZWFyTWF0Y2ggPSBudWxsO1xyXG4gICAgICAgICAgICAgIGxldCBjdXJyZW50RGVhdGhZZWFyTWF0Y2ggPSBudWxsO1xyXG4gICAgICAgICAgICAgIGxldCBjdXJyZW50TWFycmlhZ2VZZWFyTWF0Y2ggPSBudWxsO1xyXG4gICAgICAgICAgICAgIGlmICgkKFwiI21CaXJ0aERhdGVcIikubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50QmlydGhZZWFyTWF0Y2ggPSAkKFwiI21CaXJ0aERhdGVcIilcclxuICAgICAgICAgICAgICAgICAgLnZhbCgpXHJcbiAgICAgICAgICAgICAgICAgIC5tYXRjaCgvWzAtOV17Myw0fS8pO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBpZiAoJChcIiNtRGVhdGhEYXRlXCIpLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgY3VycmVudERlYXRoWWVhck1hdGNoID0gJChcIiNtRGVhdGhEYXRlXCIpXHJcbiAgICAgICAgICAgICAgICAgIC52YWwoKVxyXG4gICAgICAgICAgICAgICAgICAubWF0Y2goL1swLTldezMsNH0vKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgaWYgKCQoXCIjbU1hcnJpYWdlRGF0ZVwiKS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGN1cnJlbnRNYXJyaWFnZVllYXJNYXRjaCA9ICQoXCIjbU1hcnJpYWdlRGF0ZVwiKVxyXG4gICAgICAgICAgICAgICAgICAudmFsKClcclxuICAgICAgICAgICAgICAgICAgLm1hdGNoKC9bMC05XXszLDR9Lyk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGxldCBzdGFydFllYXIgPSBcIlwiO1xyXG4gICAgICAgICAgICAgIGxldCBlbmRZZWFyID0gXCJcIjtcclxuICAgICAgICAgICAgICBsZXQgZ29vZERhdGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICBsZXQgZmFtaWx5TG9jID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgbGV0IGZhbWlseUxvYzIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICBjb25zdCB5ZWFyc01hdGNoID0gZFRleHQubWF0Y2goL1xcKFteQS16XSpbMC05XXszLDR9LipcXCkvZyk7XHJcbiAgICAgICAgICAgICAgaWYgKHllYXJzTWF0Y2ggIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgeWVhcnMgPSB5ZWFyc01hdGNoWzBdLnJlcGxhY2VBbGwoL1soKV0vZywgXCJcIikuc3BsaXQoXCItXCIpO1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyh5ZWFycyk7XHJcbiAgICAgICAgICAgICAgICBpZiAoeWVhcnNbMF0udHJpbSgpICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgc3RhcnRZZWFyID0geWVhcnNbMF0udHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHllYXJzWzFdLnRyaW0oKSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgIGVuZFllYXIgPSB5ZWFyc1sxXS50cmltKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGdvb2REYXRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgbGV0IG15WWVhciA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgaWYgKGN1cnJlbnRCaXJ0aFllYXJNYXRjaCAhPSBudWxsICYmIHdoaWNoTG9jYXRpb24gPT0gXCJCaXJ0aFwiKSB7XHJcbiAgICAgICAgICAgICAgICBteVllYXIgPSBjdXJyZW50QmlydGhZZWFyTWF0Y2hbMF07XHJcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICAgICAgICAgIGN1cnJlbnREZWF0aFllYXJNYXRjaCAhPSBudWxsICYmXHJcbiAgICAgICAgICAgICAgICB3aGljaExvY2F0aW9uID09IFwiRGVhdGhcIlxyXG4gICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgbXlZZWFyID0gY3VycmVudERlYXRoWWVhck1hdGNoWzBdO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgICAgICAgICBjdXJyZW50TWFycmlhZ2VZZWFyTWF0Y2ggIT0gbnVsbCAmJlxyXG4gICAgICAgICAgICAgICAgd2hpY2hMb2NhdGlvbiA9PSBcIk1hcnJpYWdlXCJcclxuICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIG15WWVhciA9IGN1cnJlbnRNYXJyaWFnZVllYXJNYXRjaFswXTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgaWYgKG15WWVhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoc3RhcnRZZWFyID09IFwiXCIgJiYgcGFyc2VJbnQobXlZZWFyKSA8IHBhcnNlSW50KGVuZFllYXIpKSB7XHJcbiAgICAgICAgICAgICAgICAgIGdvb2REYXRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgICAgICAgICAgIGVuZFllYXIgPT0gXCJcIiAmJlxyXG4gICAgICAgICAgICAgICAgICBwYXJzZUludChteVllYXIpID4gcGFyc2VJbnQoc3RhcnRZZWFyKVxyXG4gICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgIGdvb2REYXRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgICAgICAgICAgIHBhcnNlSW50KG15WWVhcikgPiBwYXJzZUludChzdGFydFllYXIpICYmXHJcbiAgICAgICAgICAgICAgICAgIHBhcnNlSW50KG15WWVhcikgPCBwYXJzZUludChlbmRZZWFyKVxyXG4gICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgIGdvb2REYXRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZ29vZERhdGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB3aW5kb3cuYmRMb2NhdGlvbnMuZm9yRWFjaChmdW5jdGlvbiAoYUxvYykge1xyXG4gICAgICAgICAgICAgICAgZFRleHQgPSBkVGV4dC5zcGxpdChcIihcIilbMF0udHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHNpbWlsYXJpdHkoYUxvYywgZFRleHQpID4gMC44KSB7XHJcbiAgICAgICAgICAgICAgICAgIGZhbWlseUxvYyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoc2ltaWxhcml0eShhTG9jLCBkVGV4dCkgPiAwLjk1KSB7XHJcbiAgICAgICAgICAgICAgICAgIGZhbWlseUxvYzIgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHRoZUNvbnRhaW5lciA9ICQoYWRkZWRfbm9kZSkuY2xvc2VzdChcclxuICAgICAgICAgICAgICAgIFwiLmF1dG9jb21wbGV0ZS1zdWdnZXN0aW9uLWNvbnRhaW5lclwiXHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICBpZiAoZ29vZERhdGUgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhlQ29udGFpbmVyLmFkZENsYXNzKFwicmlnaHRQZXJpb2RcIik7XHJcbiAgICAgICAgICAgICAgICBpZiAoZmFtaWx5TG9jMiA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgIHRoZUNvbnRhaW5lclxyXG4gICAgICAgICAgICAgICAgICAgIC5hZGRDbGFzcyhcImZhbWlseUxvYzJcIilcclxuICAgICAgICAgICAgICAgICAgICAucHJlcGVuZFRvKCQoXCIuYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zXCIpKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZmFtaWx5TG9jID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgdGhlQ29udGFpbmVyXHJcbiAgICAgICAgICAgICAgICAgICAgLmFkZENsYXNzKFwiZmFtaWx5TG9jMVwiKVxyXG4gICAgICAgICAgICAgICAgICAgIC5wcmVwZW5kVG8oJChcIi5hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnNcIikpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGVDb250YWluZXJcclxuICAgICAgICAgICAgICAgICAgLmFkZENsYXNzKFwid3JvbmdQZXJpb2RcIilcclxuICAgICAgICAgICAgICAgICAgLmFwcGVuZFRvKCQoXCIuYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zXCIpKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIG9ic2VydmVyMi5vYnNlcnZlKCQoXCIuYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zXCIpLmVxKDApWzBdLCB7XHJcbiAgICAgICAgICBzdWJ0cmVlOiBmYWxzZSxcclxuICAgICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoJChcIiNtRGVhdGhMb2NhdGlvblwiKS5sZW5ndGgpIHtcclxuICAgICAgICAgIG9ic2VydmVyMi5vYnNlcnZlKCQoXCIuYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zXCIpLmVxKDEpWzBdLCB7XHJcbiAgICAgICAgICAgIHN1YnRyZWU6IGZhbHNlLFxyXG4gICAgICAgICAgICBjaGlsZExpc3Q6IHRydWUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sIDMwMDApO1xyXG4gICAgfVxyXG4gICAgbG9jYXRpb25zSGVscGVyKCk7XHJcbiAgfVxyXG59KTtcclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IHtjcmVhdGVUb3BNZW51SXRlbX0gZnJvbSAnLi4vLi4vY29yZS9jb21tb24nO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoJ3ByaW50ZXJGcmllbmRseScsIChyZXN1bHQpID0+IHtcclxuXHRpZiAocmVzdWx0LnByaW50ZXJGcmllbmRseSkge1xyXG5cdFx0Ly8gY3JlYXRlIGEgdG9wIG1lbnUgaXRlbVxyXG5cdFx0Y3JlYXRlVG9wTWVudUl0ZW0oe1xyXG5cdFx0XHR0aXRsZTogJ0NoYW5nZXMgdGhlIGZvcm1hdCB0byBhIHByaW50ZXItZnJpZW5kbHkgb25lLicsXHJcblx0XHRcdG5hbWU6ICdQcmludGVyIEZyaWVuZGx5IEJpbycsXHJcblx0XHRcdGlkOiAnd3RlLXRtLXByaW50ZXItZnJpZW5kbHknXHJcblx0XHR9KTtcclxuXHJcblx0XHQkKGAjd3RlLXRtLXByaW50ZXItZnJpZW5kbHlgKS5vbignY2xpY2snLCAoKSA9PiB7XHJcblx0XHRcdHByaW50QmlvKCk7XHJcblx0XHR9KTtcclxuXHR9XHJcbn0pO1xyXG5cclxuLy8gbW9kaWZpZWQgY29kZSBmcm9tIFN0ZXZlbidzIFdpa2lUcmVlIFRvb2xraXRcclxuZnVuY3Rpb24gcHJpbnRCaW8oKSB7XHJcblx0dmFyIHBUaXRsZUNsZWFuID0gJChkb2N1bWVudCkuYXR0cigndGl0bGUnKTtcclxuXHR2YXIgcFRpdGxlQ2xlYW5lciA9IHBUaXRsZUNsZWFuLnJlcGxhY2UoJyB8IFdpa2lUcmVlIEZSRUUgRmFtaWx5IFRyZWUnLCAnJyk7XHJcblx0dmFyIHBUaXRsZSA9IHBUaXRsZUNsZWFuZXIucmVwbGFjZSgnIC0gV2lraVRyZWUgUHJvZmlsZScsICcnKTtcclxuXHR2YXIgcEltYWdlID0gJChcImltZ1tzcmNePScvcGhvdG8ucGhwLyddXCIpLmF0dHIoJ3NyYycpO1xyXG5cdHZhciBwVGl0bGVJbnNlcnQgPSAkKCdoMicpLmZpcnN0KCk7XHJcblx0cFRpdGxlSW5zZXJ0LmJlZm9yZShcclxuXHRcdGA8ZGl2PlxyXG5cdFx0XHQ8aW1nIHN0eWxlPVwiZmxvYXQ6bGVmdDtcIiBzcmM9XCJodHRwczovL3d3dy53aWtpdHJlZS5jb20ke3BJbWFnZX1cIiB3aWR0aD1cIjc1XCIgaGVpZ2h0PVwiNzVcIj5cclxuXHRcdFx0PGRpdiBzdHlsZT1cImZvbnQtc2l6ZTogMi4xNDI5ZW07IGxpbmUtaGVpZ2h0OiAxLjRlbTsgbWFyZ2luLWJvdHRvbTo1MHB4OyBwYWRkaW5nOiAyMHB4IDEwMHB4O1wiPlxyXG5cdFx0XHRcdCR7cFRpdGxlfVxyXG5cdFx0XHQ8L2Rpdj5cclxuXHRcdDwvZGl2PmBcclxuXHQpO1xyXG5cclxuXHQkKFwiYVt0YXJnZXQ9J19IZWxwJ11cIikucGFyZW50KCkucmVtb3ZlKCk7XHJcblx0JChcInNwYW5bdGl0bGUqPSdmb3IgdGhlIHByb2ZpbGUgYW5kJ11cIikucGFyZW50KCkucmVtb3ZlKCk7XHJcblx0JChcImRpdltzdHlsZT0nYmFja2dyb3VuZC1jb2xvcjojZTFlZmJiOyddXCIpLnJlbW92ZSgpO1xyXG5cdCQoXCJkaXZbc3R5bGU9J2JhY2tncm91bmQtY29sb3I6I2VlZTsnXVwiKS5yZW1vdmUoKTtcclxuXHQkKFwiYVtocmVmXj0nL3RyZWV3aWRnZXQvJ11cIikucmVtb3ZlKCk7XHJcblx0JChcImFbaHJlZj0nL2cyZy8nXVwiKS5yZW1vdmUoKTtcclxuXHQkKFwiYVtjbGFzcz0nbm9ob3ZlciddXCIpLnJlbW92ZSgpO1xyXG5cclxuXHQkKCdkaXYnKS5yZW1vdmVDbGFzcygndGVuIGNvbHVtbnMnKTtcclxuXHQkKCcuVklUQUxTJykucmVtb3ZlKCk7XHJcblx0JCgnLnN0YXInKS5yZW1vdmUoKTtcclxuXHQkKCcucHJvZmlsZS10YWJzJykucmVtb3ZlKCk7XHJcblx0Ly8kKFwiLlNNQUxMXCIpLnJlbW92ZSgpO1xyXG5cdCQoJy5zaG93aGlkZXRyZWUnKS5yZW1vdmUoKTtcclxuXHQkKCcucm93JykucmVtb3ZlKCk7XHJcblx0JCgnLmJ1dHRvbicpLnJlbW92ZSgpO1xyXG5cdCQoJy5sYXJnZScpLnJlbW92ZSgpO1xyXG5cdCQoJy5zaXh0ZWVuJykucmVtb3ZlKCk7XHJcblx0JCgnLmZpdmUnKS5yZW1vdmUoKTtcclxuXHQkKCcuZWRpdHNlY3Rpb24nKS5yZW1vdmUoKTtcclxuXHQkKCcuRURJVCcpLnJlbW92ZSgpO1xyXG5cdCQoJy5jb21tZW50LWFic2VudCcpLnJlbW92ZSgpO1xyXG5cdCQoJy5ib3gnKS5yZW1vdmUoKTtcclxuXHJcblx0JCgnI3ZpZXdzLXdyYXAnKS5yZW1vdmUoKTtcclxuXHQkKCcjZm9vdGVyJykucmVtb3ZlKCk7XHJcblx0JCgnI2NvbW1lbnRQb3N0RGl2JykucmVtb3ZlKCk7XHJcblx0JCgnI2NvbW1lbnRzJykucmVtb3ZlKCk7XHJcblx0JCgnI2NvbW1lbnRFZGl0RGl2JykucmVtb3ZlKCk7XHJcblx0JCgnI2NvbW1lbnRHMkdEaXYnKS5yZW1vdmUoKTtcclxuXHQkKCcjaGVhZGVyJykucmVtb3ZlKCk7XHJcblx0JCgnI3Nob3dIaWRlRGVzY2VuZGFudHMnKS5yZW1vdmUoKTtcclxuXHJcblx0d2luZG93LnByaW50KCk7XHJcblx0bG9jYXRpb24ucmVsb2FkKCk7XHJcbn1cclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCdyYW5kb21Qcm9maWxlJywgKHJlc3VsdCkgPT4ge1xyXG5cdGlmIChyZXN1bHQucmFuZG9tUHJvZmlsZSAmJiAkKFwiYm9keS5CRUVcIikubGVuZ3RoPT0wKSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0UmFuZG9tUHJvZmlsZSgpIHtcclxuICAgICAgICAgICAgdmFyIHJhbmRvbVByb2ZpbGVJRCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDM2MDY1OTg4KTtcclxuICAgICAgICAgICAgdmFyIGxpbmsgPSAnJztcclxuICAgICAgICAgICAgLy8gY2hlY2sgaWYgZXhpc3RzXHJcbiAgICAgICAgICAgICQuZ2V0SlNPTignaHR0cHM6Ly9hcGkud2lraXRyZWUuY29tL2FwaS5waHA/YWN0aW9uPWdldFBlcnNvbiZrZXk9JyArIHJhbmRvbVByb2ZpbGVJRClcclxuICAgICAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uIChqc29uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgdG8gc2VlIGlmIHRoZSBwcm9maWxlIGlzIE9wZW5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoanNvblswXVsnc3RhdHVzJ10gPT0gMCAmJiAnUHJpdmFjeV9Jc09wZW4nIGluIGpzb25bMF1bJ3BlcnNvbiddICYmIGpzb25bMF1bJ3BlcnNvbiddWydQcml2YWN5X0lzT3BlbiddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmsgPSAnaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvJyArIHJhbmRvbVByb2ZpbGVJRDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uID0gbGluaztcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgeyAvLyBJZiBpdCBpc24ndCBvcGVuLCBmaW5kIGEgbmV3IHByb2ZpbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0UmFuZG9tUHJvZmlsZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAuZmFpbChmdW5jdGlvbiAoanFYSFIsIHRleHRTdGF0dXMsIGVycm9yVGhyb3duKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2dldEpTT04gcmVxdWVzdCBmYWlsZWQhICcgKyB0ZXh0U3RhdHVzICsgJyAnICsgZXJyb3JUaHJvd24pO1xyXG4gICAgICAgICAgICAgICAgICAgIGdldFJhbmRvbVByb2ZpbGUoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gYWRkIHJhbmRvbSBvcHRpb24gdG8gJ0ZpbmQnXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gYWRkUmFuZG9tVG9GaW5kTWVudSgpIHtcclxuICAgICAgICAgICAgY29uc3QgcmVsYXRpb25zaGlwTGkgPSAkKFwibGkgYS5wdXJlQ3NzTWVudWlbaHJlZj0nL3dpa2kvU3BlY2lhbDpSZWxhdGlvbnNoaXAnXVwiKTtcclxuICAgICAgICAgICAgY29uc3QgbmV3TGkgPSAkKFwiPGxpPjxhIGNsYXNzPSdwdXJlQ3NzTWVudWkgcmFuZG9tUHJvZmlsZScgdGl0bGU9J0dvIHRvIGEgcmFuZG9tIHByb2ZpbGUnPlJhbmRvbSBQcm9maWxlPC9saT5cIik7XHJcbiAgICAgICAgICAgIG5ld0xpLmluc2VydEJlZm9yZShyZWxhdGlvbnNoaXBMaS5wYXJlbnQoKSk7XHJcbiAgICAgICAgICAgICQoXCIucmFuZG9tUHJvZmlsZVwiKS5jbGljayhmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgZ2V0UmFuZG9tUHJvZmlsZSgpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIGFkZFJhbmRvbVRvRmluZE1lbnUoKTtcclxuICAgIH1cclxufSlcclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCdzUHJldmlld3MnLCBmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICBpZiAocmVzdWx0LnNQcmV2aWV3cyA9PSB0cnVlKSB7XHJcbiAgICAgICAgc291cmNlUHJldmlldygpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBzb3VyY2VQcmV2aWV3KCkge1xyXG4gICAgICAgICAgICBpZiAoJCgnLnJlZmVyZW5jZScpLmxlbmd0aCkgeyAvLyBhbmQgb25seSBpZiBpbmxpbmUgY2l0YXRpb25zIGFyZSBmb3VuZFxyXG4gICAgICAgICAgICAgICAgJCgnLnJlZmVyZW5jZScpLmhvdmVyKGZ1bmN0aW9uIChlKSB7IC8vIGpxdWVyeS5ob3ZlcigpIGhhbmRsZXJJbiAoc2hvdyBzb3VyY2VQcmV2aWV3KVxyXG4gICAgICAgICAgICAgICAgICAgIHZhciBzb3VyY2VJRCA9IHRoaXMuaWQucmVwbGFjZSgncmVmJywgJ25vdGUnKS5yZXBsYWNlKC8oX1swLTldKyQpL2csICcnKTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgc1ByZXZpZXcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICAgICAgICAgICAgICBzUHJldmlldy5zZXRBdHRyaWJ1dGUoJ2lkJywgJ3NvdXJjZVByZXZpZXcnKTtcclxuICAgICAgICAgICAgICAgICAgICBzUHJldmlldy5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2JveCByb3VuZGVkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgc1ByZXZpZXcuc2V0QXR0cmlidXRlKCdzdHlsZScsICd6LWluZGV4Ojk5OTsgd2lkdGg6IDQ1MHB4OyBwb3NpdGlvbjphYnNvbHV0ZTsnKTtcclxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCh0aGlzLmlkKS5hcHBlbmRDaGlsZChzUHJldmlldyk7XHJcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NvdXJjZVByZXZpZXcnKS5pbm5lckhUTUwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChzb3VyY2VJRCkuaW5uZXJIVE1MO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAvLyBqcWV1cnkuaG92ZXIoKSBoYW5kbGVyT3V0IChyZW1vdmUgc291cmNlUHJldmlldylcclxuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICQoJyNzb3VyY2VQcmV2aWV3JykucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHRhcmdldE5vZGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncHJldmlld2JveCcpO1xyXG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IHsgY2hpbGRMaXN0OiB0cnVlIH07XHJcbiAgICAgICAgY29uc3QgY2FsbGJhY2sgPSAobXV0YXRpb25MaXN0LCBvYnNlcnZlcikgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGNvbnN0IG11dGF0aW9uIG9mIG11dGF0aW9uTGlzdCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKG11dGF0aW9uLnR5cGUgPT09ICdjaGlsZExpc3QnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNlUHJldmlldygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGNhbGxiYWNrKTtcclxuICAgICAgICBpZiAoJCgnI3ByZXZpZXdib3gnKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIG9ic2VydmVyLm9ic2VydmUodGFyZ2V0Tm9kZSwgY29uZmlnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pXHJcbiIsImltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCAnLi4vLi4vdGhpcmRwYXJ0eS9qcXVlcnkuaG92ZXJEZWxheSdcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwic3BhY2VQcmV2aWV3c1wiLCBmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgaWYgKHJlc3VsdC5zcGFjZVByZXZpZXdzID09IHRydWUpIHtcclxuICAgICQoJy50ZW4uY29sdW1ucyBhW2hyZWYqPVwiL3dpa2kvU3BhY2U6XCJdLCAuc2l4dGVlbi5jb2x1bW5zIGFbaHJlZio9XCIvd2lraS9TcGFjZTpcIl0nKS5ob3ZlckRlbGF5KHtcclxuICAgICAgZGVsYXlJbjogMTAwMCxcclxuICAgICAgZGVsYXlPdXQ6IDAsXHJcbiAgICAgIGhhbmRsZXJJbjogZnVuY3Rpb24gKCRlbGVtZW50KSB7XHJcbiAgICAgICAgJChcIiNzcGFjZVByZXZpZXdcIikucmVtb3ZlKCk7XHJcbiAgICAgICAgJChcIiNzcGFjZUhvdmVyXCIpLmF0dHIoXCJpZFwiLCBcIlwiKTtcclxuICAgICAgICBjb25zb2xlLmxvZygkZWxlbWVudFswXS5ocmVmKTtcclxuICAgICAgICAkZWxlbWVudC5hdHRyKFwiaWRcIiwgXCJzcGFjZUhvdmVyXCIpO1xyXG4gICAgICAgIHZhciBzUHJldmlldyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XHJcbiAgICAgICAgc1ByZXZpZXcuc2V0QXR0cmlidXRlKFwiaWRcIiwgXCJzcGFjZVByZXZpZXdcIik7XHJcbiAgICAgICAgc1ByZXZpZXcuc2V0QXR0cmlidXRlKFwiY2xhc3NcIiwgXCJib3ggcm91bmRlZFwiKTtcclxuICAgICAgICBzUHJldmlldy5zZXRBdHRyaWJ1dGUoXHJcbiAgICAgICAgICBcInN0eWxlXCIsXHJcbiAgICAgICAgICBgei1pbmRleDo5OTk5OyBtYXgtaGVpZ2h0OjQ1MHB4OyBvdmVyZmxvdzogc2Nyb2xsOyBwb3NpdGlvbjphYnNvbHV0ZTsgcGFkZGluZzogMTBweDsgbWFyZ2luLXRvcDotMjBweDtgXHJcbiAgICAgICAgKTtcclxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNwYWNlSG92ZXJcIikucGFyZW50RWxlbWVudC5hcHBlbmRDaGlsZChzUHJldmlldyk7XHJcbiAgICAgICAgJC5hamF4KHtcclxuICAgICAgICAgIHVybDogJGVsZW1lbnRbMF0uaHJlZixcclxuICAgICAgICAgIGNvbnRleHQ6IGRvY3VtZW50LmJvZHksXHJcbiAgICAgICAgfSkuZG9uZShmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICAgICAgICB2YXIgcGFnZUNvbnRlbnQgPSAkKHJlc3VsdCkuZmluZChcIi50ZW4uY29sdW1uc1wiKS5odG1sKCk7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcclxuICAgICAgICAgICAgICBcInNwYWNlUHJldmlld1wiXHJcbiAgICAgICAgICAgICkuaW5uZXJIVE1MID0gYDxzcGFuIHN0eWxlPVwiZmxvYXQ6cmlnaHQ7IGZvbnQtd2VpZ2h0OjcwMDtcIj5jbGljayBvdXRzaWRlIHRvIGNsb3NlPC9zcGFuPiR7cGFnZUNvbnRlbnR9YDtcclxuICAgICAgICAgIH0gY2F0Y2gge31cclxuICAgICAgICB9KTtcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH1cclxuICAkKGRvY3VtZW50KS5vbihcImNsaWNrXCIsIGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgaWYgKCQoZXZlbnQudGFyZ2V0KS5jbG9zZXN0KFwiI3NwYWNlUHJldmlld1wiKS5sZW5ndGggPT09IDApIHtcclxuICAgICAgJChcIiNzcGFjZVByZXZpZXdcIikucmVtb3ZlKCk7XHJcbiAgICAgICQoXCIjc3BhY2VIb3ZlclwiKS5hdHRyKFwiaWRcIiwgXCJcIik7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn0pO1xyXG4iLCJpbXBvcnQgJy4vd3RQbHVzLmNzcyc7XHJcblxyXG5sZXQgdGIgPSB7fTtcclxuXHJcbmZ1bmN0aW9uIGl0ZW1zRmluZEJ5VGVtcGxhdGUobmFtZSkge1xyXG5cdHJldHVybiB0Yi50ZW1wbGF0ZXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5uYW1lLnRvVXBwZXJDYXNlKCkgPT09IG5hbWUudG9VcHBlckNhc2UoKSlbMF1cclxufVxyXG5cclxuZnVuY3Rpb24gcGFyYW1zQ29weSAodGVtcGxhdGVOYW1lKXtcclxuXHR0Yi50ZW1wbGF0ZSA9IGl0ZW1zRmluZEJ5VGVtcGxhdGUodGVtcGxhdGVOYW1lKTsgXHJcblx0dGIudGVtcGxhdGVpdGVtcyA9IHRiLnRlbXBsYXRlLnByb3AubWFwKGl0ZW0gPT4geyAgICAgICAgXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRuYW1lOiBpdGVtLm5hbWUsXHJcblx0XHRcdHR5cGU6IGl0ZW0udHlwZSxcclxuXHRcdFx0dXNhZ2U6IGl0ZW0udXNhZ2UsXHJcblx0XHRcdG51bWJlcmVkOiBpdGVtLm51bWJlcmVkLFxyXG5cdFx0XHRpbml0aWFsOiBpdGVtLmluaXRpYWwsXHJcblx0XHRcdGhlbHA6IGl0ZW0uaGVscCxcclxuXHRcdFx0ZXhhbXBsZTogaXRlbS5leGFtcGxlLFxyXG5cdFx0XHRncm91cDogaXRlbS5ncm91cCxcclxuXHRcdFx0dmFsdWVzOiBpdGVtLnZhbHVlcyB8fCBbXSwgXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fVxyXG5cdH0pXHJcblx0dGIudW5rbm93blBhcmFtcyA9ICcnXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcmFtc0Zyb21TZWxlY3Rpb24oKXtcclxuXHQvL2ZpbmRzIG1lbnUgaXRlbVxyXG4vLyAgICB2YXIgcGFyYW1zID0gdGIudGV4dFNlbGVjdGVkLnNwbGl0KC8uKj9cXHxcXHMqKFtee31bXFxdfF0qPyg/OlxcW1xcW1tee31bXFxdfF0qPyg/OlxcfFtee31bXFxdfF0qPykqP1tee31bXFxdfF0qP1xcXVxcXVtee31bXFxdfF0qP3xcXHtcXHtbXnt9W1xcXXxdKj8oPzpcXHxbXnt9W1xcXXxdKj8pKj9bXnt9W1xcXXxdKj9cXH1cXH1bXnt9W1xcXXxdKj8pKj9bXnt9W1xcXXxdKj8pXFxzKig/Oig/PVxcfCl8fX0pL2cpLm1hcChwYXIgPT4gcGFyLnRyaW0oKSkuZmlsdGVyKHBhciA9PiBwYXIgIT0gJycpO1xyXG5cdHZhciBwYXJhbXMgPSB0Yi50ZXh0U2VsZWN0ZWQuc3BsaXQoL1xcfFxccyooW157fVtcXF18XSo/KD86XFxbXFxbW157fVtcXF18XSo/KD86XFx8W157fVtcXF18XSo/KSo/W157fVtcXF18XSo/XFxdXFxdW157fVtcXF18XSo/fFxce1xce1tee31bXFxdfF0qPyg/OlxcfFtee31bXFxdfF0qPykqP1tee31bXFxdfF0qP1xcfVxcfVtee31bXFxdfF0qPykqP1tee31bXFxdfF0qPylcXHMqKD86KD89XFx8KXx9fSkvZykubWFwKHBhciA9PiBwYXIudHJpbSgpKS5maWx0ZXIocGFyID0+IHBhciAhPSAnJyk7XHJcblx0dGIudGV4dFNlbGVjdGVkID0gdGIudGV4dFNlbGVjdGVkLnJlcGxhY2UoJ3t7JywgJycpLnJlcGxhY2UoJ319JywgJycpO1xyXG5cdHBhcmFtc1swXSA9IHBhcmFtc1swXS5yZXBsYWNlKCd7eycsICcnKS5yZXBsYWNlKCd9fScsICcnKS5yZXBsYWNlKCdfJywgJyAnKVxyXG5cdHRiLnRlbXBsYXRlID0gaXRlbXNGaW5kQnlUZW1wbGF0ZShwYXJhbXNbMF0pOyBcclxuXHRpZiAodGIudGVtcGxhdGUpIHtcclxuXHRcdHBhcmFtcy5zcGxpY2UoMCwgMSk7XHJcblx0XHR2YXIgcGFyYW1zTnVtYmVyZWQgPSBwYXJhbXMuZmlsdGVyKHBhciA9PiAhKHBhci5pbmNsdWRlcygnPScpKSk7XHJcblx0XHR2YXIgcGFyYW1zTmFtZWQgPSBwYXJhbXMuZmlsdGVyKHBhciA9PiBwYXIuaW5jbHVkZXMoJz0nKSkubWFwKGl0ZW0gPT4gaXRlbS5zcGxpdChcIj1cIikubWFwKHBhciA9PiBwYXIudHJpbSgpKSk7XHJcblx0XHR0Yi50ZW1wbGF0ZWl0ZW1zID0gdGIudGVtcGxhdGUucHJvcC5tYXAoaXRlbSA9PiB7XHJcblx0XHRcdHZhciB4O1xyXG5cdFx0XHRpZiAoaXRlbS5udW1iZXJlZCkge1xyXG5cdFx0XHRcdHggPSBwYXJhbXNOdW1iZXJlZFtpdGVtLm51bWJlcmVkLTFdXHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0eCA9IHBhcmFtc05hbWVkLmZpbHRlcihwYXIgPT4gcGFyWzBdLnRvVXBwZXJDYXNlKCkgPT09IGl0ZW0ubmFtZS50b1VwcGVyQ2FzZSgpKS5tYXAocGFyID0+IHBhclsxXSkuam9pbignJyk7XHJcblx0XHRcdH07XHJcblx0XHRcdGlmICgheCkge3ggPSAnJ307XHJcblx0XHRcdHJldHVybiB7XHJcblx0XHRcdFx0bmFtZTogaXRlbS5uYW1lLFxyXG5cdFx0XHRcdHR5cGU6IGl0ZW0udHlwZSxcclxuXHRcdFx0XHR1c2FnZTogaXRlbS51c2FnZSxcclxuXHRcdFx0XHRudW1iZXJlZDogaXRlbS5udW1iZXJlZCxcclxuXHRcdFx0XHRpbml0aWFsOiBpdGVtLmluaXRpYWwsXHJcblx0XHRcdFx0aGVscDogaXRlbS5oZWxwLFxyXG5cdFx0XHRcdGV4YW1wbGU6IGl0ZW0uZXhhbXBsZSxcclxuXHRcdFx0XHRncm91cDogaXRlbS5ncm91cCwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG5cdFx0XHRcdHZhbHVlczogaXRlbS52YWx1ZXMgfHwgW10sIFxyXG5cdFx0XHRcdHZhbHVlOiB4LnRyaW0oKVxyXG5cdFx0XHR9ICAgICAgICAgICAgXHJcblx0XHR9KVxyXG5cdFx0dmFyIHVua25vd25OYW1lZCA9IHBhcmFtc05hbWVkLmZpbHRlcihwYXIgPT4gIUJvb2xlYW4odGIudGVtcGxhdGVpdGVtcy5maW5kKHRpID0+IHRpLm5hbWUudG9VcHBlckNhc2UoKSA9PT0gcGFyWzBdLnRvVXBwZXJDYXNlKCkpKSkgICAgICAgIFxyXG5cdFx0dmFyIHVua25vd25OdW1iZXJlZCA9IHBhcmFtc051bWJlcmVkLmZpbHRlcigocGFyLCBpKSA9PiAhQm9vbGVhbih0Yi50ZW1wbGF0ZWl0ZW1zLmZpbmQodGkgPT4gdGkubnVtYmVyZWQgPT09IGkrMSkpKVxyXG5cdFx0dGIudW5rbm93blBhcmFtcyA9IHVua25vd25OYW1lZC5tYXAoaSA9PiAnfCcgKyBpWzBdICsgJz0gJyArIGlbMV0pLmNvbmNhdCh1bmtub3duTnVtYmVyZWQubWFwKGkgPT4gJ3wnICsgaSkpLmpvaW4oJ1xcbicpXHJcblx0fSBlbHNlIHtcclxuXHRcdGFsZXJ0ICgnVGVtcGxhdGUgXCInICsgcGFyYW1zWzBdICsgJ1wiIGlzIG5vdCByZWNvZ25pc2VkIGJ5IHRoZSBleHRlbnNpb24nKVxyXG5cdH0gICBcclxufTtcclxuXHJcbmZ1bmN0aW9uIHBhcmFtc0luaXRpYWxWYWx1ZXMgKCl7XHJcblx0aWYgKHRiLnRlbXBsYXRlaXRlbXMgJiYgdGIudGVtcGxhdGVpdGVtcy5sZW5ndGgpIHtcclxuXHRcdGZvciAobGV0IHByb3Agb2YgdGIudGVtcGxhdGVpdGVtcykge1xyXG5cdFx0XHRpZiAocHJvcC52YWx1ZSA9PT0gJycgJiYgcHJvcC5pbml0aWFsKSB7XHJcblx0XHRcdFx0aWYgKHByb3AuaW5pdGlhbC5zdGFydHNXaXRoKFwiVGl0bGU6XCIpKSB7XHJcblx0XHRcdFx0XHRwcm9wLnZhbHVlID0gZG9jdW1lbnQudGl0bGUucmVwbGFjZShSZWdFeHAocHJvcC5pbml0aWFsLnN1YnN0cmluZyg2KSksICckMScpO1xyXG5cdFx0XHRcdH0gICAgXHJcblx0XHRcdFx0aWYgKHByb3AuaW5pdGlhbC5zdGFydHNXaXRoKFwiQ2F0ZWdvcnk6XCIpICYmICh0Yi5jYXRlZ29yaWVzKSkge1xyXG5cdFx0XHRcdFx0dmFyIHIgPSBSZWdFeHAocHJvcC5pbml0aWFsLnN1YnN0cmluZyg5KSwgJ21nJylcclxuXHRcdFx0XHRcdHZhciBhID0gdGIuY2F0ZWdvcmllcy5tYXRjaChyKVxyXG5cdFx0XHRcdFx0cHJvcC52YWx1ZSA9ICgoYSkgPyBhLmpvaW4oJ1xcbicpLnJlcGxhY2UociwgJyQxJykgOiAnJyApXHJcblx0XHRcdFx0fSAgICBcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVmb3JtYXRDb29ydG9VUkwgKHMpIHtcclxuXHRyZXR1cm4gJ2h0dHBzOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnLyNtYXA9MTgvJyArIHMucmVwbGFjZSAoJywnLCAnLycpLnJlcGxhY2UgKCclMjAnLCAnJylcclxufVxyXG5cclxuZnVuY3Rpb24gcmVmb3JtYXRVUkx0b0Nvb3IgKHMpIHtcclxuXHRpZiAocy5tYXRjaCAoIC9eICpbXFxkXSogKsKwICpbXFxkXSogKlvigLInXSAqKFtcXGQuXSogKlvigLPigJ1cIl0pPyAqW05TXVssIF0qW1xcZF0qICrCsCAqW1xcZF0qICpb4oCyJ10gKihbXFxkLl0qICpb4oCz4oCdXCJdKT8gKltFV10gKiQvbWdpKSkge1xyXG5cdFx0Ly8gMzLCsDQyJzE2LjAyXCJOLCAxN8KwOCcwLjY3XCJXXHJcblx0XHRsZXQgczEgPSBzLnJlcGxhY2UoXHJcblx0XHRcdC9eICooW1xcZF17MSwyfSkgKsKwICooW1xcZF17MSwyfSkgKlvigLInXSAqKChbXFxkLl17MSw1fSkgKlvigLPigJ1cIl0pPyAqKFtOU10pWywgXSooW1xcZF17MSwzfSkgKsKwICooW1xcZF17MSwyfSkgKlvigLInXSAqKChbXFxkLl17MSw1fSkgKlvigLPigJ1cIl0pPyAqKFtFV10pICokL21naSxcclxuXHRcdFx0JyQxOyQyOyQ0OyQ1OyQ2OyQ3OyQ5OyQxMCcpXHJcblx0XHRsZXQgYXJyID0gczEuc3BsaXQoJzsnKVxyXG5cdFx0dmFyIGxvbiwgbGF0XHJcblx0XHRsYXQgPSAoYXJyWzNdID09ICdTJyA/IC0xIDogMSkgKiAoTnVtYmVyKGFyclswXSkgKyBOdW1iZXIoYXJyWzFdKSAvIDYwICsgTnVtYmVyKGFyclsyXSkgLyAzNjAwKVxyXG5cdFx0bG9uID0gKGFycls3XSA9PSAnVycgPyAtMSA6IDEpICogKE51bWJlcihhcnJbNF0pICsgTnVtYmVyKGFycls1XSkgLyA2MCArIE51bWJlcihhcnJbNl0pIC8gMzYwMClcclxuXHRcdHJldHVybiBwYXJzZUZsb2F0KGxhdC50b0ZpeGVkKDYpKSArICcsICcgKyBwYXJzZUZsb2F0KGxvbi50b0ZpeGVkKDYpKVxyXG5cdH0gZWxzZSBpZiAocy5tYXRjaCAoL15odHRwczpcXC9cXC93d3dcXC5vcGVuc3RyZWV0bWFwXFwub3JnXFwvI21hcD1bXFxkXSpcXC9bXFxkLi1dKlxcL1tcXGQuLV0qJC9tZ2kpKSB7XHJcblx0XHQvLyBodHRwczovL3d3dy5vcGVuc3RyZWV0bWFwLm9yZy8jbWFwPTE1LzMyLjcwNTEvLTE3LjEyMjBcclxuXHRcdGxldCBzMSA9IHMucmVwbGFjZShcclxuXHRcdFx0L15odHRwczpcXC9cXC93d3dcXC5vcGVuc3RyZWV0bWFwXFwub3JnXFwvI21hcD1bXFxkXXsxLDJ9XFwvKFtcXGQuLV0qKVxcLyhbXFxkLi1dKikkL21naSxcclxuXHRcdFx0JyQxLCAkMicpXHJcblx0XHRyZXR1cm4gczFcclxuXHR9IGVsc2UgeyAgXHJcblx0XHRyZXR1cm4gcy5yZXBsYWNlICgnLycsICcsICcpXHJcblx0fVxyXG59XHJcblxyXG5mdW5jdGlvbiByZWZvcm1hdFRleHR0b1dpa2kgKHMpIHtcclxuXHRyZXR1cm4gcy5yZXBsYWNlICgvIC9nLCAnXycpO1xyXG59XHJcblxyXG5mdW5jdGlvbiByZWZvcm1hdFdpa2l0b1RleHQgIChzKSB7XHJcblx0cmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudCAocy5yZXBsYWNlICgvXy9nLCAnICcpKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0TnVtYmVydG9TbGFzaCAgKHMpIHtcclxuXHRyZXR1cm4gcy5yZXBsYWNlICgvKFxcZCopXFwvLiovZywgJyQxJyk7XHJcbn1cclxuXHJcbmNvbnN0IHVybE1hcHBpbmdzID0gW1xyXG5cdHt0eXBlOiBcIlwiLCBwbGFjZWhvbGRlcjpcIlVuZGVmaW5lZCB0eXBlXCJ9LFxyXG5cdHt0eXBlOiBcInR5cGVUZXh0XCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgdGV4dFwifSxcclxuXHR7dHlwZTogXCJ0eXBlTnVtYmVyXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgYSBudW1iZXJcIn0sXHJcblx0e3R5cGU6IFwidHlwZVllYXJcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciB5ZWFyXCJ9LFxyXG5cdHt0eXBlOiBcInR5cGVZZXNcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciB5ZXNcIn0sXHJcblx0e3R5cGU6IFwidHlwZU5vXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgbm9cIn0sXHJcblx0e3R5cGU6IFwidHlwZVVSTFwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFVSTCBodHRwczovLy4uLlwiLCBwcmVmaXhVUkw6JycsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJ30sXHJcblx0e3R5cGU6IFwidHlwZVdpa2l0cmVlSURcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBwcm9maWxlJ3MgV2lraXRyZWVJRFwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpLycsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJywgdG9VUkw6cmVmb3JtYXRUZXh0dG9XaWtpLCBmcm9tVVJMOnJlZm9ybWF0V2lraXRvVGV4dH0sXHJcblx0e3R5cGU6IFwidHlwZVBhZ2VcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBQYWdlIG5hbWUgd2l0aCBOYW1lc3BhY2VcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS8nLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6JycsIHRvVVJMOnJlZm9ybWF0VGV4dHRvV2lraSwgZnJvbVVSTDpyZWZvcm1hdFdpa2l0b1RleHR9LFxyXG5cdHt0eXBlOiBcInR5cGVDYXRlZ29yeVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIENhdGVnb3J5IG9uIFdpa2lUcmVlXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvQ2F0ZWdvcnk6Jywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnLCB0b1VSTDpyZWZvcm1hdFRleHR0b1dpa2ksIGZyb21VUkw6cmVmb3JtYXRXaWtpdG9UZXh0fSxcclxuXHR7dHlwZTogXCJ0eXBlUHJvamVjdE5lZWRzQ2F0ZWdvcnlcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBQcm9qZWN0IE5lZWRzIGNhdGVnb3J5XCIsIHByZWZpeFVSTDonJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnfSxcclxuXHR7dHlwZTogXCJ0eXBlUHJvamVjdFwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFByb2plY3Qgb24gV2lraVRyZWVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9Qcm9qZWN0OicsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJywgdG9VUkw6cmVmb3JtYXRUZXh0dG9XaWtpLCBmcm9tVVJMOnJlZm9ybWF0V2lraXRvVGV4dH0sXHJcblx0e3R5cGU6IFwidHlwZVRlYW1cIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBUZWFtIG9mIHRoZSBwcm9qZWN0IG9uIFdpa2lUcmVlXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvU3BhY2U6Jywgc3VmaXhVUkw6JyBUZWFtJywgZW1wdHlVUkw6JycsIHRvVVJMOnJlZm9ybWF0VGV4dHRvV2lraSwgZnJvbVVSTDpyZWZvcm1hdFdpa2l0b1RleHR9LFxyXG5cdHt0eXBlOiBcInR5cGVTcGFjZVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFNwYWNlIHBhZ2Ugb24gV2lraVRyZWVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9TcGFjZTonLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6JycsIHRvVVJMOnJlZm9ybWF0VGV4dHRvV2lraSwgZnJvbVVSTDpyZWZvcm1hdFdpa2l0b1RleHR9LFxyXG5cdHt0eXBlOiBcInR5cGVJbWFnZVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIEltYWdlIG5hbWVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9JbWFnZTonLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6JycsIHRvVVJMOnJlZm9ybWF0VGV4dHRvV2lraSwgZnJvbVVSTDpyZWZvcm1hdFdpa2l0b1RleHR9LFxyXG5cdHt0eXBlOiBcInR5cGVHMkdcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBxdWVzdGlvbiBJRFwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9nMmcvJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnLCBmcm9tVVJMOmdldE51bWJlcnRvU2xhc2h9LFxyXG5cdHt0eXBlOiBcInR5cGVXaWtpVHJlZUJsb2dcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBibG9nIG5hbWVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vYmxvZy8nLCBzdWZpeFVSTDonLycsIGVtcHR5VVJMOicnfSxcclxuXHR7dHlwZTogXCJ0eXBlV2lraURhdGFcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBXaWtpRGF0YSBjb2RlXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cud2lraWRhdGEub3JnL3dpa2kvJywgc3VmaXhVUkw6Jyd9LFxyXG5cdHt0eXBlOiBcInR5cGVZb3VUdWJlXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgWW91VHViZSBjb2RlXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj0nLCBzdWZpeFVSTDonJ30sXHJcblx0e3R5cGU6IFwidHlwZUZBR0lEXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgRmluZEFHcmF2ZSBJRFwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3LmZpbmRhZ3JhdmUuY29tL21lbW9yaWFsLycsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJywgZnJvbVVSTDpnZXROdW1iZXJ0b1NsYXNofSxcclxuXHR7dHlwZTogXCJ0eXBlRkFHQ2VtSURcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBGaW5kQUdyYXZlIENlbWV0ZXJ5IElEXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cuZmluZGFncmF2ZS5jb20vY2VtZXRlcnkvJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnLCBmcm9tVVJMOmdldE51bWJlcnRvU2xhc2h9LFxyXG5cdHt0eXBlOiBcInR5cGVGQUdMb2NJRFwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIEZpbmRBR3JhdmUgTG9jYXRpb24gSURcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy5maW5kYWdyYXZlLmNvbS9jZW1ldGVyeS9zZWFyY2g/bG9jYXRpb25JZD0nfSxcclxuXHR7dHlwZTogXCJ0eXBlQkdJRFwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIEJpbGxpb25HcmF2ZXMgSURcIiwgcHJlZml4VVJMOidodHRwczovL2JpbGxpb25ncmF2ZXMuY29tL2NlbWV0ZXJ5L0NlbWV0ZXJ5LycsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonaHR0cHM6Ly9iaWxsaW9uZ3JhdmVzLmNvbS8nfSxcclxuXHR7dHlwZTogXCJ0eXBlQ29vclwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIGNvb3JkaW5hdGUgMTUuMTIzLCAtMzMuMjEzXCIsIHByZWZpeFVSTDonJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOidodHRwczovL3d3dy5vcGVuc3RyZWV0bWFwLm9yZy8nLCB0b1VSTDpyZWZvcm1hdENvb3J0b1VSTCwgZnJvbVVSTDpyZWZvcm1hdFVSTHRvQ29vcn0sXHJcblx0e3R5cGU6IFwidHlwZVRPQ1wiLCBwbGFjZWhvbGRlcjpcIk5vdCBlbm91Z2ggcHJmaWxlc1wifSxcclxuXHR7dHlwZTogXCJ0eXBlUmVhZE9ubHlcIn0sXHJcbl07XHJcblxyXG4vKiBTZXR0aW5nIHJlc3VsdCAqL1xyXG5cclxuZnVuY3Rpb24gdXBkYXRlRWRpdCAoKXtcclxuXHRpZiAodGIuZWxFbmhhbmNlZEFjdGl2ZSkge1xyXG5cdFx0dGIuZWxFbmhhbmNlZC5jbGljaygpO1xyXG5cdH1cclxuXHR0Yi5lbFRleHQudmFsdWUgPSB0Yi50ZXh0UmVzdWx0O1xyXG5cdGlmICh0Yi5lbEVuaGFuY2VkQWN0aXZlKSB7XHJcblx0XHR0Yi5lbEVuaGFuY2VkLmNsaWNrKCk7XHJcblx0fVxyXG5cdHRiLmVsVGV4dC5zZXRTZWxlY3Rpb25SYW5nZSh0Yi5zZWxTdGFydCwgdGIuc2VsRW5kKTtcclxuXHJcblx0aWYgKHRiLmJpcnRoTG9jYXRpb25SZXN1bHQpIHtcclxuXHRcdHRiLmVsQmlydGhMb2NhdGlvbi52YWx1ZSA9IHRiLmJpcnRoTG9jYXRpb25SZXN1bHRcclxuXHR9XHJcblx0aWYgKHRiLmRlYXRoTG9jYXRpb25SZXN1bHQpIHtcclxuXHRcdHRiLmVsRGVhdGhMb2NhdGlvbi52YWx1ZSA9IHRiLmRlYXRoTG9jYXRpb25SZXN1bHRcclxuXHR9XHJcblxyXG5cdGlmICh0Yi5lbFN1bW1hcnkpIHtcclxuXHRcdHRiLmVsU3VtbWFyeS5mb2N1cygpO1xyXG5cdFx0dmFyIHMgPSB0Yi5lbFN1bW1hcnkudmFsdWU7XHJcblx0XHRpZiAocykge1xyXG5cdFx0XHRpZiAocy5pbmRleE9mKHRiLmFkZFRvU3VtbWFyeSkgPT0gLTEpIHtcclxuXHRcdFx0XHRzICs9ICcsICcgKyB0Yi5hZGRUb1N1bW1hcnlcclxuXHRcdFx0fVxyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0cyA9IHRiLmFkZFRvU3VtbWFyeVxyXG5cdFx0fTtcclxuXHRcdHRiLmVsU3VtbWFyeS52YWx1ZSA9IHM7XHJcblx0fVxyXG5cdHRiLmVsVGV4dC5mb2N1cygpO1xyXG5cdHRiLmFkZFRvU3VtbWFyeSA9ICcnXHJcblxyXG5cdC8vIExldCB0aGUgcGFnZSBrbm93IHRoYXQgY2hhbmdlcyBoYXZlIGJlZW4gbWFkZSBzbyB0aGF0IHRoZSBcIlNhdmUgQ2hhbmdlc1wiIGJ1dHRvbiB3b3Jrc1xyXG4vLyAgICBpZiAoXCJjcmVhdGVFdmVudFwiIGluIGRvY3VtZW50KSB7XHJcblx0dmFyIGV2dCA9IGRvY3VtZW50LmNyZWF0ZUV2ZW50KFwiSFRNTEV2ZW50c1wiKTtcclxuXHRldnQuaW5pdEV2ZW50KFwiY2hhbmdlXCIsIGZhbHNlLCB0cnVlKTtcclxuXHR0Yi5lbFRleHQuZGlzcGF0Y2hFdmVudChldnQpO1xyXG4vLyAgICAgIH0gZWxzZSB7XHJcbi8vICAgICAgICB0ZXh0Ym94LmZpcmVFdmVudChcIm9uY2hhbmdlXCIpO1xyXG4vLyAgICAgIH1cclxufVxyXG5cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuLyogZWRpdCBUZW1wbGF0ZSAgICAgICAgICAqL1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5mdW5jdGlvbiBlZGl0VGVtcGxhdGUgKHN1bW1hcnlQcmVmaXgpe1xyXG5cdGlmICh0Yi50ZW1wbGF0ZSkge1xyXG5cdFx0dmFyIGdyb3VwLCBncm91cEV4cGFuZGVkIFxyXG5cdFx0dGIuZWxEbGcuaW5uZXJIVE1MID0gXHJcblx0XHRcdCc8aDMgc3R5bGU9XCJtYXJnaW46IDAgMCAwIDEwcHg7XCI+RWRpdGluZyAnICsgJzxhIGhyZWY9XCIvd2lraS9UZW1wbGF0ZTonICsgdGIudGVtcGxhdGUubmFtZSArICdcIiB0YXJnZXQ9XCJfYmxhbmtcIj5UZW1wbGF0ZTonICsgdGIudGVtcGxhdGUubmFtZSArICc8L2E+PC9oMz4nICsgXHJcblx0XHRcdCc8dGFibGUgc3R5bGU9XCJtYXJnaW4tYm90dG9tOiAxMHB4O1wiPjx0cj48dGQgc3R5bGU9XCJ3aGl0ZS1zcGFjZTogbm93cmFwO3BhZGRpbmctcmlnaHQ6IDEwcHg7XCI+JyArXHJcblx0XHRcdCh0Yi50ZW1wbGF0ZS50eXBlID8gJ1R5cGU6IDxiPicgKyB0Yi50ZW1wbGF0ZS50eXBlICsgJzwvYj48YnI+JyA6ICcnKSArIFxyXG5cdFx0XHQodGIudGVtcGxhdGUuZ3JvdXAgPyAnR3JvdXA6IDxiPicgKyB0Yi50ZW1wbGF0ZS5ncm91cCArICc8L2I+PGJyPicgOiAnJykgKyBcclxuXHRcdFx0KHRiLnRlbXBsYXRlLnN1Ymdyb3VwID8gJ1N1Ykdyb3VwOiA8Yj4nICsgdGIudGVtcGxhdGUuc3ViZ3JvdXAgKyAnPC9iPicgOiAnJykgKyBcclxuXHRcdFx0JzwvdGQ+PHRkPicgKyB0Yi50ZW1wbGF0ZS5oZWxwICsgJzwvdGQ+PC90cj48L3RhYmxlPicgKyBcclxuXHRcdFx0JzxkaXYgaWQ9XCJ3dFBsdXNEbGdQYXJhbXNcIj4nK1xyXG5cdFx0XHQnPHRhYmxlIHN0eWxlPVwid2lkdGg6IDEwMCU7XCI+JyArIFxyXG5cdFx0XHR0Yi50ZW1wbGF0ZWl0ZW1zLm1hcCgoaXRlbSwgaSkgPT4ge1xyXG5cdFx0XHRcdHZhciBpdGVtRGVmID0gdXJsTWFwcGluZ3MuZmlsdGVyKGE9PmEudHlwZSA9PSBpdGVtLnR5cGUpWzBdIFxyXG5cdFx0XHRcdGlmICghaXRlbURlZikge1xyXG5cdFx0XHRcdFx0Y29uc29sZS5sb2coJ01pc3NpbmcgJyArIGl0ZW0udHlwZSArICcgdHlwZScpIFxyXG5cdFx0XHRcdFx0aXRlbURlZiA9IHVybE1hcHBpbmdzWzBdO1xyXG5cdFx0XHRcdH07XHJcblx0XHRcdFx0Ly8gU2V0cyBUT0MgcGFyYW1ldGVyXHJcblx0XHRcdFx0aWYgKGl0ZW0udHlwZSA9PT0gXCJ0eXBlVE9DXCIpIHtcclxuXHRcdFx0XHRcdHZhciBoYXNfbGluayA9IFtdLnNvbWUuY2FsbChkb2N1bWVudC5saW5rcywgZnVuY3Rpb24obGluaykge1xyXG5cdFx0XHRcdFx0XHRyZXR1cm4gbGluay5pbm5lckhUTUwuZW5kc1dpdGgoJyAyMDAnKTtcclxuXHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdFx0aXRlbS52YWx1ZSA9IChoYXNfbGluaykgPyAneWVzJzogJydcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0dmFyIHggPSAnJ1xyXG5cdFx0XHRcdC8vIEdyb3VwXHJcblx0XHRcdFx0aWYgKGl0ZW0uZ3JvdXAgIT09IGdyb3VwKSB7XHJcblx0XHRcdFx0XHRpZiAoaXRlbS5ncm91cCkge1xyXG5cdFx0XHRcdFx0XHRncm91cEV4cGFuZGVkID0gQm9vbGVhbiAodGIudGVtcGxhdGVpdGVtcy5maW5kKGE9PiBhLmdyb3VwID09IGl0ZW0uZ3JvdXAgJiYgYS52YWx1ZSkpIFxyXG5cdFx0XHRcdFx0XHR4ICs9ICc8dHIgY2xhc3M9XCJ3dFBsdXMnICsgaXRlbS5ncm91cCArICdcIj48dGQgY29sc3Bhbj1cIjJcIj48bGFiZWw+JyArIGl0ZW0uZ3JvdXAgKyAnOjwvbGFiZWw+PC90ZD48dGQ+JyArIFxyXG5cdFx0XHRcdFx0XHRcdCc8YnV0dG9uIGlkPVwiZ3JvdXBCdG4nICsgaXRlbS5ncm91cCArICdcIiB0aXRsZT1cIkV4cGFuZC9Db2xsYXBzZVwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdFZGl0VGVtcGxhdGVFeHBDb2xcIiBkYXRhLWlkPVwiJyArIGl0ZW0uZ3JvdXAgKyAnXCI+JyArIFxyXG5cdFx0XHRcdFx0XHRcdChncm91cEV4cGFuZGVkID8gJ0NvbGxhcHNlJyA6ICdFeHBhbmQnKSArICc8L2J1dHRvbj48L3RkPjx0ZCBjb2xzcGFuPVwiM1wiPjwvdGQ+PC90cj4nIFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0Z3JvdXAgPSBpdGVtLmdyb3VwXHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHggICs9ICc8dHIgY2xhc3M9XCJ3dFBsdXMnICsgaXRlbS51c2FnZSArIChpdGVtLmdyb3VwID8gJyBncm91cCcgKyBpdGVtLmdyb3VwICsgJ1wiICcgKyAoZ3JvdXBFeHBhbmRlZCA/ICcnIDogJ3N0eWxlPVwidmlzaWJpbGl0eTogY29sbGFwc2U7JykgOiAnJyApICsgJ1wiPic7XHJcblx0XHRcdFx0Ly8gTmFtZVxyXG5cdFx0XHRcdHggKz0gJzx0ZD48bGFiZWw+JyArIGl0ZW0ubmFtZSArICc6PC9sYWJlbD48L3RkPicgXHJcblx0XHRcdFx0Ly8gSGVscFxyXG5cdFx0XHRcdHggKz0gJzx0ZD4nICsgKGl0ZW0uaGVscCA/IFxyXG5cdFx0XHRcdFx0JzxpbWcgc3JjPVwiL2ltYWdlcy9pY29ucy9oZWxwLmdpZlwiIGJvcmRlcj1cIjBcIiB3aWR0aD1cIjIyXCIgaGVpZ2h0PVwiMjJcIiBhbHQ9XCJIZWxwXCIgdGl0bGU9XCJVc2FnZTogJyArIGl0ZW0udXNhZ2UgKyAnXFxuJyArIGl0ZW0uaGVscCArIChpdGVtLmV4YW1wbGUgPyAnXFxuRXhhbXBsZTogJyArIGl0ZW0uZXhhbXBsZSA6ICcnICkgKyAnXCIgLz4nOiAnJykgKyAnPC90ZD4nO1xyXG5cdFx0XHRcdC8vIElucHV0XHJcblx0XHRcdFx0eCArPSAnPHRkPjxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJ3dHBhcmFtJyArIGkgKyAnXCIgY2xhc3M9XCJkbGdQYXN0ZScgKyAvKigoaXRlbS50eXBlID09PSBcInR5cGVDYXRlZ29yeVwiKSA/ICcgZGxnQ2F0JyA6ICcnICkgKyAqLydcIiAnICtcclxuXHRcdFx0XHRcdCAnZGF0YS1vcD1cIm9uRGxnRWRpdFRlbXBsYXRlUGFzdGVcIiBkYXRhLWlkPVwiJyArIGkgKyAnXCIgdmFsdWU9XCInICsgaXRlbS52YWx1ZSArICdcIiAnO1xyXG5cdFx0XHRcdHggKz0gJ3BsYWNlaG9sZGVyPVwiJyArIGl0ZW1EZWYucGxhY2Vob2xkZXIgKyAnXCIgJ1xyXG5cdFx0XHRcdHggKz0gJ2xpc3Q9XCJ3dFBsdXNBdXRvQ29tcGxldGUnICsgaSArICdcIiAnXHJcblx0XHRcdFx0aWYgKChpdGVtLnR5cGUgPT09IFwidHlwZVJlYWRPbmx5XCIpIHx8IChpdGVtLnR5cGUgPT09IFwidHlwZVRPQ1wiKSkge1xyXG5cdFx0XHRcdFx0eCArPSAncmVhZG9ubHkgJ1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZiAoaSA9PT0gMCkge1xyXG5cdFx0XHRcdFx0eCArPSAnYXV0b2ZvY3VzICdcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0eCArPSAnLz48ZGF0YWxpc3QgaWQ9XCJ3dFBsdXNBdXRvQ29tcGxldGUnICsgaSArICdcIj4nIFxyXG5cdFx0XHRcdHggKz0gaXRlbS52YWx1ZXMubWFwKGl0ZW0gPT4gJzxvcHRpb24gdmFsdWU9XCInICsgaXRlbSArICdcIi8+JyApLmpvaW4oJ1xcbicpXHJcblx0XHRcdFx0eCArPSc8L2RhdGFsaXN0PjwvdGQ+JztcclxuXHRcdFx0XHQvL0J1dHRvbnNcclxuXHRcdFx0XHR4ICs9Jzx0ZD4nICsgKChpdGVtLnR5cGUgIT0gXCJ0eXBlUmVhZE9ubHlcIikgJiYgKGl0ZW0udHlwZSAhPSBcInR5cGVUT0NcIikgPyBcclxuXHRcdFx0XHRcdCc8YnV0dG9uIHRpdGxlPVwiUmVzdG9yZSB2YWx1ZVwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdFZGl0VGVtcGxhdGVSZXN0b3JlXCIgZGF0YS1pZD1cIicgKyBpICsgJ1wiIHRhYmluZGV4PVwiLTFcIj5SPC9idXR0b24+JyA6ICcnKSArICc8L3RkPicgXHJcblx0XHRcdFx0eCArPSc8dGQ+JyArICgoaXRlbS5pbml0aWFsKSA/IFxyXG5cdFx0XHRcdFx0JzxidXR0b24gdGl0bGU9XCJBdXRvIHZhbHVlXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ0VkaXRUZW1wbGF0ZUluaXRpYWxcIiBkYXRhLWlkPVwiJyArIGkgKyAnXCIgdGFiaW5kZXg9XCItMVwiPkE8L2J1dHRvbj4nIDogJycpICsgJzwvdGQ+JyBcclxuXHRcdFx0XHR4ICs9Jzx0ZD4nICsgKCh1cmxNYXBwaW5ncy5maWx0ZXIoYT0+YS5wcmVmaXhVUkwgIT09IHVuZGVmaW5lZCkubWFwKGE9PmEudHlwZSkuaW5jbHVkZXMoaXRlbS50eXBlKSkgPyBcclxuXHRcdFx0XHRcdCc8YnV0dG9uIHRpdGxlPVwiT3BlbiBsaW5rXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ0VkaXRUZW1wbGF0ZUZvbGxvd1wiIGRhdGEtaWQ9XCInICsgaSArICdcIiB0YWJpbmRleD1cIi0xXCI+TzwvYnV0dG9uPicgOiAnJykgKyAnPC90ZD4nIFxyXG5cdFx0XHRcdHggKz0nPC90cj4nO1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdHJldHVybiB4XHJcblx0XHRcdH0pLmpvaW4oJycpICsgXHJcblx0XHRcdCc8L3RhYmxlPicgK1xyXG5cdFx0XHQnPC9kaXY+JyArXHJcblx0XHRcdCc8ZGl2IHN0eWxlPVwiZGlzcGxheTpmbGV4XCI+JysgICAgICAgIFxyXG5cdFx0XHQvL0xlZ2VuZFxyXG5cdFx0XHQnPGJ1dHRvbiBpZD1cInd0UGx1c0xlZ2VuZEJ0blwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdOb25lXCIgdGFiaW5kZXg9XCItMVwiPkxlZ2VuZCcrXHJcblx0XHRcdCc8dGFibGUgY2xhc3M9XCJ3dFBsdXNMZWdlbmRcIj4nICsgXHJcblx0XHRcdCc8dHI+PHRkIGNvbHNwYW49XCIyXCIgY2xhc3M9XCJ3dFBsdXNSZXF1aXJlZFwiPlJlcXVpcmVkPC90ZD48L3RyPicgK1xyXG5cdFx0XHQnPHRyPjx0ZCBjb2xzcGFuPVwiMlwiIGNsYXNzPVwid3RQbHVzUHJlZmVycmVkXCI+UHJlZmVycmVkPC90ZD48L3RyPicgK1xyXG5cdFx0XHQnPHRyPjx0ZCBjb2xzcGFuPVwiMlwiIGNsYXNzPVwid3RQbHVzT3B0aW9uYWxcIj5PcHRpb25hbDwvdGQ+PC90cj4nICtcclxuXHRcdFx0Jzx0cj48dGQ+PGltZyBzcmM9XCIvaW1hZ2VzL2ljb25zL2hlbHAuZ2lmXCIgYm9yZGVyPVwiMFwiIHdpZHRoPVwiMjJcIiBoZWlnaHQ9XCIyMlwiIGFsdD1cIkhlbHBcIiAvPjwvdGQ+PHRkPkhvd2VyIGZvciBoaW50PC90ZD48L3RyPicgK1xyXG5cdFx0XHQnPHRyPjx0ZD48YnV0dG9uIHRpdGxlPVwiUmVzdG9yZSB2YWx1ZVwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdOb25lXCI+UjwvYnV0dG9uPjwvdGQ+PHRkPlJlc3RvcmUgdmFsdWU8L3RkPjwvdHI+JyArXHJcblx0XHRcdCc8dHI+PHRkPjxidXR0b24gdGl0bGU9XCJBdXRvIHZhbHVlXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ05vbmVcIj5BPC9idXR0b24+PC90ZD48dGQ+QXV0byB2YWx1ZTwvdGQ+PC90cj4nICtcclxuXHRcdFx0Jzx0cj48dGQ+PGJ1dHRvbiB0aXRsZT1cIk9wZW4gbGlua1wiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdOb25lXCI+TzwvYnV0dG9uPjwvdGQ+PHRkPk9wZW4gbGluazwvdGQ+PC90cj4nICtcclxuXHRcdFx0JzwvdGFibGU+JyArXHJcblx0XHRcdCc8L2J1dHRvbj4nICtcclxuXHRcdFx0JzxkaXYgc3R5bGU9XCJmbGV4OjFcIj48L2Rpdj4nICtcclxuXHRcdFx0JzxhIGNsYXNzPVwiYnV0dG9uXCIgaHJlZj1cImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL1NwYWNlOldpa2lUcmVlX1BsdXNfQ2hyb21lX0V4dGVuc2lvbiNFZGl0X1RlbXBsYXRlXCIgdGFyZ2V0PVwiX2JsYW5rXCI+SGVscDwvYT4nICtcclxuXHRcdFx0Ly9PSywgQ2FuY2VsXHJcblx0XHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdFZGl0VGVtcGxhdGVCdG5cIiBkYXRhLWlkPVwiMFwiPkNsb3NlPC9idXR0b24+JyArXHJcblx0XHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdFZGl0VGVtcGxhdGVCdG5cIiBkYXRhLWlkPVwiMVwiIHZhbHVlPVwiZGVmYXVsdFwiPlVwZGF0ZSBjaGFuZ2VzPC9idXR0b24+JyArXHJcblx0XHRcdCc8L2Rpdj4nIFxyXG5cclxuXHRcdHRiLmVsRGxnUGFyYW1zID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ3dFBsdXNEbGdQYXJhbXNcIik7XHJcblx0XHRcdFx0ICBcclxuXHRcdGF0dGFjaEV2ZW50cygnYnV0dG9uLmRsZ0NsaWNrJywgJ2NsaWNrJylcclxuXHRcdGF0dGFjaEV2ZW50cygnaW5wdXQuZGxnUGFzdGUnLCAncGFzdGUnKVxyXG5cdFx0YXR0YWNoRXZlbnRzKCdpbnB1dC5kbGdQYXN0ZScsICdrZXlwcmVzcycpXHJcblx0XHRcclxuXHRcdHRiLmFkZFRvU3VtbWFyeSA9IHN1bW1hcnlQcmVmaXggKyBcIiBUZW1wbGF0ZTpcIiArIHRiLnRlbXBsYXRlLm5hbWU7XHJcblx0XHRpZiAodGIudW5rbm93blBhcmFtcykgXHJcblx0XHQgIGFsZXJ0KCdVbnJlY29nbml6ZWQgcGFyYW1ldGVyczpcXG4nICsgdGIudW5rbm93blBhcmFtcyArICdcXG5cXG5UaGV5IHdpbGwgYmUgcmVtb3ZlZCwgdW5sZXNzIHlvdSBjYW5jZWwuJylcclxuXHRcdHRiLmVsRGxnLnNob3dNb2RhbCgpO1xyXG5cdH0gICAgXHJcbn07XHJcbi8qXHJcblxyXG5cdGlmICgkKCcjYWRkQ2F0ZWdvcnlJbnB1dCcpLmxlbmd0aCkge1xyXG5cdFx0JCgnI2FkZENhdGVnb3J5SW5wdXQnKS5hdXRvQ29tcGxldGUoe1xyXG5cdFx0XHRjYWNoZTogZmFsc2UsXHJcblx0XHRcdHNvdXJjZTogZnVuY3Rpb24odGVybSwgc3VnZ2VzdCkge1xyXG5cdFx0XHRcdHd0Q2F0ZWdvcnlTdWdnZXN0aW9uKHRlcm0sIHN1Z2dlc3QpO1xyXG5cdFx0XHR9LFxyXG5cdFx0XHRyZW5kZXJJdGVtOiBmdW5jdGlvbihjYXRlZ29yeSwgc2VhcmNoKSB7XHJcblx0XHRcdFx0cmV0dXJuIHd0Q2F0ZWdvcnlTdWdnZXN0aW9uSXRlbVJlbmRlcihjYXRlZ29yeSwgc2VhcmNoKTtcclxuXHRcdFx0fSxcclxuXHRcdFx0b25TZWxlY3Q6IGZ1bmN0aW9uKGUsIHRlcm0sIGl0ZW0pIHtcclxuXHRcdFx0XHRjaGFuZ2VzTWFkZSA9IDE7XHJcblx0XHRcdFx0dmFyIGNhdGVnb3J5VGV4dCA9IFwiW1tDYXRlZ29yeTpcIiArIHRlcm0gKyBcIl1dXFxuXCI7XHJcblx0XHRcdFx0Y2F0ZWdvcnlUZXh0ID0gY2F0ZWdvcnlUZXh0LnJlcGxhY2UoL18vZywgJyAnKTtcclxuXHRcdFx0XHRpZiAoKHR5cGVvZiBjb2xvcmVkRWRpdG9yICE9PSAndW5kZWZpbmVkJykgJiYgKGNvbG9yZWRFZGl0b3IpKSB7XHJcblx0XHRcdFx0XHRjb2xvcmVkRWRpdG9yLnNldEN1cnNvcigwLCAwKTtcclxuXHRcdFx0XHRcdHZhciBjdXJzb3IgPSBjb2xvcmVkRWRpdG9yLmdldEN1cnNvcigpO1xyXG5cdFx0XHRcdFx0Y29sb3JlZEVkaXRvci5yZXBsYWNlUmFuZ2UoY2F0ZWdvcnlUZXh0LCBjdXJzb3IsIGN1cnNvcik7XHJcblx0XHRcdFx0XHRjb2xvcmVkRWRpdG9yLmZvY3VzKCk7XHJcblx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdHZhciB0ZXh0QXJlYSA9IGRvY3VtZW50LmVkaXRmb3JtLndwVGV4dGJveDE7XHJcblx0XHRcdFx0XHR2YXIgdGV4dFNjcm9sbCA9IHRleHRBcmVhLnNjcm9sbFRvcDtcclxuXHRcdFx0XHRcdHRleHRBcmVhLnZhbHVlID0gY2F0ZWdvcnlUZXh0ICsgdGV4dEFyZWEudmFsdWU7XHJcblx0XHRcdFx0XHR0ZXh0QXJlYS5zZWxlY3Rpb25TdGFydCA9IDA7XHJcblx0XHRcdFx0XHR0ZXh0QXJlYS5zZWxlY3Rpb25FbmQgPSBjYXRlZ29yeVRleHQubGVuZ3RoO1xyXG5cdFx0XHRcdFx0dGV4dEFyZWEuc2Nyb2xsVG9wID0gdGV4dFNjcm9sbDtcclxuXHRcdFx0XHRcdHRleHRBcmVhLmZvY3VzKCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdCQoJyNhZGRDYXRlZ29yeUlucHV0JykudmFsKCcnKS5oaWRlKCk7XHJcblx0XHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cdFx0XHRcdHJldHVybiBmYWxzZTtcclxuXHRcdFx0fSxcclxuXHRcdH0pO1xyXG5cdH1cclxufSk7XHJcbmZ1bmN0aW9uIHd0Q2F0ZWdvcnlTdWdnZXN0aW9uKHRlcm0sIHN1Z2dlc3QpIHtcclxuXHR2YXIgaW5jbHVkZUFsbCA9IDA7XHJcblx0aWYgKCQoJyNjYXRlZ29yeVN1Z2dlc3Rpb25JbmNsdWRlQWxsJykubGVuZ3RoICYmICQoJyNjYXRlZ29yeVN1Z2dlc3Rpb25JbmNsdWRlQWxsJykudmFsKCkpIHtcclxuXHRcdGluY2x1ZGVBbGwgPSAxO1xyXG5cdH1cclxuXHRzYWpheF9kb19jYWxsKFwiVGl0bGU6OmFqYXhDYXRlZ29yeVNlYXJjaFwiLCBbdGVybSwgaW5jbHVkZUFsbF0sIGZ1bmN0aW9uKHJlc3VsdCkge1xyXG5cdFx0dmFyIHN1Z2dlc3Rpb25zID0gSlNPTi5wYXJzZShyZXN1bHQucmVzcG9uc2VUZXh0KTtcclxuXHRcdHN1Z2dlc3Qoc3VnZ2VzdGlvbnMpO1xyXG5cdH0pO1xyXG59XHJcbmZ1bmN0aW9uIHd0Q2F0ZWdvcnlTdWdnZXN0aW9uSXRlbVJlbmRlcihpdGVtLCBzZWFyY2gpIHtcclxuXHRzZWFyY2ggPSBzZWFyY2gucmVwbGFjZSgvWy1cXC9cXFxcXiQqKz8uKCl8W1xcXXt9XS9nLCAnXFxcXCQmJyk7XHJcblx0dmFyIHJlID0gbmV3IFJlZ0V4cChcIihcIiArIHNlYXJjaC5zcGxpdCgnICcpLmpvaW4oJ3wnKSArIFwiKVwiLFwiZ2lcIik7XHJcblx0dmFyIGh0bWwgPSAnJztcclxuXHRodG1sICs9ICc8ZGl2IGNsYXNzPVwiYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25cIiBkYXRhLXZhbD1cIicgKyBpdGVtICsgJ1wiPic7XHJcblx0aHRtbCArPSBpdGVtLnJlcGxhY2UocmUsIFwiPGI+JDE8L2I+XCIpO1xyXG5cdGh0bWwgKz0gJzwvZGl2Pic7XHJcblx0cmV0dXJuIGh0bWw7XHJcbn1cclxuXHJcbiovXHJcbmZ1bmN0aW9uIG9uRGxnRWRpdFRlbXBsYXRlQnRuKHVwZGF0ZSkge1xyXG5cdHRiLmVsRGxnLmNsb3NlKCk7XHJcblx0aWYgKHVwZGF0ZT09PScxJykge1xyXG5cdFx0dmFyIGEgPSB0Yi5lbERsZ1BhcmFtcy5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dCcpO1xyXG5cdFx0Zm9yICh2YXIgaSBpbiB0Yi50ZW1wbGF0ZWl0ZW1zKSB7dGIudGVtcGxhdGVpdGVtc1tpXS52YWx1ZSA9IGFbaV0udmFsdWUudHJpbSgpfTtcclxuXHRcdHRiLmluc2VydHRleHQgPSAnJztcclxuXHRcdHZhciBsaW5lID0gJyc7XHJcblx0XHRpZiAodGIudGVtcGxhdGVpdGVtcyAmJiB0Yi50ZW1wbGF0ZWl0ZW1zLmxlbmd0aCkge1xyXG5cdFx0XHR2YXIgbGluZSA9ICdcXG4nO1xyXG5cdFx0XHRmb3IgKGxldCBwcm9wIG9mIHRiLnRlbXBsYXRlaXRlbXMpIHtcclxuXHRcdFx0XHRpZiAocHJvcC5udW1iZXJlZCkge1xyXG5cdFx0XHRcdFx0bGluZSA9ICcnO1xyXG5cdFx0XHRcdFx0aWYgKHByb3AudmFsdWUpIHtcclxuXHRcdFx0XHRcdFx0dGIuaW5zZXJ0dGV4dCArPSAnfCcgKyBwcm9wLnZhbHVlO1xyXG5cdFx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdFx0c3dpdGNoKHByb3AudXNhZ2UpIHtcclxuXHRcdFx0XHRcdFx0Y2FzZSBcIlJlcXVpcmVkXCI6XHJcblx0XHRcdFx0XHRcdGNhc2UgXCJQcmVmZXJyZWRcIjpcclxuXHRcdFx0XHRcdFx0dGIuaW5zZXJ0dGV4dCArPSAnfCc7XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHR9IFxyXG5cdFx0XHRcdFx0fSAgICBcclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0aWYgKHByb3AudmFsdWUpIHtcclxuXHRcdFx0XHRcdFx0dGIuaW5zZXJ0dGV4dCArPSAnXFxufCcgKyBwcm9wLm5hbWUgKyAnPSAnICsgcHJvcC52YWx1ZTtcclxuXHRcdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRcdHN3aXRjaChwcm9wLnVzYWdlKSB7XHJcblx0XHRcdFx0XHRcdFx0Y2FzZSBcIlJlcXVpcmVkXCI6XHJcblx0XHRcdFx0XHRcdFx0Y2FzZSBcIlByZWZlcnJlZFwiOlxyXG5cdFx0XHRcdFx0XHRcdHRiLmluc2VydHRleHQgKz0gJ1xcbnwnICsgcHJvcC5uYW1lICsgJz0gJztcclxuXHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0fSBcclxuXHRcdFx0XHRcdH0gICAgXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHR0Yi5pbnNlcnR0ZXh0ID0gJ3t7JyArIHRiLnRlbXBsYXRlLm5hbWUgKyB0Yi5pbnNlcnR0ZXh0ICsgbGluZSArICd9fScgO1xyXG5cdFx0dGIuaW5zZXJ0dGV4dCArPSAodGIudGV4dEFmdGVyWzBdPT09J1xcbicpID8gJyc6IGxpbmU7XHJcblx0XHRcclxuXHRcdHRiLnRleHRSZXN1bHQgPSB0Yi50ZXh0QmVmb3JlICsgdGIuaW5zZXJ0dGV4dCArIHRiLnRleHRBZnRlcjtcclxuXHRcdHRiLnNlbFN0YXJ0ID0gdGIudGV4dEJlZm9yZS5sZW5ndGhcclxuXHRcdHRiLnNlbEVuZCA9IHRiLnNlbFN0YXJ0ICsgIHRiLmluc2VydHRleHQubGVuZ3RoO1xyXG5cdFx0dGIuYmlydGhMb2NhdGlvblJlc3VsdCA9ICcnO1xyXG5cdFx0dGIuZGVhdGhMb2NhdGlvblJlc3VsdCA9ICcnO1xyXG5cdFx0dXBkYXRlRWRpdCgpO1xyXG5cdH07XHJcblx0dGIuZWxEbGcuaW5uZXJIVE1MID0gJyc7XHJcblx0dGIuYWRkVG9TdW1tYXJ5ID0gJydcclxuXHRyZXR1cm4gZmFsc2VcclxufTtcclxuXHJcbi8vbGlzdGVuZXIgZm9yIHBhc3RlIGV2ZW50XHJcbmZ1bmN0aW9uIG9uRGxnRWRpdFRlbXBsYXRlUGFzdGUoaSwgZXZ0KSB7XHJcblx0aWYgKGV2dC50eXBlID09ICdrZXlwcmVzcycpIHtcclxuXHRcdHZhciBrZXkgPSBldnQud2hpY2ggfHwgZXZ0LmtleUNvZGU7XHJcblx0XHRpZiAoa2V5ID09PSAxMykgeyBcclxuXHRcdFx0b25EbGdFZGl0VGVtcGxhdGVCdG4oJzEnKVxyXG5cdFx0fSBcclxuXHR9IFxyXG5cdGlmIChldnQudHlwZSA9PSAncGFzdGUnKSB7XHJcblx0XHRsZXQgY2xpcGRhdGEgPSBldnQuY2xpcGJvYXJkRGF0YSB8fCB3aW5kb3cuY2xpcGJvYXJkRGF0YTtcclxuXHRcdHZhciBzID0gY2xpcGRhdGEuZ2V0RGF0YSgndGV4dC9wbGFpbicpO1xyXG5cdFx0cyA9IGRlY29kZVVSSUNvbXBvbmVudCAocyk7XHJcblx0XHRmb3IoY29uc3QgaiBvZiB1cmxNYXBwaW5ncykge1xyXG5cdFx0XHRpZiAodGIudGVtcGxhdGVpdGVtc1tpXS50eXBlID09PSBqLnR5cGUpIHtcclxuXHRcdFx0XHRpZiAocy5zdGFydHNXaXRoKGoucHJlZml4VVJMKSkge1xyXG5cdFx0XHRcdFx0cyA9IHMucmVwbGFjZShqLnByZWZpeFVSTCwgJycpO1xyXG5cdFx0XHRcdFx0aWYgKChqLnN1Zml4VVJMIT0nJykgJiYgKHMuZW5kc1dpdGgoai5zdWZpeFVSTCkpKSB7XHJcblx0XHRcdFx0XHRcdHMgPSBzLnJlcGxhY2Uoai5zdWZpeFVSTCwgJycpO1xyXG5cdFx0XHRcdFx0fSAgICBcclxuXHRcdFx0XHRcdHMgPSBqLmZyb21VUkwgPyBqLmZyb21VUkwocykgOiBzXHJcblx0XHRcdFx0XHRkb2N1bWVudC5leGVjQ29tbWFuZChcImluc2VydEhUTUxcIiwgZmFsc2UsIHMpO1xyXG5cdFx0XHRcdFx0ZXZ0LnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG5mdW5jdGlvbiBvbkRsZ0VkaXRUZW1wbGF0ZUZvbGxvdyhpKSB7XHJcblx0dmFyIGl0ZW09dGIudGVtcGxhdGVpdGVtc1tpXTtcclxuXHR2YXIgZT10Yi5lbERsZ1BhcmFtcy5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dCcpW2ldO1xyXG5cdHZhciBzID0gZS52YWx1ZTtcclxuXHJcblx0Zm9yKGNvbnN0IGkgb2YgdXJsTWFwcGluZ3MpIHtcclxuXHRcdGlmIChpdGVtLnR5cGUgPT09IGkudHlwZSkge1xyXG5cdFx0XHRpZiAocykge1xyXG5cdFx0XHRcdHMgPSAoaS5wcmVmaXhVUkwgPT09ICcnKSA/IGVuY29kZVVSSSAocykgOiBlbmNvZGVVUklDb21wb25lbnQgKHMpXHJcblx0XHRcdFx0cyA9IGkudG9VUkwgPyBpLnRvVVJMKHMpIDogc1xyXG5cdFx0XHRcdHMgPSBpLnByZWZpeFVSTCArIHMgKyBpLnN1Zml4VVJMXHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0cyA9IGkuZW1wdHlVUkwgIT09IHVuZGVmaW5lZCA/IGkuZW1wdHlVUkwgOiBpLnByZWZpeFVSTFxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG4gICBcclxuXHRpZiAocy5zdGFydHNXaXRoKCdodHRwJykpIHtcclxuXHRcdHdpbmRvdy5vcGVuKHMsICdfYmxhbmsnKTtcclxuXHR9XHJcblx0cmV0dXJuIGZhbHNlXHJcbn07XHJcblxyXG5mdW5jdGlvbiBvbkRsZ0VkaXRUZW1wbGF0ZUluaXRpYWwoaSkge1xyXG5cdHZhciBpdGVtPXRiLnRlbXBsYXRlaXRlbXNbaV07XHJcblx0dmFyIGU9dGIuZWxEbGdQYXJhbXMucXVlcnlTZWxlY3RvckFsbCgnaW5wdXQnKVtpXTtcclxuXHRpZiAoaXRlbS5pbml0aWFsLnN0YXJ0c1dpdGgoXCJUaXRsZTpcIikpIHtcclxuXHRcdGUudmFsdWUgPSBkb2N1bWVudC50aXRsZS5yZXBsYWNlKFJlZ0V4cChpdGVtLmluaXRpYWwuc3Vic3RyaW5nKDYpKSwgJyQxJyk7XHJcblx0fSAgICBcclxuXHRpZiAoaXRlbS5pbml0aWFsLnN0YXJ0c1dpdGgoXCJDYXRlZ29yeTpcIikgJiYgKHRiLmNhdGVnb3JpZXMpKSB7XHJcblx0XHR2YXIgcj1SZWdFeHAoaXRlbS5pbml0aWFsLnN1YnN0cmluZyg5KSwgJ21nJylcclxuXHRcdGUudmFsdWUgPSB0Yi5jYXRlZ29yaWVzLm1hdGNoKHIpLmpvaW4oJ1xcbicpLnJlcGxhY2UociwgJyQxJyk7XHJcblx0fVxyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuZnVuY3Rpb24gb25EbGdFZGl0VGVtcGxhdGVSZXN0b3JlKGkpIHtcclxuXHR2YXIgaXRlbT10Yi50ZW1wbGF0ZWl0ZW1zW2ldO1xyXG5cdHZhciBlID0gdGIuZWxEbGdQYXJhbXMucXVlcnlTZWxlY3RvckFsbCgnaW5wdXQnKVtpXTtcclxuXHRlLnZhbHVlID0gaXRlbS52YWx1ZTtcclxuXHRyZXR1cm4gZmFsc2VcclxufTtcclxuXHJcbmZ1bmN0aW9uIG9uRGxnRWRpdFRlbXBsYXRlRXhwQ29sKGdOYW1lKSB7XHJcblx0dmFyIGUgPSB0Yi5lbERsZy5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdncm91cCcgKyBnTmFtZSk7XHJcblx0dmFyIGIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZ3JvdXBCdG4nICsgZ05hbWUpO1xyXG5cdGlmIChiLmlubmVySFRNTCA9PSAnRXhwYW5kJykge1xyXG5cdFx0Yi5pbm5lckhUTUwgPSAnQ29sbGFwc2UnXHJcblx0XHRmb3IodmFyIGVpIG9mIGUpIHtlaS5zdHlsZS52aXNpYmlsaXR5ID0gJ3Zpc2libGUnO31cclxuXHR9IGVsc2Uge1xyXG5cdFx0Yi5pbm5lckhUTUwgPSAnRXhwYW5kJ1xyXG5cdFx0Zm9yKHZhciBlaSBvZiBlKSB7ZWkuc3R5bGUudmlzaWJpbGl0eSA9ICdjb2xsYXBzZSc7fVxyXG5cdH1cclxuXHRyZXR1cm4gZmFsc2VcclxufTtcclxuXHJcbmZ1bmN0aW9uIFdpa2lUcmVlR2V0Q2F0ZWdvcnkgKHF1ZXJ5LCBmaXhlZCl7XHJcblx0ZmV0Y2goXCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vaW5kZXgucGhwP2FjdGlvbj1hamF4JnJzPVRpdGxlOjphamF4Q2F0ZWdvcnlTZWFyY2gmcnNhcmdzW109XCIgKyBxdWVyeSArIFwiJnJzYXJnc1tdPTFcIilcclxuXHQudGhlbigocmVzcCkgPT4gcmVzcC5qc29uKCkpXHJcblx0LnRoZW4oanNvbkRhdGEgPT4ge1xyXG5cdFx0Y29uc29sZS5sb2coJ2NhdDogJyArIGpzb25EYXRhKTtcclxuXHRcdHJldHVybiAoanNvbkRhdGEpO1xyXG5cdH0pXHJcbn07XHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbi8qIFNlbGVjdCB0ZW1wbGF0ZSB0byBhZGQgKi9cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gXHJcbmZ1bmN0aW9uIHNlbGVjdFRlbXBsYXRlIChkYXRhKSB7XHJcblx0dGIuZWxEbGcuaW5uZXJIVE1MID0gXHJcblx0XHQnPGgzPlNlbGVjdCB0ZW1wbGF0ZTwvaDM+JyArIFxyXG5cdFx0JzxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzcz1cImNiRmlsdGVyXCIgaWQ9XCJjYjFcIiBuYW1lPVwiY2IxXCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVGbHRcIiBkYXRhLWlkPVwiMVwiIHZhbHVlPVwiUHJvamVjdCBCb3hcIicgKyAoZGF0YT09XCJQcm9qZWN0IEJveFwiID8gJyBjaGVja2VkJyA6ICcnKSArICc+PGxhYmVsIGZvcj1cImNiMVwiPiBQcm9qZWN0IEJveDwvbGFiZWw+PGJyPicgK1xyXG5cdFx0JzxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzcz1cImNiRmlsdGVyXCIgaWQ9XCJjYjJcIiBuYW1lPVwiY2IyXCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVGbHRcIiBkYXRhLWlkPVwiMlwiIHZhbHVlPVwiU3RpY2tlclwiJyArIChkYXRhPT1cIlN0aWNrZXJcIiA/ICcgY2hlY2tlZCcgOiAnJykgKyAnPjxsYWJlbCBmb3I9XCJjYjJcIj4gU3RpY2tlcjwvbGFiZWw+PGJyPicgK1xyXG5cdFx0JzxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzcz1cImNiRmlsdGVyXCIgaWQ9XCJjYjNcIiBuYW1lPVwiY2IzXCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVGbHRcIiBkYXRhLWlkPVwiM1wiIHZhbHVlPVwiUHJvZmlsZSBCb3hcIicgKyAoZGF0YT09XCJQcm9maWxlIEJveFwiID8gJyBjaGVja2VkJyA6ICcnKSArICc+PGxhYmVsIGZvcj1cImNiM1wiPiBSZXNlYXJjaCBOb3RlPC9sYWJlbD48YnI+JyArXHJcblx0XHQnPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzPVwiY2JGaWx0ZXJcIiBpZD1cImNiNFwiIG5hbWU9XCJjYjRcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUZsdFwiIGRhdGEtaWQ9XCI0XCIgdmFsdWU9XCJFeHRlcm5hbCBMaW5rXCInICsgKGRhdGE9PVwiRXh0ZXJuYWwgTGlua1wiID8gJyBjaGVja2VkJyA6ICcnKSArICc+PGxhYmVsIGZvcj1cImNiNFwiPiBFeHRlcm5hbCBMaW5rPC9sYWJlbD48YnI+JyArXHJcblx0XHQnPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzPVwiY2JGaWx0ZXJcIiBpZD1cImNiNVwiIG5hbWU9XCJjYjVcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUZsdFwiIGRhdGEtaWQ9XCI1XCIgdmFsdWU9XCJDYXRlZ29yeUluZm9Cb3hcIicgKyAoZGF0YT09XCJDYXRlZ29yeUluZm9Cb3hcIiA/ICcgY2hlY2tlZCcgOiAnJykgKyAnPjxsYWJlbCBmb3I9XCJjYjVcIj4gQ2F0ZWdvcnlJbmZvQm94PC9sYWJlbD48YnI+JyArXHJcblx0XHQnPGxhYmVsIGZvcj1cImZsdDFcIj5GaWx0ZXI6IDwvbGFiZWw+PGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJjYkZpbHRlclwiIGlkPVwiZmx0MVwiIG5hbWU9XCJmbHQxXCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVGbHRcIiBkYXRhLWlkPVwiOVwiPjxicj4nICtcclxuXHRcdCc8ZGl2IHN0eWxlPVwibWluLXdpZHRoOiA2MDBweDtvdmVyZmxvdy15OmF1dG87aGVpZ2h0OiA0MDBweDtcIj48dGFibGUgc3R5bGU9XCJ3aWR0aDogMTAwJTtcIiBpZD1cInRiXCI+JyArXHJcblx0XHR0Yi50ZW1wbGF0ZXMubWFwKGl0ZW0gPT4gJzx0ciBjbGFzcz1cInRyU2VsZWN0XCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVUclNlbFwiPjx0ZD4nICsgaXRlbS5uYW1lICsgJzwvdGQ+PHRkPicgKyBpdGVtLmdyb3VwICsgJzwvdGQ+PHRkPicgKyBpdGVtLnN1Ymdyb3VwICsgJzwvdGQ+PC90cj4nICkuam9pbignXFxuJykgK1xyXG5cdFx0JzwvdGFibGU+PC9kaXY+JyArXHJcblx0XHQnPGRpdiBzdHlsZT1cInRleHQtYWxpZ246cmlnaHRcIj4nK1xyXG5cdFx0JzxhIGNsYXNzPVwiYnV0dG9uXCIgaHJlZj1cImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL1NwYWNlOldpa2lUcmVlX1BsdXNfQ2hyb21lX0V4dGVuc2lvbiNBZGRfVGVtcGxhdGVcIiB0YXJnZXQ9XCJfYmxhbmtcIj5IZWxwPC9hPicgK1xyXG5cdFx0Ly9PSywgQ2FuY2VsXHJcblx0XHQnPGJ1dHRvbiBzdHlsZT1cInRleHQtYWxpZ246cmlnaHRcIiBjbGFzcz1cImRsZ0NsaWNrXCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVCdG5cIiBkYXRhLWlkPVwiMFwiPkNsb3NlPC9idXR0b24+JyArXHJcblx0XHQnPGJ1dHRvbiBzdHlsZT1cInRleHQtYWxpZ246cmlnaHRcIiBjbGFzcz1cImRsZ0NsaWNrXCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVCdG5cIiBkYXRhLWlkPVwiMVwiIHZhbHVlPVwiZGVmYXVsdFwiPlNlbGVjdDwvYnV0dG9uPicgK1xyXG5cdFx0JzwvZGl2PicgXHJcblx0YXR0YWNoRXZlbnRzKCdidXR0b24uZGxnQ2xpY2snLCAnY2xpY2snKVxyXG5cdGF0dGFjaEV2ZW50cygnaW5wdXQuY2JGaWx0ZXInLCAnaW5wdXQnKVxyXG5cdGF0dGFjaEV2ZW50cygndHIudHJTZWxlY3QnLCAnY2xpY2snKVxyXG5cdG9uRGxnU2VsZWN0VGVtcGxhdGVGbHQgKClcclxuXHR0Yi5lbERsZy5zaG93TW9kYWwoKTtcclxufTtcclxuXHJcbmZ1bmN0aW9uIG9uRGxnU2VsZWN0VGVtcGxhdGVGbHQgKCkge1xyXG5cdGxldCBsYiA9IHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3IoXCIjdGJcIilcclxuXHR2YXIgczAgPSAnJztcclxuXHRmb3IgKGxldCBpPTE7aTw9NTtpKyspIHtcclxuXHRcdGlmICh0Yi5lbERsZy5xdWVyeVNlbGVjdG9yKFwiI2NiXCIraSkuY2hlY2tlZClcclxuXHRcdCAgczAgKz0gKHMwPT0nJyA/ICcnIDogJ3wnKSArIHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3IoXCIjY2JcIitpKS52YWx1ZVxyXG5cdH1cclxuXHR2YXIgcjAgPSBuZXcgUmVnRXhwKCcoJytzMCsnKScsJ2knKVxyXG5cdFxyXG5cdHZhciBzMSA9IHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3IoXCIjZmx0MVwiKS52YWx1ZVxyXG5cdHZhciByMSA9IG5ldyBSZWdFeHAoczEsJ2knKVxyXG5cdFxyXG5cdGxiLmlubmVySFRNTCA9IHRiLnRlbXBsYXRlcy5maWx0ZXIoaXRlbT0+IFxyXG5cdFx0KChzMD09PScnKSB8fCBpdGVtLnR5cGUubWF0Y2gocjApKSAmJiBcclxuXHRcdCgoczE9PT0nJykgfHwgaXRlbS5uYW1lLm1hdGNoKHIxKSB8fCBpdGVtLmdyb3VwLm1hdGNoKHIxKSB8fCBpdGVtLnN1Ymdyb3VwLm1hdGNoKHIxKSlcclxuLy8gICAgKS5tYXAoaXRlbSA9PiAnPG9wdGlvbiB2YWx1ZT1cIicgKyBpdGVtLm5hbWUgKyAnXCI+JyArIGl0ZW0ubmFtZSArICcgKCcgKyBpdGVtLmdyb3VwICsgJzogJyArIGl0ZW0uc3ViZ3JvdXAgKyAnKTwvb3B0aW9uPicgKS5qb2luKCdcXG4nKSBcclxuXHRcdCkubWFwKGl0ZW0gPT4gJzx0ciBjbGFzcz1cInRyU2VsZWN0XCIgZGF0YS1vcD1cIm9uRGxnU2VsZWN0VGVtcGxhdGVUclNlbFwiPjx0ZD4nICsgaXRlbS5uYW1lICsgJzwvdGQ+PHRkPicgKyBpdGVtLmdyb3VwICsgJzwvdGQ+PHRkPicgKyBpdGVtLnN1Ymdyb3VwICsgJzwvdGQ+PC90cj4nICkuam9pbignXFxuJykgXHJcblx0YXR0YWNoRXZlbnRzKCd0ci50clNlbGVjdCcsICdjbGljaycpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIG9uRGxnU2VsZWN0VGVtcGxhdGVUclNlbCAodHIpIHtcclxuXHRyZW1vdmVDbGFzcyAoJ3RyLnRyU2VsZWN0JywgJ3RyU2VsZWN0ZWQnKVxyXG5cdHRyLmNsYXNzTGlzdC5hZGQoXCJ0clNlbGVjdGVkXCIpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIG9uRGxnU2VsZWN0VGVtcGxhdGVCdG4odXBkYXRlKSB7XHJcblx0aWYgKHVwZGF0ZT09PScxJykge1xyXG5cdFx0aWYgKHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3JBbGwoJy50clNlbGVjdGVkPnRkJykubGVuZ3RoID09PSAwKSB7XHJcblx0XHRcdGFsZXJ0ICgnTm8gdGVtcGxhdGUgc2VsZWN0ZWQ6IFNlbGVjdCBhIHRlbXBsYXRlIGJlZm9yZSBjbG9zaW5nIHRoZSBkaWFsb2cnKVxyXG5cdFx0XHRyZXR1cm4gZmFsc2VcclxuXHRcdH1cclxuXHRcdHRiLmVsRGxnLmNsb3NlKCk7XHJcblx0XHQvL0FkZCB0ZW1wbGF0ZSBcclxuXHRcdHZhciB0ZW1wbGF0ZU5hbWUgPSB0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcudHJTZWxlY3RlZD50ZCcpWzBdLmlubmVyVGV4dFxyXG5cdFx0cGFyYW1zQ29weSAodGVtcGxhdGVOYW1lKVxyXG5cdFx0cGFyYW1zSW5pdGlhbFZhbHVlcyAoKTtcclxuXHRcdGVkaXRUZW1wbGF0ZSAoXCJBZGRlZFwiKTtcclxuXHR9IGVsc2Uge1xyXG5cdFx0dGIuZWxEbGcuY2xvc2UoKTtcclxuXHRcdHRiLmVsRGxnLmlubmVySFRNTCA9ICcnO1xyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gJydcclxuXHR9O1xyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuLyogQXV0b21hdGljIHVwZGF0ZSBsaWtlIEVkaXRCT1QgKi9cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbmZ1bmN0aW9uIEF1dG9VcGRhdGUgKCkge1xyXG5cdGxldCBzMCA9ICcnXHJcblx0bGV0IHMxID0gJydcclxuXHRsZXQgczIgPSAnJ1xyXG5cdGZvciAodmFyIGxvYz0wO2xvYzwzO2xvYysrKSB7XHJcblx0XHRsZXQgYWN0QXJyID0gJydcclxuXHRcdGlmIChsb2M9PTApIHtcclxuXHRcdFx0aWYgKHRiLmJpcnRoTG9jYXRpb24pIHtcclxuXHRcdFx0XHRzMCA9ICdCaXJ0aCBMb2NhdGlvbidcclxuXHRcdFx0XHRzMSA9IHRiLmJpcnRoTG9jYXRpb25cclxuXHRcdFx0XHRhY3RBcnIgPSB0Yi5sb2NhdGlvbnNcclxuXHRcdFx0fVxyXG5cdFx0fSBlbHNlIGlmIChsb2M9PTEpIHtcclxuXHRcdFx0aWYgKHRiLmRlYXRoTG9jYXRpb24pIHtcclxuXHRcdFx0XHRzMCA9ICdEZWF0aCBMb2NhdGlvbidcclxuXHRcdFx0XHRzMSA9IHRiLmRlYXRoTG9jYXRpb25cclxuXHRcdFx0XHRhY3RBcnIgPSB0Yi5sb2NhdGlvbnNcclxuXHRcdFx0fVxyXG5cdFx0fSBlbHNlIGlmIChsb2M9PTIpIHtcclxuXHRcdFx0aWYgKHRiLnRleHRBbGwpIHtcclxuXHRcdFx0XHRzMCA9ICdCaW8nXHJcblx0XHRcdFx0czEgPSB0Yi50ZXh0QWxsXHJcblx0XHRcdFx0YWN0QXJyID0gdGIuY2xlYW51cFxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHRpZiAoYWN0QXJyKSB7XHJcblx0XHRcdGZvciAodmFyIGo9MDtqPGFjdEFyci5sZW5ndGg7aisrKSB7XHJcblx0XHRcdFx0bGV0IGNsZWFuID0gYWN0QXJyW2pdXHJcblx0XHRcdFx0bGV0IHMzID0gJydcclxuXHRcdFx0XHRmb3IgKHZhciBpPTA7aTxjbGVhbi5hY3Rpb25zLmxlbmd0aDtpKyspIHtcclxuXHRcdFx0XHRcdGxldCBzID0gczFcclxuXHRcdFx0XHRcdGxldCBhY3Rpb24gPSBjbGVhbi5hY3Rpb25zW2ldXHJcblx0XHRcdFx0XHRzd2l0Y2goYWN0aW9uLmFjdGlvbikge1xyXG5cdFx0XHRcdFx0XHRjYXNlIFwicmVwbGFjZVJlZ0V4XCI6IFxyXG5cdFx0XHRcdFx0XHRsZXQgcmVnID0gUmVnRXhwKGFjdGlvbi5mcm9tLCBhY3Rpb24uZmxhZ3MpXHJcblx0XHRcdFx0XHRcdHMxID0gczEucmVwbGFjZShyZWcsIGFjdGlvbi50bylcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdGNhc2UgXCJyZXBsYWNlXCI6IFxyXG5cdFx0XHRcdFx0XHRzMSA9IHMxLnJlcGxhY2UoYWN0aW9uLmZyb20sIGFjdGlvbi50bylcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdGFsZXJ0ICgnVW5rbm93biBhY3Rpb246ICcgKyBhY3Rpb24uYWN0aW9uICsgJyBkZWZpbmVkIGZvciBzb3VyY2U6ICcgKyBjbGVhbi5uYW1lKVxyXG5cdFx0XHRcdFx0XHRzMSA9ICcnXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRpZiAoczE9PScnKSBicmVha1xyXG5cdFx0XHRcdFx0aWYgKChzMSE9PScnKSAmJiAocyAhPT0gczEpKSB7XHJcblx0XHRcdFx0XHRcdHMzICs9IChzMyE9PScnID8gJywgJyA6ICcnKSArIGFjdGlvbi5kZXNjcmlwdGlvblxyXG5cdFx0XHRcdFx0fSAgICBcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0aWYgKHMzIT09JycpIHtcclxuXHRcdFx0XHRcdHMyICs9ICc8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJjYicgKyBsb2MgKyAnXycgKyBqICsgJ1wiIGlkPVwiY2InICsgbG9jICsgJ18nICsgaiArICdcIiBuYW1lPVwiY2InICsgbG9jICsgJ18nICsgaiArICdcIiBkYXRhLW9wPVwib25EbGdQYXN0ZVNvdXJjZUNCXCIgZGF0YS1pZD1cIjFcIiB2YWx1ZT1cIicgKyBsb2MgKyAnXycgKyBqICsgJ1wiIGNoZWNrZWQ+JyArXHJcblx0XHRcdFx0XHRcdCc8bGFiZWwgZm9yPVwiY2InICsgbG9jICsgJ18nICsgaiArICdcIj4gJyArIHMwICsgJyAnICsgY2xlYW4uZGVzY3JpcHRpb24gKyAnICcgKyAnICgnICsgczMgKyAnKTwvbGFiZWw+PGJyPlxcbicgXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cdGlmIChzMiA9PSAnJykge1xyXG5cdFx0YWxlcnQgKCdOb3RoaW5nIHRvIGNoYW5nZS4nKVxyXG5cdH0gZWxzZSB7XHJcblx0XHR0Yi5lbERsZy5pbm5lckhUTUwgPSBcclxuXHRcdFx0JzxoMz5BdXRvbWF0ZWQgY2xlYW51cDwvaDM+JyArIFxyXG5cdFx0XHRzMiArXHJcblx0XHRcdCc8ZGl2IHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiPicrXHJcblx0XHRcdC8vT0ssIENhbmNlbFxyXG5cdFx0XHQnPGEgY2xhc3M9XCJidXR0b25cIiBocmVmPVwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvU3BhY2U6V2lraVRyZWVfUGx1c19DaHJvbWVfRXh0ZW5zaW9uI1Byb2ZpbGVfQ2xlYW51cFwiIHRhcmdldD1cIl9ibGFua1wiPkhlbHA8L2E+JyArXHJcblx0XHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdQcm9maWxlQ2xlYW51cEJ0blwiIGRhdGEtaWQ9XCIwXCI+Q2xvc2U8L2J1dHRvbj4nICtcclxuXHRcdFx0JzxidXR0b24gc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ1Byb2ZpbGVDbGVhbnVwQnRuXCIgZGF0YS1pZD1cIjFcIiB2YWx1ZT1cImRlZmF1bHRcIj5TZWxlY3Q8L2J1dHRvbj4nICtcclxuXHRcdFx0JzwvZGl2PicgXHJcblx0XHRhdHRhY2hFdmVudHMoJ2J1dHRvbi5kbGdDbGljaycsICdjbGljaycpXHJcblx0XHRhdHRhY2hFdmVudHMoJ2lucHV0LmNiSW5saW5lJywgJ2lucHV0JylcclxuXHRcdHRiLmVsRGxnLnNob3dNb2RhbCgpO1xyXG5cdH1cclxufTtcclxuXHJcbmZ1bmN0aW9uIG9uRGxnUHJvZmlsZUNsZWFudXBCdG4odXBkYXRlKSB7XHJcblx0dGIuZWxEbGcuY2xvc2UoKTtcclxuXHRpZiAodXBkYXRlPT09JzEnKSB7XHJcblx0XHQvL1NldCB1cGRhdGVkIHRleHRcclxuXHJcblx0XHRsZXQgczAgPSAnJ1xyXG5cdFx0bGV0IHMxID0gJydcclxuXHRcdGxldCBzMiA9ICcnXHJcblx0XHRsZXQgYWN0QXJyID0gW11cclxuXHRcdGZvciAodmFyIGxvYz0wO2xvYzwzO2xvYysrKSB7XHJcblx0XHRcdGlmIChsb2M9PTApIHtcclxuXHRcdFx0XHRzMCA9ICdCaXJ0aCBMb2NhdGlvbidcclxuXHRcdFx0XHRzMSA9IHRiLmJpcnRoTG9jYXRpb25cclxuXHRcdFx0XHRhY3RBcnIgPSB0Yi5sb2NhdGlvbnNcclxuXHRcdFx0fSBlbHNlIGlmIChsb2M9PTEpIHtcclxuXHRcdFx0XHRzMCA9ICdEZWF0aCBMb2NhdGlvbidcclxuXHRcdFx0XHRzMSA9IHRiLmRlYXRoTG9jYXRpb25cclxuXHRcdFx0XHRhY3RBcnIgPSB0Yi5sb2NhdGlvbnNcclxuXHRcdFx0fSBlbHNlIGlmIChsb2M9PTIpIHtcclxuXHRcdFx0XHRzMCA9ICdCaW8nXHJcblx0XHRcdFx0czEgPSB0Yi50ZXh0QWxsXHJcblx0XHRcdFx0YWN0QXJyID0gdGIuY2xlYW51cFxyXG5cdFx0XHR9XHJcblx0XHRcdGlmIChhY3RBcnIpIHtcclxuXHRcdFx0XHRmb3IgKHZhciBqPTA7ajxhY3RBcnIubGVuZ3RoO2orKykge1xyXG5cdFx0XHRcdFx0dmFyIGNiID0gdGIuZWxEbGcucXVlcnlTZWxlY3RvckFsbCgnI2NiJytsb2MrJ18nK2opWzBdXHJcblx0XHRcdFx0XHRpZiAoKGNiKSAmJiAoY2IuY2hlY2tlZCkpIHtcclxuXHRcdFx0XHRcdFx0bGV0IGNsZWFuID0gYWN0QXJyW2pdXHJcblxyXG5cdFx0XHRcdFx0XHRsZXQgcyA9ICcnXHJcblx0XHRcdFx0XHRcdGxldCBzMSA9ICcnXHJcblx0XHRcdFx0XHRcdGxldCBzMyA9ICcnXHJcblx0XHRcdFx0XHRcdGZvciAodmFyIGk9MDtpPGNsZWFuLmFjdGlvbnMubGVuZ3RoO2krKykge1xyXG5cdFx0XHRcdFx0XHRcdHMgPSBzMVxyXG5cdFx0XHRcdFx0XHRcdGxldCBhY3Rpb24gPSBjbGVhbi5hY3Rpb25zW2ldXHJcblx0XHRcdFx0XHRcdFx0c3dpdGNoKGFjdGlvbi5hY3Rpb24pIHtcclxuXHRcdFx0XHRcdFx0XHRcdGNhc2UgXCJyZXBsYWNlUmVnRXhcIjogXHJcblx0XHRcdFx0XHRcdFx0XHRsZXQgcmVnID0gUmVnRXhwKGFjdGlvbi5mcm9tLCBhY3Rpb24uZmxhZ3MpXHJcblx0XHRcdFx0XHRcdFx0XHRzMSA9IHMxLnJlcGxhY2UocmVnLCBhY3Rpb24udG8pXHJcblx0XHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRcdGNhc2UgXCJyZXBsYWNlXCI6IFxyXG5cdFx0XHRcdFx0XHRcdFx0czEgPSBzMS5yZXBsYWNlKGFjdGlvbi5mcm9tLCBhY3Rpb24udG8pXHJcblx0XHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRcdGRlZmF1bHQ6IFxyXG5cdFx0XHRcdFx0XHRcdFx0czEgPSAnJ1xyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0XHRpZiAoczE9PScnKSBicmVha1xyXG5cdFx0XHRcdFx0XHRcdGlmICgoczEhPT0nJykgJiYgKHMgIT09IHMxKSkge1xyXG5cdFx0XHRcdFx0XHRcdFx0czMgKz0gKHMzIT09JycgPyAnLCAnIDogJycpICsgYWN0aW9uLmRlc2NyaXB0aW9uXHJcblx0XHRcdFx0XHRcdFx0fSAgICBcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRpZiAoczMhPT0nJykge1xyXG5cdFx0XHRcdFx0XHRcdHMyICs9IChzMiE9PScnID8gJywgJyA6ICcnICkgKyAnKycgKyBzMCArICcgJyArIGNsZWFuLmRlc2NyaXB0aW9uICsgJyAoJyArIHMzICsgJyknIFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdGlmIChsb2M9PTApIHtcclxuXHRcdFx0XHR0Yi5iaXJ0aExvY2F0aW9uUmVzdWx0ID0gczE7XHJcblx0XHRcdH0gZWxzZSBpZiAobG9jPT0xKSB7XHJcblx0XHRcdFx0dGIuZGVhdGhMb2NhdGlvblJlc3VsdCA9IHMxO1xyXG5cdFx0XHR9IGVsc2UgaWYgKGxvYz09Mikge1xyXG5cdFx0XHRcdHRiLnRleHRSZXN1bHQgPSBzMTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gczI7XHJcblx0XHR1cGRhdGVFZGl0KCk7XHJcblx0fSBlbHNlIHtcclxuXHRcdHRiLmVsRGxnLmlubmVySFRNTCA9ICcnO1xyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gJydcclxuXHR9O1xyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuLyogUGFzdGUgc291cmNlIHJlZm9ybWF0ICAqL1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5mdW5jdGlvbiBwYXN0ZVNvdXJjZSAoKSB7XHJcblx0dGIuZWxEbGcuaW5uZXJIVE1MID0gXHJcblx0XHQnPGgzPlBhc3RlIHNvdXJjZTwvaDM+JyArIFxyXG5cdFx0JzxsYWJlbCBmb3I9XCJzcmNQYXN0ZVwiPkNsaXBib2FyZDo8L2xhYmVsPjxicj4nICtcclxuXHRcdCc8dGV4dGFyZWEgY2xhc3M9XCJzcmNQYXN0ZVwiIGRhdGEtb3A9XCJvbkRsZ1Bhc3RlU291cmNlUGFzdGVcIiBkYXRhLWlkPVwiMVwiIHBsYWNlaG9sZGVyPVwiUGFzdGUgYSBzb3VyY2Ugb3IgVVJMIGhlcmUuXCIgcm93cz1cIjVcIiBjb2xzPVwiODBcIj48L3RleHRhcmVhPjxicj4nICtcclxuXHRcdCc8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJjYklubGluZVwiIGlkPVwiY2IxXCIgbmFtZT1cImNiMVwiIGRhdGEtb3A9XCJvbkRsZ1Bhc3RlU291cmNlQ0JcIiBkYXRhLWlkPVwiMVwiIHZhbHVlPVwiSW5saW5lXCIgY2hlY2tlZD48bGFiZWwgZm9yPVwiY2IxXCI+IElubGluZSBjaXRhdGlvbjwvbGFiZWw+PGJyPicgK1xyXG5cdFx0JzxsYWJlbCBmb3I9XCJyZXN1bHRGbGRcIj5DaXRhdGlvbiB0byBhZGQ6PC9sYWJlbD48YnI+JyArXHJcblx0XHQnPHRleHRhcmVhIGNsYXNzPVwicmVzdWx0RmxkXCIgcm93cz1cIjVcIiBjb2xzPVwiODBcIj48L3RleHRhcmVhPicgK1xyXG5cdFx0JzxkaXYgc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCI+JytcclxuXHRcdC8vT0ssIENhbmNlbFxyXG5cdFx0JzxhIGNsYXNzPVwiYnV0dG9uXCIgaHJlZj1cImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL1NwYWNlOldpa2lUcmVlX1BsdXNfQ2hyb21lX0V4dGVuc2lvbiNQYXN0ZV9Tb3VyY2VzXCIgdGFyZ2V0PVwiX2JsYW5rXCI+SGVscDwvYT4nICtcclxuXHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdQYXN0ZVNvdXJjZUJ0blwiIGRhdGEtaWQ9XCIwXCI+Q2xvc2U8L2J1dHRvbj4nICtcclxuXHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdQYXN0ZVNvdXJjZUJ0blwiIGRhdGEtaWQ9XCIxXCIgdmFsdWU9XCJkZWZhdWx0XCI+U2VsZWN0PC9idXR0b24+JyArXHJcblx0XHQnPC9kaXY+JyBcclxuXHRhdHRhY2hFdmVudHMoJ2J1dHRvbi5kbGdDbGljaycsICdjbGljaycpXHJcblx0YXR0YWNoRXZlbnRzKCdpbnB1dC5jYklubGluZScsICdpbnB1dCcpXHJcblx0YXR0YWNoRXZlbnRzKCd0ZXh0YXJlYS5zcmNQYXN0ZScsICdwYXN0ZScpXHJcblx0dGIuZWxEbGcuc2hvd01vZGFsKCk7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBvbkRsZ1Bhc3RlU291cmNlQnRuKHVwZGF0ZSkge1xyXG5cdHRiLmVsRGxnLmNsb3NlKCk7XHJcblx0aWYgKHVwZGF0ZT09PScxJykge1xyXG5cdFx0Ly9BZGQgdGVtcGxhdGUgXHJcblx0XHR0Yi5pbnNlcnR0ZXh0ID0gdGIuZWxEbGcucXVlcnlTZWxlY3RvckFsbCgnLnJlc3VsdEZsZCcpWzBdLnZhbHVlO1xyXG5cdFx0dGIuaW5zZXJ0dGV4dCArPSAodGIudGV4dEFmdGVyWzBdPT09J1xcbicpID8gJyc6ICdcXG4nO1xyXG5cdFx0dGIudGV4dFJlc3VsdCA9IHRiLnRleHRCZWZvcmUgKyB0Yi5pbnNlcnR0ZXh0ICsgdGIudGV4dEFmdGVyO1xyXG5cdFx0dGIuc2VsU3RhcnQgPSB0Yi50ZXh0QmVmb3JlLmxlbmd0aFxyXG5cdFx0dGIuc2VsRW5kID0gdGIuc2VsU3RhcnQgKyAgdGIuaW5zZXJ0dGV4dC5sZW5ndGg7XHJcblx0XHR0Yi5iaXJ0aExvY2F0aW9uUmVzdWx0ID0gJyc7XHJcblx0XHR0Yi5kZWF0aExvY2F0aW9uUmVzdWx0ID0gJyc7XHJcblx0XHR1cGRhdGVFZGl0KCk7XHJcblx0fSBlbHNlIHtcclxuXHRcdHRiLmVsRGxnLmlubmVySFRNTCA9ICcnO1xyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gJydcclxuXHR9O1xyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuZnVuY3Rpb24gb25EbGdQYXN0ZVNvdXJjZUNCKGksIGV2dCkge1xyXG5cdHZhciBlID0gdGIuZWxEbGcucXVlcnlTZWxlY3RvckFsbCgnLnJlc3VsdEZsZCcpWzBdXHJcblx0bGV0IHMgPSBlLnZhbHVlLnJlcGxhY2UoJzxyZWY+JywgJycpLnJlcGxhY2UoJzwvcmVmPicsICcnKS5yZXBsYWNlKCcqICcsICcnKVxyXG5cdGlmICh0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcuY2JJbmxpbmUnKVswXS5jaGVja2VkKSB7XHJcblx0XHRlLnZhbHVlID0gJzxyZWY+JyArIHMgKyAnPC9yZWY+J1xyXG5cdH0gZWxzZSB7XHJcblx0XHRlLnZhbHVlID0gJyogJyArIHNcclxuXHR9XHJcbn1cclxuXHJcbi8vbGlzdGVuZXIgZm9yIHBhc3RlIGV2ZW50XHJcbmZ1bmN0aW9uIG9uRGxnUGFzdGVTb3VyY2VQYXN0ZShpLCBldnQpIHtcclxuXHRpZiAoZXZ0LnR5cGUgPT0gJ2tleXByZXNzJykge1xyXG5cdFx0dmFyIGtleSA9IGV2dC53aGljaCB8fCBldnQua2V5Q29kZTtcclxuXHRcdGlmIChrZXkgPT09IDEzKSB7IFxyXG5cdFx0XHRvbkRsZ1Bhc3RlU291cmNlQnRuKCcxJylcclxuXHRcdH0gXHJcblx0fSBcclxuXHRpZiAoZXZ0LnR5cGUgPT0gJ3Bhc3RlJykge1xyXG5cdFx0dmFyIGNsaXBkYXRhID0gZXZ0LmNsaXBib2FyZERhdGEgfHwgd2luZG93LmNsaXBib2FyZERhdGE7XHJcblx0XHR2YXIgcyA9IGNsaXBkYXRhLmdldERhdGEoJ3RleHQvcGxhaW4nKTtcclxuXHRcdHZhciBzMSA9ICcnO1xyXG5cdFx0cyA9IGRlY29kZVVSSUNvbXBvbmVudCAocyk7XHJcblxyXG5cdFx0aWYgKHRiLnNvdXJjZXMpIHtcclxuXHRcdFx0Zm9yIChsZXQgc291cmNlIG9mIHRiLnNvdXJjZXMpIHtcclxuXHRcdFx0XHR2YXIgYiA9IGZhbHNlXHJcblx0XHRcdFx0Zm9yIChsZXQgY29uZGl0aW9uIG9mIHNvdXJjZS5jb25kaXRpb25zKSB7XHJcblx0XHRcdFx0XHRzd2l0Y2goY29uZGl0aW9uLmFjdGlvbikge1xyXG5cdFx0XHRcdFx0XHRjYXNlIFwic3RhcnRzV2l0aFwiOiBcclxuXHRcdFx0XHRcdFx0YiA9IHMuc3RhcnRzV2l0aChjb25kaXRpb24uZmluZClcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdGNhc2UgXCJpbmNsdWRlc1wiOiBcclxuXHRcdFx0XHRcdFx0YiA9IHMuaW5jbHVkZXMoY29uZGl0aW9uLmZpbmQpXHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBhbGVydCAoJ1Vua25vd24gY29uZGl0aW9uOiAnICsgY29uZGl0aW9uLmFjdGlvbiArICcgZGVmaW5lZCBmb3Igc291cmNlOiAnICsgc291cmNlLm5hbWUpXHJcblx0XHRcdFx0XHR9ICAgXHJcblx0XHRcdFx0XHRpZiAoYikgYnJlYWs7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGlmIChiKSB7XHJcblx0XHRcdFx0XHRzMSA9IHNcclxuXHRcdFx0XHRcdGZvciAobGV0IGFjdGlvbiBvZiBzb3VyY2UuYWN0aW9ucykge1xyXG5cdFx0XHRcdFx0XHRzd2l0Y2goYWN0aW9uLmFjdGlvbikge1xyXG5cdFx0XHRcdFx0XHRcdGNhc2UgXCJyZXBsYWNlUmVnRXhcIjogXHJcblx0XHRcdFx0XHRcdFx0bGV0IHJlZyA9IFJlZ0V4cChhY3Rpb24uZnJvbSwgJ21nJylcclxuXHRcdFx0XHRcdFx0XHRzMSA9IHMxLnJlcGxhY2UocmVnLCBhY3Rpb24udG8pXHJcblx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0Y2FzZSBcInJlcGxhY2VcIjogXHJcblx0XHRcdFx0XHRcdFx0czEgPSBzMS5yZXBsYWNlKGFjdGlvbi5mcm9tLCBhY3Rpb24udG8pXHJcblx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdFx0YWxlcnQgKCdVbmtub3duIGFjdGlvbjogJyArIGFjdGlvbi5hY3Rpb24gKyAnIGRlZmluZWQgZm9yIHNvdXJjZTogJyArIHNvdXJjZS5uYW1lKVxyXG5cdFx0XHRcdFx0XHRcdHMxID0gJydcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRpZiAoczE9PScnKSBicmVha1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0aWYgKHMxIT09JycpIHtcclxuXHRcdFx0XHRcdFx0dGIuYWRkVG9TdW1tYXJ5ID0gJ0FkZGVkICcgKyBzb3VyY2UuZGVzY3JpcHRpb25cclxuXHRcdFx0XHRcdFx0YnJlYWtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHJcblx0XHQvLyBBZGRpbmcgaW5saW5lIGNpdGF0aW9uXHJcblx0XHRpZiAoczEhPT0nJykge1xyXG5cdFx0XHRpZiAodGIuZWxEbGcucXVlcnlTZWxlY3RvckFsbCgnLmNiSW5saW5lJylbMF0uY2hlY2tlZCkge1xyXG5cdFx0XHRcdHMxID0gJzxyZWY+JyArIHMxICsgJzwvcmVmPidcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRzMSA9ICcqICcgKyBzMVxyXG5cdFx0XHR9IFxyXG5cdFx0fVxyXG5cdFx0dGIuZWxEbGcucXVlcnlTZWxlY3RvckFsbCgnLnJlc3VsdEZsZCcpWzBdLnZhbHVlID0gczFcclxuXHR9XHJcbn1cclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuLyogTWVudSBldmVudHMgICAgICAgICAgICAqL1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5mdW5jdGlvbiBwb3NUb09mZnNldCAodHh0LCBwb3Mpe1xyXG4gIGNvbnN0IGFycj10eHQuc3BsaXQoXCJcXG5cIik7XHJcbiAgdmFyIGxlbj0wO1xyXG4gIGZvciAodmFyIGk9MDtpPHBvcy5saW5lO2krKykgXHJcblx0bGVuKz0gbGVuZ3RoKGFycltpXSkgKyAxIDtcclxuICByZXR1cm4gbGVuK3Bvcy5jaCA7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gd3RQbHVzIChwYXJhbXMpe1xyXG5cdGlmICh0Yi5lbFRleHQuc3R5bGUuZGlzcGxheSA9PSBcIm5vbmVcIikge1xyXG5cdFx0YWxlcnQoJ0VuaGFuY2VkIGVkaXRvciBpcyBub3Qgc3VwcG9ydGVkLlxcblxcblR1cm5pbmcgaXQgb2ZmIHRvIHVzZSB0aGUgZXh0ZW5zaW9uLicpO1xyXG5cdFx0dGIuZWxFbmhhbmNlZC5jbGljaygpO1xyXG5cdH1cclxuXHJcblx0Ly9TZXRzIGFsbCBlZGl0IHZhcmlhYmxlc1xyXG5cdHRiLmVsRW5oYW5jZWRBY3RpdmUgPSAodGIuZWxUZXh0LnN0eWxlLmRpc3BsYXkgPT0gXCJub25lXCIpO1xyXG5cdGlmICh0Yi5lbEVuaGFuY2VkQWN0aXZlKSB7XHJcblx0XHR0Yi5lbEVuaGFuY2VkLmNsaWNrKCk7XHJcblx0XHRcdFxyXG5cdFx0XHRcclxuLy8gICAgICAgICAgICBhbGVydCAoJ0VuaGFuY2VkIGVkaXRvciBpcyBub3Qgc3VwcG9ydGVkLjxicj5UdXJuIGl0IG9mZiB0byB1c2UgV2lraVRyZWUrIGV4dGVuc2lvbi4nKTtcclxuLypcclxuXHRcdGlmICh3aW5kb3cuY29sb3JlZEVkaXRvcikge1xyXG5cdFx0XHR0Yi50ZXh0QWxsID0gY29sb3JlZEVkaXRvci5nZXRWYWx1ZSgpLnJlcGxhY2UoL1xcclxcbnxcXG5cXHJ8XFxufFxcci9nLCAnXFxuJylcclxuXHRcdFx0dGIuc2VsU3RhcnQgPSBwb3NUb09mZnNldCAodGIudGV4dEFsbCwgY29sb3JlZEVkaXRvci5nZXRDdXJzb3IoXCJmcm9tXCIpKVxyXG5cdFx0XHR0Yi5zZWxFbmQgPSBwb3NUb09mZnNldCAodGIudGV4dEFsbCwgY29sb3JlZEVkaXRvci5nZXRDdXJzb3IoXCJ0b1wiKSlcclxuKi9cclxuXHRcdH1cclxuXHJcblx0dGIuc2VsU3RhcnQgPSB0Yi5lbFRleHQuc2VsZWN0aW9uU3RhcnQ7XHJcblx0dGIuc2VsRW5kID0gdGIuZWxUZXh0LnNlbGVjdGlvbkVuZDtcclxuXHR0Yi50ZXh0QWxsID0gdGIuZWxUZXh0LnZhbHVlO1xyXG5cdGlmICh0Yi5lbEJpcnRoTG9jYXRpb24pIHtcclxuXHRcdHRiLmJpcnRoTG9jYXRpb24gPSB0Yi5lbEJpcnRoTG9jYXRpb24udmFsdWU7XHJcblx0fVxyXG5cdGlmICh0Yi5lbERlYXRoTG9jYXRpb24pIHtcclxuXHRcdHRiLmRlYXRoTG9jYXRpb24gPSB0Yi5lbERlYXRoTG9jYXRpb24udmFsdWU7XHJcblx0fVxyXG5cdGlmICh0Yi5lbEVuaGFuY2VkQWN0aXZlKSB7XHJcblx0XHR0Yi5lbEVuaGFuY2VkLmNsaWNrKCk7XHJcblx0fVxyXG5cclxuXHR0Yi50ZXh0QmVmb3JlID0gdGIudGV4dEFsbC5zdWJzdHJpbmcoMCwgIHRiLnNlbFN0YXJ0KTtcclxuXHR0Yi50ZXh0U2VsZWN0ZWQgPSB0Yi5zZWxFbmQgPT0gdGIuc2VsU3RhcnQgPyAnJyA6IHRiLnRleHRBbGwuc3Vic3RyaW5nKHRiLnNlbFN0YXJ0LCB0Yi5zZWxFbmQpO1xyXG5cdHRiLnRleHRBZnRlciA9IHRiLnRleHRBbGwuc3Vic3RyaW5nKHRiLnNlbEVuZCk7XHJcblx0dGIuY2F0ZWdvcmllcyA9IHRiLnRleHRBbGwubWF0Y2goL1xcW1xcW0NhdGVnb3J5Oi4qP1xcXVxcXS9tZ2kpXHJcblx0aWYgKHRiLmNhdGVnb3JpZXMpe1xyXG5cdFx0dGIuY2F0ZWdvcmllcyA9IHRiLmNhdGVnb3JpZXMuam9pbignXFxuJykucmVwbGFjZSgvXFxbXFxbQ2F0ZWdvcnk6XFxzKiguKj8pXFxzKlxcXVxcXS9tZ2ksICckMScpO1xyXG5cdH0gICAgICAgIFxyXG5cdHRiLnRleHRSZXN1bHQgPSB0Yi50ZXh0QWxsOyBcclxuXHJcblx0aWYgKHBhcmFtcy50ZW1wbGF0ZSkge1xyXG5cdFx0Ly9BZGQgdGVtcGxhdGUgXHJcblx0XHRwYXJhbXNDb3B5IChwYXJhbXMudGVtcGxhdGUpXHJcblx0XHRwYXJhbXNJbml0aWFsVmFsdWVzICgpO1xyXG5cdFx0ZWRpdFRlbXBsYXRlIChcIkFkZGVkXCIpO1xyXG5cdH0gZWxzZSB7XHJcblx0XHRzd2l0Y2gocGFyYW1zLmFjdGlvbikge1xyXG5cdFx0XHRjYXNlIFwiXCI6IGJyZWFrO1xyXG5cdFx0XHRjYXNlIFwiRWRpdFRlbXBsYXRlXCI6IC8vRWRpdCB0ZW1wbGF0ZVxyXG4vLyAgICAgICAgICAgIHZhciBleHByZXNzaW9uID0gL3t7W1xcc1xcU10qP319L2dcclxuXHRcdHZhciBleHByZXNzaW9uID0gL1xce1xcey4qPyhcXFtcXFtbXnt9W1xcXV0qP1xcXVxcXVtee31bXFxdXSo/fFxcW1tee31bXFxdXSo/XFxdW157fVtcXF1dKj98XFx7XFx7W157fVtcXF1dKj9cXH1cXH1bXnt9W1xcXV0qPykqP1tee31bXFxdXSo/XFx9XFx9L2dtc1xyXG5cclxuXHJcblx0XHRpZiAodGIuc2VsU3RhcnQgIT0gdGIuc2VsRW5kKSB7XHJcblx0XHRcdGxldCB0ZW0gPSB0Yi50ZXh0U2VsZWN0ZWQubWF0Y2goZXhwcmVzc2lvbik7XHJcblx0XHRcdGlmICh0ZW0gJiYgKHRlbS5sZW5ndGggPT0gMSkpIHtcclxuXHRcdFx0XHR2YXIgcyA9IHRiLnRleHRTZWxlY3RlZC5zcGxpdChleHByZXNzaW9uKTtcclxuXHRcdFx0XHR0Yi50ZXh0QmVmb3JlICs9IHNbMF07XHJcblx0XHRcdFx0dGIudGV4dFNlbGVjdGVkID0gdGVtWzBdO1xyXG5cdFx0XHRcdHRiLnRleHRBZnRlciA9IHNbMl0gKyB0Yi50ZXh0QWZ0ZXI7XHJcblx0XHRcdFx0dGIuc2VsU3RhcnQgPSB0Yi50ZXh0QmVmb3JlLmxlbmd0aFxyXG5cdFx0XHRcdHRiLnNlbEVuZCA9IHRiLnNlbFN0YXJ0ICsgdGIudGV4dFNlbGVjdGVkLmxlbmd0aDtcclxuXHRcdFx0XHRwYXJhbXNGcm9tU2VsZWN0aW9uKCk7XHJcblx0XHRcdFx0ZWRpdFRlbXBsYXRlKFwiRWRpdGVkXCIpO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGFsZXJ0ICgnVGhlcmUgaXMgbm8gdGVtcGxhdGUgaW4gc2VsZWN0ZWQgdGV4dCcpO1xyXG5cdFx0XHR9ICAgIFxyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0bGV0IHRlbSA9IHRiLnRleHRBbGwubWF0Y2goZXhwcmVzc2lvbik7XHJcblx0XHRcdGlmICh0ZW0pIHtcclxuXHRcdFx0XHRpZiAodGVtLmxlbmd0aCA9PSAxKSB7XHJcblx0XHRcdFx0XHR2YXIgcyA9IHRiLnRleHRBbGwuc3BsaXQoZXhwcmVzc2lvbik7XHJcblx0XHRcdFx0XHR0Yi50ZXh0QmVmb3JlID0gc1swXTtcclxuXHRcdFx0XHRcdHRiLnRleHRTZWxlY3RlZCA9IHRlbVswXTtcclxuXHRcdFx0XHRcdHRiLnRleHRBZnRlciAgPSBzWzJdO1xyXG5cdFx0XHRcdFx0dGIuc2VsU3RhcnQgPSB0Yi50ZXh0QmVmb3JlLmxlbmd0aFxyXG5cdFx0XHRcdFx0dGIuc2VsRW5kID0gdGIuc2VsU3RhcnQgKyB0Yi50ZXh0U2VsZWN0ZWQubGVuZ3RoO1xyXG5cdFx0XHRcdFx0cGFyYW1zRnJvbVNlbGVjdGlvbigpO1xyXG5cdFx0XHRcdFx0ZWRpdFRlbXBsYXRlKFwiRWRpdGVkXCIpO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRsZXQgbWF0Y2ggPSAnJ1xyXG5cdFx0XHRcdFx0d2hpbGUgKG1hdGNoID0gZXhwcmVzc2lvbi5leGVjKHRiLnRleHRBbGwpKSB7XHJcblx0XHRcdFx0XHRcdGlmICgobWF0Y2guaW5kZXggPCB0Yi5zZWxTdGFydCkgJiYgKGV4cHJlc3Npb24ubGFzdEluZGV4ID4gdGIuc2VsU3RhcnQpKSB7XHJcblx0XHRcdFx0XHRcdFx0dGIudGV4dEJlZm9yZSA9IHRiLnRleHRBbGwuc3Vic3RyaW5nKDAsICBtYXRjaC5pbmRleCk7XHJcblx0XHRcdFx0XHRcdFx0dGIudGV4dFNlbGVjdGVkID0gbWF0Y2hbMF07XHJcblx0XHRcdFx0XHRcdFx0dGIudGV4dEFmdGVyICA9IHRiLnRleHRBbGwuc3Vic3RyaW5nKGV4cHJlc3Npb24ubGFzdEluZGV4KTtcclxuXHRcdFx0XHRcdFx0XHR0Yi5zZWxTdGFydCA9IHRiLnRleHRCZWZvcmUubGVuZ3RoXHJcblx0XHRcdFx0XHRcdFx0dGIuc2VsRW5kID0gdGIuc2VsU3RhcnQgKyB0Yi50ZXh0U2VsZWN0ZWQubGVuZ3RoO1xyXG5cdFx0XHRcdFx0XHRcdHBhcmFtc0Zyb21TZWxlY3Rpb24oKTtcclxuXHRcdFx0XHRcdFx0XHRlZGl0VGVtcGxhdGUoXCJFZGl0ZWRcIik7XHJcblx0XHRcdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdFx0XHR9O1xyXG5cdFx0XHRcdFx0fTtcclxuXHRcdFx0XHRcdGFsZXJ0ICgnVGhlcmUgaXMgbm8gdGVtcGxhdGUgYXQgY3Vyc29yIHBvc2l0aW9uLicpXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGFsZXJ0ICgnVGhlcmUgaXMgbm8gdGVtcGxhdGUgb24gdGhlIHBhZ2UuJylcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0YnJlYWs7XHJcblxyXG5cdFx0Y2FzZSBcIkF1dG9Gb3JtYXRcIjogLy9hdXRvbWF0aWMgZm9ybXRpbmdcclxuXHRcdHRiLnRleHRSZXN1bHQgPSB0Yi50ZXh0QWxsLnJlcGxhY2UoL14gKlxcfCAqKFteID18XSopICo9ICovbWcsIFwifCQxPSBcIilcclxuXHRcdHRiLmJpcnRoTG9jYXRpb25SZXN1bHQgPSAnJztcclxuXHRcdHRiLmRlYXRoTG9jYXRpb25SZXN1bHQgPSAnJztcclxuXHRcdHRiLmFkZFRvU3VtbWFyeSA9ICcnXHJcblx0XHR1cGRhdGVFZGl0ICgpO1xyXG5cdFx0YnJlYWs7XHJcblxyXG5cdFx0Y2FzZSBcIkF1dG9VcGRhdGVcIjogLy9hdXRvbWF0aWMgY29ycmVjdGlvbnNcclxuXHRcdEF1dG9VcGRhdGUgKCk7XHJcblx0XHRicmVhazsgICBcclxuXHJcblx0XHRjYXNlIFwiRWRpdEJPVENvbmZpcm1cIjogLy9FZGl0Qk9UIGNvbmZpcm1hdGlvblxyXG5cdFx0dGIudGV4dFJlc3VsdCA9IHRiLnRleHRBbGwucmVwbGFjZSgvXFx8KFJldmlld3xNYW51YWwpXFx9XFx9L21nLCBcInxDb25maXJtZWR9fVwiKVxyXG5cdFx0dGIudGV4dFJlc3VsdCA9IHRiLnRleHRSZXN1bHQucmVwbGFjZSgvXFxzXFxzXFx9XFx9L21nLCBcIiBcIilcclxuXHRcdHRiLmJpcnRoTG9jYXRpb25SZXN1bHQgPSAnJztcclxuXHRcdHRiLmRlYXRoTG9jYXRpb25SZXN1bHQgPSAnJztcclxuXHRcdHRiLmFkZFRvU3VtbWFyeSA9IFwiQ29uZmlybWF0aW9uIGZvciBFZGl0Qk9UXCJcclxuXHRcdHVwZGF0ZUVkaXQgKCk7XHJcblx0XHRicmVhaztcclxuXHRcdFxyXG5cdFx0Y2FzZSBcIkFkZFRlbXBsYXRlXCI6IC8vYWRkIGFueSB0ZW1wbGF0ZVxyXG5cdFx0c2VsZWN0VGVtcGxhdGUgKHBhcmFtcy5kYXRhKTtcclxuXHRcdGJyZWFrO1xyXG5cclxuXHRcdGNhc2UgXCJQYXN0ZVNvdXJjZVwiOiAvL3Bhc3RlIGEgc291cmNlIGNpdGF0aW9uXHJcblx0XHRwYXN0ZVNvdXJjZSAoKTtcclxuXHRcdGJyZWFrO1xyXG5cdFx0XHJcblxyXG5cdFx0ZGVmYXVsdDogYWxlcnQgKFwiVW5rbm93biBldmVudCBcIiArIHBhcmFtcy5hY3Rpb24pXHJcblx0XHR9O1xyXG5cdH07XHJcblx0XHJcbn07XHJcblxyXG4vKiBDbGFzc2VzICovXHJcblxyXG5jb25zdCBhdHRhY2hDbGFzcyA9IChzZWxlY3RvciwgY2xhc3NOYW1lKSA9PiB7XHJcblx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcikuZm9yRWFjaChpPT5pLmNsYXNzTGlzdC5hZGQoY2xhc3NOYW1lKSlcclxufVxyXG5cclxuY29uc3QgcmVtb3ZlQ2xhc3MgPSAoc2VsZWN0b3IsIGNsYXNzTmFtZSkgPT4ge1xyXG5cdGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3IpLmZvckVhY2goaT0+aS5jbGFzc0xpc3QucmVtb3ZlKGNsYXNzTmFtZSkpXHJcbn1cclxuXHJcbi8qIEV2ZW50cyAqL1xyXG5cclxuY29uc3QgYXR0YWNoRXZlbnRzID0gKHNlbGVjdG9yLCBldmVudFR5cGUpID0+IHtcclxuXHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKS5mb3JFYWNoKGk9PmkuYWRkRXZlbnRMaXN0ZW5lcihldmVudFR5cGUsIGV2ZW50PT5tYWluRXZlbnRMb29wKGV2ZW50KSkpXHJcbn1cclxuZnVuY3Rpb24gbWFpbkV2ZW50TG9vcCAoZXZlbnQpIHtcclxuXHJcblx0aWYgKHRiLmVsVGV4dC5zdHlsZS5kaXNwbGF5ID09IFwibm9uZVwiKSB7XHJcblx0XHRhbGVydCAoJ0VuaGFuY2VkIGVkaXRvciBpcyBub3Qgc3VwcG9ydGVkLlxcblxcblR1cm5pbmcgaXQgb2ZmIHRvIHVzZSB0aGUgZXh0ZW5zaW9uLicpO1xyXG5cdFx0dGIuZWxFbmhhbmNlZC5jbGljaygpO1xyXG5cdH0gICBcclxuXHJcblx0bGV0IGVsZW1lbnQgPSBldmVudC5zcmNFbGVtZW50XHJcblx0aWYgKGVsZW1lbnQudGFnTmFtZSA9PSAnVEQnKSB7XHJcblx0XHRlbGVtZW50ID0gZWxlbWVudC5wYXJlbnRFbGVtZW50XHJcblx0fVxyXG5cdGNvbnN0IG9wID0gZWxlbWVudC5kYXRhc2V0Lm9wXHJcblx0Y29uc3QgaWQgPSBlbGVtZW50LmRhdGFzZXQuaWRcclxuXHRpZiAob3AgPT09ICd3dFBsdXMnKSAgICB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIHd0UGx1cyhpZCl9XHJcblx0XHJcblx0aWYgKG9wID09PSAnb25EbGdFZGl0VGVtcGxhdGVFeHBDb2wnKSB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnRWRpdFRlbXBsYXRlRXhwQ29sKGlkKX1cclxuXHRpZiAob3AgPT09ICdvbkRsZ0VkaXRUZW1wbGF0ZVJlc3RvcmUnKSAgICB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnRWRpdFRlbXBsYXRlUmVzdG9yZShpZCl9XHJcblx0aWYgKG9wID09PSAnb25EbGdFZGl0VGVtcGxhdGVJbml0aWFsJykgICAge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJldHVybiBvbkRsZ0VkaXRUZW1wbGF0ZUluaXRpYWwoaWQpfVxyXG5cdGlmIChvcCA9PT0gJ29uRGxnRWRpdFRlbXBsYXRlRm9sbG93Jykge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJldHVybiBvbkRsZ0VkaXRUZW1wbGF0ZUZvbGxvdyhpZCl9XHJcblx0aWYgKG9wID09PSAnb25EbGdFZGl0VGVtcGxhdGVCdG4nKSAge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJldHVybiBvbkRsZ0VkaXRUZW1wbGF0ZUJ0bihpZCl9XHJcblx0aWYgKG9wID09PSAnb25EbGdFZGl0VGVtcGxhdGVQYXN0ZScpICByZXR1cm4gb25EbGdFZGl0VGVtcGxhdGVQYXN0ZShpZCwgZXZlbnQpXHJcblxyXG5cdGlmIChvcCA9PT0gJ29uRGxnUGFzdGVTb3VyY2VQYXN0ZScpICByZXR1cm4gb25EbGdQYXN0ZVNvdXJjZVBhc3RlKGlkLCBldmVudClcclxuXHRpZiAob3AgPT09ICdvbkRsZ1Bhc3RlU291cmNlQ0InKSAgcmV0dXJuIG9uRGxnUGFzdGVTb3VyY2VDQihpZCwgZXZlbnQpICAgIFxyXG5cdGlmIChvcCA9PT0gJ29uRGxnUGFzdGVTb3VyY2VCdG4nKSB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnUGFzdGVTb3VyY2VCdG4oaWQpfVxyXG5cclxuXHRpZiAob3AgPT09ICdvbkRsZ1Byb2ZpbGVDbGVhbnVwQnRuJykge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJldHVybiBvbkRsZ1Byb2ZpbGVDbGVhbnVwQnRuKGlkKX1cclxuXHJcblx0aWYgKG9wID09PSAnb25EbGdTZWxlY3RUZW1wbGF0ZUZsdCcpIHJldHVybiBvbkRsZ1NlbGVjdFRlbXBsYXRlRmx0KClcclxuXHRpZiAob3AgPT09ICdvbkRsZ1NlbGVjdFRlbXBsYXRlVHJTZWwnKSByZXR1cm4gb25EbGdTZWxlY3RUZW1wbGF0ZVRyU2VsKGVsZW1lbnQpXHJcblx0aWYgKG9wID09PSAnb25EbGdTZWxlY3RUZW1wbGF0ZUJ0bicpIHtldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXR1cm4gb25EbGdTZWxlY3RUZW1wbGF0ZUJ0bihpZCl9XHJcblxyXG5cdGlmIChvcCA9PT0gJ29uRGxnTm9uZScpIHtldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXR1cm59XHJcblx0XHJcblx0Y29uc29sZS5lcnJvciAoJ01pc3NpbmcgZGF0YS1vcCBvbiAnLCBlbGVtZW50KVxyXG59XHJcblxyXG5mdW5jdGlvbiBpc0VkaXRQYWdlKCkge1xyXG5cdHJldHVybiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVNwZWNpYWw6RWRpdFBlcnNvbiYuKi9nKSB8fFxyXG5cdCAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPS4qJmFjdGlvbj1lZGl0LiovZykgfHxcclxuXHRcdFx0d2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPS4qJmFjdGlvbj1zdWJtaXQuKi9nKSk7XHJcbn1cclxuXHJcbi8qIEluaXRpYWxpemF0aW9uICovXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCd3dHBsdXMnLCAocmVzdWx0KSA9PiB7XHJcblx0aWYgKHJlc3VsdC53dHBsdXMgJiYgaXNFZGl0UGFnZSgpKSB7XHJcblx0XHR0Yi5uYW1lU3BhY2UgPSAoZG9jdW1lbnQudGl0bGUuc3RhcnRzV2l0aCgnRWRpdCBQZXJzb24gJykpID8gJ1Byb2ZpbGUnIDogJydcclxuXHRcdGxldCB3ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaDEgPiAuY29weVdpZGdldCcpXHJcblx0XHRpZiAodykge1xyXG5cdFx0XHR0Yi53aWtpdHJlZUlEID0gdy5nZXRBdHRyaWJ1dGUoJ2RhdGEtY29weS10ZXh0Jyk7XHJcblx0XHR9XHJcblx0XHR0Yi5lbFRleHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIndwVGV4dGJveDFcIik7XHJcblx0XHR0Yi5lbEJpcnRoTG9jYXRpb24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1CaXJ0aExvY2F0aW9uXCIpO1xyXG5cdFx0dGIuZWxEZWF0aExvY2F0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtRGVhdGhMb2NhdGlvblwiKTtcclxuXHJcblx0XHR0Yi5lbFN1bW1hcnkgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIndwU3VtbWFyeVwiKTtcclxuXHRcdHRiLmVsRW5oYW5jZWQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRvZ2dsZU1hcmt1cENvbG9yXCIpO1xyXG5cclxuXHRcdGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidG9vbGJhclwiKS5pbnNlcnRBZGphY2VudEhUTUwoJ2JlZm9yZWVuZCcsICc8ZGlhbG9nIGlkPVwid3RQbHVzRGxnXCI+PC9kaWFsb2c+JylcclxuXHRcdHRiLmVsRGxnID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ3dFBsdXNEbGdcIik7XHJcblxyXG5cdFx0Ly8gTG9hZGluZyBvZiB0ZW1wbGF0ZSBkZWZpbml0aW9uIEZyb20gU3RvcmFnZVxyXG5cdFx0Y2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsnYWxsdGVtcGxhdGVzJ10sIGZ1bmN0aW9uKGEpe1xyXG5cdFx0XHRpZiAoYS5hbGx0ZW1wbGF0ZXMgJiYgYS5hbGx0ZW1wbGF0ZXMudmVyc2lvbikge1xyXG5cdFx0XHRcdC8vIElzIGluIHN0b3JhZ2VcclxuXHRcdFx0XHR0Yi50ZW1wbGF0ZXMgPSBhLmFsbHRlbXBsYXRlcy50ZW1wbGF0ZXM7XHJcblx0XHRcdFx0dGIuY2xlYW51cCA9IGEuYWxsdGVtcGxhdGVzLmNsZWFudXA7IGlmICghKHRiLmNsZWFudXApKSB7dGIuY2xlYW51cCA9IFtdfTtcclxuXHRcdFx0XHR0Yi5sb2NhdGlvbnMgPSBhLmFsbHRlbXBsYXRlcy5sb2NhdGlvbnM7IGlmICghKHRiLmxvY2F0aW9ucykpIHt0Yi5sb2NhdGlvbnMgPSBbXX07XHJcblx0XHRcdFx0dGIuc291cmNlcyA9IGEuYWxsdGVtcGxhdGVzLnNvdXJjZXM7IGlmICghKHRiLnNvdXJjZXMpKSB7dGIuc291cmNlcyA9IFtdfTtcclxuXHRcdFx0XHR0Yi5kYXRhVmVyc2lvbiA9IG5ldyBEYXRlKGEuYWxsdGVtcGxhdGVzLnZlcnNpb24pO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKCdTdG9yYWdlOiAnICsgdGIuZGF0YVZlcnNpb24gKyAnLCAnICsgIHRiLnRlbXBsYXRlcy5sZW5ndGggKyAnIHRlbXBsYXRlcycgKyAnLCAnICsgIHRiLmNsZWFudXAubGVuZ3RoICsgJyBjbGVhbnVwJyArICcsICcgKyB0Yi5sb2NhdGlvbnMubGVuZ3RoICsgJyBsb2NhdGlvbnMnICsgJywgJyArIHRiLnNvdXJjZXMubGVuZ3RoICsgJyBzb3VyY2VzLicpXHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0Ly8gTm90IGluIHN0b3JhZ2VcclxuXHRcdFx0XHR0Yi5kYXRhVmVyc2lvbiA9IG5ldyBEYXRlKFwiMjAwMC0wMS0wMVQwMDowMDowMCswMTowMFwiKTtcclxuXHRcdFx0fSBcclxuXHRcdFx0Ly8gTG9hZGluZyBvZiB0ZW1wbGF0ZSBkZWZpbml0aW9uIEZyb20gRXh0ZW5zaW9uXHJcblx0XHRcdGZldGNoKGNocm9tZS5ydW50aW1lLmdldFVSTChcImZlYXR1cmVzL3d0Ky90ZW1wbGF0ZXNFeHAuanNvblwiKSlcclxuXHRcdFx0LnRoZW4oKHJlc3ApID0+IHJlc3AuanNvbigpKVxyXG5cdFx0XHQudGhlbihqc29uRGF0YSA9PiB7XHJcblx0XHRcdFx0Y29uc3QgZCA9IG5ldyBEYXRlKGpzb25EYXRhLnZlcnNpb24pXHJcblx0XHRcdFx0aWYgKGQuZ2V0VGltZSAoKSA+IHRiLmRhdGFWZXJzaW9uLmdldFRpbWUgKCkpIHtcclxuXHRcdFx0XHRcdC8vIEV4dGVuc2lvbiBkZWZpbml0aW9uIGlzIG5ld2VyXHJcblx0XHRcdFx0XHR0Yi50ZW1wbGF0ZXMgPSBqc29uRGF0YS50ZW1wbGF0ZXM7XHJcblx0XHRcdFx0XHR0Yi5jbGVhbnVwID0ganNvbkRhdGEuY2xlYW51cDsgaWYgKCEodGIuY2xlYW51cCkpIHt0Yi5jbGVhbnVwID0gW119O1xyXG5cdFx0XHRcdFx0dGIubG9jYXRpb25zID0ganNvbkRhdGEubG9jYXRpb25zOyBpZiAoISh0Yi5sb2NhdGlvbnMpKSB7dGIubG9jYXRpb25zID0gW119O1xyXG5cdFx0XHRcdFx0dGIuc291cmNlcyA9IGpzb25EYXRhLnNvdXJjZXM7IGlmICghKHRiLnNvdXJjZXMpKSB7dGIuc291cmNlcyA9IFtdfTtcclxuXHRcdFx0XHRcdHRiLmRhdGFWZXJzaW9uID0gZDtcclxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKCdFeHRlbnNpb246ICcgKyB0Yi5kYXRhVmVyc2lvbiArICcsICcgKyAgdGIudGVtcGxhdGVzLmxlbmd0aCArICcgdGVtcGxhdGVzLicgKyAnLCAnICsgIHRiLmNsZWFudXAubGVuZ3RoICsgJyBjbGVhbnVwLicgKyAnLCAnICsgdGIubG9jYXRpb25zLmxlbmd0aCArICcgbG9jYXRpb25zJyArICcsICcgKyB0Yi5zb3VyY2VzLmxlbmd0aCArICcgc291cmNlcy4nKVxyXG5cdFx0XHRcdFx0Y2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcImFsbHRlbXBsYXRlc1wiOiBqc29uRGF0YX0pO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZiAodGIuZGF0YVZlcnNpb24uZ2V0VGltZSAoKSA8IG5ldyBEYXRlKCkuZ2V0VGltZSAoKSAtIDYgKiAzNjAwICogMTAwMCkge1xyXG5cdFx0XHRcdFx0Ly8gTG9hZGluZyBvZiB0ZW1wbGF0ZSBkZWZpbml0aW9uIEZyb20gV2ViXHJcblx0XHRcdFx0XHRmZXRjaChcImh0dHBzOi8vd2lraXRyZWUuc2Rtcy5zaS9jaHJvbWUvdGVtcGxhdGVzRXhwLmpzb25cIilcclxuXHRcdFx0XHRcdC50aGVuKChyZXNwKSA9PiByZXNwLmpzb24oKSlcclxuXHRcdFx0XHRcdC50aGVuKGpzb25EYXRhID0+IHtcclxuXHRcdFx0XHRcdFx0Y29uc3QgZCA9IG5ldyBEYXRlKGpzb25EYXRhLnZlcnNpb24pXHJcblx0XHRcdFx0XHRcdGlmIChkLmdldFRpbWUgKCkgPiB0Yi5kYXRhVmVyc2lvbi5nZXRUaW1lICgpKSB7XHJcblx0XHRcdFx0XHRcdFx0Ly8gV2ViIGRlZmluaXRpb24gaXMgbmV3ZXJcclxuXHRcdFx0XHRcdFx0XHR0Yi50ZW1wbGF0ZXMgPSBqc29uRGF0YS50ZW1wbGF0ZXM7XHJcblx0XHRcdFx0XHRcdFx0dGIuY2xlYW51cCA9IGpzb25EYXRhLmNsZWFudXA7IGlmICghKHRiLmNsZWFudXApKSB7dGIuY2xlYW51cCA9IFtdfTtcclxuXHRcdFx0XHRcdFx0XHR0Yi5sb2NhdGlvbnMgPSBqc29uRGF0YS5sb2NhdGlvbnM7IGlmICghKHRiLmxvY2F0aW9ucykpIHt0Yi5sb2NhdGlvbnMgPSBbXX07XHJcblx0XHRcdFx0XHRcdFx0dGIuc291cmNlcyA9IGpzb25EYXRhLnNvdXJjZXM7IGlmICghKHRiLnNvdXJjZXMpKSB7dGIuc291cmNlcyA9IFtdfTtcclxuXHRcdFx0XHRcdFx0XHR0Yi5kYXRhVmVyc2lvbiA9IGQ7XHJcblx0XHRcdFx0XHRcdFx0Y29uc29sZS5sb2coJ1dlYjogJyArIHRiLmRhdGFWZXJzaW9uICsgJywgJyArICB0Yi50ZW1wbGF0ZXMubGVuZ3RoICsgJyB0ZW1wbGF0ZXMuJyArICcsICcgKyAgdGIuY2xlYW51cC5sZW5ndGggKyAnIGNsZWFudXAuJyArICcsICcgKyB0Yi5sb2NhdGlvbnMubGVuZ3RoICsgJyBsb2NhdGlvbnMnICsgJywgJyArIHRiLnNvdXJjZXMubGVuZ3RoICsgJyBzb3VyY2VzLicpXHJcblx0XHRcdFx0XHRcdFx0Y2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcImFsbHRlbXBsYXRlc1wiOiBqc29uRGF0YX0pO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9KVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSlcclxuXHRcdH0pO1xyXG5cdH1cclxufSk7XHJcblxyXG4vKlxyXG5Ub2RvLiBBZGQgc3BhY2VzIG9uIGVkaXQgY29tbWVudC5cclxuMS4wLjRcclxuICAqIENvbmRlbnNlZCB0ZW1wbGF0ZSBpbmZvIGluIHRoZSBkaWFsb2cgdG8gb2NjdXB5IGxlc3Mgc3BhY2UuXHJcbiAgKiBBZnRlciBzd2l0Y2hpbmcgb2ZmIHRoZSBlbmhhbmNlZCBlZGl0b3IgdGhlIHNlbGVjdGVkIGZ1bmN0aW9uIGlzIGV4ZWN1dGVkIGlmIHBvc3NpYmxlLlxyXG4gICogQXV0b0NvcnJlY3Rpb24gb2YgbG9jYXRpb24gZmllbGRzLlxyXG4gICogQWRkZWQgQXV0b0NvcnJlY3Rpb24gdG8gY2F0ZWdvcmllc1xyXG4gICogSW1wbGVtZW50ZWQgY2FzZSBpbnNlbnNpdGl2ZSBpbiB0ZW1wbGF0ZSBwYXJhbWV0ZXIgbmFtZXMgcmVjb2duaXRpb25cclxuKi9cclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuXHJcbiQuZm4uaG92ZXJEZWxheSA9IGZ1bmN0aW9uIChuKSB7XHJcbiAgdmFyIGUgPSB7IGRlbGF5SW46IDMwMCwgZGVsYXlPdXQ6IDMwMCwgaGFuZGxlckluOiBmdW5jdGlvbiAoKSB7fSwgaGFuZGxlck91dDogZnVuY3Rpb24gKCkge30gfTtcclxuICByZXR1cm4gKFxyXG4gICAgKG4gPSAkLmV4dGVuZChlLCBuKSksXHJcbiAgICB0aGlzLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICB2YXIgZSxcclxuICAgICAgICB0LFxyXG4gICAgICAgIHUgPSAkKHRoaXMpO1xyXG4gICAgICB1LmhvdmVyKFxyXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIHQgJiYgY2xlYXJUaW1lb3V0KHQpLFxyXG4gICAgICAgICAgICAoZSA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgIG4uaGFuZGxlckluKHUpO1xyXG4gICAgICAgICAgICB9LCBuLmRlbGF5SW4pKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIGUgJiYgY2xlYXJUaW1lb3V0KGUpLFxyXG4gICAgICAgICAgICAodCA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgIG4uaGFuZGxlck91dCh1KTtcclxuICAgICAgICAgICAgfSwgbi5kZWxheU91dCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgIH0pXHJcbiAgKTtcclxufTtcclxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHRpZDogbW9kdWxlSWQsXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBfX3dlYnBhY2tfbW9kdWxlc19fO1xuXG4iLCJ2YXIgZGVmZXJyZWQgPSBbXTtcbl9fd2VicGFja19yZXF1aXJlX18uTyA9IChyZXN1bHQsIGNodW5rSWRzLCBmbiwgcHJpb3JpdHkpID0+IHtcblx0aWYoY2h1bmtJZHMpIHtcblx0XHRwcmlvcml0eSA9IHByaW9yaXR5IHx8IDA7XG5cdFx0Zm9yKHZhciBpID0gZGVmZXJyZWQubGVuZ3RoOyBpID4gMCAmJiBkZWZlcnJlZFtpIC0gMV1bMl0gPiBwcmlvcml0eTsgaS0tKSBkZWZlcnJlZFtpXSA9IGRlZmVycmVkW2kgLSAxXTtcblx0XHRkZWZlcnJlZFtpXSA9IFtjaHVua0lkcywgZm4sIHByaW9yaXR5XTtcblx0XHRyZXR1cm47XG5cdH1cblx0dmFyIG5vdEZ1bGZpbGxlZCA9IEluZmluaXR5O1xuXHRmb3IgKHZhciBpID0gMDsgaSA8IGRlZmVycmVkLmxlbmd0aDsgaSsrKSB7XG5cdFx0dmFyIFtjaHVua0lkcywgZm4sIHByaW9yaXR5XSA9IGRlZmVycmVkW2ldO1xuXHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuXHRcdGZvciAodmFyIGogPSAwOyBqIDwgY2h1bmtJZHMubGVuZ3RoOyBqKyspIHtcblx0XHRcdGlmICgocHJpb3JpdHkgJiAxID09PSAwIHx8IG5vdEZ1bGZpbGxlZCA+PSBwcmlvcml0eSkgJiYgT2JqZWN0LmtleXMoX193ZWJwYWNrX3JlcXVpcmVfXy5PKS5ldmVyeSgoa2V5KSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXy5PW2tleV0oY2h1bmtJZHNbal0pKSkpIHtcblx0XHRcdFx0Y2h1bmtJZHMuc3BsaWNlKGotLSwgMSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRmdWxmaWxsZWQgPSBmYWxzZTtcblx0XHRcdFx0aWYocHJpb3JpdHkgPCBub3RGdWxmaWxsZWQpIG5vdEZ1bGZpbGxlZCA9IHByaW9yaXR5O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihmdWxmaWxsZWQpIHtcblx0XHRcdGRlZmVycmVkLnNwbGljZShpLS0sIDEpXG5cdFx0XHR2YXIgciA9IGZuKCk7XG5cdFx0XHRpZiAociAhPT0gdW5kZWZpbmVkKSByZXN1bHQgPSByO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufTsiLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIvLyBubyBiYXNlVVJJXG5cbi8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4vLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbi8vIFtyZXNvbHZlLCByZWplY3QsIFByb21pc2VdID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxudmFyIGluc3RhbGxlZENodW5rcyA9IHtcblx0XCJjb250ZW50XCI6IDBcbn07XG5cbi8vIG5vIGNodW5rIG9uIGRlbWFuZCBsb2FkaW5nXG5cbi8vIG5vIHByZWZldGNoaW5nXG5cbi8vIG5vIHByZWxvYWRlZFxuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0XG5cbl9fd2VicGFja19yZXF1aXJlX18uTy5qID0gKGNodW5rSWQpID0+IChpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPT09IDApO1xuXG4vLyBpbnN0YWxsIGEgSlNPTlAgY2FsbGJhY2sgZm9yIGNodW5rIGxvYWRpbmdcbnZhciB3ZWJwYWNrSnNvbnBDYWxsYmFjayA9IChwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbiwgZGF0YSkgPT4ge1xuXHR2YXIgW2NodW5rSWRzLCBtb3JlTW9kdWxlcywgcnVudGltZV0gPSBkYXRhO1xuXHQvLyBhZGQgXCJtb3JlTW9kdWxlc1wiIHRvIHRoZSBtb2R1bGVzIG9iamVjdCxcblx0Ly8gdGhlbiBmbGFnIGFsbCBcImNodW5rSWRzXCIgYXMgbG9hZGVkIGFuZCBmaXJlIGNhbGxiYWNrXG5cdHZhciBtb2R1bGVJZCwgY2h1bmtJZCwgaSA9IDA7XG5cdGlmKGNodW5rSWRzLnNvbWUoKGlkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2lkXSAhPT0gMCkpKSB7XG5cdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG5cdFx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8obW9yZU1vZHVsZXMsIG1vZHVsZUlkKSkge1xuXHRcdFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLm1bbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihydW50aW1lKSB2YXIgcmVzdWx0ID0gcnVudGltZShfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblx0fVxuXHRpZihwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbikgcGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24oZGF0YSk7XG5cdGZvcig7aSA8IGNodW5rSWRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y2h1bmtJZCA9IGNodW5rSWRzW2ldO1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhpbnN0YWxsZWRDaHVua3MsIGNodW5rSWQpICYmIGluc3RhbGxlZENodW5rc1tjaHVua0lkXSkge1xuXHRcdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdWzBdKCk7XG5cdFx0fVxuXHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG5cdH1cblx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18uTyhyZXN1bHQpO1xufVxuXG52YXIgY2h1bmtMb2FkaW5nR2xvYmFsID0gc2VsZltcIndlYnBhY2tDaHVua3dpa2l0cmVlX2Jyb3dzZXJfZXh0ZW5zaW9uXCJdID0gc2VsZltcIndlYnBhY2tDaHVua3dpa2l0cmVlX2Jyb3dzZXJfZXh0ZW5zaW9uXCJdIHx8IFtdO1xuY2h1bmtMb2FkaW5nR2xvYmFsLmZvckVhY2god2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCAwKSk7XG5jaHVua0xvYWRpbmdHbG9iYWwucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2guYmluZChjaHVua0xvYWRpbmdHbG9iYWwpKTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm5jID0gdW5kZWZpbmVkOyIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgZGVwZW5kcyBvbiBvdGhlciBsb2FkZWQgY2h1bmtzIGFuZCBleGVjdXRpb24gbmVlZCB0byBiZSBkZWxheWVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18uTyh1bmRlZmluZWQsIFtcInZlbmRvclwiXSwgKCkgPT4gKF9fd2VicGFja19yZXF1aXJlX18oXCIuL3NyYy9jb250ZW50LmpzXCIpKSlcbl9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8oX193ZWJwYWNrX2V4cG9ydHNfXyk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=