/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css":
/*!************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css ***!
  \************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\n#editToolbarExt {\r\n\tdisplay: inline-block;\r\n}\r\n\r\n#editToolbarDiv {\r\n\tposition: relative;\r\n\tfloat: left;\r\n\tz-index: 10;\r\n}\r\n\r\n#editToolbarDiv:hover .editToolbarMenu0 {\r\n\tdisplay: block;\r\n}\r\n\r\n#editToolbarButton {\r\n\tcursor: pointer;\r\n\tborder: 1px solid #aaa;\r\n\tborder-radius: 3px;\r\n\tpadding: 2px;\r\n\tmargin: 1px;\r\n\tbackground-color: #eee;\r\n}\r\n\r\n.editToolbarMenu2 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu2>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu2>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* second level of menus */\r\n.editToolbarMenu1 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu1>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu1>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* first level of menus */\r\n.editToolbarMenu0 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tleft: 0px;\r\n\tlist-style: none;\r\n\tpadding: 1px;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n\tz-index: 10;\r\n}\r\n\r\n.editToolbarMenu0>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmin-width: 160px;\r\n\tmargin-bottom: 1px;\r\n\tfloat: left;\r\n\tz-index: 11;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n\ttext-align: left;\r\n\ttext-decoration: none;\r\n\tcursor: pointer;\r\n}\r\n\r\n.editToolbarMenu0>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* On hover, display the next level's menu */\r\n.editToolbarMenu0 li:hover>ul {\r\n\tdisplay: inline;\r\n}\r\n\r\n/* Menu Link Styles - Apply to all links inside the multi-level menu */\r\n.editToolbarMenu0 a {\r\n\tfont: normal 11px verdana, arial, sans-serif;\r\n\tcolor: #000000;\r\n\ttext-decoration: none !important;\r\n\tpadding: 0px 5px;\r\n\r\n\t/* Make the link cover the entire list item-container */\r\n\tdisplay: block;\r\n\tline-height: 24px;\r\n}\r\n\r\n.editToolbarMenu0 a:link {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:hover {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:visited {\r\n\tcolor: #000000 !important;\r\n}", "",{"version":3,"sources":["webpack://./src/core/editToolbar.css"],"names":[],"mappings":";AACA;CACC,qBAAqB;AACtB;;AAEA;CACC,kBAAkB;CAClB,WAAW;CACX,WAAW;AACZ;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,eAAe;CACf,sBAAsB;CACtB,kBAAkB;CAClB,YAAY;CACZ,WAAW;CACX,sBAAsB;AACvB;;AAEA;CACC,aAAa;CACb,kBAAkB;CAClB,SAAS;CACT,WAAW;CACX,YAAY;CACZ,gBAAgB;CAChB,UAAU;CACV,SAAS;CACT,sBAAsB;AACvB;;AAEA;CACC,kBAAkB;CAClB,YAAY;CACZ,kBAAkB;CAClB,sBAAsB;CACtB,sBAAsB;AACvB;;AAEA;CACC,mBAAmB;AACpB;;AAEA,0BAA0B;AAC1B;CACC,aAAa;CACb,kBAAkB;CAClB,SAAS;CACT,WAAW;CACX,YAAY;CACZ,gBAAgB;CAChB,UAAU;CACV,SAAS;CACT,sBAAsB;AACvB;;AAEA;CACC,kBAAkB;CAClB,YAAY;CACZ,kBAAkB;CAClB,sBAAsB;CACtB,sBAAsB;AACvB;;AAEA;CACC,mBAAmB;AACpB;;AAEA,yBAAyB;AACzB;CACC,aAAa;CACb,kBAAkB;CAClB,SAAS;CACT,gBAAgB;CAChB,YAAY;CACZ,SAAS;CACT,sBAAsB;CACtB,WAAW;AACZ;;AAEA;CACC,kBAAkB;CAClB,YAAY;CACZ,gBAAgB;CAChB,kBAAkB;CAClB,WAAW;CACX,WAAW;CACX,sBAAsB;CACtB,sBAAsB;CACtB,gBAAgB;CAChB,qBAAqB;CACrB,eAAe;AAChB;;AAEA;CACC,mBAAmB;AACpB;;AAEA,4CAA4C;AAC5C;CACC,eAAe;AAChB;;AAEA,sEAAsE;AACtE;CACC,4CAA4C;CAC5C,cAAc;CACd,gCAAgC;CAChC,gBAAgB;;CAEhB,uDAAuD;CACvD,cAAc;CACd,iBAAiB;AAClB;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,yBAAyB;AAC1B","sourcesContent":["\r\n#editToolbarExt {\r\n\tdisplay: inline-block;\r\n}\r\n\r\n#editToolbarDiv {\r\n\tposition: relative;\r\n\tfloat: left;\r\n\tz-index: 10;\r\n}\r\n\r\n#editToolbarDiv:hover .editToolbarMenu0 {\r\n\tdisplay: block;\r\n}\r\n\r\n#editToolbarButton {\r\n\tcursor: pointer;\r\n\tborder: 1px solid #aaa;\r\n\tborder-radius: 3px;\r\n\tpadding: 2px;\r\n\tmargin: 1px;\r\n\tbackground-color: #eee;\r\n}\r\n\r\n.editToolbarMenu2 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu2>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu2>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* second level of menus */\r\n.editToolbarMenu1 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\ttop: -1px;\r\n\tleft: 161px;\r\n\twidth: 160px;\r\n\tlist-style: none;\r\n\tpadding: 1;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.editToolbarMenu1>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmargin-bottom: 1px;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n}\r\n\r\n.editToolbarMenu1>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* first level of menus */\r\n.editToolbarMenu0 {\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tleft: 0px;\r\n\tlist-style: none;\r\n\tpadding: 1px;\r\n\tmargin: 0;\r\n\tvertical-align: middle;\r\n\tz-index: 10;\r\n}\r\n\r\n.editToolbarMenu0>li {\r\n\tposition: relative;\r\n\theight: 24px;\r\n\tmin-width: 160px;\r\n\tmargin-bottom: 1px;\r\n\tfloat: left;\r\n\tz-index: 11;\r\n\tbackground-color: #fff;\r\n\tborder: 1px solid #ccc;\r\n\ttext-align: left;\r\n\ttext-decoration: none;\r\n\tcursor: pointer;\r\n}\r\n\r\n.editToolbarMenu0>li:hover {\r\n\tbackground: #CCCCCC;\r\n}\r\n\r\n/* On hover, display the next level's menu */\r\n.editToolbarMenu0 li:hover>ul {\r\n\tdisplay: inline;\r\n}\r\n\r\n/* Menu Link Styles - Apply to all links inside the multi-level menu */\r\n.editToolbarMenu0 a {\r\n\tfont: normal 11px verdana, arial, sans-serif;\r\n\tcolor: #000000;\r\n\ttext-decoration: none !important;\r\n\tpadding: 0px 5px;\r\n\r\n\t/* Make the link cover the entire list item-container */\r\n\tdisplay: block;\r\n\tline-height: 24px;\r\n}\r\n\r\n.editToolbarMenu0 a:link {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:hover {\r\n\tcolor: #000000;\r\n}\r\n\r\n.editToolbarMenu0 a:visited {\r\n\tcolor: #000000 !important;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css":
/*!**********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css ***!
  \**********************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "menu#appsSubMenu {\r\n\tdisplay:none;\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tbackground-color:white !important;\t\r\n\toverflow:visible;\r\n}\r\nmenu#appsSubMenu a{\r\n\tmargin-left:-19.1em;\r\n\tbackground-color:white !important;\r\n\tborder:1px solid #ccc;\r\n\twidth:18em;\r\n\tdisplay:block;\r\n\tpadding:5px;\r\n\tfloat:none;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu a{\r\n\tmargin-left:-22.8em;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu {\r\n\tbackground-color:transparent !important;\r\n}\r\nmenu#appsSubMenu a:hover{\r\n\tbackground-color:#ffe270 !important;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/appsMenu/appsMenu.css"],"names":[],"mappings":"AAAA;CACC,YAAY;CACZ,iBAAiB;CACjB,KAAK;CACL,iCAAiC;CACjC,gBAAgB;AACjB;AACA;CACC,mBAAmB;CACnB,iCAAiC;CACjC,qBAAqB;CACrB,UAAU;CACV,aAAa;CACb,WAAW;CACX,UAAU;AACX;AACA;CACC,mBAAmB;AACpB;AACA;CACC,uCAAuC;AACxC;AACA;CACC,mCAAmC;AACpC","sourcesContent":["menu#appsSubMenu {\r\n\tdisplay:none;\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tbackground-color:white !important;\t\r\n\toverflow:visible;\r\n}\r\nmenu#appsSubMenu a{\r\n\tmargin-left:-19.1em;\r\n\tbackground-color:white !important;\r\n\tborder:1px solid #ccc;\r\n\twidth:18em;\r\n\tdisplay:block;\r\n\tpadding:5px;\r\n\tfloat:none;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu a{\r\n\tmargin-left:-22.8em;\r\n}\r\nbody.qa-body-js-on menu#appsSubMenu {\r\n\tbackground-color:transparent !important;\r\n}\r\nmenu#appsSubMenu a:hover{\r\n\tbackground-color:#ffe270 !important;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css ***!
  \**********************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "button.wikitreeturbo {\r\n    padding: 2px 10px;\r\n    font-family: monospace;\r\n    background-color: #eee;\r\n    color: #333;\r\n\tposition:absolute !important;\r\n\tmargin-left:-2.85em;\r\n\tmargin-top: -0.25em;\r\n}\r\nbutton.wikitreeturbo, button.wikitreeturbo:active {\r\n\ttop:auto !important;\r\n}\r\n#descendantsContainer li.collapse {\r\n\tposition:relative;\r\n}", "",{"version":3,"sources":["webpack://./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css"],"names":[],"mappings":"AAAA;IACI,iBAAiB;IACjB,sBAAsB;IACtB,sBAAsB;IACtB,WAAW;CACd,4BAA4B;CAC5B,mBAAmB;CACnB,mBAAmB;AACpB;AACA;CACC,mBAAmB;AACpB;AACA;CACC,iBAAiB;AAClB","sourcesContent":["button.wikitreeturbo {\r\n    padding: 2px 10px;\r\n    font-family: monospace;\r\n    background-color: #eee;\r\n    color: #333;\r\n\tposition:absolute !important;\r\n\tmargin-left:-2.85em;\r\n\tmargin-top: -0.25em;\r\n}\r\nbutton.wikitreeturbo, button.wikitreeturbo:active {\r\n\ttop:auto !important;\r\n}\r\n#descendantsContainer li.collapse {\r\n\tposition:relative;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css":
/*!**********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css ***!
  \**********************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "body.darkMode *,\r\nbody.darkMode html body,\r\nbody.darkMode .wrapper,\r\nbody.darkMode a,\r\nbody.darkMode a:link,\r\nbody.darkMode a:visited,\r\nbody.darkMode .SMALL,\r\nbody.darkMode .small,\r\nbody.darkMode .pureCssMenum,\r\nbody.darkMode .home,\r\nbody.darkMode .person,\r\nbody.darkMode .add,\r\nbody.darkMode .find,\r\nbody.darkMode .help,\r\nbody.darkMode strong,\r\nbody.darkMode a.viewsi,\r\nbody.darkMode ul.views a,\r\nbody.darkMode ul.pure-css-menu,\r\nbody.darkMode a:link.activeProfile,\r\nbody.darkMode a:hover.activeProfile,\r\nbody.darkMode a:visited.activeProfile a:active.activeProfile,\r\nbody.darkMode iframe.cke_wysiwyg_frame,\r\nbody.darkMode #cke_61_contents,\r\nbody.darkMode body.blackLinks strong,\r\nbody.darkMode menu#appsSubMenu a,\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode {\r\n  font-weight: 400;\r\n  background-color: #36393f !important;\r\n  color: #dcddde !important;\r\n}\r\nbody.darkMode .button,\r\nbody.darkMode div.pad form button,\r\nbody.darkMode input.button.green.search {\r\n  padding: 12px 12px !important;\r\n}\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode span#showHideDescendants {\r\n  padding: 6px !important;\r\n}\r\nbody.darkMode .qa-vote-buttons input {\r\n  padding: 0 !important;\r\n}\r\nbody.darkMode .large,\r\nbody.darkMode ul,\r\nbody.darkMode li {\r\n  background: none !important;\r\n}\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode div.stripes,\r\nbody.darkMode div.getstarted {\r\n  background-image: none !important;\r\n}\r\nbody.darkMode menu#appsSubMenu a:hover {\r\n  background: navy !important;\r\n}\r\nbody.darkMode ul.profile-tabs li,\r\nbody.darkMode {\r\n  font-weight: bold;\r\n  border: 1px solid white;\r\n}\r\nbody.darkMode ul.pureCssMenu ul li a:hover {\r\n  background-color: navy !important;\r\n}\r\nbody.darkMode .yourConnection,\r\nbody.darkMode #yourConnection {\r\n  background: white !important;\r\n}\r\nbody.darkMode #yourConnection {\r\n  margin-right: 4px;\r\n}\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode button,\r\nbody.darkMode input[type=\"button\"],\r\nbody.darkMode a.button,\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode span#showHideDescendants {\r\n  border: 1px solid white !important;\r\n}\r\nbody.darkMode button.copyWidget,\r\nbody.darkMode div.comment-actions button.button,\r\nbody.darkMode span.commentContainerToggle button,\r\nbody.darkMode div.qa-vote-buttons input,\r\nbody.darkMode input.qa-favorite-button,\r\nbody.darkMode #wtIDgo_go,\r\nbody.darkMode input.qa-form-light-button-reshow,\r\nbody.darkMode input.qa-form-light-button-hide,\r\nbody.darkMode input.qa-form-light-button-edit,\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  background: url(\"https://www.wikitree.com/images/icons/search-submit-icon.png\")\r\n    white !important;\r\n  font-size: 0;\r\n  top: -5px !important;\r\n}\r\nbody.darkMode input.qa-a-select-button {\r\n  background-image: url(\"https://www.wikitree.com/g2g/qa-theme/WikiTree/select-star.png\")\r\n    no-repeat !important;\r\n  border: 0 !important;\r\n  background-color: white !important;\r\n}\r\nbody.darkMode input.qa-form-light-button.qa-form-light-button-flag,\r\nbody.darkMode div.qa-vote-buttons qa-vote-buttons-net input {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode #header,\r\nbody.darkMode #footer {\r\n  background: #36393f;\r\n}\r\nbody.darkMode div.copyWidgetContainer,\r\nbody.darkMode div.copyWidgetContainerInner,\r\nbody.darkMode div.copyWidgetContainerInner button {\r\n  background: none !important;\r\n}\r\nbody.darkMode li.GREEN-ARROW {\r\n  background-blend-mode: color;\r\n}\r\nbody.darkMode div.qa-q-item-title a:link .checkmark,\r\nbody.darkMode span.qa-q-item-meta a.qa-q-item-what:link .checkmark {\r\n  color: #36393f !important;\r\n}\r\nbody.darkMode div.qa-nav-main a:hover,\r\nbody.darkMode div.qa-footer a:hover,\r\nbody.darkMode div.qa-nav-main a:visited:hover,\r\nbody.darkMode div.qa-footer a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:hover {\r\n  color: #36393f !important;\r\n  background: #dcddde !important;\r\n}\r\nbody.darkMode a[href*=\"wiki/Privacy\"] img,\r\nbody.darkMode img[src*=\"images/icons/privacy\"] {\r\n  background-color: #9196a1 !important;\r\n  border-radius: 50%;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/darkMode/darkMode.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;;;;;;;;;;;;;EA2BE,gBAAgB;EAChB,oCAAoC;EACpC,yBAAyB;AAC3B;AACA;;;EAGE,6BAA6B;AAC/B;AACA;;;EAGE,uBAAuB;AACzB;AACA;EACE,qBAAqB;AACvB;AACA;;;EAGE,2BAA2B;AAC7B;AACA;;;EAGE,iCAAiC;AACnC;AACA;EACE,2BAA2B;AAC7B;AACA;;EAEE,iBAAiB;EACjB,uBAAuB;AACzB;AACA;EACE,iCAAiC;AACnC;AACA;;EAEE,4BAA4B;AAC9B;AACA;EACE,iBAAiB;AACnB;AACA;;;;;;EAME,kCAAkC;AACpC;AACA;;;;;;;;;;EAUE,oBAAoB;AACtB;AACA;EACE;oBACkB;EAClB,YAAY;EACZ,oBAAoB;AACtB;AACA;EACE;wBACsB;EACtB,oBAAoB;EACpB,kCAAkC;AACpC;AACA;;EAEE,oBAAoB;AACtB;AACA;;EAEE,mBAAmB;AACrB;AACA;;;EAGE,2BAA2B;AAC7B;AACA;EACE,4BAA4B;AAC9B;AACA;;EAEE,yBAAyB;AAC3B;AACA;;;;;;EAME,yBAAyB;EACzB,8BAA8B;AAChC;AACA;;EAEE,oCAAoC;EACpC,kBAAkB;AACpB","sourcesContent":["body.darkMode *,\r\nbody.darkMode html body,\r\nbody.darkMode .wrapper,\r\nbody.darkMode a,\r\nbody.darkMode a:link,\r\nbody.darkMode a:visited,\r\nbody.darkMode .SMALL,\r\nbody.darkMode .small,\r\nbody.darkMode .pureCssMenum,\r\nbody.darkMode .home,\r\nbody.darkMode .person,\r\nbody.darkMode .add,\r\nbody.darkMode .find,\r\nbody.darkMode .help,\r\nbody.darkMode strong,\r\nbody.darkMode a.viewsi,\r\nbody.darkMode ul.views a,\r\nbody.darkMode ul.pure-css-menu,\r\nbody.darkMode a:link.activeProfile,\r\nbody.darkMode a:hover.activeProfile,\r\nbody.darkMode a:visited.activeProfile a:active.activeProfile,\r\nbody.darkMode iframe.cke_wysiwyg_frame,\r\nbody.darkMode #cke_61_contents,\r\nbody.darkMode body.blackLinks strong,\r\nbody.darkMode menu#appsSubMenu a,\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode {\r\n  font-weight: 400;\r\n  background-color: #36393f !important;\r\n  color: #dcddde !important;\r\n}\r\nbody.darkMode .button,\r\nbody.darkMode div.pad form button,\r\nbody.darkMode input.button.green.search {\r\n  padding: 12px 12px !important;\r\n}\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode span#showHideDescendants {\r\n  padding: 6px !important;\r\n}\r\nbody.darkMode .qa-vote-buttons input {\r\n  padding: 0 !important;\r\n}\r\nbody.darkMode .large,\r\nbody.darkMode ul,\r\nbody.darkMode li {\r\n  background: none !important;\r\n}\r\nbody.darkMode div.stripes-1,\r\nbody.darkMode div.stripes,\r\nbody.darkMode div.getstarted {\r\n  background-image: none !important;\r\n}\r\nbody.darkMode menu#appsSubMenu a:hover {\r\n  background: navy !important;\r\n}\r\nbody.darkMode ul.profile-tabs li,\r\nbody.darkMode {\r\n  font-weight: bold;\r\n  border: 1px solid white;\r\n}\r\nbody.darkMode ul.pureCssMenu ul li a:hover {\r\n  background-color: navy !important;\r\n}\r\nbody.darkMode .yourConnection,\r\nbody.darkMode #yourConnection {\r\n  background: white !important;\r\n}\r\nbody.darkMode #yourConnection {\r\n  margin-right: 4px;\r\n}\r\nbody.darkMode input[type=\"submit\"],\r\nbody.darkMode button,\r\nbody.darkMode input[type=\"button\"],\r\nbody.darkMode a.button,\r\nbody.darkMode span.showHideTree,\r\nbody.darkMode span#showHideDescendants {\r\n  border: 1px solid white !important;\r\n}\r\nbody.darkMode button.copyWidget,\r\nbody.darkMode div.comment-actions button.button,\r\nbody.darkMode span.commentContainerToggle button,\r\nbody.darkMode div.qa-vote-buttons input,\r\nbody.darkMode input.qa-favorite-button,\r\nbody.darkMode #wtIDgo_go,\r\nbody.darkMode input.qa-form-light-button-reshow,\r\nbody.darkMode input.qa-form-light-button-hide,\r\nbody.darkMode input.qa-form-light-button-edit,\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode input[name=\"wpSearch\"] {\r\n  background: url(\"https://www.wikitree.com/images/icons/search-submit-icon.png\")\r\n    white !important;\r\n  font-size: 0;\r\n  top: -5px !important;\r\n}\r\nbody.darkMode input.qa-a-select-button {\r\n  background-image: url(\"https://www.wikitree.com/g2g/qa-theme/WikiTree/select-star.png\")\r\n    no-repeat !important;\r\n  border: 0 !important;\r\n  background-color: white !important;\r\n}\r\nbody.darkMode input.qa-form-light-button.qa-form-light-button-flag,\r\nbody.darkMode div.qa-vote-buttons qa-vote-buttons-net input {\r\n  border: 0 !important;\r\n}\r\nbody.darkMode #header,\r\nbody.darkMode #footer {\r\n  background: #36393f;\r\n}\r\nbody.darkMode div.copyWidgetContainer,\r\nbody.darkMode div.copyWidgetContainerInner,\r\nbody.darkMode div.copyWidgetContainerInner button {\r\n  background: none !important;\r\n}\r\nbody.darkMode li.GREEN-ARROW {\r\n  background-blend-mode: color;\r\n}\r\nbody.darkMode div.qa-q-item-title a:link .checkmark,\r\nbody.darkMode span.qa-q-item-meta a.qa-q-item-what:link .checkmark {\r\n  color: #36393f !important;\r\n}\r\nbody.darkMode div.qa-nav-main a:hover,\r\nbody.darkMode div.qa-footer a:hover,\r\nbody.darkMode div.qa-nav-main a:visited:hover,\r\nbody.darkMode div.qa-footer a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:visited:hover,\r\nbody.darkMode div.qa-nav-sub a:hover {\r\n  color: #36393f !important;\r\n  background: #dcddde !important;\r\n}\r\nbody.darkMode a[href*=\"wiki/Privacy\"] img,\r\nbody.darkMode img[src*=\"images/icons/privacy\"] {\r\n  background-color: #9196a1 !important;\r\n  border-radius: 50%;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css ***!
  \****************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#distanceFromYou {\r\n  font-size: 0.5em;\r\n  font-weight: bold;\r\n  padding: 0.2em;\r\n  border: 2px solid forestgreen;\r\n  border-radius: 50%;\r\n  width: 3em;\r\n  text-align: center;\r\n  background: white;\r\n  opacity: 0.8;\r\n  z-index: 1;\r\n  cursor:default;\r\n}\r\nbutton.copyWidget {\r\n  z-index: 10;\r\n}\r\n\r\n#yourRelationshipText {\r\n  display: inline-block;\r\n  border: 1px solid green;\r\n  border-bottom: 2px solid forestgreen;\r\n  border-right: 2px solid forestgreen;\r\n  padding: 0.5em;\r\n  border-radius: 0.5em;\r\n  margin: 0.1em 1em 1em;\r\n  font-weight: bold;\r\n}\r\n#yourCommonAncestor {\r\n  margin: auto;\r\n  padding: 0;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li {\r\n  display: block;\r\n  margin: auto;\r\n  padding: auto;\r\n  list-style: none;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li:nth-child(n + 3) {\r\n  display: none;\r\n}\r\n#yourRelationshipText {\r\n  position: relative;\r\n  background: whitesmoke;\r\n}\r\n#showMoreAncestors {\r\n  position: absolute;\r\n  font-size: 0.8em;\r\n  padding: 0.5em;\r\n  top: -0.5em;\r\n  right: -0.5em;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/features/distanceAndRelationship/distanceAndRelationship.css"],"names":[],"mappings":"AAAA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,cAAc;EACd,6BAA6B;EAC7B,kBAAkB;EAClB,UAAU;EACV,kBAAkB;EAClB,iBAAiB;EACjB,YAAY;EACZ,UAAU;EACV,cAAc;AAChB;AACA;EACE,WAAW;AACb;;AAEA;EACE,qBAAqB;EACrB,uBAAuB;EACvB,oCAAoC;EACpC,mCAAmC;EACnC,cAAc;EACd,oBAAoB;EACpB,qBAAqB;EACrB,iBAAiB;AACnB;AACA;EACE,YAAY;EACZ,UAAU;AACZ;AACA;EACE,cAAc;EACd,YAAY;EACZ,aAAa;EACb,gBAAgB;AAClB;AACA;EACE,aAAa;AACf;AACA;EACE,kBAAkB;EAClB,sBAAsB;AACxB;AACA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,cAAc;EACd,WAAW;EACX,aAAa;AACf","sourcesContent":["#distanceFromYou {\r\n  font-size: 0.5em;\r\n  font-weight: bold;\r\n  padding: 0.2em;\r\n  border: 2px solid forestgreen;\r\n  border-radius: 50%;\r\n  width: 3em;\r\n  text-align: center;\r\n  background: white;\r\n  opacity: 0.8;\r\n  z-index: 1;\r\n  cursor:default;\r\n}\r\nbutton.copyWidget {\r\n  z-index: 10;\r\n}\r\n\r\n#yourRelationshipText {\r\n  display: inline-block;\r\n  border: 1px solid green;\r\n  border-bottom: 2px solid forestgreen;\r\n  border-right: 2px solid forestgreen;\r\n  padding: 0.5em;\r\n  border-radius: 0.5em;\r\n  margin: 0.1em 1em 1em;\r\n  font-weight: bold;\r\n}\r\n#yourCommonAncestor {\r\n  margin: auto;\r\n  padding: 0;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li {\r\n  display: block;\r\n  margin: auto;\r\n  padding: auto;\r\n  list-style: none;\r\n}\r\n#yourRelationshipText #yourCommonAncestor > li:nth-child(n + 3) {\r\n  display: none;\r\n}\r\n#yourRelationshipText {\r\n  position: relative;\r\n  background: whitesmoke;\r\n}\r\n#showMoreAncestors {\r\n  position: absolute;\r\n  font-size: 0.8em;\r\n  padding: 0.5em;\r\n  top: -0.5em;\r\n  right: -0.5em;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css":
/*!************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css ***!
  \************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#myDrafts {\r\n\tposition: absolute;\r\n\ttop: 100px;\r\n\tleft: 50%;\r\n\tz-index: 11000;\r\n\tbackground: white;\r\n\tborder: 2px solid forestgreen;\r\n\tborder-radius: 1em;\r\n\tbox-shadow: 0.1em 0.1em 0.1em 0.1em lightgreen;\r\n\tpadding: 1em;\r\n\tdisplay: none;\r\n\ttext-align: left;\r\n}\r\n\r\n#myDrafts x {\r\n\tfont-weight: bold;\r\n\tposition: absolute;\r\n\ttop: 0;\r\n\tright: 0.2em;\r\n\tcursor: pointer;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tmargin: 0.5em;\r\n}\r\n\r\n#myDrafts table td {\r\n\tpadding: 0.5em;\r\n\tlist-style: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n#myDrafts a {\r\n\tmargin: 0.2em 0.5em;\r\n}\r\n\r\n#myDrafts a.button:active {\r\n\tcolor: gold;\r\n\tbackground: rgb(0, 100, 0);\r\n}\r\n\r\n#myDrafts p {\r\n\ttext-align: center;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tpadding: 0.5em;\r\n}\r\n\r\nbody.qa-body-js-on .button.small {\r\n\tpadding: 7px 15px;\r\n\tbackground: #25422d;\r\n\tborder: 0;\r\n\toutline: none;\r\n\tcursor: pointer;\r\n\ttext-align: center;\r\n\ttext-transform: uppercase;\r\n\tborder-radius: 5px;\r\n\tcolor: #fff;\r\n\tfont-weight: normal;\r\n\ttext-decoration: none !important;\r\n\tcursor: pointer;\r\n\tline-height: normal;\r\n}", "",{"version":3,"sources":["webpack://./src/features/draftList/draftList.css"],"names":[],"mappings":"AAAA;CACC,kBAAkB;CAClB,UAAU;CACV,SAAS;CACT,cAAc;CACd,iBAAiB;CACjB,6BAA6B;CAC7B,kBAAkB;CAClB,8CAA8C;CAC9C,YAAY;CACZ,aAAa;CACb,gBAAgB;AACjB;;AAEA;CACC,iBAAiB;CACjB,kBAAkB;CAClB,MAAM;CACN,YAAY;CACZ,eAAe;AAChB;;AAEA;CACC,aAAa;AACd;;AAEA;CACC,cAAc;CACd,gBAAgB;CAChB,mBAAmB;AACpB;;AAEA;CACC,mBAAmB;AACpB;;AAEA;CACC,WAAW;CACX,0BAA0B;AAC3B;;AAEA;CACC,kBAAkB;AACnB;;AAEA;CACC,cAAc;AACf;;AAEA;CACC,iBAAiB;CACjB,mBAAmB;CACnB,SAAS;CACT,aAAa;CACb,eAAe;CACf,kBAAkB;CAClB,yBAAyB;CACzB,kBAAkB;CAClB,WAAW;CACX,mBAAmB;CACnB,gCAAgC;CAChC,eAAe;CACf,mBAAmB;AACpB","sourcesContent":["#myDrafts {\r\n\tposition: absolute;\r\n\ttop: 100px;\r\n\tleft: 50%;\r\n\tz-index: 11000;\r\n\tbackground: white;\r\n\tborder: 2px solid forestgreen;\r\n\tborder-radius: 1em;\r\n\tbox-shadow: 0.1em 0.1em 0.1em 0.1em lightgreen;\r\n\tpadding: 1em;\r\n\tdisplay: none;\r\n\ttext-align: left;\r\n}\r\n\r\n#myDrafts x {\r\n\tfont-weight: bold;\r\n\tposition: absolute;\r\n\ttop: 0;\r\n\tright: 0.2em;\r\n\tcursor: pointer;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tmargin: 0.5em;\r\n}\r\n\r\n#myDrafts table td {\r\n\tpadding: 0.5em;\r\n\tlist-style: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n#myDrafts a {\r\n\tmargin: 0.2em 0.5em;\r\n}\r\n\r\n#myDrafts a.button:active {\r\n\tcolor: gold;\r\n\tbackground: rgb(0, 100, 0);\r\n}\r\n\r\n#myDrafts p {\r\n\ttext-align: center;\r\n}\r\n\r\n#myDrafts h2 {\r\n\tpadding: 0.5em;\r\n}\r\n\r\nbody.qa-body-js-on .button.small {\r\n\tpadding: 7px 15px;\r\n\tbackground: #25422d;\r\n\tborder: 0;\r\n\toutline: none;\r\n\tcursor: pointer;\r\n\ttext-align: center;\r\n\ttext-transform: uppercase;\r\n\tborder-radius: 5px;\r\n\tcolor: #fff;\r\n\tfont-weight: normal;\r\n\ttext-decoration: none !important;\r\n\tcursor: pointer;\r\n\tline-height: normal;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/familyGroup/familyGroup.css":
/*!****************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/familyGroup/familyGroup.css ***!
  \****************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css":
/*!**********************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css ***!
  \**********************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#timeline.wrap, .familySheet.wrap{\r\n\twidth:80%;\r\n\twhite-space:normal;\r\n}\r\n#timeline {\r\n\twhite-space:nowrap;\r\n\theight:auto;\r\n\tposition:absolute;\r\n\twidth:auto;\r\n\tleft:10%;\r\n\tz-index:4000;\r\n\tbackground:white;\r\n\tborder:3px solid forestgreen;\r\n\tborder-radius:1em;\r\n\tbox-shadow:1em 1em 1em #ccc;\r\n\tpadding:0.3em;\r\n\tdisplay:none;\r\n\tcursor:move;\r\n}\r\n#timelineTable td{\r\n\tpadding:0.3em;\r\n}\r\n#timelineTable caption{\r\n\tfont-size:1.5em;\r\n\tfont-weight:bold;\r\n}\r\n.tlAge,.tlBioAge{\r\n\ttext-align:center;\r\n}\r\nth.tlBioAge{\r\n\ttext-align:center;\r\n}\r\n.tlEventName{\r\n\ttext-align:center;\r\n}\r\n.tlDate{\r\n\twhite-space:nowrap;\r\n}\r\n#timeline x, .familySheet x{\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tright:0.5em;\r\n\tfont-weight:bold;\r\n\tcursor:pointer;\r\n}\r\n#timeline w, .familySheet w{\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tleft:0.5em;\r\n\tfont-weight:bold;\r\n\tcursor:pointer;\r\n}\r\n#timeline .BioPerson, #timeline .marriage{\r\n\tfont-weight:bold;\r\n}\r\n#timeline tr.BioPerson.Birth{\r\n\tborder-top:1px solid forestgreen;\r\n}\r\n#timeline tr.BioPerson.Death{\r\n\tborder-bottom:1px solid forestgreen;\r\n}\r\n#timelineTable {\r\n\twidth:98%;\r\n\tmargin:auto;\r\n}", "",{"version":3,"sources":["webpack://./src/features/familyTimeline/familyTimeline.css"],"names":[],"mappings":"AAAA;CACC,SAAS;CACT,kBAAkB;AACnB;AACA;CACC,kBAAkB;CAClB,WAAW;CACX,iBAAiB;CACjB,UAAU;CACV,QAAQ;CACR,YAAY;CACZ,gBAAgB;CAChB,4BAA4B;CAC5B,iBAAiB;CACjB,2BAA2B;CAC3B,aAAa;CACb,YAAY;CACZ,WAAW;AACZ;AACA;CACC,aAAa;AACd;AACA;CACC,eAAe;CACf,gBAAgB;AACjB;AACA;CACC,iBAAiB;AAClB;AACA;CACC,iBAAiB;AAClB;AACA;CACC,iBAAiB;AAClB;AACA;CACC,kBAAkB;AACnB;AACA;CACC,iBAAiB;CACjB,KAAK;CACL,WAAW;CACX,gBAAgB;CAChB,cAAc;AACf;AACA;CACC,iBAAiB;CACjB,KAAK;CACL,UAAU;CACV,gBAAgB;CAChB,cAAc;AACf;AACA;CACC,gBAAgB;AACjB;AACA;CACC,gCAAgC;AACjC;AACA;CACC,mCAAmC;AACpC;AACA;CACC,SAAS;CACT,WAAW;AACZ","sourcesContent":["#timeline.wrap, .familySheet.wrap{\r\n\twidth:80%;\r\n\twhite-space:normal;\r\n}\r\n#timeline {\r\n\twhite-space:nowrap;\r\n\theight:auto;\r\n\tposition:absolute;\r\n\twidth:auto;\r\n\tleft:10%;\r\n\tz-index:4000;\r\n\tbackground:white;\r\n\tborder:3px solid forestgreen;\r\n\tborder-radius:1em;\r\n\tbox-shadow:1em 1em 1em #ccc;\r\n\tpadding:0.3em;\r\n\tdisplay:none;\r\n\tcursor:move;\r\n}\r\n#timelineTable td{\r\n\tpadding:0.3em;\r\n}\r\n#timelineTable caption{\r\n\tfont-size:1.5em;\r\n\tfont-weight:bold;\r\n}\r\n.tlAge,.tlBioAge{\r\n\ttext-align:center;\r\n}\r\nth.tlBioAge{\r\n\ttext-align:center;\r\n}\r\n.tlEventName{\r\n\ttext-align:center;\r\n}\r\n.tlDate{\r\n\twhite-space:nowrap;\r\n}\r\n#timeline x, .familySheet x{\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tright:0.5em;\r\n\tfont-weight:bold;\r\n\tcursor:pointer;\r\n}\r\n#timeline w, .familySheet w{\r\n\tposition:absolute;\r\n\ttop:0;\r\n\tleft:0.5em;\r\n\tfont-weight:bold;\r\n\tcursor:pointer;\r\n}\r\n#timeline .BioPerson, #timeline .marriage{\r\n\tfont-weight:bold;\r\n}\r\n#timeline tr.BioPerson.Birth{\r\n\tborder-top:1px solid forestgreen;\r\n}\r\n#timeline tr.BioPerson.Death{\r\n\tborder-bottom:1px solid forestgreen;\r\n}\r\n#timelineTable {\r\n\twidth:98%;\r\n\tmargin:auto;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css":
/*!************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css ***!
  \************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".wrongPeriod {\r\n\tbackground: #ffe6ea;\r\n}\r\n\r\n.familyLoc.rightPeriod {\r\n\tbackground: #DAF7A6;\r\n}\r\n\r\n.familyLoc2.rightPeriod {\r\n\tbackground: lightgreen;\r\n}\r\n\r\n.autocomplete-suggestions div.currentSelectedLocation {\r\n\tbackground: #DCDCDC !important;\r\n}\r\n\r\ninput[name='mMarriageLocation'] {\r\n\twidth: 100%;\r\n}", "",{"version":3,"sources":["webpack://./src/features/locationsHelper/locationsHelper.css"],"names":[],"mappings":"AAAA;CACC,mBAAmB;AACpB;;AAEA;CACC,mBAAmB;AACpB;;AAEA;CACC,sBAAsB;AACvB;;AAEA;CACC,8BAA8B;AAC/B;;AAEA;CACC,WAAW;AACZ","sourcesContent":[".wrongPeriod {\r\n\tbackground: #ffe6ea;\r\n}\r\n\r\n.familyLoc.rightPeriod {\r\n\tbackground: #DAF7A6;\r\n}\r\n\r\n.familyLoc2.rightPeriod {\r\n\tbackground: lightgreen;\r\n}\r\n\r\n.autocomplete-suggestions div.currentSelectedLocation {\r\n\tbackground: #DCDCDC !important;\r\n}\r\n\r\ninput[name='mMarriageLocation'] {\r\n\twidth: 100%;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css":
/*!***************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css ***!
  \***************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\ntr.trSelect:hover { \r\n  background: #ffe270;; \r\n}\r\n\r\ntr.trSelected { \r\n  background: #CCCCCC !important; \r\n}\r\n\r\n::placeholder {\r\n  color:    #bbb;\r\n}\r\n\r\n/* dialog formatting  */\r\n\r\ndialog {\r\n  max-width: 600px;\r\n}  \r\n\r\ndialog input[type=\"text\"] {\r\n  min-width: 350px;\r\n  padding: 4px 4px;\r\n  margin: 2px;\r\n}\r\ndialog button, dialog .button{\r\n  padding: 8px 20px;\r\n  margin: 5px;\r\n}\r\ntd button{\r\n  padding: 5px 5px;\r\n  margin: 3px;\r\n  font-size: 14px;\r\n}\r\ndialog select{\r\n  overflow: auto;\r\n  background: unset;  \r\n}\r\ndialog textarea{\r\n  width: 100%;\r\n  margin: 5px;\r\n}\r\n\r\n.wtPlusRequired {\r\n  background-color: palevioletred;\r\n}\r\n.wtPlusPreferred {\r\n  background-color: palegreen;\r\n}\r\n.wtPlusOptional {\r\n  background-color: palegoldenrod;\r\n}\r\n.wtPlusDeprecated{\r\n  background-color:  lightgrey;\r\n  text-decoration-line: line-through;\r\n}\r\n\r\n.wtPlusLegend{\r\n  display: none;\r\n  background: white;\r\n  color: black;\r\n  text-align: left;\r\n  font-size: 14px;\r\n  text-transform: none;\r\n  position: absolute;\r\n  bottom: 65px;\r\n  left: 25px;\r\n  padding: 10px;\r\n  border: 1px solid black;\r\n  line-height: 35px;\r\n}\r\n\r\n#wtPlusLegendBtn:hover .wtPlusLegend{\r\n  display: block;\r\n}\r\n\r\n", "",{"version":3,"sources":["webpack://./src/features/wt+/wtPlus.css"],"names":[],"mappings":";AACA;EACE,mBAAmB;AACrB;;AAEA;EACE,8BAA8B;AAChC;;AAEA;EACE,cAAc;AAChB;;AAEA,uBAAuB;;AAEvB;EACE,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;EAChB,gBAAgB;EAChB,WAAW;AACb;AACA;EACE,iBAAiB;EACjB,WAAW;AACb;AACA;EACE,gBAAgB;EAChB,WAAW;EACX,eAAe;AACjB;AACA;EACE,cAAc;EACd,iBAAiB;AACnB;AACA;EACE,WAAW;EACX,WAAW;AACb;;AAEA;EACE,+BAA+B;AACjC;AACA;EACE,2BAA2B;AAC7B;AACA;EACE,+BAA+B;AACjC;AACA;EACE,4BAA4B;EAC5B,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,iBAAiB;EACjB,YAAY;EACZ,gBAAgB;EAChB,eAAe;EACf,oBAAoB;EACpB,kBAAkB;EAClB,YAAY;EACZ,UAAU;EACV,aAAa;EACb,uBAAuB;EACvB,iBAAiB;AACnB;;AAEA;EACE,cAAc;AAChB","sourcesContent":["\r\ntr.trSelect:hover { \r\n  background: #ffe270;; \r\n}\r\n\r\ntr.trSelected { \r\n  background: #CCCCCC !important; \r\n}\r\n\r\n::placeholder {\r\n  color:    #bbb;\r\n}\r\n\r\n/* dialog formatting  */\r\n\r\ndialog {\r\n  max-width: 600px;\r\n}  \r\n\r\ndialog input[type=\"text\"] {\r\n  min-width: 350px;\r\n  padding: 4px 4px;\r\n  margin: 2px;\r\n}\r\ndialog button, dialog .button{\r\n  padding: 8px 20px;\r\n  margin: 5px;\r\n}\r\ntd button{\r\n  padding: 5px 5px;\r\n  margin: 3px;\r\n  font-size: 14px;\r\n}\r\ndialog select{\r\n  overflow: auto;\r\n  background: unset;  \r\n}\r\ndialog textarea{\r\n  width: 100%;\r\n  margin: 5px;\r\n}\r\n\r\n.wtPlusRequired {\r\n  background-color: palevioletred;\r\n}\r\n.wtPlusPreferred {\r\n  background-color: palegreen;\r\n}\r\n.wtPlusOptional {\r\n  background-color: palegoldenrod;\r\n}\r\n.wtPlusDeprecated{\r\n  background-color:  lightgrey;\r\n  text-decoration-line: line-through;\r\n}\r\n\r\n.wtPlusLegend{\r\n  display: none;\r\n  background: white;\r\n  color: black;\r\n  text-align: left;\r\n  font-size: 14px;\r\n  text-transform: none;\r\n  position: absolute;\r\n  bottom: 65px;\r\n  left: 25px;\r\n  padding: 10px;\r\n  border: 1px solid black;\r\n  line-height: 35px;\r\n}\r\n\r\n#wtPlusLegendBtn:hover .wtPlusLegend{\r\n  display: block;\r\n}\r\n\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/core/editToolbar.css":
/*!**********************************!*\
  !*** ./src/core/editToolbar.css ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./editToolbar.css */ "./node_modules/css-loader/dist/cjs.js!./src/core/editToolbar.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_editToolbar_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/appsMenu/appsMenu.css":
/*!********************************************!*\
  !*** ./src/features/appsMenu/appsMenu.css ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./appsMenu.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/appsMenu/appsMenu.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_appsMenu_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css":
/*!********************************************************************************!*\
  !*** ./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./collapsibleDescendantsTree.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/darkMode/darkMode.css":
/*!********************************************!*\
  !*** ./src/features/darkMode/darkMode.css ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./darkMode.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/darkMode/darkMode.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_darkMode_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/distanceAndRelationship/distanceAndRelationship.css":
/*!**************************************************************************!*\
  !*** ./src/features/distanceAndRelationship/distanceAndRelationship.css ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./distanceAndRelationship.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/distanceAndRelationship/distanceAndRelationship.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/draftList/draftList.css":
/*!**********************************************!*\
  !*** ./src/features/draftList/draftList.css ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./draftList.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/draftList/draftList.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_draftList_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/familyGroup/familyGroup.css":
/*!**************************************************!*\
  !*** ./src/features/familyGroup/familyGroup.css ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_familyGroup_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./familyGroup.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/familyGroup/familyGroup.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_familyGroup_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_familyGroup_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_familyGroup_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_familyGroup_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/familyTimeline/familyTimeline.css":
/*!********************************************************!*\
  !*** ./src/features/familyTimeline/familyTimeline.css ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./familyTimeline.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/familyTimeline/familyTimeline.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_familyTimeline_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/locationsHelper/locationsHelper.css":
/*!**********************************************************!*\
  !*** ./src/features/locationsHelper/locationsHelper.css ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./locationsHelper.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/locationsHelper/locationsHelper.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_locationsHelper_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/features/wt+/wtPlus.css":
/*!*************************************!*\
  !*** ./src/features/wt+/wtPlus.css ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!./wtPlus.css */ "./node_modules/css-loader/dist/cjs.js!./src/features/wt+/wtPlus.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_wtPlus_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/content.js":
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/common */ "./src/core/common.js");
/* harmony import */ var _features_akaNameLinks_akaNameLinks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./features/akaNameLinks/akaNameLinks */ "./src/features/akaNameLinks/akaNameLinks.js");
/* harmony import */ var _features_appsMenu_appsMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./features/appsMenu/appsMenu */ "./src/features/appsMenu/appsMenu.js");
/* harmony import */ var _features_collapsibleDescendantsTree_collapsibleDescendantsTree__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./features/collapsibleDescendantsTree/collapsibleDescendantsTree */ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js");
/* harmony import */ var _features_darkMode_darkMode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./features/darkMode/darkMode */ "./src/features/darkMode/darkMode.js");
/* harmony import */ var _features_distanceAndRelationship_distanceAndRelationship__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./features/distanceAndRelationship/distanceAndRelationship */ "./src/features/distanceAndRelationship/distanceAndRelationship.js");
/* harmony import */ var _features_draftList_draftList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./features/draftList/draftList */ "./src/features/draftList/draftList.js");
/* harmony import */ var _features_familyGroup_familyGroup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./features/familyGroup/familyGroup */ "./src/features/familyGroup/familyGroup.js");
/* harmony import */ var _features_familyTimeline_familyTimeline__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./features/familyTimeline/familyTimeline */ "./src/features/familyTimeline/familyTimeline.js");
/* harmony import */ var _features_locationsHelper_locationsHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./features/locationsHelper/locationsHelper */ "./src/features/locationsHelper/locationsHelper.js");
/* harmony import */ var _features_printerfriendly_printerfriendly__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./features/printerfriendly/printerfriendly */ "./src/features/printerfriendly/printerfriendly.js");
/* harmony import */ var _features_randomProfile_randomProfile__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./features/randomProfile/randomProfile */ "./src/features/randomProfile/randomProfile.js");
/* harmony import */ var _features_sourcepreview_sourcepreview__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./features/sourcepreview/sourcepreview */ "./src/features/sourcepreview/sourcepreview.js");
/* harmony import */ var _features_spacepreview_spacepreview__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./features/spacepreview/spacepreview */ "./src/features/spacepreview/spacepreview.js");
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _core_editToolbar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./core/editToolbar */ "./src/core/editToolbar.js");

















(0,_core_common__WEBPACK_IMPORTED_MODULE_0__.createTopMenu)();


/***/ }),

/***/ "./src/core/common.js":
/*!****************************!*\
  !*** ./src/core/common.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createProfileSubmenuLink": () => (/* binding */ createProfileSubmenuLink),
/* harmony export */   "createTopMenu": () => (/* binding */ createTopMenu),
/* harmony export */   "createTopMenuItem": () => (/* binding */ createTopMenuItem),
/* harmony export */   "extractRelatives": () => (/* binding */ extractRelatives),
/* harmony export */   "familyArray": () => (/* binding */ familyArray),
/* harmony export */   "getRelatives": () => (/* binding */ getRelatives),
/* harmony export */   "isOK": () => (/* binding */ isOK),
/* harmony export */   "pageCategory": () => (/* binding */ pageCategory),
/* harmony export */   "pageG2G": () => (/* binding */ pageG2G),
/* harmony export */   "pageHelp": () => (/* binding */ pageHelp),
/* harmony export */   "pageProfile": () => (/* binding */ pageProfile),
/* harmony export */   "pageSpace": () => (/* binding */ pageSpace),
/* harmony export */   "pageSpecial": () => (/* binding */ pageSpecial),
/* harmony export */   "pageTemplate": () => (/* binding */ pageTemplate)
/* harmony export */ });
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


let pageProfile = false;
let pageHelp = false;
let pageSpecial = false;
let pageCategory = false;
let pageTemplate = false;
let pageSpace = false;
let pageG2G = false;

if (
    window.location.pathname.match(/(\/wiki\/)\w[^:]*-[0-9]*/g) ||
    window.location.href.match(/\?title\=\w[^:]+-[0-9]+/g)
  ) {
      // Is a Profile Page
	pageProfile = true;
} else if (window.location.pathname.match(/(\/wiki\/)Help:*/g)) {
	// Is a Help Page
	pageHelp = true;
} else if (window.location.pathname.match(/(\/wiki\/)Special:*/g)) {
	// Is a Special Page
	pageSpecial = true;
} else if (window.location.pathname.match(/(\/wiki\/)Category:*/g)) {
	// Is a Category Page
	pageCategory = true;
} else if (window.location.pathname.match(/(\/wiki\/)Template:*/g)) {
	// Is a Template Page
	pageTemplate = true;
} else if (window.location.pathname.match(/(\/wiki\/)Space:*/g)) {
	// Is a Space Page
	pageSpace = true;
} else if (window.location.pathname.match(/\/g2g\//g)) {
	// Is a G2G page
	pageG2G = true;
}

// Add wte class to body to let WikiTree BEE know not to add the same functions
document.querySelector("body").classList.add("wte");

/**
 * Creates a new menu item in the Apps dropdown menu.
 *
 */
function createTopMenuItem(options) {
  let title = options.title;
  let name = options.name;
  let id = options.id;
  let url = options.url;

  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#wte-topMenu").append(`<li>
        <a id="${id}" class="pureCssMenui" title="${title}">${name}</a>
    </li>`);
}

// Add a link to the short list of links below the tabs
function createProfileSubmenuLink(options) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.views.viewsm")
    .eq(0)
    .append(
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(
        `<li class='viewsi'><a title='${options.title}' href='${options.url}' id='${options.id}'>${options.text}</a></li>`
      )
    );
  let links = jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.views.viewsm:first li");
  // Re-sort the links into alphabetical order
  links.sort(function (a, b) {
    return jquery__WEBPACK_IMPORTED_MODULE_0___default()(a).text().localeCompare(jquery__WEBPACK_IMPORTED_MODULE_0___default()(b).text());
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.views.viewsm").eq(0).append(links);
}

function createTopMenu() {
  const newUL = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<ul class='pureCssMenu' id='wte-topMenuUL'></ul>");
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu").eq(0).after(newUL);
  newUL.append(`<li>
        <a class="pureCssMenui0">
            <span>App Features</span>
        </a>
        <ul class="pureCssMenum" id="wte-topMenu"></ul>
    </li>`);
}

// Used in familyTimeline, familyGroup, locationsHelper
async function getRelatives(id, fields = "*") {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: {
        action: "getRelatives",
        keys: id,
        fields: fields,
        getParents: 1,
        getSiblings: 1,
        getSpouses: 1,
        getChildren: 1,
      },
    });
    return result[0].items[0].person;
  } catch (error) {
    console.error(error);
  }
}

// Used in familyTimeline, familyGroup, locationsHelper
// Make the family member arrays easier to handle
function extractRelatives(rel, theRelation = false) {
  let people = [];
  if (typeof rel == undefined || rel == null) {
    return false;
  }
  const pKeys = Object.keys(rel);
  pKeys.forEach(function (pKey) {
    var aPerson = rel[pKey];
    if (theRelation != false) {
      aPerson.Relation = theRelation;
    }
    people.push(aPerson);
  });
  return people;
}

// Used in familyTimeline, familyGroup, locationsHelper
function familyArray(person) {
  // This is a person from getRelatives()
  const rels = ["Parents", "Siblings", "Spouses", "Children"];
  let familyArr = [person];
  rels.forEach(function (rel) {
    const relation = rel.replace(/s$/, "").replace(/ren$/, "");
    familyArr = familyArr.concat(extractRelatives(person[rel], relation));
  });
  return familyArr;
}

function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

// Check that a value is OK
// Used in familyTimeline and familyGroup
function isOK(thing) {
  const excludeValues = [
    "",
    null,
    "null",
    "0000-00-00",
    "unknown",
    "Unknown",
    "undefined",
    undefined,
    "0000",
    "0",
    0,
  ];
  if (!excludeValues.includes(thing)) {
    if (isNumeric(thing)) {
      return true;
    } else {
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default().type(thing) === "string") {
        const nanMatch = thing.match(/NaN/);
        if (nanMatch == null) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  } else {
    return false;
  }
}


/***/ }),

/***/ "./src/core/editToolbar.js":
/*!*********************************!*\
  !*** ./src/core/editToolbar.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "editToolbarApp": () => (/* binding */ editToolbarApp),
/* harmony export */   "editToolbarWiki": () => (/* binding */ editToolbarWiki)
/* harmony export */ });
/* harmony import */ var _editToolbarCategoryOptions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editToolbarCategoryOptions */ "./src/core/editToolbarCategoryOptions.js");
/* harmony import */ var _editToolbarGenericOptions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbarGenericOptions */ "./src/core/editToolbarGenericOptions.js");
/* harmony import */ var _editToolbarProfileOptions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./editToolbarProfileOptions */ "./src/core/editToolbarProfileOptions.js");
/* harmony import */ var _editToolbarTemplateOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./editToolbarTemplateOptions */ "./src/core/editToolbarTemplateOptions.js");
/* harmony import */ var _editToolbarSpaceOptions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./editToolbarSpaceOptions */ "./src/core/editToolbarSpaceOptions.js");
/* harmony import */ var _editToolbar_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./editToolbar.css */ "./src/core/editToolbar.css");







let editToolbarOptions = []

/* Common events for links */
function editToolbarWiki(params) {
	window.open('https://www.wikitree.com/wiki/' + params.wiki, '_blank')
}

function editToolbarApp(params) {
	let w = document.querySelector('h1 > .copyWidget') 
	let wikitreeID = w.getAttribute('data-copy-text');
	window.open('https://apps.wikitree.com/apps/' + params.app + '?wikitreeid=' + wikitreeID, '_blank')
}

/* Finds the clicked item in editToolbarOptions */
function editToolbarFindItem(items, name) {
	if (items && items.length) {
		for (var item of items) {
			if (item.button) {
				let result = editToolbarFindItem(item.items, name)
				if (result) { return result }
			} else if (name.toUpperCase() === item.title.toUpperCase()) {
				return item
			} else {
				let result = editToolbarFindItem(item.items, name)
				if (result) { return result }
			}
		}
	}
}

/* main event handler */
function editToolbarEvent(event) {
	let element = event.srcElement
	const id = element.dataset.id
	event.preventDefault();
	let item = editToolbarFindItem(editToolbarOptions, id);
	if (item) {
		return item.call(item.params || {})
	} else {
		alert("Unknown event " + id)
	}
}

/* creates html of the drop down menu */
function editToolbarCreateHtml(items, featureEnabled, level) {
	let result = '';
	if (items && items.length) {
		for (var item of items) {
			if ((!item.featureid) || featureEnabled[item.featureid]) {
				let s = editToolbarCreateHtml(item.items, featureEnabled, level + 1)
				if (s || item.call) {
					if (item.button) {
						result +=
							'<div id="editToolbarDiv">' +
							'<p id="editToolbarButton">' + item.button + '</p>' +
							// '<img src="/photo.php/8/89/WikiTree_Images-22.png" height="22" id="editToolbarButton" />' + 
							s +
							'</div>';
					} else {
						result += '<li><a '
						result += (item.hint ? 'title= "' + item.hint + '"' : "");
						result += 'href="javascript:void(0);" class="editToolbarClick" data-id="' + item.title + '"';
						result += '>' + item.title + (item.items ? " &gt;&gt;" : "") + "</a>";
						result += s;
						result += '</li>';
					}
				}
			}
		}
		if ((level >= 0) && (result))
			result = '<ul class="editToolbarMenu' + level + '">' + result + '</ul>';
	}
	return result;
}

/* creates menu next to the toolbar  */
function editToolbarCreate(options) {
	editToolbarOptions = options
	chrome.storage.sync.get(null, (featureEnabled) => {
		var menuHTML = editToolbarCreateHtml(editToolbarOptions, featureEnabled, -1);
		document.getElementById("toolbar").insertAdjacentHTML('afterend', '<div id="editToolbarExt">' + menuHTML + '</div>')
		document.querySelectorAll('a.editToolbarClick').forEach(i => i.addEventListener('click', event => editToolbarEvent(event)))
	})
}

if (window.location.href.match(/\/index.php\?title=Special:EditPerson&.*/g)) {
    editToolbarCreate(_editToolbarProfileOptions__WEBPACK_IMPORTED_MODULE_2__["default"]);

} else if (window.location.href.match(/\/index.php\?title=Category:.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=Category:.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarCategoryOptions__WEBPACK_IMPORTED_MODULE_0__["default"]);

} else if (window.location.href.match(/\/index.php\?title=Template:.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=Template:.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarTemplateOptions__WEBPACK_IMPORTED_MODULE_3__["default"]);

} else if (window.location.href.match(/\/index.php\?title=Space:.*&action=edit.*/g) ||
		   window.location.href.match(/\/index.php\?title=Space:.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarSpaceOptions__WEBPACK_IMPORTED_MODULE_4__["default"]);

} else if (window.location.href.match(/\/index.php\?title=.*&action=edit.*/g) ||
           window.location.href.match(/\/index.php\?title=.*&action=submit.*/g)) {
	editToolbarCreate(_editToolbarGenericOptions__WEBPACK_IMPORTED_MODULE_1__["default"]);
}


/***/ }),

/***/ "./src/core/editToolbarCategoryOptions.js":
/*!************************************************!*\
  !*** ./src/core/editToolbarCategoryOptions.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{
				title: "Category templates", items: [
					{ featureid: "wtplus", title: "Aka", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Aka" } },
					{ featureid: "wtplus", title: "Top Level", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Top Level" } },
					{ featureid: "wtplus", title: "Geographic Location", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Geographic Location" } }
				]
			},
			{ "featureid": "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "CIB", items: [
			{ featureid: "wtplus", title: "Cemetery", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Cemetery" } },
			{ featureid: "wtplus", title: "Location", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Location" } },
			{ featureid: "wtplus", title: "Add any CIB", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "CategoryInfoBox" } },
			{
				title: "Cemeteries", items: [
					{ featureid: "wtplus", title: "Cemetery", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Cemetery" } },
					{ featureid: "wtplus", title: "Cemetery Group", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox CemeteryGroup" } }
				]
			},
			{
				title: "Religion", items: [
					{ featureid: "wtplus", title: "Religious Institution Group", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox ReligiousInstitutionGroup" } }
				]
			},
			{
				title: "Maintenance", items: [
					{ featureid: "wtplus", title: "Maintenance", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Maintenance" } },
					{ featureid: "wtplus", title: "Needs", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Needs" } },
					{ featureid: "wtplus", title: "Needs GEDCOM Cleanup", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox NeedsGEDCOMCleanup" } },
					{ featureid: "wtplus", title: "Unconnected", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Unconnected" } },
					{ featureid: "wtplus", title: "Unsourced", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Unsourced" } }
				]
			},
			{
				title: "Others", items: [
					{ featureid: "wtplus", title: "Location", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Location" } },
					{ featureid: "wtplus", title: "Migration", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox Migration" } },
					{ featureid: "wtplus", title: "One Name Study", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox OneNameStudy" } },
					{ featureid: "wtplus", title: "One Place Study", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox OnePlaceStudy" } },
					{ featureid: "wtplus", title: "CategoryInfoBox", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "CategoryInfoBox" } }
				]
			}
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } },
		]
	},
	{
		button: "EditBOT", items: [
			{ featureid: "wtplus", title: "Rename Category", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Rename Category" } },
			{ featureid: "wtplus", title: "Merge Category", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Merge Category" } },
			{ featureid: "wtplus", title: "Delete Category", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Delete Category" } },
			{ featureid: "wtplus", title: "Confirm for EditBOT", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditBOTConfirm" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Category_pages" } }
		]
	},
]);


/***/ }),

/***/ "./src/core/editToolbarGenericOptions.js":
/*!***********************************************!*\
  !*** ./src/core/editToolbarGenericOptions.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", 
			title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Other_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/core/editToolbarProfileOptions.js":
/*!***********************************************!*\
  !*** ./src/core/editToolbarProfileOptions.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Sources",
		items: [
			{ featureid: "wtplus", title: "Paste sources", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "PasteSource" } }
		]
	}, {
		button: "Templates",
		items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Add Project Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "Project Box" } },
			{ featureid: "wtplus", title: "Add Sticker", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "Sticker" } },
			{ featureid: "wtplus", title: "Add Research Note Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "Profile Box" } },
			{ featureid: "wtplus", title: "Add External links", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate", data: "External Link" } },
			{ featureid: "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	}, {
		button: "Biography",
		items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } }
		]
	}, {
		button: "Misc",
		items: [
			{
				title: "WikiTree Apps",
				items: [
					{ title: "DNA Confirmation", hint: "DNA Confirmation by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/DNAconf.php" } },
					{ title: "Ancestry Citation", hint: "Ancestry Citation by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/ancite.php" } },
					{ title: "Drouin Citer", hint: "Drouin Citer by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/drouinCite.php" } },
					{ title: "Surnames Generator", hint: "Surnames Generator by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/surnames.php" } },
					{ title: "Riksarkivet SVAR sources", hint: "Riksarkivet SVAR sources by Maria Lundholm", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "lundholm24/ref-making/ra-ref.php" } },
					{ title: "Arkiv Digital sources", hint: "Arkiv Digital sources by Maria Lundholm", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "lundholm24/ref-making/ad-ref.php" } },
					{ title: "Sveriges Dödbok sources", hint: "Sveriges Dödbok sources by Maria Lundholm", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "lundholm24/ref-making/sdb-ref.php" } },
					{ title: "Biography Generator", hint: "Biography Generator (for Open pr.) by Greg Shipley", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "shipley1223/Bio.html" } },
					{
						title: "Other Apps",
						items: [
							{ title: "Bio Check", hint: "Bio Check by Kay Knight", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "sands1865/biocheck/" } },
							{ title: "Fan Chart", hint: "Fan Chart by Greg Clarke", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarApp, params: { app: "clarke11007/fan.php" } }
						]
					}
				]
			},
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Profile_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/core/editToolbarSpaceOptions.js":
/*!*********************************************!*\
  !*** ./src/core/editToolbarSpaceOptions.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } },
			{ featureid: "wtplus", title: "Format Template Params", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } }
		]
	},
	{
		button: "Content", items: [
			{ featureid: "wtplus", title: "Automated corrections", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoUpdate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Other_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/core/editToolbarTemplateOptions.js":
/*!************************************************!*\
  !*** ./src/core/editToolbarTemplateOptions.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../features/wt+/contentEdit */ "./src/features/wt+/contentEdit.js");
/* harmony import */ var _editToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editToolbar */ "./src/core/editToolbar.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
	{
		button: "Templates", items: [
			{ featureid: "wtplus", title: "Format Parameters", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AutoFormat" } },
			{ featureid: "wtplus", title: "Edit Template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "EditTemplate" } },
			{ featureid: "wtplus", title: "Add TemplateParam", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "TemplateParam" } },
			{ featureid: "wtplus", title: "Add Documentation", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Documentation" } },
			{
				title: "Add Base Templates", items: [
					{ featureid: "wtplus", title: "Project Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Project Box" } },
					{ featureid: "wtplus", title: "Sticker", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Sticker" } },
					{ featureid: "wtplus", title: "Research Note Box", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Research Note Box" } }
				]
			},
			{
				title: "Add Other Templates", items: [
					{ featureid: "wtplus", title: "Project Box Instructions", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { template: "Project Box Instructions" } }
				]
			},
			{ featureid: "wtplus", title: "Add any template", call: _features_wt_contentEdit__WEBPACK_IMPORTED_MODULE_0__.wtPlus, params: { action: "AddTemplate" } }
		]
	},
	{
		button: "Misc", items: [
			{ featureid: "wtplus", title: "Help", call: _editToolbar__WEBPACK_IMPORTED_MODULE_1__.editToolbarWiki, params: { wiki: "Space:WikiTree_Plus_Chrome_Extension#On_Template_pages" } }
		]
	}
]);


/***/ }),

/***/ "./src/features/akaNameLinks/akaNameLinks.js":
/*!***************************************************!*\
  !*** ./src/features/akaNameLinks/akaNameLinks.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");



async function akaNames(){
// Make AKA last names clickable
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.profile").length){
        const nameBit = jquery__WEBPACK_IMPORTED_MODULE_0___default()(".VITALS").eq(0).find(".large");
        const nameText = nameBit.text();
        if (nameText.match("aka ")){
            const strongs = nameBit.find("strong");
            const lastStrong = strongs.eq(strongs.length-1);
            const akaText = lastStrong.text();
            const oAkaNames = akaText.split(",");
            lastStrong.text("");
            oAkaNames.forEach(function(akaName,i){
                jquery__WEBPACK_IMPORTED_MODULE_0___default()("<a href='https://www.wikitree.com/genealogy/"+akaName.trim()+"'>"+akaName.trim()+"</a>").appendTo(lastStrong);
                if (i+1<oAkaNames.length){
                    jquery__WEBPACK_IMPORTED_MODULE_0___default()("<span>, </span>").appendTo(lastStrong);
                }
            })
        }
    }
}

chrome.storage.sync.get('akaNameLinks', (result) => {
	if (result.akaNameLinks && _core_common__WEBPACK_IMPORTED_MODULE_1__.pageProfile == true) { 
        akaNames();
    }
})

/***/ }),

/***/ "./src/features/appsMenu/appsMenu.js":
/*!*******************************************!*\
  !*** ./src/features/appsMenu/appsMenu.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ "./node_modules/js-cookie/dist/js.cookie.mjs");
/* harmony import */ var _appsMenu_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./appsMenu.css */ "./src/features/appsMenu/appsMenu.css");




chrome.storage.sync.get('appsMenu', (result) => {
	if (result.appsMenu) {
		// Add a menu if WikiTree BEE hasn't already done so. 
		if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#appsSubMenu").length==0){
            addAppsMenu();
        }
	}
});

async function getAppsMenu(){
	try{
		const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({url: "https://wikitreebee.com/BEE.php?q=apps_menu", crossDomain: true, type: 'POST', dataType: 'json'})
		return result.apps_menu;
	} catch (error) {
		console.error(error);
	}
}

function attachAppsMenu(menu){
	const mWTID = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
	const appsList = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<menu class='subMenu' id='appsSubMenu'></menu>");
	menu.forEach(function(app){
		const appsLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<a class='pureCssMenui' href='"+app.URL.replace(/mWTID/,mWTID)+"'>"+app.title+"</a>");
		appsLi.appendTo(appsList);
	})
	appsList.appendTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").parent());
	const appsLink = jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").parent();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("ul.pureCssMenu.pureCssMenum a[href='/wiki/Help:Apps']").text("« Apps");
	appsLink.hover(function(){appsList.show();},function(){appsList.hide();})
}

function addAppsMenu(){	
	const d = new Date();
	let day = d.getUTCDate();
	let getMenu = false;
	// Store the date if it hasn't been stored
	if (!localStorage.appsMenuCheck){
		localStorage.setItem("appsMenuCheck",day);
	}
	// Store the date and update the menu if it's a new day.
	else if (day!=localStorage.appsMenuCheck){
		localStorage.setItem("appsMenuCheck",day);
		getMenu = true;
	}
	if (!localStorage.appsMenu || getMenu == true){
		getAppsMenu().then((menu)=>{
			attachAppsMenu(menu);
			// Store the menu.
			localStorage.setItem("appsMenu",JSON.stringify(menu));
		})
	} else {  // Or use the stored menu.
		attachAppsMenu(JSON.parse(localStorage.appsMenu));
	}
}

/***/ }),

/***/ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js":
/*!*******************************************************************************!*\
  !*** ./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _collapsibleDescendantsTree_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./collapsibleDescendantsTree.css */ "./src/features/collapsibleDescendantsTree/collapsibleDescendantsTree.css");




chrome.storage.sync.get('collapsibleDescendantsTree', (result) => {
	if (result.collapsibleDescendantsTree && _core_common__WEBPACK_IMPORTED_MODULE_1__.pageProfile == true) { 

    // Look out for the appearance of new list items in the descendantsContainer
    const descendantsObserver = new MutationObserver(function (mutations_list) {
      mutations_list.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (added_node) {
        if (added_node.tagName == "OL") {
        theLIS = jquery__WEBPACK_IMPORTED_MODULE_0___default()(added_node).find("li");
        theLIS.each(function (index, thing) {
            setTimeout(function () {
            createDescendantsButton(index, thing);
              }, 10);
            })
          }
        });
      });
    });

    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#descendantsContainer").length) {
        descendantsObserver.observe(document.querySelector("#descendantsContainer"),
        { subtree: true, childList: true });
    }

    // Add buttons
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_Descendants").length) {
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("ol").length) {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("ol li").each(function (index, thing) {
          setTimeout(function () {
            createDescendantsButton(index, thing);
          }, 10);
        })
      }
    }

    async function createDescendantsButton(n, li) {
    // Attach class to avoid adding button more than once
      if (li.classList.contains('collapse')) {
        return;
      }
      if (!isNextSiblingDiv(li)) {
        return;
      }
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(li).addClass('collapse');
      const button = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<button class='wikitreeturbo'>-</button>");
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(button).click(toggleCollapse);
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(li).prepend(button);
    }

    function isNextSiblingDiv(el) {
      if(el.nextElementSibling) {
        if (el.nextElementSibling.tagName=="DIV") {
          return true;
        }
      }
      return false;
    }

    function toggleCollapse(e) {
      const s = jquery__WEBPACK_IMPORTED_MODULE_0___default()(e.target).text();
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(e.target).text(s=='-' ? '+' : '-');
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(e.target.parentElement.nextElementSibling).toggle();
    }
    
  }
});


/***/ }),

/***/ "./src/features/darkMode/darkMode.js":
/*!*******************************************!*\
  !*** ./src/features/darkMode/darkMode.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _darkMode_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darkMode.css */ "./src/features/darkMode/darkMode.css");



chrome.storage.sync.get("darkMode", (result) => {
  if (result.darkMode) {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body").addClass("darkMode");
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='wikitree-logo.png']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-white.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='wikitree-small.png']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-small-white.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='Wiki-Tree.gif']").attr(
      "src",
      chrome.runtime.getURL("images/wikitree-logo-white-G2G.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src*='G2G.gif']").attr(
      "src",
      chrome.runtime.getURL("images/G2G-transparent.png")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1:contains(Connection Finder)").parent().css("background-image", "");
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.darkMode.page-Main_Page div.sixteen.columns.top").css(
      "background-image",
      "url(" + chrome.runtime.getURL("images/tree-white.png") + ")"
    );

    // Add code to iframes on merging comparison page.
    if (window.location.href.match("Special:MergePerson")) {
      setTimeout(function () {
        var iframes = document.querySelectorAll("iframe");
        iframes.forEach(function (frame) {
          let linkEl = document.createElement("link");
          linkEl.rel = "stylesheet";
          linkEl.href = chrome.runtime.getURL("features/darkMode/darkMode.css");
          linkEl.type = "text/css";
          let oDocument = frame.contentWindow.document;
          let theHead = oDocument.getElementsByTagName("head")[0];
          theHead.appendChild(linkEl);
          oDocument.getElementsByTagName("body")[0].classList.add("darkMode");
          let logo = oDocument.querySelector("img[src*='wikitree-small.png']");
          if (logo) {
            logo.setAttribute(
              "src",
              chrome.runtime.getURL("images/wikitree-logo-small-white.png")
            );
          }
        });
      }, 700);
    }
  }
});


/***/ }),

/***/ "./src/features/distanceAndRelationship/distanceAndRelationship.js":
/*!*************************************************************************!*\
  !*** ./src/features/distanceAndRelationship/distanceAndRelationship.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ "./node_modules/js-cookie/dist/js.cookie.mjs");
/* harmony import */ var dexie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! dexie */ "./node_modules/dexie/dist/modern/dexie.mjs");
/* harmony import */ var _distanceAndRelationship_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./distanceAndRelationship.css */ "./src/features/distanceAndRelationship/distanceAndRelationship.css");





chrome.storage.sync.get("distanceAndRelationship", (result) => {
  if (
    result.distanceAndRelationship &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.BEE").length == 0 &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    const profileID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
    const userID = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
    var db = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("ConnectionFinderResults");
    db.version(1).stores({
      distance: "[userId+id]",
      connection: "[userId+id]",
    });
    db.open().then(function (db) {
      db.distance
        .get({ userId: userID, id: profileID })
        .then(function (result) {
          if (result == undefined) {
            initDistanceAndRelationship(userID, profileID);
          } else {
            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#distanceFromYou").length == 0) {
              const profileName = jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 span[itemprop='name']").text();
              jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
                jquery__WEBPACK_IMPORTED_MODULE_0___default()(
                  `<span id='distanceFromYou' title='${profileName} is ${result.distance} degrees from you. \nClick to refresh.'>${result.distance}°</span>`
                )
              );

              jquery__WEBPACK_IMPORTED_MODULE_0___default()("#distanceFromYou").click(function (e) {
                e.preventDefault();
                jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).fadeOut("slow").remove();
                jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").fadeOut("slow").remove();
                initDistanceAndRelationship(userID, profileID);
              });

              var rdb = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("RelationshipFinderResults");
              rdb.version(1).stores({
                relationship: "[userId+id]",
              });
              rdb.open().then(function (rdb) {
                rdb.relationship
                  .get({ userId: userID, id: profileID })
                  .then(function (result) {
                    if (result != undefined) {
                      if (result.relationship != "") {
                        if (
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").length == 0 &&
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".ancestorTextText").length == 0 &&
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#ancestorListBox").length == 0
                        ) {
                          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").remove();
                          addRelationshipText(
                            result.relationship,
                            result.commonAncestors
                          );
                        }
                      }
                    } else {
                      doRelationshipText(userID, profileID);
                    }
                  });
              });
            }
          }
        });
    });
  }
});

async function getProfile(id, fields = "*") {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: { action: "getProfile", key: id, fields: fields },
    });
    return result[0].profile;
  } catch (error) {
    console.error(error);
  }
}

async function getConnectionFinderResult(id1, id2, relatives = 0) {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://www.wikitree.com/index.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      data: {
        title: "Special:Connection",
        action: "connect",
        person1Name: id1,
        person2Name: id2,
        relation: relatives,
        ignoreIds: "",
      },
      type: "POST",
      dataType: "json",
      success: function (data) {},
      error: function (error) {
        console.log(error);
      },
    });
    return result;
  } catch (error) {
    console.error(error);
  }
}

async function getRelationshipFinderResult(id1, id2) {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
      url: "https://www.wikitree.com/index.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      data: {
        title: "Special:Relationship",
        action: "getRelationship",
        person1_name: id1,
        person2_name: id2,
      },
      type: "POST",
      dataType: "json",
      success: function (data) {},
      error: function (error) {
        console.log(error);
      },
    });
    return result;
  } catch (error) {
    console.error(error);
  }
}

function addRelationshipText(oText, commonAncestors) {
  const commonAncestorTextOut = commonAncestorText(commonAncestors);
  const cousinText = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
    "<div id='yourRelationshipText' title='Click to refresh' class='relationshipFinder'>Your " +
      oText +
      "<ul id='yourCommonAncestor' style='white-space:nowrap'>" +
      commonAncestorTextOut +
      "</ul></div>"
  );
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").after(cousinText);
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").click(function (e) {
    e.stopPropagation();
    let id1 = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
    let id2 = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
    initDistanceAndRelationship(id1, id2);
  });
  if (commonAncestors.length > 2) {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").append(
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("<button class='small' id='showMoreAncestors'>More</button>")
    );
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#showMoreAncestors").click(function (e) {
      e.preventDefault();
      e.stopPropagation();
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourCommonAncestor li:nth-child(n+3)").toggle();
    });
  }
}

function commonAncestorText(commonAncestors) {
  let ancestorTextOut = "";
  const profileGender = jquery__WEBPACK_IMPORTED_MODULE_0___default()("body")
    .find("meta[itemprop='gender']")
    .attr("content");
  let possessiveAdj = "their";
  if (profileGender == "male") {
    possessiveAdj = "his";
  }
  if (profileGender == "female") {
    possessiveAdj = "her";
  }
  commonAncestors.forEach(function (commonAncestor) {
    const thisAncestorType = ancestorType(
      commonAncestor.path2Length - 1,
      commonAncestor.ancestor.mGender
    ).toLowerCase();
    ancestorTextOut +=
      '<li>Your common ancestor, <a href="https://www.wikitree.com/wiki/' +
      commonAncestor.ancestor.mName +
      '">' +
      commonAncestor.ancestor.mDerived.LongNameWithDates +
      "</a>, is " +
      possessiveAdj +
      " " +
      thisAncestorType +
      ".</li>";
  });
  return ancestorTextOut;
}

function doRelationshipText(userID, profileID) {
  getRelationshipFinderResult(userID, profileID).then(function (data) {
    if (data) {
      let out = "";
      var aRelationship = true;
      const commonAncestors = [];
      let realOut = "";
      let dummy = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<html></html>");
      dummy.append(jquery__WEBPACK_IMPORTED_MODULE_0___default()(data.html));
      if (dummy.find("h1").length) {
        if (dummy.find("h1").eq(0).text() == "No Relationship Found") {
          aRelationship = false;
          console.log("No Relationship Found");
        }
      }
      if (dummy.find("h2").length && aRelationship == true) {
        let oh2 = dummy
          .find("h2")
          .eq(0)
          .text()
          .replaceAll(/[\t\n]/g, "");
        if (data.commonAncestors.length == 0) {
          out = dummy.find("b").text();
        } else {
          const profileGender = jquery__WEBPACK_IMPORTED_MODULE_0___default()("body")
            .find("meta[itemprop='gender']")
            .attr("content");
          if (oh2.match("is the")) {
            out = oh2.split("is the ")[1].split(" of")[0];
          } else if (oh2.match(" are ")) {
            out = oh2.split("are ")[1].replace(/cousins/, "cousin");
          }
          if (out.match(/nephew|niece/)) {
            if (profileGender == "male") {
              out = out.replace(/nephew|niece/, "uncle");
            }
            if (profileGender == "female") {
              out = out.replace(/nephew|niece/, "aunt");
            }
          }
        }
        let outSplit = out.split(" ");
        outSplit[0] = ordinalWordToNumberAndSuffix(outSplit[0]);
        out = outSplit.join(" ");
        if (
          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").length == 0 &&
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".ancestorTextText").length == 0 &&
          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#ancestorListBox").length == 0
        ) {
          jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").remove();
          addRelationshipText(out, data.commonAncestors);
        }
      }

      var rdb = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("RelationshipFinderResults");
      rdb.version(1).stores({
        relationship: "[userId+id]",
      });
      rdb
        .open()
        .then(function (rdb) {
          rdb.relationship.put({
            userId: userID,
            id: profileID,
            relationship: out,
            commonAncestors: data.commonAncestors,
          });
          // Database opened successfully
        })
        .catch(function (err) {
          // Error occurred
        });
    }
  });
}

async function addDistance(data) {
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#degreesFromYou").length == 0) {
    window.distance = data.path.length;
    const profileName = jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 span[itemprop='name']").text();
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(
        `<span id='distanceFromYou' title='${profileName} is ${window.distance} degrees from you.'>${window.distance}°</span>`
      )
    );
    var db = new dexie__WEBPACK_IMPORTED_MODULE_2__["default"]("ConnectionFinderResults");
    db.version(1).stores({
      distance: "[userId+id]",
      connection: "[userId+id]",
    });
    db.open()
      .then(function (db) {
        db.distance.put({
          userId: js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName"),
          id: jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text(),
          distance: window.distance,
        });
        // Database opened successfully
      })
      .catch(function (err) {
        // Error occurred
      });
  }
}

async function getDistance() {
  const id1 = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("wikitree_wtb_UserName");
  const id2 = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
  const data = await getConnectionFinderResult(id1, id2);
  addDistance(data);
}

function ordinal(i) {
  var j = i % 10,
    k = i % 100;
  if (j == 1 && k != 11) {
    return i + "st";
  }
  if (j == 2 && k != 12) {
    return i + "nd";
  }
  if (j == 3 && k != 13) {
    return i + "rd";
  }
  return i + "th";
}

function ancestorType(generation, gender) {
  let relType;
  if (generation > 0 || generation == 0) {
    if (gender == "Female") {
      relType = "Mother";
    } else if (gender == "Male") {
      relType = "Father";
    } else {
      relType = "Parent";
    }
  }
  if (generation > 1) {
    relType = "Grand" + relType.toLowerCase();
  }
  if (generation > 2) {
    relType = "Great-" + relType.toLowerCase();
  }
  if (generation > 3) {
    relType = ordinal(generation - 2) + " " + relType;
  }
  return relType;
}

function ordinalWordToNumberAndSuffix(word) {
  const ordinalsArray = [
    ["first", "1st"],
    ["second", "2nd"],
    ["third", "3rd"],
    ["fourth", "4th"],
    ["fifth", "5th"],
    ["sixth", "6th"],
    ["seventh", "7th"],
    ["eigth", "8th"],
    ["ninth", "9th"],
    ["tenth", "10th"],
    ["eleventh", "11th"],
    ["twelfth", "12th"],
    ["thirteenth", "13th"],
    ["fourteenth", "14th"],
    ["fifteenth", "15th"],
    ["sixteenth", "16th"],
    ["seventeenth", "17th"],
    ["eighteenth", "18th"],
    ["nineteenth", "19th"],
    ["twentieth", "20th"],
    ["twenty-first", "21st"],
    ["twenty-second", "22nd"],
    ["twenty-third", "23rd"],
    ["twenty-fourth", "24th"],
    ["twenty-fifth", "25th"],
  ];
  ordinalsArray.forEach(function (arr) {
    if (word == arr[0]) {
      word = arr[1];
      return arr[1];
    }
  });
  return word;
}

function initDistanceAndRelationship(userID, profileID) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#distanceFromYou").fadeOut().remove();
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#yourRelationshipText").fadeOut().remove();
  getProfile(profileID).then((person) => {
    const nowTime = Date.parse(Date());
    const created = Date.parse(
      person.Created.substr(0, 8).replace(/(....)(..)(..)/, "$1-$2-$3")
    );
    const timeDifference = nowTime - created;
    const nineDays = 777600000;
    if (
      person.Privacy > 29 &&
      person.Connected == 1 &&
      timeDifference > nineDays
    ) {
      getDistance();
      doRelationshipText(userID, profileID);
    }
  });
}


/***/ }),

/***/ "./src/features/draftList/draftList.js":
/*!*********************************************!*\
  !*** ./src/features/draftList/draftList.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _draftList_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./draftList.css */ "./src/features/draftList/draftList.css");




chrome.storage.sync.get("draftList", (result) => {
  if (result.draftList) {
    // Check that WikiTree BEE hasn't added this already
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.drafts").length == 0) {
console.log ('drafts')
      addDraftsToFindMenu();
    }
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditPerson").length && jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.drafts").length) {
      saveDraftList();
    }
  }
});

async function updateDraftList() {
  const profileWTID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
  let addDraft = false;
  let timeNow = Date.now();
  let lastWeek = timeNow - 604800000;
  let isEditPage = false;
  if (
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#draftStatus:contains(saved),#status:contains(Starting with previous)")
      .length
  ) {
    addDraft = true;
    theName = jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1")
      .text()
      .replace("Edit Profile of ", "")
      .replaceAll(/\//g, "")
      .replaceAll(/ID|LINK|URL/g, "");
  } else if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditPerson").length) {
    isEditPage = true;
  }
  if (localStorage.drafts) {
    let draftsArr = [];
    let draftsArrIDs = [];
    let drafts = JSON.parse(localStorage.drafts);
    drafts.forEach(function (draft) {
      if (!draftsArrIDs.includes(draft[0])) {
        if (
          (addDraft == false || window.fullSave == true) &&
          draft[0] == profileWTID &&
          isEditPage == true
        ) {
        } else {
          if (draft[1] > lastWeek) {
            draftsArr.push(draft);
            draftsArrIDs.push(draft[0]);
          }
        }
      }
    });

    if (!draftsArrIDs.includes(profileWTID) && addDraft == true) {
      draftsArr.push([profileWTID, timeNow, theName]);
    }

    localStorage.setItem("drafts", JSON.stringify(draftsArr));
  } else {
    if (addDraft == true && window.fullSave != true) {
      localStorage.setItem(
        "drafts",
        JSON.stringify([[profileWTID, timeNow, theName]])
      );
    }
  }
  return true;
}

async function showDraftList() {
  if (localStorage.drafts) {
    await updateDraftList();
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").remove();
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("body").append(
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("<div id='myDrafts'><h2>My Drafts</h2><x>x</x><table></table></div>")
  );
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").dblclick(function () {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).slideUp();
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts x").click(function () {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).parent().slideUp();
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").draggable();

  if (localStorage.drafts != undefined && localStorage.drafts != "[]") {
    window.drafts = JSON.parse(localStorage.drafts);
    window.draftCalls = 0;
    window.tempDraftArr = [];
    window.drafts.forEach(function (draft, index) {
      const theWTID = draft[0];
      if (!(0,_core_common__WEBPACK_IMPORTED_MODULE_1__.isOK)(theWTID)) {
        delete window.drafts[index];
        window.draftCalls++;
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
          url:
            "https://www.wikitree.com/index.php?title=" +
            theWTID +
            "&displayDraft=1",
          type: "GET",
          dataType: "html", // added data type
          success: function (res) {
            window.draftCalls++;
            let dummy = jquery__WEBPACK_IMPORTED_MODULE_0___default()(res); 
            aWTID = dummy
              .find("h1 button[aria-label='Copy ID']")
              .data("copy-text");
            if (
              dummy.find("div.status:contains('You have an uncommitted')")
                .length
            ) {
              window.tempDraftArr.push(aWTID);
              useLink = dummy.find("a:contains(Use the Draft)").attr("href");
              if (useLink != undefined) {
                personID = useLink.match(/&u=[0-9]+/)[0].replace("&u=", "");
                draftID = useLink.match(/&ud=[0-9]+/)[0].replace("&ud=", "");
                window.drafts.forEach(function (yDraft) {
                  if (yDraft[0] == aWTID) {
                    yDraft[3] = personID;
                    yDraft[4] = draftID;
                  }
                });
              }
            }
            if (window.draftCalls == window.drafts.length) {
              window.newDraftArr = [];
              window.drafts.forEach(function (aDraft) {
                if (
                  window.tempDraftArr.includes(aDraft[0]) &&
                  (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.isOK)(aDraft[0])
                ) {
                  window.newDraftArr.push(aDraft);
                }
              });

              newDraftArr.forEach(function (xDraft) {
                dButtons = "<td></td><td></td>";
                if (xDraft[3] != undefined) {
                  dButtons =
                    "<td><a href='https://www.wikitree.com/index.php?title=Special:EditPerson&u=" +
                    xDraft[3] +
                    "&ud=" +
                    xDraft[4] +
                    "' class='small button'>USE</a></td><td><a href='https://www.wikitree.com/index.php?title=Special:EditPerson&u=" +
                    xDraft[3] +
                    "&dd=" +
                    xDraft[4] +
                    "' class='small button'>DISCARD</a></td>";
                }

                jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts table").append(
                  jquery__WEBPACK_IMPORTED_MODULE_0___default()(
                    "<tr><td><a href='https://www.wikitree.com/index.php?title=" +
                      xDraft[0] +
                      "&displayDraft=1'>" +
                      xDraft[2] +
                      "</a></td>" +
                      dButtons +
                      "</tr>"
                  )
                );
              });
              jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").slideDown();
              if (newDraftArr.length == 0) {
                jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").append(jquery__WEBPACK_IMPORTED_MODULE_0___default()("<p>No drafts!</p>"));
              }
              localStorage.setItem("drafts", JSON.stringify(newDraftArr));
            }
          },
          error: function (res) {},
        });
      }
    });
  } else {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").append(jquery__WEBPACK_IMPORTED_MODULE_0___default()("<p>No drafts!</p>"));
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#myDrafts").slideDown();
  }
}

function saveDraftList() {
  window.fullSave = false;
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#wpSave").click(function () {
    window.fullSave = true;
  });
  window.addEventListener("beforeunload", (event) => {
    updateDraftList();
  });
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#wpSaveDraft").click(function () {
    updateDraftList();
  });
  setInterval(updateDraftList, 60000);
}

function addDraftsToFindMenu() {
  let connectionLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("li a.pureCssMenui[href='/wiki/Special:Connection']");
  let newLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
    "<li><a class='pureCssMenui drafts' id='draftsLink' title='See your uncommitted drafts'>Drafts</li>"
  );
  newLi.insertAfter(connectionLi.parent());
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("li a.drafts").click(function (e) {
    e.preventDefault();
    showDraftList();
  });
}


/***/ }),

/***/ "./src/features/familyGroup/familyGroup.js":
/*!*************************************************!*\
  !*** ./src/features/familyGroup/familyGroup.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _familyGroup_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./familyGroup.css */ "./src/features/familyGroup/familyGroup.css");




chrome.storage.sync.get("familyGroup", (result) => {
  if (
    result.familyGroup &&
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    // Add a link to the short list of links below the tabs
    const options = {
      title: "Display family group dates and locations",
      id: "familyGroupButton",
      text: "Family Group",
      url: "#n",
    };
    (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.createProfileSubmenuLink)(options);
    jquery__WEBPACK_IMPORTED_MODULE_0___default()("#" + options.id).click(function (e) {
      e.preventDefault();
      const profileID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
      showFamilySheet(jquery__WEBPACK_IMPORTED_MODULE_0___default()(this)[0], profileID);
    });

    async function showFamilySheet(theClicked, profileID) {
      // If the table already exists toggle it.
      if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#" + profileID.replace(" ", "_") + "_family").length) {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("#" + profileID.replace(" ", "_") + "_family").fadeToggle();
      } else {
        // Make the table and do other things
        (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.getRelatives)(profileID).then((person) => {
          const uPeople = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.familyArray)(person);
          // Make the table
          const familyTable = peopleToTable(uPeople);
          // Attach the table to the body, position it and make it draggable and toggleable
          familyTable.prependTo("body");
          familyTable.attr("id", profileID.replace(" ", "_") + "_family");
          familyTable.draggable();
          familyTable.on("dblclick", function () {
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).fadeOut();
          });
          let theLeft = getOffset(jquery__WEBPACK_IMPORTED_MODULE_0___default()("div.ten.columns")[0]).left;
          familyTable.css({
            top: getOffset(theClicked).top + 50,
            left: theLeft,
          });
          // Adjust the position of the table on window resize
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(window).resize(function () {
            if (familyTable.length) {
              theLeft = getOffset(jquery__WEBPACK_IMPORTED_MODULE_0___default()("div.ten.columns")[0]).left;
              familyTable.css({
                top: getOffset(theClicked).top + 50,
                left: theLeft,
              });
            }
          });

          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet x").unbind();
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet x").click(function () {
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).parent().fadeOut();
          });
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet w").unbind();
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(".familySheet w").click(function () {
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).parent().toggleClass("wrap");
          });
        });
      }
    }

    // Put a group of people in a table
    function peopleToTable(kPeople) {
      const kTable = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
        "<div class='familySheet'><w>↔</w><x>x</x><table><caption></caption><thead><tr><th>Relation</th><th>Name</th><th>Birth Date</th><th>Birth Place</th><th>Death Date</th><th>Death Place</th></tr></thead><tbody></tbody></table></div>"
      );
      kPeople.forEach(function (kPers) {
        let rClass = "";
        let isDecades = false;
        kPers.RelationShow = kPers.Relation;
        if (kPers.Relation == undefined || kPers.Active) {
          kPers.Relation = "Sibling";
          kPers.RelationShow = "";
          rClass = "self";
        }

        let bDate;
        if (kPers.BirthDate) {
          bDate = kPers.BirthDate;
        } else if (kPers.BirthDateDecade) {
          bDate = kPers.BirthDateDecade.slice(0, -1) + "-00-00";
          isDecades = true;
        } else {
          bDate = "0000-00-00";
        }

        let dDate;
        if (kPers.DeathDate) {
          dDate = kPers.DeathDate;
        } else if (kPers.DeathDateDecade) {
          if (kPers.DeathDateDecade == "unknown") {
            dDate = "0000-00-00";
          } else {
            dDate = kPers.DeathDateDecade.slice(0, -1) + "-00-00";
          }
        } else {
          dDate = "0000-00-00";
        }

        if (kPers.BirthLocation == null || kPers.BirthLocation == undefined) {
          kPers.BirthLocation = "";
        }

        if (kPers.DeathLocation == null || kPers.DeathLocation == undefined) {
          kPers.DeathLocation = "";
        }

        if (kPers.MiddleName == null) {
          kPers.MiddleName = "";
        }
        const oName = displayName(kPers)[0];

        if (kPers.Relation) {
          // The relation is stored as "Parents", "Spouses", etc., so...
          kPers.Relation = kPers.Relation.replace(/s$/, "").replace(/ren$/, "");
          if (rClass != "self") {
            kPers.RelationShow = kPers.Relation;
          }
        }
        if (oName) {
          let oBDate = ymdFix(bDate);
          let oDDate = ymdFix(dDate);
          if (isDecades == true) {
            oBDate = kPers.BirthDateDecade;
            if (oDDate != "") {
              oDDate = kPers.DeathDateDecade;
            }
          }
          const aLine = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
            "<tr data-name='" +
              kPers.Name +
              "' data-birthdate='" +
              bDate.replaceAll(/\-/g, "") +
              "' data-relation='" +
              kPers.Relation +
              "' class='" +
              rClass +
              " " +
              kPers.Gender +
              "'><td>" +
              kPers.RelationShow +
              "</td><td><a href='https://www.wikitree.com/wiki/" +
              htmlEntities(kPers.Name) +
              "'>" +
              oName +
              "</td><td class='aDate'>" +
              oBDate +
              "</td><td>" +
              kPers.BirthLocation +
              "</td><td class='aDate'>" +
              oDDate +
              "</td><td>" +
              kPers.DeathLocation +
              "</td></tr>"
          );

          kTable.find("tbody").append(aLine);
        }

        if (kPers.Relation == "Spouse") {
          let marriageDeets = "m.";
          const dMdate = ymdFix(kPers.marriage_date);
          if (dMdate != "") {
            marriageDeets += " " + dMdate;
          }
          if ((0,_core_common__WEBPACK_IMPORTED_MODULE_1__.isOK)(kPers.marriage_location)) {
            marriageDeets += " " + kPers.marriage_location;
          }
          if (marriageDeets != "m.") {
            let kGender;
            if (kPers.DataStatus.Gender == "blank") {
              kGender = "";
            } else {
              kGender = kPers.Gender;
            }
            const spouseLine = jquery__WEBPACK_IMPORTED_MODULE_0___default()(
              "<tr class='marriageRow " +
                kGender +
                "' data-spouse='" +
                kPers.Name +
                "'><td>&nbsp;</td><td colspan='3'>" +
                marriageDeets +
                "</td><td></td><td></td></tr>"
            );
            kTable.find("tbody").append(spouseLine);
          }
        }
      });
      const rows = kTable.find("tbody tr");
      rows.sort((a, b) =>
        jquery__WEBPACK_IMPORTED_MODULE_0___default()(b).data("birthdate") < jquery__WEBPACK_IMPORTED_MODULE_0___default()(a).data("birthdate") ? 1 : -1
      );
      kTable.find("tbody").append(rows);

      const familyOrder = ["Parent", "Sibling", "Spouse", "Child"];
      familyOrder.forEach(function (relWord) {
        kTable.find("tr[data-relation='" + relWord + "']").each(function () {
          jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).appendTo(kTable.find("tbody"));
        });
      });

      kTable.find(".marriageRow").each(function () {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).insertAfter(
          kTable.find("tr[data-name='" + jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).data("spouse") + "']")
        );
      });

      return kTable;
    }

    // Find good names to display (as the API doesn't return the same fields all profiles)
    function displayName(fPerson) {
      if (fPerson != undefined) {
        let fName1 = "";
        if (typeof fPerson["LongName"] != "undefined") {
          if (fPerson["LongName"] != "") {
            fName1 = fPerson["LongName"].replace(/\s\s/, " ");
          }
        }
        let fName2 = "";
        let fName4 = "";
        if (typeof fPerson["MiddleName"] != "undefined") {
          if (
            fPerson["MiddleName"] == "" &&
            typeof fPerson["LongNamePrivate"] != "undefined"
          ) {
            if (fPerson["LongNamePrivate"] != "") {
              fName2 = fPerson["LongNamePrivate"].replace(/\s\s/, " ");
            }
          }
        } else {
          if (typeof fPerson["LongNamePrivate"] != "undefined") {
            if (fPerson["LongNamePrivate"] != "") {
              fName4 = fPerson["LongNamePrivate"].replace(/\s\s/, " ");
            }
          }
        }

        let fName3 = "";
        const checks = [
          "Prefix",
          "FirstName",
          "RealName",
          "MiddleName",
          "LastNameAtBirth",
          "LastNameCurrent",
          "Suffix",
        ];
        checks.forEach(function (dCheck) {
          if (typeof fPerson["" + dCheck + ""] != "undefined") {
            if (
              fPerson["" + dCheck + ""] != "" &&
              fPerson["" + dCheck + ""] != null
            ) {
              if (dCheck == "LastNameAtBirth") {
                if (fPerson["LastNameAtBirth"] != fPerson.LastNameCurrent) {
                  fName3 += "(" + fPerson["LastNameAtBirth"] + ") ";
                }
              } else if (dCheck == "RealName") {
                if (typeof fPerson["FirstName"] != "undefined") {
                } else {
                  fName3 += fPerson["RealName"] + " ";
                }
              } else {
                fName3 += fPerson["" + dCheck + ""] + " ";
              }
            }
          }
        });

        const arr = [fName1, fName2, fName3, fName4];
        var longest = arr.reduce(function (a, b) {
          return a.length > b.length ? a : b;
        });

        const fName = longest;

        let sName;
        if (fPerson["ShortName"]) {
          sName = fPerson["ShortName"];
        } else {
          sName = fName;
        }
        // fName = full name; sName = short name
        return [fName.trim(), sName.trim()];
      }
    }

    // Convert dates to ISO format (YYYY-MM-DD)
    function ymdFix(date) {
      let outDate;
      if (date == undefined || date == "") {
        outDate = "";
      } else {
        const dateBits1 = date.split(" ");
        if (dateBits1[2]) {
          const sMonths = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ];
          const lMonths = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          const dMonth = date.match(/[A-z]+/i);
          let dMonthNum;
          if (dMonth != null) {
            sMonths.forEach(function (aSM, i) {
              if (
                dMonth[0].toLowerCase() == aSM.toLowerCase() ||
                dMonth[0].toLowerCase() == aSM + ".".toLowerCase()
              ) {
                dMonthNum = (i + 1).toString().padStart(2, "0");
              }
            });
          }
          const dDate = date.match(/\b[0-9]{1,2}\b/);
          const dDateNum = dDate[0];
          const dYear = date.match(/\b[0-9]{4}\b/);
          const dYearNum = dYear[0];
          return dYearNum + "-" + dMonthNum + "-" + dDateNum;
        } else {
          const dateBits = date.split("-");
          outDate = date;
          if (dateBits[1] == "00" && dateBits[2] == "00") {
            if (dateBits[0] == "0000") {
              outDate = "";
            } else {
              outDate = dateBits[0];
            }
          }
        }
      }
      return outDate;
    }

    // Replace certain characters with HTML entities
    function htmlEntities(str) {
      return String(str)
        .replaceAll(/&/g, "&amp;")
        .replaceAll(/</g, "&lt;")
        .replaceAll(/>/g, "&gt;")
        .replaceAll(/"/g, "&quot;")
        .replaceAll(/'/g, "&apos;");
    }

    // Get the position of an element
    function getOffset(el) {
      const rect = el.getBoundingClientRect();
      return {
        left: rect.left + window.scrollX,
        top: rect.top + window.scrollY,
      };
    }
  }
});


/***/ }),

/***/ "./src/features/familyTimeline/familyTimeline.js":
/*!*******************************************************!*\
  !*** ./src/features/familyTimeline/familyTimeline.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery-ui/ui/widgets/draggable */ "./node_modules/jquery-ui/ui/widgets/draggable.js");
/* harmony import */ var jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery_ui_ui_widgets_draggable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _familyTimeline_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./familyTimeline.css */ "./src/features/familyTimeline/familyTimeline.css");





chrome.storage.sync.get("familyTimeline", (result) => {
  if (
    result.familyTimeline &&
    jquery__WEBPACK_IMPORTED_MODULE_0__("body.profile").length &&
    window.location.href.match("Space:") == null
  ) {
    // Add a link to the short list of links below the tabs
    const options = {
      title: "Display a family timeline",
      id: "familyTimeLineButton",
      text: "Family Timeline",
      url: "#n",
    };
    (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.createProfileSubmenuLink)(options);
    jquery__WEBPACK_IMPORTED_MODULE_0__("#" + options.id).click(function (e) {
      e.preventDefault();
      timeline();
    });
  }
});

async function getRelatives(id, fields = "*") {
  try {
    const result = await jquery__WEBPACK_IMPORTED_MODULE_0__.ajax({
      url: "https://api.wikitree.com/api.php",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      type: "POST",
      dataType: "json",
      data: {
        action: "getRelatives",
        keys: id,
        fields: fields,
        getParents: 1,
        getSiblings: 1,
        getSpouses: 1,
        getChildren: 1,
      },
    });
    return result[0].items[0].person;
  } catch (error) {
    console.error(error);
  }
}

// Make the family member arrays easier to handle
function getRels(rel, person, theRelation = false) {
  let people = [];
  if (typeof rel == undefined || rel == null) {
    return false;
  }
  const pKeys = Object.keys(rel);
  pKeys.forEach(function (pKey) {
    var aPerson = rel[pKey];
    if (theRelation != false) {
      aPerson.Relation = theRelation;
    }
    people.push(aPerson);
  });
  return people;
}

// Get a year from the person's data
function getTheYear(theDate, ev, person) {
  if (!(0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(theDate)) {
    if (ev == "Birth" || ev == "Death") {
      theDate = person[ev + "DateDecade"];
    }
  }
  const theDateM = theDate.match(/[0-9]{4}/);
  if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(theDateM)) {
    return parseInt(theDateM[0]);
  } else {
    return false;
  }
}

// Convert a date to YYYY-MM-DD
function dateToYMD(enteredDate) {
  let enteredD;
  if (enteredDate.match(/[0-9]{3,4}\-[0-9]{2}\-[0-9]{2}/)) {
    enteredD = enteredDate;
  } else {
    let eDMonth = "00";
    let eDYear = enteredDate.match(/[0-9]{3,4}/);
    if (eDYear != null) {
      eDYear = eDYear[0];
    }
    let eDDate = enteredDate.match(/\b[0-9]{1,2}\b/);
    if (eDDate != null) {
      eDDate = eDDate[0].padStart(2, "0");
    }
    if (eDDate == null) {
      eDDate = "00";
    }
    if (enteredDate.match(/jan/i) != null) {
      eDMonth = "01";
    }
    if (enteredDate.match(/feb/i) != null) {
      eDMonth = "02";
    }
    if (enteredDate.match(/mar/i) != null) {
      eDMonth = "03";
    }
    if (enteredDate.match(/apr/i) != null) {
      eDMonth = "04";
    }
    if (enteredDate.match(/may/i) != null) {
      eDMonth = "05";
    }
    if (enteredDate.match(/jun/i) != null) {
      eDMonth = "06";
    }
    if (enteredDate.match(/jul/i) != null) {
      eDMonth = "07";
    }
    if (enteredDate.match(/aug/i) != null) {
      eDMonth = "08";
    }
    if (enteredDate.match(/sep/i) != null) {
      eDMonth = "09";
    }
    if (enteredDate.match(/oct/i) != null) {
      eDMonth = "10";
    }
    if (enteredDate.match(/nov/i) != null) {
      eDMonth = "11";
    }
    if (enteredDate.match(/dec/i) != null) {
      eDMonth = "12";
    }
    enteredD = eDYear + "-" + eDMonth + "-" + eDDate;
  }
  return enteredD;
}

// Use an approximate date instead of assuming that dates are Jan 1 or the 1st of a month
function getApproxDate(theDate) {
  let approx = false;
  let aDate;
  if (theDate.match(/0s$/) != null) {
    // Change a decade date to a year ending in '5'
    aDate = theDate.replace(/0s/, "5");
    approx = true;
  } else {
    // If we only have the year, assume the date to be July 2 (the midway date)
    const bits = theDate.split("-");
    if (theDate.match(/00\-00$/) != null) {
      aDate = bits[0] + "-07-02";
      approx = true;
    } else if (theDate.match(/-00$/) != null) {
      // If we have a month, but not a day/date, assume the date to be 16 (the midway date)
      aDate = bits[0] + "-" + bits[1] + "-" + "16";
      approx = true;
    } else {
      aDate = theDate;
    }
  }
  return { Date: aDate, Approx: approx };
}

function getAge(birth, death) {
  // must be date objects
  var age = death.getFullYear() - birth.getFullYear();
  var m = death.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && death.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

function capitalizeFirstLetter(string) {
  string = string.toLowerCase();
  const bits = string.split(" ");
  let out = "";
  bits.forEach(function (abit) {
    out += abit.charAt(0).toUpperCase() + abit.slice(1) + " ";
  });
  function replacer(match, p1) {
    return "-" + p1.toUpperCase();
  }
  out = out.replace(/\-([a-z])/, replacer);
  return out.trim();
}

function timeline() {
  jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").remove();
  const fields =
    "BirthDate,BirthLocation,BirthName,BirthDateDecade,DeathDate,DeathDateDecade,DeathLocation,IsLiving,Father,FirstName,Gender,Id,LastNameAtBirth,LastNameCurrent,Prefix,Suffix,LastNameOther,Derived.LongName,Derived.LongNamePrivate,Manager,MiddleName,Mother,Name,Photo,RealName,ShortName,Touched,DataStatus,Derived.BirthName,Bio";
  const id = jquery__WEBPACK_IMPORTED_MODULE_0__("a.pureCssMenui0 span.person").text();
  getRelatives(id, fields).then((personData) => {
    var person = personData;
    const parents = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Parents, "Parent");
    const siblings = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Siblings, "Sibling");
    const spouses = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Spouses, "Spouse");
    const children = (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.extractRelatives)(person.Children, "Child");
    const family = [person];
    const familyArr = [parents, siblings, spouses, children];
    // Make an array of family members
    familyArr.forEach(function (anArr) {
      if (anArr) {
        if (anArr.length > 0) {
          family.push(...anArr);
        }
      }
    });
    let familyFacts = [];
    const startDate = getTheYear(person.BirthDate, "Birth", person);
    // Get all BMD events for each family member
    family.forEach(function (aPerson) {
      const events = ["Birth", "Death", "marriage"];
      events.forEach(function (ev) {
        let evDate = "";
        let evLocation;
        if (aPerson[ev + "Date"]) {
          evDate = aPerson[ev + "Date"];
          evLocation = aPerson[ev + "Location"];
        } else if (aPerson[ev + "DateDecade"]) {
          evDate = aPerson[ev + "DateDecade"];
          evLocation = aPerson[ev + "Location"];
        }
        if (ev == "marriage") {
          if (aPerson[ev + "_date"]) {
            evDate = aPerson[ev + "_date"];
            evLocation = aPerson[ev + "_location"];
          }
        }
        if (aPerson.Relation) {
          aPerson.Relation = aPerson.Relation.replace(/s$/, "").replace(
            /ren$/,
            ""
          );
        }
        if (evDate != "" && evDate != "0000" && (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(evDate)) {
          let fName = aPerson.FirstName;
          if (!aPerson.FirstName) {
            fName = aPerson.RealName;
          }
          let bDate = aPerson.BirthDate;
          if (!aPerson.BirthDate) {
            bDate = aPerson.BirthDateDecade;
          }
          let mBio = aPerson.bio;
          if (!aPerson.bio) {
            mBio = "";
          }
          if (evLocation == undefined) {
            evLocation = "";
          }
          familyFacts.push([
            evDate,
            evLocation,
            fName,
            aPerson.LastNameAtBirth,
            aPerson.LastNameCurrent,
            bDate,
            aPerson.Relation,
            mBio,
            ev,
            aPerson.Name,
          ]);
        }
      });
      // Look for military events in bios
      if (aPerson.bio) {
        const tlTemplates = aPerson.bio.match(/\{\{[^]*?\}\}/gm);
        if (tlTemplates != null) {
          const warTemplates = [
            "The Great War",
            "Korean War",
            "Vietnam War",
            "World War II",
            "US Civil War",
            "War of 1812",
            "Mexican-American War",
            "French and Indian War",
            "Spanish-American War",
          ];
          tlTemplates.forEach(function (aTemp) {
            let evDate = "";
            let evLocation = "";
            let ev = "";
            let evDateStart = "";
            let evDateEnd = "";
            let evStart;
            let evEnd;
            aTemp = aTemp.replaceAll(/[{}]/g, "");
            const bits = aTemp.split("|");
            const templateTitle = bits[0].replaceAll(/\n/g, "").trim();
            bits.forEach(function (aBit) {
              const aBitBits = aBit.split("=");
              const aBitField = aBitBits[0].trim();
              if (aBitBits[1]) {
                const aBitFact = aBitBits[1].trim().replaceAll(/\n/g, "");
                if (warTemplates.includes(templateTitle) && (0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(aBitFact)) {
                  if (aBitField == "startdate") {
                    evDateStart = dateToYMD(aBitFact);
                    evStart = "Joined " + templateTitle;
                  }
                  if (aBitField == "enddate") {
                    evDateEnd = dateToYMD(aBitFact);
                    evEnd = "Left " + templateTitle;
                  }
                  if (aBitField == "enlisted") {
                    evDateStart = dateToYMD(aBitFact);
                    evStart =
                      "Enlisted for " +
                      templateTitle.replace("american", "American");
                  }
                  if (aBitField == "discharged") {
                    evDateEnd = dateToYMD(aBitFact);
                    evEnd =
                      "Discharged from " +
                      templateTitle.replace("american", "American");
                  }
                  if (aBitField == "branch") {
                    evLocation = aBitFact;
                  }
                }
              }
            });
            if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(evDateStart)) {
              evDate = evDateStart;
              ev = evStart;
              familyFacts.push([
                evDate,
                evLocation,
                aPerson.FirstName,
                aPerson.LastNameAtBirth,
                aPerson.LastNameCurrent,
                aPerson.BirthDate,
                aPerson.Relation,
                aPerson.bio,
                ev,
                aPerson.Name,
              ]);
            }
            if ((0,_core_common__WEBPACK_IMPORTED_MODULE_2__.isOK)(evDateEnd)) {
              evDate = evDateEnd;
              ev = evEnd;
              familyFacts.push([
                evDate,
                evLocation,
                aPerson.FirstName,
                aPerson.LastNameAtBirth,
                aPerson.LastNameCurrent,
                aPerson.BirthDate,
                aPerson.Relation,
                aPerson.bio,
                ev,
                aPerson.Name,
              ]);
            }
          });
        }
      }
    });
    // Sort the events
    familyFacts.sort();
    if (!person.FirstName) {
      person.FirstName = person.RealName;
    }
    // Make a table
    const timelineTable = jquery__WEBPACK_IMPORTED_MODULE_0__(
      `<div class='wrap' id='timeline' data-wtid='${person.Name}'><w>↔</w><x>x</x><table id='timelineTable'>` +
        `<caption>Events in the life of ${person.FirstName}'s family</caption><thead><th class='tlDate'>Date</th><th class='tlBioAge'>Age (${person.FirstName})</th>` +
        `<th class='tlRelation'>Relation</th><th class='tlName'>Name</th><th class='tlAge'>Age</th><th class='tlEventName'>Event</th><th class='tlEventLocation'>Location</th>` +
        `</thead></table></div>`
    );
    // Attach the table to the container div
    timelineTable.prependTo(jquery__WEBPACK_IMPORTED_MODULE_0__("div.container.full-width"));
    if (jquery__WEBPACK_IMPORTED_MODULE_0__("#connectionList").length) {
      timelineTable.prependTo(jquery__WEBPACK_IMPORTED_MODULE_0__("#content"));
      timelineTable.css({ top: window.pointerY - 30, left: 10 });
    }
    let bpDead = false;
    let bpDeadAge;

    familyFacts.forEach(function (aFact) {
      // Add events to the table
      const showDate = aFact[0].replace("-00-00", "").replace("-00", "");
      const tlDate = "<td class='tlDate'>" + showDate + "</td>";
      let aboutAge = "";
      let bpBdate = person.BirthDate;
      if (!person.BirthDate) {
        bpBdate = person.BirthDateDecade.replace(/0s/, "5");
      }
      let hasBdate = true;
      if (bpBdate == "0000-00-00") {
        hasBdate = false;
      }
      const bpBD = getApproxDate(bpBdate);
      const evDate = getApproxDate(aFact[0]);
      const aPersonBD = getApproxDate(aFact[5]);
      if (bpBD.Approx == true) {
        aboutAge = "~";
      }
      if (evDate.Approx == true) {
        aboutAge = "~";
      }
      let bpAge = getAge(new Date(bpBD.Date), new Date(evDate.Date));
      if (bpAge == 0) {
        bpAge = "";
      }
      if (bpDead == true) {
        const theDiff = parseInt(bpAge - bpDeadAge);
        bpAge = bpAge + " (" + bpDeadAge + " + " + theDiff + ")";
      }
      let theBPAge;
      if (aboutAge != "" && bpAge != "") {
        theBPAge = "(" + bpAge + ")";
      } else {
        theBPAge = bpAge;
      }
      if (hasBdate == false) {
        theBPAge = "";
      }
      const tlBioAge = "<td class='tlBioAge'>" + theBPAge + "</td>";
      if (aFact[6] == undefined || aFact[9] == person.Name) {
        aFact[6] = "";
      }
      const tlRelation =
        "<td class='tlRelation'>" + aFact[6].replace(/s$/, "") + "</td>";
      let fNames = aFact[2];
      if (aFact[8] == "marriage") {
        fNames = person.FirstName + " and " + aFact[2];
      }
      const tlFirstName =
        "<td class='tlFirstName'><a href='https://www.wikitree.com/wiki/" +
        aFact[9] +
        "'>" +
        fNames +
        "</a></td>";
      const tlEventName =
        "<td class='tlEventName'>" +
        capitalizeFirstLetter(aFact[8])
          .replaceAll(/Us\b/g, "US")
          .replaceAll(/Ii\b/g, "II") +
        "</td>";
      const tlEventLocation = "<td class='tlEventLocation'>" + aFact[1] + "</td>";

      if (aPersonBD.Approx == true) {
        aboutAge = "~";
      }
      let aPersonAge = getAge(new Date(aPersonBD.Date), new Date(evDate.Date));
      if (aPersonAge == 0 || aPersonBD.Date.match(/0000/) != null) {
        aPersonAge = "";
        aboutAge = "";
      }
      let theAge;
      if (aboutAge != "" && aPersonAge != "") {
        theAge = "(" + aPersonAge + ")";
      } else {
        theAge = aPersonAge;
      }
      const tlAge = "<td class='tlAge'>" + theAge + "</td>";
      let classText = "";
      if (aFact[9] == person.Name) {
        classText += "BioPerson ";
      }
      classText += aFact[8] + " ";
      const tlTR = jquery__WEBPACK_IMPORTED_MODULE_0__(
        "<tr class='" +
          classText +
          "'>" +
          tlDate +
          tlBioAge +
          tlRelation +
          tlFirstName +
          tlAge +
          tlEventName +
          tlEventLocation +
          "</tr>"
      );
      jquery__WEBPACK_IMPORTED_MODULE_0__("#timelineTable").append(tlTR);
      if (aFact[8] == "Death" && aFact[9] == person.Name) {
        bpDead = true;
        bpDeadAge = bpAge;
      }
    });

    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").slideDown("slow");
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline x").click(function () {
      jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").slideUp();
    });
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline w").click(function () {
      jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").toggleClass("wrap");
    });
    // Use jquery-ui to make the table draggable
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").draggable();
    jquery__WEBPACK_IMPORTED_MODULE_0__("#timeline").dblclick(function () {
      jquery__WEBPACK_IMPORTED_MODULE_0__(this).slideUp("swing");
    });
  });
}


/***/ }),

/***/ "./src/features/locationsHelper/locationsHelper.js":
/*!*********************************************************!*\
  !*** ./src/features/locationsHelper/locationsHelper.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");
/* harmony import */ var _locationsHelper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./locationsHelper.css */ "./src/features/locationsHelper/locationsHelper.css");




chrome.storage.sync.get('locationsHelper', (result) => {
	if (result.locationsHelper && jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.BEE").length==0 && 
        (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditPerson").length || jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditFamily").length)) {

        function addRelArraysToPerson(zPerson) {
            const zSpouses = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Spouses, "Spouse"); 
            zPerson.Spouse = zSpouses;
            const zChildren = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Children, "Child"); 
            zPerson.Child = zChildren;
            const zSiblings = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Siblings, "Sibling"); 
            zPerson.Sibling = zSiblings;
            const zParents = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.extractRelatives)(zPerson.Parents, "Parent"); 
            zPerson.Parent = zParents;
            return zPerson;
        }
                
        function editDistance(s1, s2) {
            s1 = s1.toLowerCase();
            s2 = s2.toLowerCase();
            let costs = new Array();
            for (var i = 0; i <= s1.length; i++) {
                var lastValue = i;
                for (var j = 0; j <= s2.length; j++) {
                    if (i == 0)
                        costs[j] = j;
                    else {
                        if (j > 0) {
                            var newValue = costs[j - 1];
                            if (s1.charAt(i - 1) != s2.charAt(j - 1))
                                newValue = Math.min(Math.min(newValue, lastValue),
                                    costs[j]) + 1;
                            costs[j - 1] = lastValue;
                            lastValue = newValue;
                        }
                    }
                }
                if (i > 0)
                    costs[s2.length] = lastValue;
            }
            return costs[s2.length];
        }

        function similarity(s1, s2) {
            s1 = s1.toLowerCase();
            s2 = s2.toLowerCase();
            var longer = s1;
            var shorter = s2;
            if (s1.length < s2.length) {
                longer = s2;
                shorter = s1;
            }
            var longerLength = longer.length;
            if (longerLength == 0) {
                return 1.0;
            }
            return (longerLength - editDistance(longer, shorter)) / parseFloat(longerLength);
        }

        async function locationsHelper() {
            let theID;
            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.page-Special_EditFamily").length) {
                theID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui0 span.person").text();
            } else {
                theID = jquery__WEBPACK_IMPORTED_MODULE_0___default()("a.pureCssMenui:Contains(Edit)").attr("href").split("u=")[1];
            }
            (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.getRelatives)(theID).then((result)=>{
                const thisFamily = (0,_core_common__WEBPACK_IMPORTED_MODULE_1__.familyArray)(result);
                window.bdLocations = [];
                thisFamily.forEach(function (aPe) {
                    if (aPe.BirthLocation) {
                        window.bdLocations.push(aPe.BirthLocation);
                    }
                    if (aPe.DeathLocation) {
                        window.bdLocations.push(aPe.DeathLocation);
                    }
                })
            });

            const observer2 = new MutationObserver(function (mutations_list) {
                mutations_list.forEach(function (mutation) {
                    mutation.addedNodes.forEach(function (added_node) {
                        if (added_node.className == "autocomplete-suggestion-container") {
                            let activeEl = document.activeElement;
                            let whichLocation = "";
                            if (activeEl.id == "mBirthLocation") {
                                whichLocation = "Birth";
                            }
                            if (activeEl.id == "mDeathLocation") {
                                whichLocation = "Death";
                            }
                            if (activeEl.name == "mMarriageLocation") {
                                whichLocation = "Marriage";
                            }
                            let dText = added_node.textContent;
                            currentBirthYearMatch = null;
                            currentDeathYearMatch = null;
                            currentMarriageYearMatch = null;
                            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mBirthDate").length) {
                                currentBirthYearMatch = jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mBirthDate").val().match(/[0-9]{3,4}/);
                            }
                            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mDeathDate").length) {
                                currentDeathYearMatch = jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mDeathDate").val().match(/[0-9]{3,4}/);
                            }
                            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mMarriageDate").length) {
                                currentMarriageYearMatch = jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mMarriageDate").val().match(/[0-9]{3,4}/);
                            }
                            let startYear = "";
                            let endYear = "";
                            let goodDate = false;
                            let familyLoc = false;
                            let familyLoc2 = false;
                            const yearsMatch = dText.match(/\([^A-z]*[0-9]{3,4}.*\)/g);
                            if (yearsMatch != null) {
                                years = yearsMatch[0].replaceAll(/[()]/g, "").split("-");
                                //console.log(years);
                                if (years[0].trim() != "") {
                                    startYear = years[0].trim();
                                }
                                if (years[1].trim() != "") {
                                    endYear = years[1].trim();
                                }
                            }
                            else {
                                goodDate = true;
                            }
                            let myYear = "";
                            if (currentBirthYearMatch != null && whichLocation == "Birth") {
                                myYear = currentBirthYearMatch[0];
                            }
                            else if (currentDeathYearMatch != null && whichLocation == "Death") {
                                myYear = currentDeathYearMatch[0];
                            }
                            else if (currentMarriageYearMatch != null && whichLocation == "Marriage") {
                                myYear = currentMarriageYearMatch[0];
                            }
                            if (myYear != "") {
                                if (startYear == "" && parseInt(myYear) < parseInt(endYear)) {
                                    goodDate = true;
                                }
                                else if (endYear == "" && parseInt(myYear) > parseInt(startYear)) {
                                    goodDate = true;
                                }
                                else if (parseInt(myYear) > parseInt(startYear) && parseInt(myYear) < parseInt(endYear)) {
                                    goodDate = true;
                                }
                            }
                            else {
                                goodDate = true;
                            }
                            window.bdLocations.forEach(function (aLoc) {
                                dText = dText.split("(")[0].trim();
                                if (similarity(aLoc, dText) > 0.8) {
                                    familyLoc = true;
                                }
                                if (similarity(aLoc, dText) > 0.95) {
                                    familyLoc2 = true;
                                }
                            })
                            const theContainer = jquery__WEBPACK_IMPORTED_MODULE_0___default()(added_node).closest(".autocomplete-suggestion-container");
                            if (goodDate == true) {
                                theContainer.addClass("rightPeriod");
                                if (familyLoc2 == true) {
                                    theContainer.addClass("familyLoc2").prependTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions"));
                                }
                                else if (familyLoc == true) {
                                    theContainer.addClass("familyLoc1").prependTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions"));
                                }
                            }
                            else {
                                theContainer.addClass("wrongPeriod").appendTo(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions"));
                            }
                        }
                    });
                });
            });

            setTimeout(function () {
                observer2.observe(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions").eq(0)[0], { subtree: false, childList: true });
                if (jquery__WEBPACK_IMPORTED_MODULE_0___default()("#mDeathLocation").length) {
                    observer2.observe(jquery__WEBPACK_IMPORTED_MODULE_0___default()(".autocomplete-suggestions").eq(1)[0], { subtree: false, childList: true });
                }
            }, 3000);
        }
        locationsHelper();
    }
});


/***/ }),

/***/ "./src/features/printerfriendly/printerfriendly.js":
/*!*********************************************************!*\
  !*** ./src/features/printerfriendly/printerfriendly.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/common */ "./src/core/common.js");



chrome.storage.sync.get('printerFriendly', (result) => {
	if (result.printerFriendly) {
		// create a top menu item
		(0,_core_common__WEBPACK_IMPORTED_MODULE_1__.createTopMenuItem)({
			title: 'Changes the format to a printer-friendly one.',
			name: 'Printer Friendly Bio',
			id: 'wte-tm-printer-friendly'
		});

		jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#wte-tm-printer-friendly`).on('click', () => {
			printBio();
		});
	}
});

// modified code from Steven's WikiTree Toolkit
function printBio() {
	var pTitleClean = jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).attr('title');
	var pTitleCleaner = pTitleClean.replace(' | WikiTree FREE Family Tree', '');
	var pTitle = pTitleCleaner.replace(' - WikiTree Profile', '');
	var pImage = jquery__WEBPACK_IMPORTED_MODULE_0___default()("img[src^='/photo.php/']").attr('src');
	var pTitleInsert = jquery__WEBPACK_IMPORTED_MODULE_0___default()('h2').first();
	pTitleInsert.before(
		`<div>
			<img style="float:left;" src="https://www.wikitree.com${pImage}" width="75" height="75">
			<div style="font-size: 2.1429em; line-height: 1.4em; margin-bottom:50px; padding: 20px 100px;">
				${pTitle}
			</div>
		</div>`
	);

	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[target='_Help']").parent().remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("span[title*='for the profile and']").parent().remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("div[style='background-color:#e1efbb;']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("div[style='background-color:#eee;']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[href^='/treewidget/']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[href='/g2g/']").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()("a[class='nohover']").remove();

	jquery__WEBPACK_IMPORTED_MODULE_0___default()('div').removeClass('ten columns');
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.VITALS').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.star').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.profile-tabs').remove();
	//$(".SMALL").remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.showhidetree').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.row').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.button').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.large').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.sixteen').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.five').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.editsection').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.EDIT').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.comment-absent').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('.box').remove();

	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#views-wrap').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#footer').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#commentPostDiv').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#comments').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#commentEditDiv').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#commentG2GDiv').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#header').remove();
	jquery__WEBPACK_IMPORTED_MODULE_0___default()('#showHideDescendants').remove();

	window.print();
	location.reload();
}


/***/ }),

/***/ "./src/features/randomProfile/randomProfile.js":
/*!*****************************************************!*\
  !*** ./src/features/randomProfile/randomProfile.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


chrome.storage.sync.get('randomProfile', (result) => {
	if (result.randomProfile && jquery__WEBPACK_IMPORTED_MODULE_0___default()("body.BEE").length==0) {
        function getRandomProfile() {
            var randomProfileID = Math.floor(Math.random() * 36065988);
            var link = '';
            // check if exists
            jquery__WEBPACK_IMPORTED_MODULE_0___default().getJSON('https://api.wikitree.com/api.php?action=getPerson&key=' + randomProfileID)
                .done(function (json) {
                    // check to see if the profile is Open
                    if (json[0]['status'] == 0 && 'Privacy_IsOpen' in json[0]['person'] && json[0]['person']['Privacy_IsOpen']) {
                        link = 'https://www.wikitree.com/wiki/' + randomProfileID;
                        window.location = link;
                    } else { // If it isn't open, find a new profile
                        getRandomProfile();
                    }
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.log('getJSON request failed! ' + textStatus + ' ' + errorThrown);
                    getRandomProfile();
                });
        }

        // add random option to 'Find'
        async function addRandomToFindMenu() {
            const relationshipLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("li a.pureCssMenui[href='/wiki/Special:Relationship']");
            const newLi = jquery__WEBPACK_IMPORTED_MODULE_0___default()("<li><a class='pureCssMenui randomProfile' title='Go to a random profile'>Random Profile</li>");
            newLi.insertBefore(relationshipLi.parent());
            jquery__WEBPACK_IMPORTED_MODULE_0___default()(".randomProfile").click(function (e) {
                e.preventDefault();
                getRandomProfile()
            });
        }
    addRandomToFindMenu();
    }
})


/***/ }),

/***/ "./src/features/sourcepreview/sourcepreview.js":
/*!*****************************************************!*\
  !*** ./src/features/sourcepreview/sourcepreview.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


chrome.storage.sync.get('sPreviews', function (result) {
    if (result.sPreviews == true) {
        sourcePreview();

        function sourcePreview() {
            if (jquery__WEBPACK_IMPORTED_MODULE_0___default()('.reference').length) { // and only if inline citations are found
                jquery__WEBPACK_IMPORTED_MODULE_0___default()('.reference').hover(function (e) { // jquery.hover() handlerIn (show sourcePreview)
                    var sourceID = this.id.replace('ref', 'note').replace(/(_[0-9]+$)/g, '');
                    var sPreview = document.createElement('div');
                    sPreview.setAttribute('id', 'sourcePreview');
                    sPreview.setAttribute('class', 'box rounded');
                    sPreview.setAttribute('style', 'z-index:999; width: 450px; position:absolute;');
                    document.getElementById(this.id).appendChild(sPreview);
                    document.getElementById('sourcePreview').innerHTML = document.getElementById(sourceID).innerHTML;
                },
                    // jqeury.hover() handlerOut (remove sourcePreview)
                    function () {
                        jquery__WEBPACK_IMPORTED_MODULE_0___default()('#sourcePreview').remove();
                    }
                )
            }
        }
        const targetNode = document.getElementById('previewbox');
        const config = { childList: true };
        const callback = (mutationList, observer) => {
            for (const mutation of mutationList) {
                if (mutation.type === 'childList') {
                    sourcePreview();
                }
            }
        };
        const observer = new MutationObserver(callback);
        if (jquery__WEBPACK_IMPORTED_MODULE_0___default()('#previewbox').length > 0) {
            observer.observe(targetNode, config);
        }
    }
})


/***/ }),

/***/ "./src/features/spacepreview/spacepreview.js":
/*!***************************************************!*\
  !*** ./src/features/spacepreview/spacepreview.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _thirdparty_jquery_hoverDelay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../thirdparty/jquery.hoverDelay */ "./src/thirdparty/jquery.hoverDelay.js");



chrome.storage.sync.get("spacePreviews", function (result) {
  if (result.spacePreviews == true) {
    jquery__WEBPACK_IMPORTED_MODULE_0___default()('.ten.columns a[href*="/wiki/Space:"], .sixteen.columns a[href*="/wiki/Space:"]').hoverDelay({
      delayIn: 1000,
      delayOut: 0,
      handlerIn: function ($element) {
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spacePreview").remove();
        jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spaceHover").attr("id", "");
        console.log($element[0].href);
        $element.attr("id", "spaceHover");
        var sPreview = document.createElement("div");
        sPreview.setAttribute("id", "spacePreview");
        sPreview.setAttribute("class", "box rounded");
        sPreview.setAttribute(
          "style",
          `z-index:9999; max-height:450px; overflow: scroll; position:absolute; padding: 10px; margin-top:-20px;`
        );
        document.getElementById("spaceHover").parentElement.appendChild(sPreview);
        jquery__WEBPACK_IMPORTED_MODULE_0___default().ajax({
          url: $element[0].href,
          context: document.body,
        }).done(function (result) {
          var pageContent = jquery__WEBPACK_IMPORTED_MODULE_0___default()(result).find(".ten.columns").html();
          try {
            document.getElementById(
              "spacePreview"
            ).innerHTML = `<span style="float:right; font-weight:700;">click outside to close</span>${pageContent}`;
          } catch {}
        });
      },
    });
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).on("click", function (event) {
    if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(event.target).closest("#spacePreview").length === 0) {
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spacePreview").remove();
      jquery__WEBPACK_IMPORTED_MODULE_0___default()("#spaceHover").attr("id", "");
    }
  });
});


/***/ }),

/***/ "./src/features/wt+/contentEdit.js":
/*!*****************************************!*\
  !*** ./src/features/wt+/contentEdit.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "wtPlus": () => (/* binding */ wtPlus)
/* harmony export */ });
/* harmony import */ var _wtPlus_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wtPlus.css */ "./src/features/wt+/wtPlus.css");


let tb = {};

function itemsFindByTemplate(name) {
	return tb.templates.filter(item => item.name.toUpperCase() === name.toUpperCase())[0]
}

function paramsCopy (templateName){
	tb.template = itemsFindByTemplate(templateName); 
	tb.templateitems = tb.template.prop.map(item => {        
		return {
			name: item.name,
			type: item.type,
			usage: item.usage,
			numbered: item.numbered,
			initial: item.initial,
			help: item.help,
			example: item.example,
			group: item.group,
			values: item.values || [], 
			value: ''
		}
	})
	tb.unknownParams = ''
}

function paramsFromSelection(){
	//finds menu item
//    var params = tb.textSelected.split(/.*?\|\s*([^{}[\]|]*?(?:\[\[[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\]\][^{}[\]|]*?|\{\{[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\}\}[^{}[\]|]*?)*?[^{}[\]|]*?)\s*(?:(?=\|)|}})/g).map(par => par.trim()).filter(par => par != '');
	var params = tb.textSelected.split(/\|\s*([^{}[\]|]*?(?:\[\[[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\]\][^{}[\]|]*?|\{\{[^{}[\]|]*?(?:\|[^{}[\]|]*?)*?[^{}[\]|]*?\}\}[^{}[\]|]*?)*?[^{}[\]|]*?)\s*(?:(?=\|)|}})/g).map(par => par.trim()).filter(par => par != '');
	tb.textSelected = tb.textSelected.replace('{{', '').replace('}}', '');
	params[0] = params[0].replace('{{', '').replace('}}', '').replace('_', ' ')
	tb.template = itemsFindByTemplate(params[0]); 
	if (tb.template) {
		params.splice(0, 1);
		var paramsNumbered = params.filter(par => !(par.includes('=')));
		var paramsNamed = params.filter(par => par.includes('=')).map(item => item.split("=").map(par => par.trim()));
		tb.templateitems = tb.template.prop.map(item => {
			var x;
			if (item.numbered) {
				x = paramsNumbered[item.numbered-1]
			} else {
				x = paramsNamed.filter(par => par[0].toUpperCase() === item.name.toUpperCase()).map(par => par[1]).join('');
			};
			if (!x) {x = ''};
			return {
				name: item.name,
				type: item.type,
				usage: item.usage,
				numbered: item.numbered,
				initial: item.initial,
				help: item.help,
				example: item.example,
				group: item.group,                                
				values: item.values || [], 
				value: x.trim()
			}            
		})
		var unknownNamed = paramsNamed.filter(par => !Boolean(tb.templateitems.find(ti => ti.name.toUpperCase() === par[0].toUpperCase())))        
		var unknownNumbered = paramsNumbered.filter((par, i) => !Boolean(tb.templateitems.find(ti => ti.numbered === i+1)))
		tb.unknownParams = unknownNamed.map(i => '|' + i[0] + '= ' + i[1]).concat(unknownNumbered.map(i => '|' + i)).join('\n')
	} else {
		alert ('Template "' + params[0] + '" is not recognised by the extension')
	}   
};

function paramsInitialValues (){
	if (tb.templateitems && tb.templateitems.length) {
		for (let prop of tb.templateitems) {
			if (prop.value === '' && prop.initial) {
				if (prop.initial.startsWith("Title:")) {
					prop.value = document.title.replace(RegExp(prop.initial.substring(6)), '$1');
				}    
				if (prop.initial.startsWith("Category:") && (tb.categories)) {
					var r = RegExp(prop.initial.substring(9), 'mg')
					var a = tb.categories.match(r)
					prop.value = ((a) ? a.join('\n').replace(r, '$1') : '' )
				}    
			}
		}
	}
}

function reformatCoortoURL (s) {
	return 'https://www.openstreetmap.org/#map=18/' + s.replace (',', '/').replace ('%20', '')
}

function reformatURLtoCoor (s) {
	if (s.match ( /^ *[\d]* *° *[\d]* *[′'] *([\d.]* *[″”"])? *[NS][, ]*[\d]* *° *[\d]* *[′'] *([\d.]* *[″”"])? *[EW] *$/mgi)) {
		// 32°42'16.02"N, 17°8'0.67"W
		let s1 = s.replace(
			/^ *([\d]{1,2}) *° *([\d]{1,2}) *[′'] *(([\d.]{1,5}) *[″”"])? *([NS])[, ]*([\d]{1,3}) *° *([\d]{1,2}) *[′'] *(([\d.]{1,5}) *[″”"])? *([EW]) *$/mgi,
			'$1;$2;$4;$5;$6;$7;$9;$10')
		let arr = s1.split(';')
		var lon, lat
		lat = (arr[3] == 'S' ? -1 : 1) * (Number(arr[0]) + Number(arr[1]) / 60 + Number(arr[2]) / 3600)
		lon = (arr[7] == 'W' ? -1 : 1) * (Number(arr[4]) + Number(arr[5]) / 60 + Number(arr[6]) / 3600)
		return parseFloat(lat.toFixed(6)) + ', ' + parseFloat(lon.toFixed(6))
	} else if (s.match (/^https:\/\/www\.openstreetmap\.org\/#map=[\d]*\/[\d.-]*\/[\d.-]*$/mgi)) {
		// https://www.openstreetmap.org/#map=15/32.7051/-17.1220
		let s1 = s.replace(
			/^https:\/\/www\.openstreetmap\.org\/#map=[\d]{1,2}\/([\d.-]*)\/([\d.-]*)$/mgi,
			'$1, $2')
		return s1
	} else {  
		return s.replace ('/', ', ')
	}
}

function reformatTexttoWiki (s) {
	return s.replace (/ /g, '_');
}

function reformatWikitoText  (s) {
	return decodeURIComponent (s.replace (/_/g, ' '));
}

function getNumbertoSlash  (s) {
	return s.replace (/(\d*)\/.*/g, '$1');
}

const urlMappings = [
	{type: "", placeholder:"Undefined type"},
	{type: "typeText", placeholder:"Enter text"},
	{type: "typeNumber", placeholder:"Enter a number"},
	{type: "typeYear", placeholder:"Enter year"},
	{type: "typeYes", placeholder:"Enter yes"},
	{type: "typeNo", placeholder:"Enter no"},
	{type: "typeURL", placeholder:"Enter URL https://...", prefixURL:'', sufixURL:'', emptyURL:''},
	{type: "typeWikitreeID", placeholder:"Enter profile's WikitreeID", prefixURL:'https://www.wikitree.com/wiki/', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typePage", placeholder:"Enter Page name with Namespace", prefixURL:'https://www.wikitree.com/wiki/', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeCategory", placeholder:"Enter Category on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Category:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeProjectNeedsCategory", placeholder:"Enter Project Needs category", prefixURL:'', sufixURL:'', emptyURL:''},
	{type: "typeProject", placeholder:"Enter Project on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Project:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeTeam", placeholder:"Enter Team of the project on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Space:', sufixURL:' Team', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeSpace", placeholder:"Enter Space page on WikiTree", prefixURL:'https://www.wikitree.com/wiki/Space:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeImage", placeholder:"Enter Image name", prefixURL:'https://www.wikitree.com/wiki/Image:', sufixURL:'', emptyURL:'', toURL:reformatTexttoWiki, fromURL:reformatWikitoText},
	{type: "typeG2G", placeholder:"Enter question ID", prefixURL:'https://www.wikitree.com/g2g/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeWikiTreeBlog", placeholder:"Enter blog name", prefixURL:'https://www.wikitree.com/blog/', sufixURL:'/', emptyURL:''},
	{type: "typeWikiData", placeholder:"Enter WikiData code", prefixURL:'https://www.wikidata.org/wiki/', sufixURL:''},
	{type: "typeYouTube", placeholder:"Enter YouTube code", prefixURL:'https://www.youtube.com/watch?v=', sufixURL:''},
	{type: "typeFAGID", placeholder:"Enter FindAGrave ID", prefixURL:'https://www.findagrave.com/memorial/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeFAGCemID", placeholder:"Enter FindAGrave Cemetery ID", prefixURL:'https://www.findagrave.com/cemetery/', sufixURL:'', emptyURL:'', fromURL:getNumbertoSlash},
	{type: "typeFAGLocID", placeholder:"Enter FindAGrave Location ID", prefixURL:'https://www.findagrave.com/cemetery/search?locationId='},
	{type: "typeBGID", placeholder:"Enter BillionGraves ID", prefixURL:'https://billiongraves.com/cemetery/Cemetery/', sufixURL:'', emptyURL:'https://billiongraves.com/'},
	{type: "typeCoor", placeholder:"Enter coordinate 15.123, -33.213", prefixURL:'', sufixURL:'', emptyURL:'https://www.openstreetmap.org/', toURL:reformatCoortoURL, fromURL:reformatURLtoCoor},
	{type: "typeTOC", placeholder:"Not enough prfiles"},
	{type: "typeReadOnly"},
];

/* Setting result */

function updateEdit (){
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}
	tb.elText.value = tb.textResult;
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}
	tb.elText.setSelectionRange(tb.selStart, tb.selEnd);

	if (tb.birthLocationResult) {
		tb.elBirthLocation.value = tb.birthLocationResult
	}
	if (tb.deathLocationResult) {
		tb.elDeathLocation.value = tb.deathLocationResult
	}

	if (tb.elSummary) {
		tb.elSummary.focus();
		var s = tb.elSummary.value;
		if (s) {
			if (s.indexOf(tb.addToSummary) == -1) {
				s += ', ' + tb.addToSummary
			}
		} else {
			s = tb.addToSummary
		};
		tb.elSummary.value = s;
	}
	tb.elText.focus();
	tb.addToSummary = ''

	// Let the page know that changes have been made so that the "Save Changes" button works
//    if ("createEvent" in document) {
	var evt = document.createEvent("HTMLEvents");
	evt.initEvent("change", false, true);
	tb.elText.dispatchEvent(evt);
//      } else {
//        textbox.fireEvent("onchange");
//      }
}


/**************************/
/* edit Template          */
/**************************/

function editTemplate (summaryPrefix){
	if (tb.template) {
		var group, groupExpanded 
		tb.elDlg.innerHTML = 
			'<h3 style="margin: 0 0 0 10px;">Editing ' + '<a href="/wiki/Template:' + tb.template.name + '" target="_blank">Template:' + tb.template.name + '</a></h3>' + 
			'<table style="margin-bottom: 10px;"><tr><td style="white-space: nowrap;padding-right: 10px;">' +
			(tb.template.type ? 'Type: <b>' + tb.template.type + '</b><br>' : '') + 
			(tb.template.group ? 'Group: <b>' + tb.template.group + '</b><br>' : '') + 
			(tb.template.subgroup ? 'SubGroup: <b>' + tb.template.subgroup + '</b>' : '') + 
			'</td><td>' + tb.template.help + '</td></tr></table>' + 
			'<div id="wtPlusDlgParams">'+
			'<table style="width: 100%;">' + 
			tb.templateitems.map((item, i) => {
				var itemDef = urlMappings.filter(a=>a.type == item.type)[0] 
				if (!itemDef) {
					console.log('Missing ' + item.type + ' type') 
					itemDef = urlMappings[0];
				};
				// Sets TOC parameter
				if (item.type === "typeTOC") {
					var has_link = [].some.call(document.links, function(link) {
						return link.innerHTML.endsWith(' 200');
					});
					item.value = (has_link) ? 'yes': ''
				}
				var x = ''
				// Group
				if (item.group !== group) {
					if (item.group) {
						groupExpanded = Boolean (tb.templateitems.find(a=> a.group == item.group && a.value)) 
						x += '<tr class="wtPlus' + item.group + '"><td colspan="2"><label>' + item.group + ':</label></td><td>' + 
							'<button id="groupBtn' + item.group + '" title="Expand/Collapse" class="dlgClick" data-op="onDlgEditTemplateExpCol" data-id="' + item.group + '">' + 
							(groupExpanded ? 'Collapse' : 'Expand') + '</button></td><td colspan="3"></td></tr>' 
					}
					group = item.group
				}
				x  += '<tr class="wtPlus' + item.usage + (item.group ? ' group' + item.group + '" ' + (groupExpanded ? '' : 'style="visibility: collapse;') : '' ) + '">';
				// Name
				x += '<td><label>' + item.name + ':</label></td>' 
				// Help
				x += '<td>' + (item.help ? 
					'<img src="/images/icons/help.gif" border="0" width="22" height="22" alt="Help" title="Usage: ' + item.usage + '\n' + item.help + (item.example ? '\nExample: ' + item.example : '' ) + '" />': '') + '</td>';
				// Input
				x += '<td><input type="text" name="wtparam' + i + '" class="dlgPaste' + /*((item.type === "typeCategory") ? ' dlgCat' : '' ) + */'" ' +
					 'data-op="onDlgEditTemplatePaste" data-id="' + i + '" value="' + item.value + '" ';
				x += 'placeholder="' + itemDef.placeholder + '" '
				x += 'list="wtPlusAutoComplete' + i + '" '
				if ((item.type === "typeReadOnly") || (item.type === "typeTOC")) {
					x += 'readonly '
				}
				if (i === 0) {
					x += 'autofocus '
				}
				x += '/><datalist id="wtPlusAutoComplete' + i + '">' 
				x += item.values.map(item => '<option value="' + item + '"/>' ).join('\n')
				x +='</datalist></td>';
				//Buttons
				x +='<td>' + ((item.type != "typeReadOnly") && (item.type != "typeTOC") ? 
					'<button title="Restore value" class="dlgClick" data-op="onDlgEditTemplateRestore" data-id="' + i + '" tabindex="-1">R</button>' : '') + '</td>' 
				x +='<td>' + ((item.initial) ? 
					'<button title="Auto value" class="dlgClick" data-op="onDlgEditTemplateInitial" data-id="' + i + '" tabindex="-1">A</button>' : '') + '</td>' 
				x +='<td>' + ((urlMappings.filter(a=>a.prefixURL !== undefined).map(a=>a.type).includes(item.type)) ? 
					'<button title="Open link" class="dlgClick" data-op="onDlgEditTemplateFollow" data-id="' + i + '" tabindex="-1">O</button>' : '') + '</td>' 
				x +='</tr>';
													
				return x
			}).join('') + 
			'</table>' +
			'</div>' +
			'<div style="display:flex">'+        
			//Legend
			'<button id="wtPlusLegendBtn" class="dlgClick" data-op="onDlgNone" tabindex="-1">Legend'+
			'<table class="wtPlusLegend">' + 
			'<tr><td colspan="2" class="wtPlusRequired">Required</td></tr>' +
			'<tr><td colspan="2" class="wtPlusPreferred">Preferred</td></tr>' +
			'<tr><td colspan="2" class="wtPlusOptional">Optional</td></tr>' +
			'<tr><td><img src="/images/icons/help.gif" border="0" width="22" height="22" alt="Help" /></td><td>Hower for hint</td></tr>' +
			'<tr><td><button title="Restore value" class="dlgClick" data-op="onDlgNone">R</button></td><td>Restore value</td></tr>' +
			'<tr><td><button title="Auto value" class="dlgClick" data-op="onDlgNone">A</button></td><td>Auto value</td></tr>' +
			'<tr><td><button title="Open link" class="dlgClick" data-op="onDlgNone">O</button></td><td>Open link</td></tr>' +
			'</table>' +
			'</button>' +
			'<div style="flex:1"></div>' +
			'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Edit_Template" target="_blank">Help</a>' +
			//OK, Cancel
			'<button style="text-align:right" class="dlgClick" data-op="onDlgEditTemplateBtn" data-id="0">Close</button>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgEditTemplateBtn" data-id="1" value="default">Update changes</button>' +
			'</div>' 

		tb.elDlgParams = document.getElementById("wtPlusDlgParams");
				  
		attachEvents('button.dlgClick', 'click')
		attachEvents('input.dlgPaste', 'paste')
		attachEvents('input.dlgPaste', 'keypress')
		
		tb.addToSummary = summaryPrefix + " Template:" + tb.template.name;
		if (tb.unknownParams) 
		  alert('Unrecognized parameters:\n' + tb.unknownParams + '\n\nThey will be removed, unless you cancel.')
		tb.elDlg.showModal();
	}    
};
/*

	if ($('#addCategoryInput').length) {
		$('#addCategoryInput').autoComplete({
			cache: false,
			source: function(term, suggest) {
				wtCategorySuggestion(term, suggest);
			},
			renderItem: function(category, search) {
				return wtCategorySuggestionItemRender(category, search);
			},
			onSelect: function(e, term, item) {
				changesMade = 1;
				var categoryText = "[[Category:" + term + "]]\n";
				categoryText = categoryText.replace(/_/g, ' ');
				if ((typeof coloredEditor !== 'undefined') && (coloredEditor)) {
					coloredEditor.setCursor(0, 0);
					var cursor = coloredEditor.getCursor();
					coloredEditor.replaceRange(categoryText, cursor, cursor);
					coloredEditor.focus();
				} else {
					var textArea = document.editform.wpTextbox1;
					var textScroll = textArea.scrollTop;
					textArea.value = categoryText + textArea.value;
					textArea.selectionStart = 0;
					textArea.selectionEnd = categoryText.length;
					textArea.scrollTop = textScroll;
					textArea.focus();
				}
				$('#addCategoryInput').val('').hide();
				e.preventDefault();
				return false;
			},
		});
	}
});
function wtCategorySuggestion(term, suggest) {
	var includeAll = 0;
	if ($('#categorySuggestionIncludeAll').length && $('#categorySuggestionIncludeAll').val()) {
		includeAll = 1;
	}
	sajax_do_call("Title::ajaxCategorySearch", [term, includeAll], function(result) {
		var suggestions = JSON.parse(result.responseText);
		suggest(suggestions);
	});
}
function wtCategorySuggestionItemRender(item, search) {
	search = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
	var re = new RegExp("(" + search.split(' ').join('|') + ")","gi");
	var html = '';
	html += '<div class="autocomplete-suggestion" data-val="' + item + '">';
	html += item.replace(re, "<b>$1</b>");
	html += '</div>';
	return html;
}

*/
function onDlgEditTemplateBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		var a = tb.elDlgParams.querySelectorAll('input');
		for (var i in tb.templateitems) {tb.templateitems[i].value = a[i].value.trim()};
		tb.inserttext = '';
		var line = '';
		if (tb.templateitems && tb.templateitems.length) {
			var line = '\n';
			for (let prop of tb.templateitems) {
				if (prop.numbered) {
					line = '';
					if (prop.value) {
						tb.inserttext += '|' + prop.value;
					} else {
						switch(prop.usage) {
						case "Required":
						case "Preferred":
						tb.inserttext += '|';
						break;
						} 
					}    
				} else {
					if (prop.value) {
						tb.inserttext += '\n|' + prop.name + '= ' + prop.value;
					} else {
						switch(prop.usage) {
							case "Required":
							case "Preferred":
							tb.inserttext += '\n|' + prop.name + '= ';
							break;
						} 
					}    
				}
			}
		}
		tb.inserttext = '{{' + tb.template.name + tb.inserttext + line + '}}' ;
		tb.inserttext += (tb.textAfter[0]==='\n') ? '': line;
		
		tb.textResult = tb.textBefore + tb.inserttext + tb.textAfter;
		tb.selStart = tb.textBefore.length
		tb.selEnd = tb.selStart +  tb.inserttext.length;
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		updateEdit();
	};
	tb.elDlg.innerHTML = '';
	tb.addToSummary = ''
	return false
};

//listener for paste event
function onDlgEditTemplatePaste(i, evt) {
	if (evt.type == 'keypress') {
		var key = evt.which || evt.keyCode;
		if (key === 13) { 
			onDlgEditTemplateBtn('1')
		} 
	} 
	if (evt.type == 'paste') {
		let clipdata = evt.clipboardData || window.clipboardData;
		var s = clipdata.getData('text/plain');
		s = decodeURIComponent (s);
		for(const j of urlMappings) {
			if (tb.templateitems[i].type === j.type) {
				if (s.startsWith(j.prefixURL)) {
					s = s.replace(j.prefixURL, '');
					if ((j.sufixURL!='') && (s.endsWith(j.sufixURL))) {
						s = s.replace(j.sufixURL, '');
					}    
					s = j.fromURL ? j.fromURL(s) : s
					document.execCommand("insertHTML", false, s);
					evt.preventDefault();
				}
			}
		}
	}
}

function onDlgEditTemplateFollow(i) {
	var item=tb.templateitems[i];
	var e=tb.elDlgParams.querySelectorAll('input')[i];
	var s = e.value;

	for(const i of urlMappings) {
		if (item.type === i.type) {
			if (s) {
				s = (i.prefixURL === '') ? encodeURI (s) : encodeURIComponent (s)
				s = i.toURL ? i.toURL(s) : s
				s = i.prefixURL + s + i.sufixURL
			} else {
				s = i.emptyURL !== undefined ? i.emptyURL : i.prefixURL
			}
		}
	}
   
	if (s.startsWith('http')) {
		window.open(s, '_blank');
	}
	return false
};

function onDlgEditTemplateInitial(i) {
	var item=tb.templateitems[i];
	var e=tb.elDlgParams.querySelectorAll('input')[i];
	if (item.initial.startsWith("Title:")) {
		e.value = document.title.replace(RegExp(item.initial.substring(6)), '$1');
	}    
	if (item.initial.startsWith("Category:") && (tb.categories)) {
		var r=RegExp(item.initial.substring(9), 'mg')
		e.value = tb.categories.match(r).join('\n').replace(r, '$1');
	}
	return false
};

function onDlgEditTemplateRestore(i) {
	var item=tb.templateitems[i];
	var e = tb.elDlgParams.querySelectorAll('input')[i];
	e.value = item.value;
	return false
};

function onDlgEditTemplateExpCol(gName) {
	var e = tb.elDlg.getElementsByClassName('group' + gName);
	var b = document.getElementById('groupBtn' + gName);
	if (b.innerHTML == 'Expand') {
		b.innerHTML = 'Collapse'
		for(var ei of e) {ei.style.visibility = 'visible';}
	} else {
		b.innerHTML = 'Expand'
		for(var ei of e) {ei.style.visibility = 'collapse';}
	}
	return false
};

function WikiTreeGetCategory (query, fixed){
	fetch("https://www.wikitree.com/index.php?action=ajax&rs=Title::ajaxCategorySearch&rsargs[]=" + query + "&rsargs[]=1")
	.then((resp) => resp.json())
	.then(jsonData => {
		console.log('cat: ' + jsonData);
		return (jsonData);
	})
};

/**************************/
/* Select template to add */
/**************************/
 
function selectTemplate (data) {
	tb.elDlg.innerHTML = 
		'<h3>Select template</h3>' + 
		'<input type="checkbox" class="cbFilter" id="cb1" name="cb1" data-op="onDlgSelectTemplateFlt" data-id="1" value="Project Box"' + (data=="Project Box" ? ' checked' : '') + '><label for="cb1"> Project Box</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb2" name="cb2" data-op="onDlgSelectTemplateFlt" data-id="2" value="Sticker"' + (data=="Sticker" ? ' checked' : '') + '><label for="cb2"> Sticker</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb3" name="cb3" data-op="onDlgSelectTemplateFlt" data-id="3" value="Profile Box"' + (data=="Profile Box" ? ' checked' : '') + '><label for="cb3"> Research Note</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb4" name="cb4" data-op="onDlgSelectTemplateFlt" data-id="4" value="External Link"' + (data=="External Link" ? ' checked' : '') + '><label for="cb4"> External Link</label><br>' +
		'<input type="checkbox" class="cbFilter" id="cb5" name="cb5" data-op="onDlgSelectTemplateFlt" data-id="5" value="CategoryInfoBox"' + (data=="CategoryInfoBox" ? ' checked' : '') + '><label for="cb5"> CategoryInfoBox</label><br>' +
		'<label for="flt1">Filter: </label><input type="text" class="cbFilter" id="flt1" name="flt1" data-op="onDlgSelectTemplateFlt" data-id="9"><br>' +
		'<div style="min-width: 600px;overflow-y:auto;height: 400px;"><table style="width: 100%;" id="tb">' +
		tb.templates.map(item => '<tr class="trSelect" data-op="onDlgSelectTemplateTrSel"><td>' + item.name + '</td><td>' + item.group + '</td><td>' + item.subgroup + '</td></tr>' ).join('\n') +
		'</table></div>' +
		'<div style="text-align:right">'+
		'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Add_Template" target="_blank">Help</a>' +
		//OK, Cancel
		'<button style="text-align:right" class="dlgClick" data-op="onDlgSelectTemplateBtn" data-id="0">Close</button>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgSelectTemplateBtn" data-id="1" value="default">Select</button>' +
		'</div>' 
	attachEvents('button.dlgClick', 'click')
	attachEvents('input.cbFilter', 'input')
	attachEvents('tr.trSelect', 'click')
	onDlgSelectTemplateFlt ()
	tb.elDlg.showModal();
};

function onDlgSelectTemplateFlt () {
	let lb = tb.elDlg.querySelector("#tb")
	var s0 = '';
	for (let i=1;i<=5;i++) {
		if (tb.elDlg.querySelector("#cb"+i).checked)
		  s0 += (s0=='' ? '' : '|') + tb.elDlg.querySelector("#cb"+i).value
	}
	var r0 = new RegExp('('+s0+')','i')
	
	var s1 = tb.elDlg.querySelector("#flt1").value
	var r1 = new RegExp(s1,'i')
	
	lb.innerHTML = tb.templates.filter(item=> 
		((s0==='') || item.type.match(r0)) && 
		((s1==='') || item.name.match(r1) || item.group.match(r1) || item.subgroup.match(r1))
//    ).map(item => '<option value="' + item.name + '">' + item.name + ' (' + item.group + ': ' + item.subgroup + ')</option>' ).join('\n') 
		).map(item => '<tr class="trSelect" data-op="onDlgSelectTemplateTrSel"><td>' + item.name + '</td><td>' + item.group + '</td><td>' + item.subgroup + '</td></tr>' ).join('\n') 
	attachEvents('tr.trSelect', 'click')
}

function onDlgSelectTemplateTrSel (tr) {
	removeClass ('tr.trSelect', 'trSelected')
	tr.classList.add("trSelected")
}

function onDlgSelectTemplateBtn(update) {
	if (update==='1') {
		if (tb.elDlg.querySelectorAll('.trSelected>td').length === 0) {
			alert ('No template selected: Select a template before closing the dialog')
			return false
		}
		tb.elDlg.close();
		//Add template 
		var templateName = tb.elDlg.querySelectorAll('.trSelected>td')[0].innerText
		paramsCopy (templateName)
		paramsInitialValues ();
		editTemplate ("Added");
	} else {
		tb.elDlg.close();
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};

/*********************************/
/* Automatic update like EditBOT */
/*********************************/

function AutoUpdate () {
	let s0 = ''
	let s1 = ''
	let s2 = ''
	for (var loc=0;loc<3;loc++) {
		let actArr = ''
		if (loc==0) {
			if (tb.birthLocation) {
				s0 = 'Birth Location'
				s1 = tb.birthLocation
				actArr = tb.locations
			}
		} else if (loc==1) {
			if (tb.deathLocation) {
				s0 = 'Death Location'
				s1 = tb.deathLocation
				actArr = tb.locations
			}
		} else if (loc==2) {
			if (tb.textAll) {
				s0 = 'Bio'
				s1 = tb.textAll
				actArr = tb.cleanup
			}
		}
		if (actArr) {
			for (var j=0;j<actArr.length;j++) {
				let clean = actArr[j]
				let s3 = ''
				for (var i=0;i<clean.actions.length;i++) {
					let s = s1
					let action = clean.actions[i]
					switch(action.action) {
						case "replaceRegEx": 
						let reg = RegExp(action.from, action.flags)
						s1 = s1.replace(reg, action.to)
						break;
						case "replace": 
						s1 = s1.replace(action.from, action.to)
						break;
							default: 
						alert ('Unknown action: ' + action.action + ' defined for source: ' + clean.name)
						s1 = ''
					}
					if (s1=='') break
					if ((s1!=='') && (s !== s1)) {
						s3 += (s3!=='' ? ', ' : '') + action.description
					}    
				}
				if (s3!=='') {
					s2 += '<input type="checkbox" class="cb' + loc + '_' + j + '" id="cb' + loc + '_' + j + '" name="cb' + loc + '_' + j + '" data-op="onDlgPasteSourceCB" data-id="1" value="' + loc + '_' + j + '" checked>' +
						'<label for="cb' + loc + '_' + j + '"> ' + s0 + ' ' + clean.description + ' ' + ' (' + s3 + ')</label><br>\n' 
				}
			}
		}
	}
	if (s2 == '') {
		alert ('Nothing to change.')
	} else {
		tb.elDlg.innerHTML = 
			'<h3>Automated cleanup</h3>' + 
			s2 +
			'<div style="text-align:right">'+
			//OK, Cancel
			'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Profile_Cleanup" target="_blank">Help</a>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgProfileCleanupBtn" data-id="0">Close</button>' +
			'<button style="text-align:right" class="dlgClick" data-op="onDlgProfileCleanupBtn" data-id="1" value="default">Select</button>' +
			'</div>' 
		attachEvents('button.dlgClick', 'click')
		attachEvents('input.cbInline', 'input')
		tb.elDlg.showModal();
	}
};

function onDlgProfileCleanupBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		//Set updated text

		let s0 = ''
		let s1 = ''
		let s2 = ''
		let actArr = []
		for (var loc=0;loc<3;loc++) {
			if (loc==0) {
				s0 = 'Birth Location'
				s1 = tb.birthLocation
				actArr = tb.locations
			} else if (loc==1) {
				s0 = 'Death Location'
				s1 = tb.deathLocation
				actArr = tb.locations
			} else if (loc==2) {
				s0 = 'Bio'
				s1 = tb.textAll
				actArr = tb.cleanup
			}
			if (actArr) {
				for (var j=0;j<actArr.length;j++) {
					var cb = tb.elDlg.querySelectorAll('#cb'+loc+'_'+j)[0]
					if ((cb) && (cb.checked)) {
						let clean = actArr[j]

						let s = ''
						let s1 = ''
						let s3 = ''
						for (var i=0;i<clean.actions.length;i++) {
							s = s1
							let action = clean.actions[i]
							switch(action.action) {
								case "replaceRegEx": 
								let reg = RegExp(action.from, action.flags)
								s1 = s1.replace(reg, action.to)
								break;
								case "replace": 
								s1 = s1.replace(action.from, action.to)
								break;
								default: 
								s1 = ''
							}
							if (s1=='') break
							if ((s1!=='') && (s !== s1)) {
								s3 += (s3!=='' ? ', ' : '') + action.description
							}    
						}
						if (s3!=='') {
							s2 += (s2!=='' ? ', ' : '' ) + '+' + s0 + ' ' + clean.description + ' (' + s3 + ')' 
						}
					}
				}
			}
			if (loc==0) {
				tb.birthLocationResult = s1;
			} else if (loc==1) {
				tb.deathLocationResult = s1;
			} else if (loc==2) {
				tb.textResult = s1;
			}
		}
		tb.addToSummary = s2;
		updateEdit();
	} else {
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};


/**************************/
/* Paste source reformat  */
/**************************/

function pasteSource () {
	tb.elDlg.innerHTML = 
		'<h3>Paste source</h3>' + 
		'<label for="srcPaste">Clipboard:</label><br>' +
		'<textarea class="srcPaste" data-op="onDlgPasteSourcePaste" data-id="1" placeholder="Paste a source or URL here." rows="5" cols="80"></textarea><br>' +
		'<input type="checkbox" class="cbInline" id="cb1" name="cb1" data-op="onDlgPasteSourceCB" data-id="1" value="Inline" checked><label for="cb1"> Inline citation</label><br>' +
		'<label for="resultFld">Citation to add:</label><br>' +
		'<textarea class="resultFld" rows="5" cols="80"></textarea>' +
		'<div style="text-align:right">'+
		//OK, Cancel
		'<a class="button" href="https://www.wikitree.com/wiki/Space:WikiTree_Plus_Chrome_Extension#Paste_Sources" target="_blank">Help</a>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgPasteSourceBtn" data-id="0">Close</button>' +
		'<button style="text-align:right" class="dlgClick" data-op="onDlgPasteSourceBtn" data-id="1" value="default">Select</button>' +
		'</div>' 
	attachEvents('button.dlgClick', 'click')
	attachEvents('input.cbInline', 'input')
	attachEvents('textarea.srcPaste', 'paste')
	tb.elDlg.showModal();
};

function onDlgPasteSourceBtn(update) {
	tb.elDlg.close();
	if (update==='1') {
		//Add template 
		tb.inserttext = tb.elDlg.querySelectorAll('.resultFld')[0].value;
		tb.inserttext += (tb.textAfter[0]==='\n') ? '': '\n';
		tb.textResult = tb.textBefore + tb.inserttext + tb.textAfter;
		tb.selStart = tb.textBefore.length
		tb.selEnd = tb.selStart +  tb.inserttext.length;
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		updateEdit();
	} else {
		tb.elDlg.innerHTML = '';
		tb.addToSummary = ''
	};
	return false
};

function onDlgPasteSourceCB(i, evt) {
	var e = tb.elDlg.querySelectorAll('.resultFld')[0]
	let s = e.value.replace('<ref>', '').replace('</ref>', '').replace('* ', '')
	if (tb.elDlg.querySelectorAll('.cbInline')[0].checked) {
		e.value = '<ref>' + s + '</ref>'
	} else {
		e.value = '* ' + s
	}
}

//listener for paste event
function onDlgPasteSourcePaste(i, evt) {
	if (evt.type == 'keypress') {
		var key = evt.which || evt.keyCode;
		if (key === 13) { 
			onDlgPasteSourceBtn('1')
		} 
	} 
	if (evt.type == 'paste') {
		var clipdata = evt.clipboardData || window.clipboardData;
		var s = clipdata.getData('text/plain');
		var s1 = '';
		s = decodeURIComponent (s);

		if (tb.sources) {
			for (let source of tb.sources) {
				var b = false
				for (let condition of source.conditions) {
					switch(condition.action) {
						case "startsWith": 
						b = s.startsWith(condition.find)
						break;
						case "includes": 
						b = s.includes(condition.find)
						break;
						default: alert ('Unknown condition: ' + condition.action + ' defined for source: ' + source.name)
					}   
					if (b) break;
				}
				if (b) {
					s1 = s
					for (let action of source.actions) {
						switch(action.action) {
							case "replaceRegEx": 
							let reg = RegExp(action.from, 'mg')
							s1 = s1.replace(reg, action.to)
							break;
							case "replace": 
							s1 = s1.replace(action.from, action.to)
							break;
							default: 
							alert ('Unknown action: ' + action.action + ' defined for source: ' + source.name)
							s1 = ''
						}
						if (s1=='') break
					}
					if (s1!=='') {
						tb.addToSummary = 'Added ' + source.description
						break
					}
				}
			}
		}

		// Adding inline citation
		if (s1!=='') {
			if (tb.elDlg.querySelectorAll('.cbInline')[0].checked) {
				s1 = '<ref>' + s1 + '</ref>'
			} else {
				s1 = '* ' + s1
			} 
		}
		tb.elDlg.querySelectorAll('.resultFld')[0].value = s1
	}
}

/**************************/
/* Menu events            */
/**************************/

function posToOffset (txt, pos){
  const arr=txt.split("\n");
  var len=0;
  for (var i=0;i<pos.line;i++) 
	len+= length(arr[i]) + 1 ;
  return len+pos.ch ;
};

function wtPlus (params){
	if (tb.elText.style.display == "none") {
		alert('Enhanced editor is not supported.\n\nTurning it off to use the extension.');
		tb.elEnhanced.click();
	}

	//Sets all edit variables
	tb.elEnhancedActive = (tb.elText.style.display == "none");
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
			
			
//            alert ('Enhanced editor is not supported.<br>Turn it off to use WikiTree+ extension.');
/*
		if (window.coloredEditor) {
			tb.textAll = coloredEditor.getValue().replace(/\r\n|\n\r|\n|\r/g, '\n')
			tb.selStart = posToOffset (tb.textAll, coloredEditor.getCursor("from"))
			tb.selEnd = posToOffset (tb.textAll, coloredEditor.getCursor("to"))
*/
		}

	tb.selStart = tb.elText.selectionStart;
	tb.selEnd = tb.elText.selectionEnd;
	tb.textAll = tb.elText.value;
	if (tb.elBirthLocation) {
		tb.birthLocation = tb.elBirthLocation.value;
	}
	if (tb.elDeathLocation) {
		tb.deathLocation = tb.elDeathLocation.value;
	}
	if (tb.elEnhancedActive) {
		tb.elEnhanced.click();
	}

	tb.textBefore = tb.textAll.substring(0,  tb.selStart);
	tb.textSelected = tb.selEnd == tb.selStart ? '' : tb.textAll.substring(tb.selStart, tb.selEnd);
	tb.textAfter = tb.textAll.substring(tb.selEnd);
	tb.categories = tb.textAll.match(/\[\[Category:.*?\]\]/mgi)
	if (tb.categories){
		tb.categories = tb.categories.join('\n').replace(/\[\[Category:\s*(.*?)\s*\]\]/mgi, '$1');
	}        
	tb.textResult = tb.textAll; 

	if (params.template) {
		//Add template 
		paramsCopy (params.template)
		paramsInitialValues ();
		editTemplate ("Added");
	} else {
		switch(params.action) {
			case "": break;
			case "EditTemplate": //Edit template
//            var expression = /{{[\s\S]*?}}/g
		var expression = /\{\{.*?(\[\[[^{}[\]]*?\]\][^{}[\]]*?|\[[^{}[\]]*?\][^{}[\]]*?|\{\{[^{}[\]]*?\}\}[^{}[\]]*?)*?[^{}[\]]*?\}\}/gms


		if (tb.selStart != tb.selEnd) {
			let tem = tb.textSelected.match(expression);
			if (tem && (tem.length == 1)) {
				var s = tb.textSelected.split(expression);
				tb.textBefore += s[0];
				tb.textSelected = tem[0];
				tb.textAfter = s[2] + tb.textAfter;
				tb.selStart = tb.textBefore.length
				tb.selEnd = tb.selStart + tb.textSelected.length;
				paramsFromSelection();
				editTemplate("Edited");
			} else {
				alert ('There is no template in selected text');
			}    
		} else {
			let tem = tb.textAll.match(expression);
			if (tem) {
				if (tem.length == 1) {
					var s = tb.textAll.split(expression);
					tb.textBefore = s[0];
					tb.textSelected = tem[0];
					tb.textAfter  = s[2];
					tb.selStart = tb.textBefore.length
					tb.selEnd = tb.selStart + tb.textSelected.length;
					paramsFromSelection();
					editTemplate("Edited");
				} else {
					let match = ''
					while (match = expression.exec(tb.textAll)) {
						if ((match.index < tb.selStart) && (expression.lastIndex > tb.selStart)) {
							tb.textBefore = tb.textAll.substring(0,  match.index);
							tb.textSelected = match[0];
							tb.textAfter  = tb.textAll.substring(expression.lastIndex);
							tb.selStart = tb.textBefore.length
							tb.selEnd = tb.selStart + tb.textSelected.length;
							paramsFromSelection();
							editTemplate("Edited");
							return;
						};
					};
					alert ('There is no template at cursor position.')
				}
			} else {
				alert ('There is no template on the page.')
			}
		}
		break;

		case "AutoFormat": //automatic formting
		tb.textResult = tb.textAll.replace(/^ *\| *([^ =|]*) *= */mg, "|$1= ")
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		tb.addToSummary = ''
		updateEdit ();
		break;

		case "AutoUpdate": //automatic corrections
		AutoUpdate ();
		break;   

		case "EditBOTConfirm": //EditBOT confirmation
		tb.textResult = tb.textAll.replace(/\|(Review|Manual)\}\}/mg, "|Confirmed}}")
		tb.textResult = tb.textResult.replace(/\s\s\}\}/mg, " ")
		tb.birthLocationResult = '';
		tb.deathLocationResult = '';
		tb.addToSummary = "Confirmation for EditBOT"
		updateEdit ();
		break;
		
		case "AddTemplate": //add any template
		selectTemplate (params.data);
		break;

		case "PasteSource": //paste a source citation
		pasteSource ();
		break;
		

		default: alert ("Unknown event " + params.action)
		};
	};
	
};

/* Classes */

const attachClass = (selector, className) => {
	document.querySelectorAll(selector).forEach(i=>i.classList.add(className))
}

const removeClass = (selector, className) => {
	document.querySelectorAll(selector).forEach(i=>i.classList.remove(className))
}

/* Events */

const attachEvents = (selector, eventType) => {
	document.querySelectorAll(selector).forEach(i=>i.addEventListener(eventType, event=>mainEventLoop(event)))
}
function mainEventLoop (event) {

	if (tb.elText.style.display == "none") {
		alert ('Enhanced editor is not supported.\n\nTurning it off to use the extension.');
		tb.elEnhanced.click();
	}   

	let element = event.srcElement
	if (element.tagName == 'TD') {
		element = element.parentElement
	}
	const op = element.dataset.op
	const id = element.dataset.id
	if (op === 'wtPlus')    {event.preventDefault(); return wtPlus(id)}
	
	if (op === 'onDlgEditTemplateExpCol') {event.preventDefault(); return onDlgEditTemplateExpCol(id)}
	if (op === 'onDlgEditTemplateRestore')    {event.preventDefault(); return onDlgEditTemplateRestore(id)}
	if (op === 'onDlgEditTemplateInitial')    {event.preventDefault(); return onDlgEditTemplateInitial(id)}
	if (op === 'onDlgEditTemplateFollow') {event.preventDefault(); return onDlgEditTemplateFollow(id)}
	if (op === 'onDlgEditTemplateBtn')  {event.preventDefault(); return onDlgEditTemplateBtn(id)}
	if (op === 'onDlgEditTemplatePaste')  return onDlgEditTemplatePaste(id, event)

	if (op === 'onDlgPasteSourcePaste')  return onDlgPasteSourcePaste(id, event)
	if (op === 'onDlgPasteSourceCB')  return onDlgPasteSourceCB(id, event)    
	if (op === 'onDlgPasteSourceBtn') {event.preventDefault(); return onDlgPasteSourceBtn(id)}

	if (op === 'onDlgProfileCleanupBtn') {event.preventDefault(); return onDlgProfileCleanupBtn(id)}

	if (op === 'onDlgSelectTemplateFlt') return onDlgSelectTemplateFlt()
	if (op === 'onDlgSelectTemplateTrSel') return onDlgSelectTemplateTrSel(element)
	if (op === 'onDlgSelectTemplateBtn') {event.preventDefault(); return onDlgSelectTemplateBtn(id)}

	if (op === 'onDlgNone') {event.preventDefault(); return}
	
	console.error ('Missing data-op on ', element)
}

function isEditPage() {
	return (window.location.href.match(/\/index.php\?title=Special:EditPerson&.*/g) ||
	        window.location.href.match(/\/index.php\?title=.*&action=edit.*/g) ||
			window.location.href.match(/\/index.php\?title=.*&action=submit.*/g));
}

/* Initialization */
chrome.storage.sync.get('wtplus', (result) => {
	if (result.wtplus && isEditPage()) {
		tb.nameSpace = (document.title.startsWith('Edit Person ')) ? 'Profile' : ''
		let w = document.querySelector('h1 > .copyWidget')
		if (w) {
			tb.wikitreeID = w.getAttribute('data-copy-text');
		}
		tb.elText = document.getElementById("wpTextbox1");
		tb.elBirthLocation = document.getElementById("mBirthLocation");
		tb.elDeathLocation = document.getElementById("mDeathLocation");

		tb.elSummary = document.getElementById("wpSummary");
		tb.elEnhanced = document.getElementById("toggleMarkupColor");

		document.getElementById("toolbar").insertAdjacentHTML('beforeend', '<dialog id="wtPlusDlg"></dialog>')
		tb.elDlg = document.getElementById("wtPlusDlg");

		// Loading of template definition From Storage
		chrome.storage.local.get(['alltemplates'], function(a){
			if (a.alltemplates && a.alltemplates.version) {
				// Is in storage
				tb.templates = a.alltemplates.templates;
				tb.cleanup = a.alltemplates.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
				tb.locations = a.alltemplates.locations; if (!(tb.locations)) {tb.locations = []};
				tb.sources = a.alltemplates.sources; if (!(tb.sources)) {tb.sources = []};
				tb.dataVersion = new Date(a.alltemplates.version);
				console.log('Storage: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates' + ', ' +  tb.cleanup.length + ' cleanup' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
			} else {
				// Not in storage
				tb.dataVersion = new Date("2000-01-01T00:00:00+01:00");
			} 
			// Loading of template definition From Extension
			fetch(chrome.runtime.getURL("features/wt+/templatesExp.json"))
			.then((resp) => resp.json())
			.then(jsonData => {
				const d = new Date(jsonData.version)
				if (d.getTime () > tb.dataVersion.getTime ()) {
					// Extension definition is newer
					tb.templates = jsonData.templates;
					tb.cleanup = jsonData.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
					tb.locations = jsonData.locations; if (!(tb.locations)) {tb.locations = []};
					tb.sources = jsonData.sources; if (!(tb.sources)) {tb.sources = []};
					tb.dataVersion = d;
					console.log('Extension: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates.' + ', ' +  tb.cleanup.length + ' cleanup.' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
					chrome.storage.local.set({"alltemplates": jsonData});
				}
				if (tb.dataVersion.getTime () < new Date().getTime () - 6 * 3600 * 1000) {
					// Loading of template definition From Web
					fetch("https://wikitree.sdms.si/chrome/templatesExp.json")
					.then((resp) => resp.json())
					.then(jsonData => {
						const d = new Date(jsonData.version)
						if (d.getTime () > tb.dataVersion.getTime ()) {
							// Web definition is newer
							tb.templates = jsonData.templates;
							tb.cleanup = jsonData.cleanup; if (!(tb.cleanup)) {tb.cleanup = []};
							tb.locations = jsonData.locations; if (!(tb.locations)) {tb.locations = []};
							tb.sources = jsonData.sources; if (!(tb.sources)) {tb.sources = []};
							tb.dataVersion = d;
							console.log('Web: ' + tb.dataVersion + ', ' +  tb.templates.length + ' templates.' + ', ' +  tb.cleanup.length + ' cleanup.' + ', ' + tb.locations.length + ' locations' + ', ' + tb.sources.length + ' sources.')
							chrome.storage.local.set({"alltemplates": jsonData});
						}
					})
				}
			})
		});
	}
});

/*
Todo. Add spaces on edit comment.
1.0.4
  * Condensed template info in the dialog to occupy less space.
  * After switching off the enhanced editor the selected function is executed if possible.
  * AutoCorrection of location fields.
  * Added AutoCorrection to categories
  * Implemented case insensitive in template parameter names recognition
*/


/***/ }),

/***/ "./src/thirdparty/jquery.hoverDelay.js":
/*!*********************************************!*\
  !*** ./src/thirdparty/jquery.hoverDelay.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


(jquery__WEBPACK_IMPORTED_MODULE_0___default().fn.hoverDelay) = function (n) {
  var e = { delayIn: 300, delayOut: 300, handlerIn: function () {}, handlerOut: function () {} };
  return (
    (n = jquery__WEBPACK_IMPORTED_MODULE_0___default().extend(e, n)),
    this.each(function () {
      var e,
        t,
        u = jquery__WEBPACK_IMPORTED_MODULE_0___default()(this);
      u.hover(
        function () {
          t && clearTimeout(t),
            (e = setTimeout(function () {
              n.handlerIn(u);
            }, n.delayIn));
        },
        function () {
          e && clearTimeout(e),
            (t = setTimeout(function () {
              n.handlerOut(u);
            }, n.delayOut));
        }
      );
    })
  );
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"content": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwikitree_browser_extension"] = self["webpackChunkwikitree_browser_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/content.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUM2RztBQUNqQjtBQUM1Riw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsK0RBQStELDRCQUE0QixLQUFLLHlCQUF5Qix5QkFBeUIsa0JBQWtCLGtCQUFrQixLQUFLLGlEQUFpRCxxQkFBcUIsS0FBSyw0QkFBNEIsc0JBQXNCLDZCQUE2Qix5QkFBeUIsbUJBQW1CLGtCQUFrQiw2QkFBNkIsS0FBSywyQkFBMkIsb0JBQW9CLHlCQUF5QixnQkFBZ0Isa0JBQWtCLG1CQUFtQix1QkFBdUIsaUJBQWlCLGdCQUFnQiw2QkFBNkIsS0FBSyw4QkFBOEIseUJBQXlCLG1CQUFtQix5QkFBeUIsNkJBQTZCLDZCQUE2QixLQUFLLG9DQUFvQywwQkFBMEIsS0FBSywwREFBMEQsb0JBQW9CLHlCQUF5QixnQkFBZ0Isa0JBQWtCLG1CQUFtQix1QkFBdUIsaUJBQWlCLGdCQUFnQiw2QkFBNkIsS0FBSyw4QkFBOEIseUJBQXlCLG1CQUFtQix5QkFBeUIsNkJBQTZCLDZCQUE2QixLQUFLLG9DQUFvQywwQkFBMEIsS0FBSyx5REFBeUQsb0JBQW9CLHlCQUF5QixnQkFBZ0IsdUJBQXVCLG1CQUFtQixnQkFBZ0IsNkJBQTZCLGtCQUFrQixLQUFLLDhCQUE4Qix5QkFBeUIsbUJBQW1CLHVCQUF1Qix5QkFBeUIsa0JBQWtCLGtCQUFrQiw2QkFBNkIsNkJBQTZCLHVCQUF1Qiw0QkFBNEIsc0JBQXNCLEtBQUssb0NBQW9DLDBCQUEwQixLQUFLLHdGQUF3RixzQkFBc0IsS0FBSyx3R0FBd0csbURBQW1ELHFCQUFxQix1Q0FBdUMsdUJBQXVCLHVGQUF1Rix3QkFBd0IsS0FBSyxrQ0FBa0MscUJBQXFCLEtBQUssbUNBQW1DLHFCQUFxQixLQUFLLHFDQUFxQyxnQ0FBZ0MsS0FBSyxPQUFPLHVGQUF1RixLQUFLLFlBQVksT0FBTyxLQUFLLFlBQVksV0FBVyxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxVQUFVLFlBQVksYUFBYSxXQUFXLFVBQVUsWUFBWSxPQUFPLEtBQUssVUFBVSxZQUFZLFdBQVcsVUFBVSxVQUFVLFlBQVksV0FBVyxVQUFVLFlBQVksT0FBTyxLQUFLLFlBQVksV0FBVyxZQUFZLGFBQWEsYUFBYSxPQUFPLEtBQUssWUFBWSxPQUFPLFlBQVksTUFBTSxVQUFVLFlBQVksV0FBVyxVQUFVLFVBQVUsWUFBWSxXQUFXLFVBQVUsWUFBWSxPQUFPLEtBQUssWUFBWSxXQUFXLFlBQVksYUFBYSxhQUFhLE9BQU8sS0FBSyxZQUFZLE9BQU8sWUFBWSxNQUFNLFVBQVUsWUFBWSxXQUFXLFlBQVksV0FBVyxVQUFVLFlBQVksV0FBVyxNQUFNLEtBQUssWUFBWSxXQUFXLFlBQVksYUFBYSxXQUFXLFVBQVUsWUFBWSxhQUFhLGFBQWEsYUFBYSxXQUFXLE9BQU8sS0FBSyxZQUFZLE9BQU8sWUFBWSxNQUFNLFVBQVUsT0FBTyxZQUFZLE1BQU0sWUFBWSxXQUFXLFlBQVksY0FBYyxhQUFhLFdBQVcsWUFBWSxPQUFPLEtBQUssVUFBVSxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssWUFBWSwrQ0FBK0MsNEJBQTRCLEtBQUsseUJBQXlCLHlCQUF5QixrQkFBa0Isa0JBQWtCLEtBQUssaURBQWlELHFCQUFxQixLQUFLLDRCQUE0QixzQkFBc0IsNkJBQTZCLHlCQUF5QixtQkFBbUIsa0JBQWtCLDZCQUE2QixLQUFLLDJCQUEyQixvQkFBb0IseUJBQXlCLGdCQUFnQixrQkFBa0IsbUJBQW1CLHVCQUF1QixpQkFBaUIsZ0JBQWdCLDZCQUE2QixLQUFLLDhCQUE4Qix5QkFBeUIsbUJBQW1CLHlCQUF5Qiw2QkFBNkIsNkJBQTZCLEtBQUssb0NBQW9DLDBCQUEwQixLQUFLLDBEQUEwRCxvQkFBb0IseUJBQXlCLGdCQUFnQixrQkFBa0IsbUJBQW1CLHVCQUF1QixpQkFBaUIsZ0JBQWdCLDZCQUE2QixLQUFLLDhCQUE4Qix5QkFBeUIsbUJBQW1CLHlCQUF5Qiw2QkFBNkIsNkJBQTZCLEtBQUssb0NBQW9DLDBCQUEwQixLQUFLLHlEQUF5RCxvQkFBb0IseUJBQXlCLGdCQUFnQix1QkFBdUIsbUJBQW1CLGdCQUFnQiw2QkFBNkIsa0JBQWtCLEtBQUssOEJBQThCLHlCQUF5QixtQkFBbUIsdUJBQXVCLHlCQUF5QixrQkFBa0Isa0JBQWtCLDZCQUE2Qiw2QkFBNkIsdUJBQXVCLDRCQUE0QixzQkFBc0IsS0FBSyxvQ0FBb0MsMEJBQTBCLEtBQUssd0ZBQXdGLHNCQUFzQixLQUFLLHdHQUF3RyxtREFBbUQscUJBQXFCLHVDQUF1Qyx1QkFBdUIsdUZBQXVGLHdCQUF3QixLQUFLLGtDQUFrQyxxQkFBcUIsS0FBSyxtQ0FBbUMscUJBQXFCLEtBQUsscUNBQXFDLGdDQUFnQyxLQUFLLG1CQUFtQjtBQUMzdk07QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsNERBQTRELG1CQUFtQix3QkFBd0IsWUFBWSx3Q0FBd0MseUJBQXlCLEtBQUssdUJBQXVCLDBCQUEwQix3Q0FBd0MsNEJBQTRCLGlCQUFpQixvQkFBb0Isa0JBQWtCLGlCQUFpQixLQUFLLDBDQUEwQywwQkFBMEIsS0FBSyx5Q0FBeUMsOENBQThDLEtBQUssNkJBQTZCLDBDQUEwQyxLQUFLLFdBQVcscUdBQXFHLFVBQVUsWUFBWSxXQUFXLFlBQVksYUFBYSxNQUFNLEtBQUssWUFBWSxhQUFhLGFBQWEsV0FBVyxVQUFVLFVBQVUsVUFBVSxLQUFLLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSw0Q0FBNEMsbUJBQW1CLHdCQUF3QixZQUFZLHdDQUF3Qyx5QkFBeUIsS0FBSyx1QkFBdUIsMEJBQTBCLHdDQUF3Qyw0QkFBNEIsaUJBQWlCLG9CQUFvQixrQkFBa0IsaUJBQWlCLEtBQUssMENBQTBDLDBCQUEwQixLQUFLLHlDQUF5Qyw4Q0FBOEMsS0FBSyw2QkFBNkIsMENBQTBDLEtBQUssdUJBQXVCO0FBQ3ZpRDtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxnRUFBZ0UsMEJBQTBCLCtCQUErQiwrQkFBK0Isb0JBQW9CLG1DQUFtQywwQkFBMEIsMEJBQTBCLEtBQUssdURBQXVELDBCQUEwQixLQUFLLHVDQUF1Qyx3QkFBd0IsS0FBSyxPQUFPLHlJQUF5SSxZQUFZLGFBQWEsYUFBYSxXQUFXLFlBQVksYUFBYSxhQUFhLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLGdEQUFnRCwwQkFBMEIsK0JBQStCLCtCQUErQixvQkFBb0IsbUNBQW1DLDBCQUEwQiwwQkFBMEIsS0FBSyx1REFBdUQsMEJBQTBCLEtBQUssdUNBQXVDLHdCQUF3QixLQUFLLG1CQUFtQjtBQUM1bEM7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsdzFCQUF3MUIsdUJBQXVCLDJDQUEyQyxnQ0FBZ0MsS0FBSyw2R0FBNkcsb0NBQW9DLEtBQUsseUhBQXlILDhCQUE4QixLQUFLLDBDQUEwQyw0QkFBNEIsS0FBSyxvRUFBb0Usa0NBQWtDLEtBQUssZ0dBQWdHLHdDQUF3QyxLQUFLLDRDQUE0QyxrQ0FBa0MsS0FBSyx3REFBd0Qsd0JBQXdCLDhCQUE4QixLQUFLLGdEQUFnRCx3Q0FBd0MsS0FBSyxxRUFBcUUsbUNBQW1DLEtBQUssbUNBQW1DLHdCQUF3QixLQUFLLHNOQUFzTix5Q0FBeUMsS0FBSyxxY0FBcWMsMkJBQTJCLEtBQUssNENBQTRDLGdIQUFnSCxtQkFBbUIsMkJBQTJCLEtBQUssNENBQTRDLDRIQUE0SCwyQkFBMkIseUNBQXlDLEtBQUssd0lBQXdJLDJCQUEyQixLQUFLLHFEQUFxRCwwQkFBMEIsS0FBSyxnSkFBZ0osa0NBQWtDLEtBQUssa0NBQWtDLG1DQUFtQyxLQUFLLGdJQUFnSSxnQ0FBZ0MsS0FBSywrUUFBK1EsZ0NBQWdDLHFDQUFxQyxLQUFLLHNHQUFzRywyQ0FBMkMseUJBQXlCLEtBQUssV0FBVywrSEFBK0gsYUFBYSxhQUFhLGFBQWEsTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxNQUFNLFlBQVksYUFBYSxNQUFNLEtBQUssWUFBWSxNQUFNLE1BQU0sWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLFVBQVUsWUFBWSxNQUFNLGNBQWMsWUFBWSxNQUFNLEtBQUssS0FBSyxPQUFPLFdBQVcsWUFBWSxNQUFNLEtBQUssS0FBSyxPQUFPLGFBQWEsYUFBYSxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sWUFBWSxNQUFNLE9BQU8sWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLE1BQU0sWUFBWSxNQUFNLFVBQVUsWUFBWSxhQUFhLE1BQU0sTUFBTSxZQUFZLGFBQWEsdzBCQUF3MEIsdUJBQXVCLDJDQUEyQyxnQ0FBZ0MsS0FBSyw2R0FBNkcsb0NBQW9DLEtBQUsseUhBQXlILDhCQUE4QixLQUFLLDBDQUEwQyw0QkFBNEIsS0FBSyxvRUFBb0Usa0NBQWtDLEtBQUssZ0dBQWdHLHdDQUF3QyxLQUFLLDRDQUE0QyxrQ0FBa0MsS0FBSyx3REFBd0Qsd0JBQXdCLDhCQUE4QixLQUFLLGdEQUFnRCx3Q0FBd0MsS0FBSyxxRUFBcUUsbUNBQW1DLEtBQUssbUNBQW1DLHdCQUF3QixLQUFLLHNOQUFzTix5Q0FBeUMsS0FBSyxxY0FBcWMsMkJBQTJCLEtBQUssNENBQTRDLGdIQUFnSCxtQkFBbUIsMkJBQTJCLEtBQUssNENBQTRDLDRIQUE0SCwyQkFBMkIseUNBQXlDLEtBQUssd0lBQXdJLDJCQUEyQixLQUFLLHFEQUFxRCwwQkFBMEIsS0FBSyxnSkFBZ0osa0NBQWtDLEtBQUssa0NBQWtDLG1DQUFtQyxLQUFLLGdJQUFnSSxnQ0FBZ0MsS0FBSywrUUFBK1EsZ0NBQWdDLHFDQUFxQyxLQUFLLHNHQUFzRywyQ0FBMkMseUJBQXlCLEtBQUssdUJBQXVCO0FBQ3A4UztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSw0REFBNEQsdUJBQXVCLHdCQUF3QixxQkFBcUIsb0NBQW9DLHlCQUF5QixpQkFBaUIseUJBQXlCLHdCQUF3QixtQkFBbUIsaUJBQWlCLHFCQUFxQixLQUFLLHVCQUF1QixrQkFBa0IsS0FBSywrQkFBK0IsNEJBQTRCLDhCQUE4QiwyQ0FBMkMsMENBQTBDLHFCQUFxQiwyQkFBMkIsNEJBQTRCLHdCQUF3QixLQUFLLHlCQUF5QixtQkFBbUIsaUJBQWlCLEtBQUssb0RBQW9ELHFCQUFxQixtQkFBbUIsb0JBQW9CLHVCQUF1QixLQUFLLHFFQUFxRSxvQkFBb0IsS0FBSywyQkFBMkIseUJBQXlCLDZCQUE2QixLQUFLLHdCQUF3Qix5QkFBeUIsdUJBQXVCLHFCQUFxQixrQkFBa0Isb0JBQW9CLEtBQUssV0FBVyxtSUFBbUksWUFBWSxhQUFhLFdBQVcsWUFBWSxhQUFhLFdBQVcsWUFBWSxhQUFhLFdBQVcsVUFBVSxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxZQUFZLGFBQWEsYUFBYSxhQUFhLFdBQVcsWUFBWSxhQUFhLGFBQWEsTUFBTSxLQUFLLFVBQVUsVUFBVSxLQUFLLEtBQUssVUFBVSxVQUFVLFVBQVUsWUFBWSxNQUFNLEtBQUssVUFBVSxLQUFLLEtBQUssWUFBWSxhQUFhLE1BQU0sS0FBSyxZQUFZLGFBQWEsV0FBVyxVQUFVLFVBQVUsMkNBQTJDLHVCQUF1Qix3QkFBd0IscUJBQXFCLG9DQUFvQyx5QkFBeUIsaUJBQWlCLHlCQUF5Qix3QkFBd0IsbUJBQW1CLGlCQUFpQixxQkFBcUIsS0FBSyx1QkFBdUIsa0JBQWtCLEtBQUssK0JBQStCLDRCQUE0Qiw4QkFBOEIsMkNBQTJDLDBDQUEwQyxxQkFBcUIsMkJBQTJCLDRCQUE0Qix3QkFBd0IsS0FBSyx5QkFBeUIsbUJBQW1CLGlCQUFpQixLQUFLLG9EQUFvRCxxQkFBcUIsbUJBQW1CLG9CQUFvQix1QkFBdUIsS0FBSyxxRUFBcUUsb0JBQW9CLEtBQUssMkJBQTJCLHlCQUF5Qiw2QkFBNkIsS0FBSyx3QkFBd0IseUJBQXlCLHVCQUF1QixxQkFBcUIsa0JBQWtCLG9CQUFvQixLQUFLLHVCQUF1QjtBQUM5M0Y7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EscURBQXFELHlCQUF5QixpQkFBaUIsZ0JBQWdCLHFCQUFxQix3QkFBd0Isb0NBQW9DLHlCQUF5QixxREFBcUQsbUJBQW1CLG9CQUFvQix1QkFBdUIsS0FBSyxxQkFBcUIsd0JBQXdCLHlCQUF5QixhQUFhLG1CQUFtQixzQkFBc0IsS0FBSyxzQkFBc0Isb0JBQW9CLEtBQUssNEJBQTRCLHFCQUFxQix1QkFBdUIsMEJBQTBCLEtBQUsscUJBQXFCLDBCQUEwQixLQUFLLG1DQUFtQyxrQkFBa0IsaUNBQWlDLEtBQUsscUJBQXFCLHlCQUF5QixLQUFLLHNCQUFzQixxQkFBcUIsS0FBSywwQ0FBMEMsd0JBQXdCLDBCQUEwQixnQkFBZ0Isb0JBQW9CLHNCQUFzQix5QkFBeUIsZ0NBQWdDLHlCQUF5QixrQkFBa0IsMEJBQTBCLHVDQUF1QyxzQkFBc0IsMEJBQTBCLEtBQUssT0FBTyx1R0FBdUcsWUFBWSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsYUFBYSxhQUFhLFdBQVcsVUFBVSxZQUFZLE9BQU8sS0FBSyxZQUFZLGFBQWEsV0FBVyxVQUFVLFVBQVUsT0FBTyxLQUFLLFVBQVUsTUFBTSxLQUFLLFVBQVUsWUFBWSxhQUFhLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxVQUFVLFlBQVksT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLFVBQVUsTUFBTSxLQUFLLFlBQVksYUFBYSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsYUFBYSxXQUFXLFlBQVksYUFBYSxXQUFXLFlBQVkscUNBQXFDLHlCQUF5QixpQkFBaUIsZ0JBQWdCLHFCQUFxQix3QkFBd0Isb0NBQW9DLHlCQUF5QixxREFBcUQsbUJBQW1CLG9CQUFvQix1QkFBdUIsS0FBSyxxQkFBcUIsd0JBQXdCLHlCQUF5QixhQUFhLG1CQUFtQixzQkFBc0IsS0FBSyxzQkFBc0Isb0JBQW9CLEtBQUssNEJBQTRCLHFCQUFxQix1QkFBdUIsMEJBQTBCLEtBQUsscUJBQXFCLDBCQUEwQixLQUFLLG1DQUFtQyxrQkFBa0IsaUNBQWlDLEtBQUsscUJBQXFCLHlCQUF5QixLQUFLLHNCQUFzQixxQkFBcUIsS0FBSywwQ0FBMEMsd0JBQXdCLDBCQUEwQixnQkFBZ0Isb0JBQW9CLHNCQUFzQix5QkFBeUIsZ0NBQWdDLHlCQUF5QixrQkFBa0IsMEJBQTBCLHVDQUF1QyxzQkFBc0IsMEJBQTBCLEtBQUssbUJBQW1CO0FBQ3hoRztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxpREFBaUQsa0VBQWtFO0FBQ25IO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQdkM7QUFDZ0g7QUFDakI7QUFDL0YsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRjtBQUNBLDRFQUE0RSxnQkFBZ0IseUJBQXlCLEtBQUssZUFBZSx5QkFBeUIsa0JBQWtCLHdCQUF3QixpQkFBaUIsZUFBZSxtQkFBbUIsdUJBQXVCLG1DQUFtQyx3QkFBd0Isa0NBQWtDLG9CQUFvQixtQkFBbUIsa0JBQWtCLEtBQUssc0JBQXNCLG9CQUFvQixLQUFLLDJCQUEyQixzQkFBc0IsdUJBQXVCLEtBQUsscUJBQXFCLHdCQUF3QixLQUFLLGdCQUFnQix3QkFBd0IsS0FBSyxpQkFBaUIsd0JBQXdCLEtBQUssWUFBWSx5QkFBeUIsS0FBSyxnQ0FBZ0Msd0JBQXdCLFlBQVksa0JBQWtCLHVCQUF1QixxQkFBcUIsS0FBSyxnQ0FBZ0Msd0JBQXdCLFlBQVksaUJBQWlCLHVCQUF1QixxQkFBcUIsS0FBSyw4Q0FBOEMsdUJBQXVCLEtBQUssaUNBQWlDLHVDQUF1QyxLQUFLLGlDQUFpQywwQ0FBMEMsS0FBSyxvQkFBb0IsZ0JBQWdCLGtCQUFrQixLQUFLLE9BQU8saUhBQWlILFVBQVUsWUFBWSxNQUFNLEtBQUssWUFBWSxXQUFXLFlBQVksV0FBVyxVQUFVLFVBQVUsWUFBWSxhQUFhLGFBQWEsYUFBYSxXQUFXLFVBQVUsVUFBVSxLQUFLLEtBQUssVUFBVSxLQUFLLEtBQUssVUFBVSxZQUFZLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLFdBQVcsVUFBVSxZQUFZLFdBQVcsS0FBSyxLQUFLLFlBQVksV0FBVyxVQUFVLFlBQVksV0FBVyxLQUFLLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxNQUFNLEtBQUssVUFBVSxVQUFVLDJEQUEyRCxnQkFBZ0IseUJBQXlCLEtBQUssZUFBZSx5QkFBeUIsa0JBQWtCLHdCQUF3QixpQkFBaUIsZUFBZSxtQkFBbUIsdUJBQXVCLG1DQUFtQyx3QkFBd0Isa0NBQWtDLG9CQUFvQixtQkFBbUIsa0JBQWtCLEtBQUssc0JBQXNCLG9CQUFvQixLQUFLLDJCQUEyQixzQkFBc0IsdUJBQXVCLEtBQUsscUJBQXFCLHdCQUF3QixLQUFLLGdCQUFnQix3QkFBd0IsS0FBSyxpQkFBaUIsd0JBQXdCLEtBQUssWUFBWSx5QkFBeUIsS0FBSyxnQ0FBZ0Msd0JBQXdCLFlBQVksa0JBQWtCLHVCQUF1QixxQkFBcUIsS0FBSyxnQ0FBZ0Msd0JBQXdCLFlBQVksaUJBQWlCLHVCQUF1QixxQkFBcUIsS0FBSyw4Q0FBOEMsdUJBQXVCLEtBQUssaUNBQWlDLHVDQUF1QyxLQUFLLGlDQUFpQywwQ0FBMEMsS0FBSyxvQkFBb0IsZ0JBQWdCLGtCQUFrQixLQUFLLG1CQUFtQjtBQUM3c0c7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0Esd0RBQXdELDBCQUEwQixLQUFLLGdDQUFnQywwQkFBMEIsS0FBSyxpQ0FBaUMsNkJBQTZCLEtBQUssK0RBQStELHFDQUFxQyxLQUFLLHlDQUF5QyxrQkFBa0IsS0FBSyxPQUFPLG1IQUFtSCxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxVQUFVLHVDQUF1QywwQkFBMEIsS0FBSyxnQ0FBZ0MsMEJBQTBCLEtBQUssaUNBQWlDLDZCQUE2QixLQUFLLCtEQUErRCxxQ0FBcUMsS0FBSyx5Q0FBeUMsa0JBQWtCLEtBQUssbUJBQW1CO0FBQzErQjtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxrRUFBa0UsNEJBQTRCLEtBQUssd0JBQXdCLHNDQUFzQyxLQUFLLHVCQUF1QixxQkFBcUIsS0FBSyxnREFBZ0QsdUJBQXVCLE9BQU8scUNBQXFDLHVCQUF1Qix1QkFBdUIsa0JBQWtCLEtBQUssa0NBQWtDLHdCQUF3QixrQkFBa0IsS0FBSyxjQUFjLHVCQUF1QixrQkFBa0Isc0JBQXNCLEtBQUssa0JBQWtCLHFCQUFxQiwwQkFBMEIsS0FBSyxvQkFBb0Isa0JBQWtCLGtCQUFrQixLQUFLLHlCQUF5QixzQ0FBc0MsS0FBSyxzQkFBc0Isa0NBQWtDLEtBQUsscUJBQXFCLHNDQUFzQyxLQUFLLHNCQUFzQixtQ0FBbUMseUNBQXlDLEtBQUssc0JBQXNCLG9CQUFvQix3QkFBd0IsbUJBQW1CLHVCQUF1QixzQkFBc0IsMkJBQTJCLHlCQUF5QixtQkFBbUIsaUJBQWlCLG9CQUFvQiw4QkFBOEIsd0JBQXdCLEtBQUssNkNBQTZDLHFCQUFxQixLQUFLLGVBQWUsMEZBQTBGLEtBQUssWUFBWSxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxPQUFPLGFBQWEsTUFBTSxZQUFZLE9BQU8sS0FBSyxZQUFZLGFBQWEsV0FBVyxLQUFLLEtBQUssWUFBWSxXQUFXLEtBQUssS0FBSyxZQUFZLFdBQVcsVUFBVSxNQUFNLEtBQUssVUFBVSxZQUFZLE1BQU0sS0FBSyxVQUFVLFVBQVUsTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVksYUFBYSxPQUFPLEtBQUssVUFBVSxZQUFZLFdBQVcsWUFBWSxXQUFXLFlBQVksYUFBYSxXQUFXLFVBQVUsVUFBVSxZQUFZLGFBQWEsT0FBTyxLQUFLLFVBQVUsa0RBQWtELDRCQUE0QixLQUFLLHdCQUF3QixzQ0FBc0MsS0FBSyx1QkFBdUIscUJBQXFCLEtBQUssZ0RBQWdELHVCQUF1QixPQUFPLHFDQUFxQyx1QkFBdUIsdUJBQXVCLGtCQUFrQixLQUFLLGtDQUFrQyx3QkFBd0Isa0JBQWtCLEtBQUssY0FBYyx1QkFBdUIsa0JBQWtCLHNCQUFzQixLQUFLLGtCQUFrQixxQkFBcUIsMEJBQTBCLEtBQUssb0JBQW9CLGtCQUFrQixrQkFBa0IsS0FBSyx5QkFBeUIsc0NBQXNDLEtBQUssc0JBQXNCLGtDQUFrQyxLQUFLLHFCQUFxQixzQ0FBc0MsS0FBSyxzQkFBc0IsbUNBQW1DLHlDQUF5QyxLQUFLLHNCQUFzQixvQkFBb0Isd0JBQXdCLG1CQUFtQix1QkFBdUIsc0JBQXNCLDJCQUEyQix5QkFBeUIsbUJBQW1CLGlCQUFpQixvQkFBb0IsOEJBQThCLHdCQUF3QixLQUFLLDZDQUE2QyxxQkFBcUIsS0FBSywyQkFBMkI7QUFDbjBHO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTnZDLE1BQWtHO0FBQ2xHLE1BQXdGO0FBQ3hGLE1BQStGO0FBQy9GLE1BQWtIO0FBQ2xILE1BQTJHO0FBQzNHLE1BQTJHO0FBQzNHLE1BQTRHO0FBQzVHO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsNEZBQU87Ozs7QUFJc0Q7QUFDOUUsT0FBTyxpRUFBZSw0RkFBTyxJQUFJLG1HQUFjLEdBQUcsbUdBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBNEc7QUFDNUc7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyx5RkFBTzs7OztBQUlzRDtBQUM5RSxPQUFPLGlFQUFlLHlGQUFPLElBQUksZ0dBQWMsR0FBRyxnR0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUE4SDtBQUM5SDtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDJHQUFPOzs7O0FBSXdFO0FBQ2hHLE9BQU8saUVBQWUsMkdBQU8sSUFBSSxrSEFBYyxHQUFHLGtIQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QjdFLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQTRHO0FBQzVHO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMseUZBQU87Ozs7QUFJc0Q7QUFDOUUsT0FBTyxpRUFBZSx5RkFBTyxJQUFJLGdHQUFjLEdBQUcsZ0dBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBMkg7QUFDM0g7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyx3R0FBTzs7OztBQUlxRTtBQUM3RixPQUFPLGlFQUFlLHdHQUFPLElBQUksK0dBQWMsR0FBRywrR0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUE2RztBQUM3RztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDBGQUFPOzs7O0FBSXVEO0FBQy9FLE9BQU8saUVBQWUsMEZBQU8sSUFBSSxpR0FBYyxHQUFHLGlHQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QjdFLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQStHO0FBQy9HO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsNEZBQU87Ozs7QUFJeUQ7QUFDakYsT0FBTyxpRUFBZSw0RkFBTyxJQUFJLG1HQUFjLEdBQUcsbUdBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBa0g7QUFDbEg7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQywrRkFBTzs7OztBQUk0RDtBQUNwRixPQUFPLGlFQUFlLCtGQUFPLElBQUksc0dBQWMsR0FBRyxzR0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUFtSDtBQUNuSDtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLGdHQUFPOzs7O0FBSTZEO0FBQ3JGLE9BQU8saUVBQWUsZ0dBQU8sSUFBSSx1R0FBYyxHQUFHLHVHQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QjdFLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQTBHO0FBQzFHO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsdUZBQU87Ozs7QUFJb0Q7QUFDNUUsT0FBTyxpRUFBZSx1RkFBTyxJQUFJLDhGQUFjLEdBQUcsOEZBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUJqQztBQUNFO0FBQ1I7QUFDb0M7QUFDcEM7QUFDOEI7QUFDNUI7QUFDSTtBQUNNO0FBQ0U7QUFDQTtBQUNKO0FBQ0E7QUFDRjtBQUNWO0FBQ1I7QUFDNUI7QUFDQSwyREFBYTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJVO0FBQ3ZCO0FBQ087QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSCxpQkFBaUIsR0FBRyxnQ0FBZ0MsTUFBTSxJQUFJLEtBQUs7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLEVBQUUsNkNBQUM7QUFDSDtBQUNBO0FBQ0EsTUFBTSw2Q0FBQztBQUNQLHdDQUF3QyxjQUFjLFVBQVUsWUFBWSxRQUFRLFdBQVcsSUFBSSxhQUFhO0FBQ2hIO0FBQ0E7QUFDQSxjQUFjLDZDQUFDO0FBQ2Y7QUFDQTtBQUNBLFdBQVcsNkNBQUMseUJBQXlCLDZDQUFDO0FBQ3RDLEdBQUc7QUFDSCxFQUFFLDZDQUFDO0FBQ0g7QUFDQTtBQUNPO0FBQ1AsZ0JBQWdCLDZDQUFDO0FBQ2pCLEVBQUUsNkNBQUM7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EseUJBQXlCLGtEQUFNO0FBQy9CO0FBQ0E7QUFDQSxtQkFBbUIsdUJBQXVCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOLFVBQVUsa0RBQU07QUFDaEI7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9Lc0U7QUFDRjtBQUNBO0FBQ0U7QUFDTjtBQUNyQztBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEMsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSwwQ0FBMEM7QUFDMUMsdURBQXVELElBQUk7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGtFQUF5QjtBQUMvQztBQUNBLEVBQUU7QUFDRjtBQUNBLG1CQUFtQixtRUFBMEI7QUFDN0M7QUFDQSxFQUFFO0FBQ0Y7QUFDQSxtQkFBbUIsbUVBQTBCO0FBQzdDO0FBQ0EsRUFBRTtBQUNGO0FBQ0EsbUJBQW1CLGdFQUF1QjtBQUMxQztBQUNBLEVBQUU7QUFDRjtBQUNBLG1CQUFtQixrRUFBeUI7QUFDNUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUdtRDtBQUNXO0FBQzlELGlFQUFlO0FBQ2Y7QUFDQTtBQUNBLEtBQUssbURBQW1ELDREQUFNLFlBQVksMEJBQTBCO0FBQ3BHLEtBQUssc0RBQXNELDREQUFNLFlBQVkseUJBQXlCO0FBQ3RHO0FBQ0E7QUFDQSxPQUFPLHlDQUF5Qyw0REFBTSxZQUFZLG1CQUFtQjtBQUNyRixPQUFPLCtDQUErQyw0REFBTSxZQUFZLHlCQUF5QjtBQUNqRyxPQUFPLHlEQUF5RCw0REFBTSxZQUFZO0FBQ2xGO0FBQ0EsSUFBSTtBQUNKLEtBQUssOERBQThELDREQUFNLFlBQVk7QUFDckY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssOENBQThDLDREQUFNLFlBQVksd0NBQXdDO0FBQzdHLEtBQUssOENBQThDLDREQUFNLFlBQVksd0NBQXdDO0FBQzdHLEtBQUssaURBQWlELDREQUFNLFlBQVksa0RBQWtEO0FBQzFIO0FBQ0E7QUFDQSxPQUFPLDhDQUE4Qyw0REFBTSxZQUFZLHdDQUF3QztBQUMvRyxPQUFPLG9EQUFvRCw0REFBTSxZQUFZO0FBQzdFO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxPQUFPLGlFQUFpRSw0REFBTSxZQUFZO0FBQzFGO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxPQUFPLGlEQUFpRCw0REFBTSxZQUFZLDJDQUEyQztBQUNySCxPQUFPLDJDQUEyQyw0REFBTSxZQUFZLHFDQUFxQztBQUN6RyxPQUFPLDBEQUEwRCw0REFBTSxZQUFZLGtEQUFrRDtBQUNySSxPQUFPLGlEQUFpRCw0REFBTSxZQUFZLDJDQUEyQztBQUNySCxPQUFPLCtDQUErQyw0REFBTSxZQUFZO0FBQ3hFO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxPQUFPLDhDQUE4Qyw0REFBTSxZQUFZLHdDQUF3QztBQUMvRyxPQUFPLCtDQUErQyw0REFBTSxZQUFZLHlDQUF5QztBQUNqSCxPQUFPLG9EQUFvRCw0REFBTSxZQUFZLDRDQUE0QztBQUN6SCxPQUFPLHFEQUFxRCw0REFBTSxZQUFZLDZDQUE2QztBQUMzSCxPQUFPLHFEQUFxRCw0REFBTSxZQUFZO0FBQzlFO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsS0FBSywyREFBMkQsNERBQU0sWUFBWSx3QkFBd0I7QUFDMUc7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUsscURBQXFELDREQUFNLFlBQVksK0JBQStCO0FBQzNHLEtBQUssb0RBQW9ELDREQUFNLFlBQVksOEJBQThCO0FBQ3pHLEtBQUsscURBQXFELDREQUFNLFlBQVksK0JBQStCO0FBQzNHLEtBQUsseURBQXlELDREQUFNLFlBQVk7QUFDaEY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMENBQTBDLHlEQUFlLFlBQVk7QUFDMUU7QUFDQSxFQUFFO0FBQ0YsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZFaUQ7QUFDVztBQUM5RCxpRUFBZTtBQUNmO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsaUNBQWlDLDREQUFNLFlBQVksMEJBQTBCO0FBQzdFLEtBQUssc0RBQXNELDREQUFNLFlBQVkseUJBQXlCO0FBQ3RHLEtBQUssNERBQTRELDREQUFNLFlBQVk7QUFDbkY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMkRBQTJELDREQUFNLFlBQVk7QUFDbEY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMENBQTBDLHlEQUFlLFlBQVk7QUFDMUU7QUFDQTtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQmlEO0FBQ1c7QUFDOUQsaUVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQSxLQUFLLG1EQUFtRCw0REFBTSxZQUFZO0FBQzFFO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxLQUFLLG1EQUFtRCw0REFBTSxZQUFZLDBCQUEwQjtBQUNwRyxLQUFLLHNEQUFzRCw0REFBTSxZQUFZLHlCQUF5QjtBQUN0RyxLQUFLLHFEQUFxRCw0REFBTSxZQUFZLDhDQUE4QztBQUMxSCxLQUFLLGlEQUFpRCw0REFBTSxZQUFZLDBDQUEwQztBQUNsSCxLQUFLLDJEQUEyRCw0REFBTSxZQUFZLDhDQUE4QztBQUNoSSxLQUFLLHdEQUF3RCw0REFBTSxZQUFZLGdEQUFnRDtBQUMvSCxLQUFLLDREQUE0RCw0REFBTSxZQUFZO0FBQ25GO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxLQUFLLDJEQUEyRCw0REFBTSxZQUFZO0FBQ2xGO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLDBFQUEwRSx3REFBYyxZQUFZLGtDQUFrQztBQUM3SSxPQUFPLDRFQUE0RSx3REFBYyxZQUFZLGlDQUFpQztBQUM5SSxPQUFPLGtFQUFrRSx3REFBYyxZQUFZLHFDQUFxQztBQUN4SSxPQUFPLDhFQUE4RSx3REFBYyxZQUFZLG1DQUFtQztBQUNsSixPQUFPLDZGQUE2Rix3REFBYyxZQUFZLDJDQUEyQztBQUN6SyxPQUFPLHVGQUF1Rix3REFBYyxZQUFZLDJDQUEyQztBQUNuSyxPQUFPLDJGQUEyRix3REFBYyxZQUFZLDRDQUE0QztBQUN4SyxPQUFPLGdHQUFnRyx3REFBYyxZQUFZLCtCQUErQjtBQUNoSztBQUNBO0FBQ0E7QUFDQSxTQUFTLDJEQUEyRCx3REFBYyxZQUFZLDhCQUE4QjtBQUM1SCxTQUFTLDREQUE0RCx3REFBYyxZQUFZO0FBQy9GO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixLQUFLLDBDQUEwQyx5REFBZSxZQUFZO0FBQzFFO0FBQ0E7QUFDQSxDQUFDLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbERpRDtBQUNXO0FBQzlELGlFQUFlO0FBQ2Y7QUFDQTtBQUNBLEtBQUssbURBQW1ELDREQUFNLFlBQVksMEJBQTBCO0FBQ3BHLEtBQUssc0RBQXNELDREQUFNLFlBQVkseUJBQXlCO0FBQ3RHLEtBQUssNERBQTRELDREQUFNLFlBQVk7QUFDbkY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMkRBQTJELDREQUFNLFlBQVk7QUFDbEY7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEtBQUssMENBQTBDLHlEQUFlLFlBQVk7QUFDMUU7QUFDQTtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQmlEO0FBQ1c7QUFDOUQsaUVBQWU7QUFDZjtBQUNBO0FBQ0EsS0FBSyx1REFBdUQsNERBQU0sWUFBWSx3QkFBd0I7QUFDdEcsS0FBSyxtREFBbUQsNERBQU0sWUFBWSwwQkFBMEI7QUFDcEcsS0FBSyx1REFBdUQsNERBQU0sWUFBWSw2QkFBNkI7QUFDM0csS0FBSyx1REFBdUQsNERBQU0sWUFBWSw2QkFBNkI7QUFDM0c7QUFDQTtBQUNBLE9BQU8saURBQWlELDREQUFNLFlBQVksMkJBQTJCO0FBQ3JHLE9BQU8sNkNBQTZDLDREQUFNLFlBQVksdUJBQXVCO0FBQzdGLE9BQU8sdURBQXVELDREQUFNLFlBQVk7QUFDaEY7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBLE9BQU8sOERBQThELDREQUFNLFlBQVk7QUFDdkY7QUFDQSxJQUFJO0FBQ0osS0FBSyxzREFBc0QsNERBQU0sWUFBWTtBQUM3RTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0EsS0FBSywwQ0FBMEMseURBQWUsWUFBWTtBQUMxRTtBQUNBO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUM3QnFCO0FBQ3VCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLFFBQVEsNkNBQUM7QUFDVCx3QkFBd0IsNkNBQUM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiw2Q0FBQztBQUNqQjtBQUNBLG9CQUFvQiw2Q0FBQztBQUNyQjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLHFEQUFXO0FBQ3ZDO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUM1QnNCO0FBQ1M7QUFDUjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sNkNBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGtEQUFNLEVBQUUsc0dBQXNHO0FBQ3JJO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHFEQUFXO0FBQzFCLGtCQUFrQiw2Q0FBQztBQUNuQjtBQUNBLGlCQUFpQiw2Q0FBQztBQUNsQjtBQUNBLEVBQUU7QUFDRixtQkFBbUIsNkNBQUM7QUFDcEIsa0JBQWtCLDZDQUFDO0FBQ25CLENBQUMsNkNBQUM7QUFDRiwyQkFBMkIsaUJBQWlCLFlBQVksaUJBQWlCO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsR0FBRyxRQUFRO0FBQ1g7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUN6RHVCO0FBQ3VCO0FBQ0o7QUFDMUM7QUFDQTtBQUNBLDBDQUEwQyxxREFBVztBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsNkNBQUM7QUFDbEI7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmLGFBQWE7QUFDYjtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0EsUUFBUSw2Q0FBQztBQUNUO0FBQ0EsVUFBVSxnQ0FBZ0M7QUFDMUM7QUFDQTtBQUNBO0FBQ0EsUUFBUSw2Q0FBQztBQUNULFVBQVUsNkNBQUM7QUFDWCxRQUFRLDZDQUFDO0FBQ1Q7QUFDQTtBQUNBLFdBQVc7QUFDWCxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sNkNBQUM7QUFDUCxxQkFBcUIsNkNBQUM7QUFDdEIsTUFBTSw2Q0FBQztBQUNQLE1BQU0sNkNBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsNkNBQUM7QUFDakIsTUFBTSw2Q0FBQztBQUNQLE1BQU0sNkNBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNyRXNCO0FBQ0M7QUFDeEI7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMLElBQUksNkNBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksNkNBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLDZDQUFDO0FBQ0wsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1A7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERzQjtBQUNTO0FBQ047QUFDYTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksNkNBQUM7QUFDTCxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBLHNCQUFzQiw2Q0FBQztBQUN2QixtQkFBbUIscURBQVc7QUFDOUIsaUJBQWlCLDZDQUFLO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsZUFBZSwrQkFBK0I7QUFDOUM7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaLGdCQUFnQiw2Q0FBQztBQUNqQixrQ0FBa0MsNkNBQUM7QUFDbkMsY0FBYyw2Q0FBQztBQUNmLGdCQUFnQiw2Q0FBQztBQUNqQix1REFBdUQsYUFBYSxLQUFLLGlCQUFpQix5Q0FBeUMsZ0JBQWdCO0FBQ25KO0FBQ0E7QUFDQTtBQUNBLGNBQWMsNkNBQUM7QUFDZjtBQUNBLGdCQUFnQiw2Q0FBQztBQUNqQixnQkFBZ0IsNkNBQUM7QUFDakI7QUFDQSxlQUFlO0FBQ2Y7QUFDQSw0QkFBNEIsNkNBQUs7QUFDakM7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0EseUJBQXlCLCtCQUErQjtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQiw2Q0FBQztBQUMzQiwwQkFBMEIsNkNBQUM7QUFDM0IsMEJBQTBCLDZDQUFDO0FBQzNCO0FBQ0EsMEJBQTBCLDZDQUFDO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CLGVBQWU7QUFDZjtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsa0RBQU07QUFDL0I7QUFDQTtBQUNBLG1CQUFtQix1QkFBdUI7QUFDMUM7QUFDQTtBQUNBLGNBQWMsK0NBQStDO0FBQzdELEtBQUs7QUFDTDtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsa0RBQU07QUFDL0I7QUFDQTtBQUNBLG1CQUFtQix1QkFBdUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsa0RBQU07QUFDL0I7QUFDQTtBQUNBLG1CQUFtQix1QkFBdUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw2Q0FBQztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFLDZDQUFDO0FBQ0gsRUFBRSw2Q0FBQztBQUNIO0FBQ0EsY0FBYyxxREFBVztBQUN6QixjQUFjLDZDQUFDO0FBQ2Y7QUFDQSxHQUFHO0FBQ0g7QUFDQSxJQUFJLDZDQUFDO0FBQ0wsTUFBTSw2Q0FBQztBQUNQO0FBQ0EsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQSxNQUFNLDZDQUFDO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsNkNBQUM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLDZDQUFDO0FBQ25CLG1CQUFtQiw2Q0FBQztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWLGdDQUFnQyw2Q0FBQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLDZDQUFDO0FBQ1gsVUFBVSw2Q0FBQztBQUNYLFVBQVUsNkNBQUM7QUFDWDtBQUNBLFVBQVUsNkNBQUM7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiw2Q0FBSztBQUN6QjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxNQUFNLDZDQUFDO0FBQ1A7QUFDQSx3QkFBd0IsNkNBQUM7QUFDekIsSUFBSSw2Q0FBQztBQUNMLE1BQU0sNkNBQUM7QUFDUCw2Q0FBNkMsYUFBYSxLQUFLLGlCQUFpQixxQkFBcUIsZ0JBQWdCO0FBQ3JIO0FBQ0E7QUFDQSxpQkFBaUIsNkNBQUs7QUFDdEI7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixxREFBVztBQUM3QixjQUFjLDZDQUFDO0FBQ2Y7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWMscURBQVc7QUFDekIsY0FBYyw2Q0FBQztBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFLDZDQUFDO0FBQ0gsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7Ozs7Ozs7Ozs7Ozs7OztBQ3hadUI7QUFDZ0I7QUFDZDtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsNkNBQUM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxRQUFRLDZDQUFDLDJDQUEyQyw2Q0FBQztBQUNyRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLHNCQUFzQiw2Q0FBQztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBLGNBQWMsNkNBQUM7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksU0FBUyw2Q0FBQztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSCxFQUFFLDZDQUFDO0FBQ0gsSUFBSSw2Q0FBQztBQUNMO0FBQ0EsRUFBRSw2Q0FBQztBQUNILElBQUksNkNBQUM7QUFDTCxHQUFHO0FBQ0gsRUFBRSw2Q0FBQztBQUNILElBQUksNkNBQUM7QUFDTCxHQUFHO0FBQ0gsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxrREFBSTtBQUNmO0FBQ0E7QUFDQSxRQUFRO0FBQ1IsUUFBUSxrREFBTTtBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsNkNBQUM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixrREFBSTtBQUN0QjtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsNkNBQUM7QUFDakIsa0JBQWtCLDZDQUFDO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixjQUFjLDZDQUFDO0FBQ2Y7QUFDQSxnQkFBZ0IsNkNBQUMscUJBQXFCLDZDQUFDO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWCxrQ0FBa0M7QUFDbEMsU0FBUztBQUNUO0FBQ0EsS0FBSztBQUNMLElBQUk7QUFDSixJQUFJLDZDQUFDLHFCQUFxQiw2Q0FBQztBQUMzQixJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsNkNBQUM7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw2Q0FBQztBQUN0QixjQUFjLDZDQUFDO0FBQ2Y7QUFDQTtBQUNBO0FBQ0EsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvTXVCO0FBQ3FFO0FBQ2pFO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw2Q0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksc0VBQXdCO0FBQzVCLElBQUksNkNBQUM7QUFDTDtBQUNBLHdCQUF3Qiw2Q0FBQztBQUN6QixzQkFBc0IsNkNBQUM7QUFDdkIsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLFVBQVUsNkNBQUM7QUFDWCxRQUFRLDZDQUFDO0FBQ1QsUUFBUTtBQUNSO0FBQ0EsUUFBUSwwREFBWTtBQUNwQiwwQkFBMEIseURBQVc7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDZDQUFDO0FBQ2IsV0FBVztBQUNYLGtDQUFrQyw2Q0FBQztBQUNuQztBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQSxVQUFVLDZDQUFDO0FBQ1g7QUFDQSxrQ0FBa0MsNkNBQUM7QUFDbkM7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0EsV0FBVztBQUNYO0FBQ0EsVUFBVSw2Q0FBQztBQUNYLFVBQVUsNkNBQUM7QUFDWCxZQUFZLDZDQUFDO0FBQ2IsV0FBVztBQUNYLFVBQVUsNkNBQUM7QUFDWCxVQUFVLDZDQUFDO0FBQ1gsWUFBWSw2Q0FBQztBQUNiLFdBQVc7QUFDWCxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw2Q0FBQztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsNkNBQUM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxrREFBSTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLCtCQUErQiw2Q0FBQztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLFFBQVEsNkNBQUMsd0JBQXdCLDZDQUFDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsNkNBQUM7QUFDWCxTQUFTO0FBQ1QsT0FBTztBQUNQO0FBQ0E7QUFDQSxRQUFRLDZDQUFDO0FBQ1QseUNBQXlDLDZDQUFDO0FBQzFDO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSw0Q0FBNEMsSUFBSTtBQUNoRDtBQUNBLDRDQUE0QyxFQUFFO0FBQzlDO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDLCtCQUErQjtBQUMvQiwrQkFBK0I7QUFDL0IsaUNBQWlDO0FBQ2pDLGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL1gyQjtBQUNZO0FBQzJDO0FBQ3JEO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxtQ0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksc0VBQXdCO0FBQzVCLElBQUksbUNBQUM7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLHlCQUF5Qix3Q0FBTTtBQUMvQjtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxrREFBSTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLEVBQUU7QUFDMUMsTUFBTSxrREFBSTtBQUNWO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLElBQUksUUFBUSxFQUFFLFFBQVEsRUFBRTtBQUN2RDtBQUNBLElBQUk7QUFDSjtBQUNBLDBDQUEwQyxJQUFJO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxJQUFJO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsbUNBQUM7QUFDSDtBQUNBO0FBQ0EsYUFBYSxtQ0FBQztBQUNkO0FBQ0E7QUFDQSxvQkFBb0IsOERBQWdCO0FBQ3BDLHFCQUFxQiw4REFBZ0I7QUFDckMsb0JBQW9CLDhEQUFnQjtBQUNwQyxxQkFBcUIsOERBQWdCO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxrREFBSTtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsaURBQWlELEVBQUUsT0FBTyxFQUFFO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUM7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsa0RBQUk7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsZ0JBQWdCLGtEQUFJO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixrREFBSTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsbUNBQUM7QUFDM0Isb0RBQW9ELFlBQVk7QUFDaEUsMENBQTBDLGlCQUFpQixrRkFBa0YsaUJBQWlCO0FBQzlKO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLG1DQUFDO0FBQzdCLFFBQVEsbUNBQUM7QUFDVCw4QkFBOEIsbUNBQUM7QUFDL0IsMEJBQTBCLHFDQUFxQztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG1DQUFDO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sbUNBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLElBQUksbUNBQUM7QUFDTCxJQUFJLG1DQUFDO0FBQ0wsTUFBTSxtQ0FBQztBQUNQLEtBQUs7QUFDTCxJQUFJLG1DQUFDO0FBQ0wsTUFBTSxtQ0FBQztBQUNQLEtBQUs7QUFDTDtBQUNBLElBQUksbUNBQUM7QUFDTCxJQUFJLG1DQUFDO0FBQ0wsTUFBTSxtQ0FBQztBQUNQLEtBQUs7QUFDTCxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuZnVCO0FBQ3VEO0FBQy9DO0FBQy9CO0FBQ0E7QUFDQSwrQkFBK0IsNkNBQUM7QUFDaEMsU0FBUyw2Q0FBQywyQ0FBMkMsNkNBQUM7QUFDdEQ7QUFDQTtBQUNBLDZCQUE2Qiw4REFBZ0I7QUFDN0M7QUFDQSw4QkFBOEIsOERBQWdCO0FBQzlDO0FBQ0EsOEJBQThCLDhEQUFnQjtBQUM5QztBQUNBLDZCQUE2Qiw4REFBZ0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixnQkFBZ0I7QUFDNUM7QUFDQSxnQ0FBZ0MsZ0JBQWdCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZDQUFDO0FBQ2pCLHdCQUF3Qiw2Q0FBQztBQUN6QixjQUFjO0FBQ2Qsd0JBQXdCLDZDQUFDO0FBQ3pCO0FBQ0EsWUFBWSwwREFBWTtBQUN4QixtQ0FBbUMseURBQVc7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyw2Q0FBQztBQUNqQyx3REFBd0QsNkNBQUMsbUNBQW1DLElBQUk7QUFDaEc7QUFDQSxnQ0FBZ0MsNkNBQUM7QUFDakMsd0RBQXdELDZDQUFDLG1DQUFtQyxJQUFJO0FBQ2hHO0FBQ0EsZ0NBQWdDLDZDQUFDO0FBQ2pDLDJEQUEyRCw2Q0FBQyxzQ0FBc0MsSUFBSTtBQUN0RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyRUFBMkUsSUFBSTtBQUMvRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0IsaURBQWlELDZDQUFDO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBLGtGQUFrRiw2Q0FBQztBQUNuRjtBQUNBO0FBQ0Esa0ZBQWtGLDZDQUFDO0FBQ25GO0FBQ0E7QUFDQTtBQUNBLDhFQUE4RSw2Q0FBQztBQUMvRTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBLGtDQUFrQyw2Q0FBQywwQ0FBMEMsaUNBQWlDO0FBQzlHLG9CQUFvQiw2Q0FBQztBQUNyQixzQ0FBc0MsNkNBQUMsMENBQTBDLGlDQUFpQztBQUNsSDtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUM3THNCO0FBQzZCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSwrREFBaUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsRUFBRSw2Q0FBQztBQUNIO0FBQ0EsR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiw2Q0FBQztBQUNwQjtBQUNBO0FBQ0EsY0FBYyw2Q0FBQztBQUNmLG9CQUFvQiw2Q0FBQztBQUNyQjtBQUNBO0FBQ0EsMEJBQTBCLGlDQUFpQyxPQUFPO0FBQ2xFLG9DQUFvQyxvQkFBb0Isb0JBQW9CLG9CQUFvQjtBQUNoRyxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUMsc0NBQXNDO0FBQ3hDLENBQUMsNkNBQUMsbUNBQW1DO0FBQ3JDLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGO0FBQ0EsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGO0FBQ0EsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGO0FBQ0EsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRixDQUFDLDZDQUFDO0FBQ0YsQ0FBQyw2Q0FBQztBQUNGLENBQUMsNkNBQUM7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7QUNyRXVCO0FBQ3ZCO0FBQ0E7QUFDQSw2QkFBNkIsNkNBQUM7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLHFEQUFTO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsT0FBTztBQUM3QjtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyw2Q0FBQztBQUNwQywwQkFBMEIsNkNBQUM7QUFDM0I7QUFDQSxZQUFZLDZDQUFDO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7OztBQ3BDc0I7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZDQUFDLHlCQUF5QjtBQUMxQyxnQkFBZ0IsNkNBQUMsb0NBQW9DO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLGNBQWMsa0JBQWtCO0FBQ2pHO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLHdCQUF3Qiw2Q0FBQztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDZDQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDdENzQjtBQUNvQjtBQUMzQztBQUNBO0FBQ0E7QUFDQSxJQUFJLDZDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsUUFBUSw2Q0FBQztBQUNULFFBQVEsNkNBQUM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixrQkFBa0Isa0JBQWtCLG1CQUFtQixlQUFlLGlCQUFpQjtBQUNoSDtBQUNBO0FBQ0EsUUFBUSxrREFBTTtBQUNkO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsNEJBQTRCLDZDQUFDO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxnQkFBZ0IsaUNBQWlDLFlBQVk7QUFDbEgsWUFBWTtBQUNaLFNBQVM7QUFDVCxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0EsRUFBRSw2Q0FBQztBQUNILFFBQVEsNkNBQUM7QUFDVCxNQUFNLDZDQUFDO0FBQ1AsTUFBTSw2Q0FBQztBQUNQO0FBQ0EsR0FBRztBQUNILENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Q3FCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQsa0JBQWtCLGdCQUFnQixjQUFjLGVBQWUsVUFBVSxFQUFFLElBQUksZ0JBQWdCLGNBQWMsU0FBUyxFQUFFLElBQUksY0FBYyx1QkFBdUI7QUFDeE4sK0NBQStDLGtCQUFrQixnQkFBZ0IsY0FBYyxlQUFlLFVBQVUsRUFBRSxJQUFJLGdCQUFnQixjQUFjLFNBQVMsRUFBRSxJQUFJLGNBQWMsdUJBQXVCO0FBQ2hOLDhDQUE4QyxrQkFBa0I7QUFDaEUsa0NBQWtDLGtCQUFrQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLElBQUksWUFBWSxJQUFJLGlCQUFpQixJQUFJLDZCQUE2QixJQUFJLFlBQVksSUFBSSxpQkFBaUIsSUFBSTtBQUM1SCxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0FBQ3pCLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0Esa0RBQWtELElBQUk7QUFDdEQ7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSx1Q0FBdUM7QUFDekMsRUFBRSwyQ0FBMkM7QUFDN0MsRUFBRSxpREFBaUQ7QUFDbkQsRUFBRSwyQ0FBMkM7QUFDN0MsRUFBRSx5Q0FBeUM7QUFDM0MsRUFBRSx1Q0FBdUM7QUFDekMsRUFBRSw2RkFBNkY7QUFDL0YsRUFBRSw2TEFBNkw7QUFDL0wsRUFBRSwyTEFBMkw7QUFDN0wsRUFBRSxvTUFBb007QUFDdE0sRUFBRSxxSEFBcUg7QUFDdkgsRUFBRSxpTUFBaU07QUFDbk0sRUFBRSw2TUFBNk07QUFDL00sRUFBRSxnTUFBZ007QUFDbE0sRUFBRSxvTEFBb0w7QUFDdEwsRUFBRSxnSkFBZ0o7QUFDbEosRUFBRSwrSEFBK0g7QUFDakksRUFBRSxpSEFBaUg7QUFDbkgsRUFBRSxpSEFBaUg7QUFDbkgsRUFBRSwySkFBMko7QUFDN0osRUFBRSx1S0FBdUs7QUFDekssRUFBRSxxSUFBcUk7QUFDdkksRUFBRSxxS0FBcUs7QUFDdkssRUFBRSwyTEFBMkw7QUFDN0wsRUFBRSxrREFBa0Q7QUFDcEQsRUFBRSxxQkFBcUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLHNDQUFzQyxxQ0FBcUMsb0JBQW9CO0FBQy9GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2SUFBNkk7QUFDN0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLDhDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixpREFBaUQ7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEIsR0FBRztBQUNIO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxnQkFBZ0IsY0FBYyw0QkFBNEI7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxLQUFLO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsTUFBTTtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGdCQUFnQjtBQUNoQztBQUNBO0FBQ0EsaUJBQWlCLHVCQUF1QjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsTUFBTTtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixnQkFBZ0I7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsdUJBQXVCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsV0FBVztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsVUFBVTtBQUM1QyxzQkFBc0IsRUFBRSxZQUFZLGNBQWMsYUFBYSxZQUFZLFNBQVMsRUFBRSxJQUFJLFFBQVEsRUFBRSxJQUFJLGFBQWEsUUFBUSxFQUFFO0FBQy9IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlELEVBQUUsa0JBQWtCO0FBQzdFLCtDQUErQyxFQUFFO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLHdCQUF3QjtBQUNsRDtBQUNBLHdDQUF3Qyx3QkFBd0I7QUFDaEUsNENBQTRDLHdCQUF3QjtBQUNwRSw0Q0FBNEMsd0JBQXdCO0FBQ3BFLHdDQUF3Qyx3QkFBd0I7QUFDaEUsc0NBQXNDLHdCQUF3QjtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyx3QkFBd0I7QUFDNUQ7QUFDQSx1Q0FBdUMsd0JBQXdCO0FBQy9EO0FBQ0E7QUFDQTtBQUNBLHVDQUF1Qyx3QkFBd0I7QUFDL0Q7QUFDQSwwQkFBMEIsd0JBQXdCO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxvQkFBb0I7QUFDN0QsNkNBQTZDLHNCQUFzQjtBQUNuRSx5Q0FBeUMsb0JBQW9CO0FBQzdEO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxvQkFBb0I7QUFDeEQsd0NBQXdDLHNCQUFzQjtBQUM5RCxvQ0FBb0Msb0JBQW9CO0FBQ3hEO0FBQ0E7QUFDQSwrQkFBK0IseUJBQXlCO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLG9CQUFvQjtBQUMxRCwwQ0FBMEMsc0JBQXNCO0FBQ2hFLHNDQUFzQyxvQkFBb0I7QUFDMUQ7QUFDQTtBQUNBLGlDQUFpQyx5QkFBeUI7QUFDMUQ7QUFDQSxNQUFNO0FBQ047QUFDQSxJQUFJO0FBQ0osR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7OztBQ2huQ3VCO0FBQ3ZCO0FBQ0EsNkRBQWU7QUFDZixZQUFZLHNEQUFzRDtBQUNsRTtBQUNBLFNBQVMsb0RBQVE7QUFDakI7QUFDQTtBQUNBO0FBQ0EsWUFBWSw2Q0FBQztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7Ozs7OztVQzFCQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOztVQUVBO1VBQ0E7Ozs7O1dDekJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsK0JBQStCLHdDQUF3QztXQUN2RTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlCQUFpQixxQkFBcUI7V0FDdEM7V0FDQTtXQUNBLGtCQUFrQixxQkFBcUI7V0FDdkM7V0FDQTtXQUNBLEtBQUs7V0FDTDtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDM0JBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7OztXQ05BOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7V0NoREE7Ozs7O1VFQUE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXIuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2FwcHNNZW51L2FwcHNNZW51LmNzcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5jc3MiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZGFya01vZGUvZGFya01vZGUuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2Rpc3RhbmNlQW5kUmVsYXRpb25zaGlwL2Rpc3RhbmNlQW5kUmVsYXRpb25zaGlwLmNzcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kcmFmdExpc3QvZHJhZnRMaXN0LmNzcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9mYW1pbHlHcm91cC9mYW1pbHlHcm91cC5jc3MiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZmFtaWx5VGltZWxpbmUvZmFtaWx5VGltZWxpbmUuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2xvY2F0aW9uc0hlbHBlci9sb2NhdGlvbnNIZWxwZXIuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL3d0Ky93dFBsdXMuY3NzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXIuY3NzPzk3MzUiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvYXBwc01lbnUvYXBwc01lbnUuY3NzPzU3MGEiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUvY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUuY3NzPzdhYTYiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZGFya01vZGUvZGFya01vZGUuY3NzP2RiMWEiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAvZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAuY3NzPzEwNmUiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvZHJhZnRMaXN0L2RyYWZ0TGlzdC5jc3M/NzhjNSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9mYW1pbHlHcm91cC9mYW1pbHlHcm91cC5jc3M/NmE4NCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9mYW1pbHlUaW1lbGluZS9mYW1pbHlUaW1lbGluZS5jc3M/NjQyYiIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9sb2NhdGlvbnNIZWxwZXIvbG9jYXRpb25zSGVscGVyLmNzcz83NzA2Iiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL3d0Ky93dFBsdXMuY3NzPzEwZDMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvY29udGVudC5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9jb3JlL2NvbW1vbi5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9jb3JlL2VkaXRUb29sYmFyLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXJDYXRlZ29yeU9wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvY29yZS9lZGl0VG9vbGJhckdlbmVyaWNPcHRpb25zLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXJQcm9maWxlT3B0aW9ucy5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9jb3JlL2VkaXRUb29sYmFyU3BhY2VPcHRpb25zLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXJUZW1wbGF0ZU9wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvYWthTmFtZUxpbmtzL2FrYU5hbWVMaW5rcy5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9hcHBzTWVudS9hcHBzTWVudS5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kYXJrTW9kZS9kYXJrTW9kZS5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9kcmFmdExpc3QvZHJhZnRMaXN0LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2ZhbWlseUdyb3VwL2ZhbWlseUdyb3VwLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2ZhbWlseVRpbWVsaW5lL2ZhbWlseVRpbWVsaW5lLmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL2xvY2F0aW9uc0hlbHBlci9sb2NhdGlvbnNIZWxwZXIuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvcHJpbnRlcmZyaWVuZGx5L3ByaW50ZXJmcmllbmRseS5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi8uL3NyYy9mZWF0dXJlcy9yYW5kb21Qcm9maWxlL3JhbmRvbVByb2ZpbGUuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvc291cmNlcHJldmlldy9zb3VyY2VwcmV2aWV3LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL2ZlYXR1cmVzL3NwYWNlcHJldmlldy9zcGFjZXByZXZpZXcuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvZmVhdHVyZXMvd3QrL2NvbnRlbnRFZGl0LmpzIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL3RoaXJkcGFydHkvanF1ZXJ5LmhvdmVyRGVsYXkuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2NodW5rIGxvYWRlZCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9qc29ucCBjaHVuayBsb2FkaW5nIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9ub25jZSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCJcXHJcXG4jZWRpdFRvb2xiYXJFeHQge1xcclxcblxcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcXHJcXG59XFxyXFxuXFxyXFxuI2VkaXRUb29sYmFyRGl2IHtcXHJcXG5cXHRwb3NpdGlvbjogcmVsYXRpdmU7XFxyXFxuXFx0ZmxvYXQ6IGxlZnQ7XFxyXFxuXFx0ei1pbmRleDogMTA7XFxyXFxufVxcclxcblxcclxcbiNlZGl0VG9vbGJhckRpdjpob3ZlciAuZWRpdFRvb2xiYXJNZW51MCB7XFxyXFxuXFx0ZGlzcGxheTogYmxvY2s7XFxyXFxufVxcclxcblxcclxcbiNlZGl0VG9vbGJhckJ1dHRvbiB7XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcblxcdGJvcmRlcjogMXB4IHNvbGlkICNhYWE7XFxyXFxuXFx0Ym9yZGVyLXJhZGl1czogM3B4O1xcclxcblxcdHBhZGRpbmc6IDJweDtcXHJcXG5cXHRtYXJnaW46IDFweDtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZWVlO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MiB7XFxyXFxuXFx0ZGlzcGxheTogbm9uZTtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0dG9wOiAtMXB4O1xcclxcblxcdGxlZnQ6IDE2MXB4O1xcclxcblxcdHdpZHRoOiAxNjBweDtcXHJcXG5cXHRsaXN0LXN0eWxlOiBub25lO1xcclxcblxcdHBhZGRpbmc6IDE7XFxyXFxuXFx0bWFyZ2luOiAwO1xcclxcblxcdHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUyPmxpIHtcXHJcXG5cXHRwb3NpdGlvbjogcmVsYXRpdmU7XFxyXFxuXFx0aGVpZ2h0OiAyNHB4O1xcclxcblxcdG1hcmdpbi1ib3R0b206IDFweDtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcclxcblxcdGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUyPmxpOmhvdmVyIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjQ0NDQ0NDO1xcclxcbn1cXHJcXG5cXHJcXG4vKiBzZWNvbmQgbGV2ZWwgb2YgbWVudXMgKi9cXHJcXG4uZWRpdFRvb2xiYXJNZW51MSB7XFxyXFxuXFx0ZGlzcGxheTogbm9uZTtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0dG9wOiAtMXB4O1xcclxcblxcdGxlZnQ6IDE2MXB4O1xcclxcblxcdHdpZHRoOiAxNjBweDtcXHJcXG5cXHRsaXN0LXN0eWxlOiBub25lO1xcclxcblxcdHBhZGRpbmc6IDE7XFxyXFxuXFx0bWFyZ2luOiAwO1xcclxcblxcdHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUxPmxpIHtcXHJcXG5cXHRwb3NpdGlvbjogcmVsYXRpdmU7XFxyXFxuXFx0aGVpZ2h0OiAyNHB4O1xcclxcblxcdG1hcmdpbi1ib3R0b206IDFweDtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcclxcblxcdGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUxPmxpOmhvdmVyIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjQ0NDQ0NDO1xcclxcbn1cXHJcXG5cXHJcXG4vKiBmaXJzdCBsZXZlbCBvZiBtZW51cyAqL1xcclxcbi5lZGl0VG9vbGJhck1lbnUwIHtcXHJcXG5cXHRkaXNwbGF5OiBub25lO1xcclxcblxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG5cXHRsZWZ0OiAwcHg7XFxyXFxuXFx0bGlzdC1zdHlsZTogbm9uZTtcXHJcXG5cXHRwYWRkaW5nOiAxcHg7XFxyXFxuXFx0bWFyZ2luOiAwO1xcclxcblxcdHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XFxyXFxuXFx0ei1pbmRleDogMTA7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwPmxpIHtcXHJcXG5cXHRwb3NpdGlvbjogcmVsYXRpdmU7XFxyXFxuXFx0aGVpZ2h0OiAyNHB4O1xcclxcblxcdG1pbi13aWR0aDogMTYwcHg7XFxyXFxuXFx0bWFyZ2luLWJvdHRvbTogMXB4O1xcclxcblxcdGZsb2F0OiBsZWZ0O1xcclxcblxcdHotaW5kZXg6IDExO1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6ICNmZmY7XFxyXFxuXFx0Ym9yZGVyOiAxcHggc29saWQgI2NjYztcXHJcXG5cXHR0ZXh0LWFsaWduOiBsZWZ0O1xcclxcblxcdHRleHQtZGVjb3JhdGlvbjogbm9uZTtcXHJcXG5cXHRjdXJzb3I6IHBvaW50ZXI7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwPmxpOmhvdmVyIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjQ0NDQ0NDO1xcclxcbn1cXHJcXG5cXHJcXG4vKiBPbiBob3ZlciwgZGlzcGxheSB0aGUgbmV4dCBsZXZlbCdzIG1lbnUgKi9cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBsaTpob3Zlcj51bCB7XFxyXFxuXFx0ZGlzcGxheTogaW5saW5lO1xcclxcbn1cXHJcXG5cXHJcXG4vKiBNZW51IExpbmsgU3R5bGVzIC0gQXBwbHkgdG8gYWxsIGxpbmtzIGluc2lkZSB0aGUgbXVsdGktbGV2ZWwgbWVudSAqL1xcclxcbi5lZGl0VG9vbGJhck1lbnUwIGEge1xcclxcblxcdGZvbnQ6IG5vcm1hbCAxMXB4IHZlcmRhbmEsIGFyaWFsLCBzYW5zLXNlcmlmO1xcclxcblxcdGNvbG9yOiAjMDAwMDAwO1xcclxcblxcdHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xcclxcblxcdHBhZGRpbmc6IDBweCA1cHg7XFxyXFxuXFxyXFxuXFx0LyogTWFrZSB0aGUgbGluayBjb3ZlciB0aGUgZW50aXJlIGxpc3QgaXRlbS1jb250YWluZXIgKi9cXHJcXG5cXHRkaXNwbGF5OiBibG9jaztcXHJcXG5cXHRsaW5lLWhlaWdodDogMjRweDtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTAgYTpsaW5rIHtcXHJcXG5cXHRjb2xvcjogIzAwMDAwMDtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTAgYTpob3ZlciB7XFxyXFxuXFx0Y29sb3I6ICMwMDAwMDA7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwIGE6dmlzaXRlZCB7XFxyXFxuXFx0Y29sb3I6ICMwMDAwMDAgIWltcG9ydGFudDtcXHJcXG59XCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL2NvcmUvZWRpdFRvb2xiYXIuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCI7QUFDQTtDQUNDLHFCQUFxQjtBQUN0Qjs7QUFFQTtDQUNDLGtCQUFrQjtDQUNsQixXQUFXO0NBQ1gsV0FBVztBQUNaOztBQUVBO0NBQ0MsY0FBYztBQUNmOztBQUVBO0NBQ0MsZUFBZTtDQUNmLHNCQUFzQjtDQUN0QixrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLFdBQVc7Q0FDWCxzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxhQUFhO0NBQ2Isa0JBQWtCO0NBQ2xCLFNBQVM7Q0FDVCxXQUFXO0NBQ1gsWUFBWTtDQUNaLGdCQUFnQjtDQUNoQixVQUFVO0NBQ1YsU0FBUztDQUNULHNCQUFzQjtBQUN2Qjs7QUFFQTtDQUNDLGtCQUFrQjtDQUNsQixZQUFZO0NBQ1osa0JBQWtCO0NBQ2xCLHNCQUFzQjtDQUN0QixzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUEsMEJBQTBCO0FBQzFCO0NBQ0MsYUFBYTtDQUNiLGtCQUFrQjtDQUNsQixTQUFTO0NBQ1QsV0FBVztDQUNYLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsVUFBVTtDQUNWLFNBQVM7Q0FDVCxzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLGtCQUFrQjtDQUNsQixzQkFBc0I7Q0FDdEIsc0JBQXNCO0FBQ3ZCOztBQUVBO0NBQ0MsbUJBQW1CO0FBQ3BCOztBQUVBLHlCQUF5QjtBQUN6QjtDQUNDLGFBQWE7Q0FDYixrQkFBa0I7Q0FDbEIsU0FBUztDQUNULGdCQUFnQjtDQUNoQixZQUFZO0NBQ1osU0FBUztDQUNULHNCQUFzQjtDQUN0QixXQUFXO0FBQ1o7O0FBRUE7Q0FDQyxrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsV0FBVztDQUNYLFdBQVc7Q0FDWCxzQkFBc0I7Q0FDdEIsc0JBQXNCO0NBQ3RCLGdCQUFnQjtDQUNoQixxQkFBcUI7Q0FDckIsZUFBZTtBQUNoQjs7QUFFQTtDQUNDLG1CQUFtQjtBQUNwQjs7QUFFQSw0Q0FBNEM7QUFDNUM7Q0FDQyxlQUFlO0FBQ2hCOztBQUVBLHNFQUFzRTtBQUN0RTtDQUNDLDRDQUE0QztDQUM1QyxjQUFjO0NBQ2QsZ0NBQWdDO0NBQ2hDLGdCQUFnQjs7Q0FFaEIsdURBQXVEO0NBQ3ZELGNBQWM7Q0FDZCxpQkFBaUI7QUFDbEI7O0FBRUE7Q0FDQyxjQUFjO0FBQ2Y7O0FBRUE7Q0FDQyxjQUFjO0FBQ2Y7O0FBRUE7Q0FDQyx5QkFBeUI7QUFDMUJcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxyXFxuI2VkaXRUb29sYmFyRXh0IHtcXHJcXG5cXHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxyXFxufVxcclxcblxcclxcbiNlZGl0VG9vbGJhckRpdiB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGZsb2F0OiBsZWZ0O1xcclxcblxcdHotaW5kZXg6IDEwO1xcclxcbn1cXHJcXG5cXHJcXG4jZWRpdFRvb2xiYXJEaXY6aG92ZXIgLmVkaXRUb29sYmFyTWVudTAge1xcclxcblxcdGRpc3BsYXk6IGJsb2NrO1xcclxcbn1cXHJcXG5cXHJcXG4jZWRpdFRvb2xiYXJCdXR0b24ge1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjYWFhO1xcclxcblxcdGJvcmRlci1yYWRpdXM6IDNweDtcXHJcXG5cXHRwYWRkaW5nOiAycHg7XFxyXFxuXFx0bWFyZ2luOiAxcHg7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2VlZTtcXHJcXG59XFxyXFxuXFxyXFxuLmVkaXRUb29sYmFyTWVudTIge1xcclxcblxcdGRpc3BsYXk6IG5vbmU7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogLTFweDtcXHJcXG5cXHRsZWZ0OiAxNjFweDtcXHJcXG5cXHR3aWR0aDogMTYwcHg7XFxyXFxuXFx0bGlzdC1zdHlsZTogbm9uZTtcXHJcXG5cXHRwYWRkaW5nOiAxO1xcclxcblxcdG1hcmdpbjogMDtcXHJcXG5cXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51Mj5saSB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGhlaWdodDogMjRweDtcXHJcXG5cXHRtYXJnaW4tYm90dG9tOiAxcHg7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51Mj5saTpob3ZlciB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0NDQ0NDQztcXHJcXG59XFxyXFxuXFxyXFxuLyogc2Vjb25kIGxldmVsIG9mIG1lbnVzICovXFxyXFxuLmVkaXRUb29sYmFyTWVudTEge1xcclxcblxcdGRpc3BsYXk6IG5vbmU7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogLTFweDtcXHJcXG5cXHRsZWZ0OiAxNjFweDtcXHJcXG5cXHR3aWR0aDogMTYwcHg7XFxyXFxuXFx0bGlzdC1zdHlsZTogbm9uZTtcXHJcXG5cXHRwYWRkaW5nOiAxO1xcclxcblxcdG1hcmdpbjogMDtcXHJcXG5cXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MT5saSB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGhlaWdodDogMjRweDtcXHJcXG5cXHRtYXJnaW4tYm90dG9tOiAxcHg7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXHJcXG5cXHRib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MT5saTpob3ZlciB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0NDQ0NDQztcXHJcXG59XFxyXFxuXFxyXFxuLyogZmlyc3QgbGV2ZWwgb2YgbWVudXMgKi9cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCB7XFxyXFxuXFx0ZGlzcGxheTogbm9uZTtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0bGVmdDogMHB4O1xcclxcblxcdGxpc3Qtc3R5bGU6IG5vbmU7XFxyXFxuXFx0cGFkZGluZzogMXB4O1xcclxcblxcdG1hcmdpbjogMDtcXHJcXG5cXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcclxcblxcdHotaW5kZXg6IDEwO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MD5saSB7XFxyXFxuXFx0cG9zaXRpb246IHJlbGF0aXZlO1xcclxcblxcdGhlaWdodDogMjRweDtcXHJcXG5cXHRtaW4td2lkdGg6IDE2MHB4O1xcclxcblxcdG1hcmdpbi1ib3R0b206IDFweDtcXHJcXG5cXHRmbG9hdDogbGVmdDtcXHJcXG5cXHR6LWluZGV4OiAxMTtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcclxcblxcdGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XFxyXFxuXFx0dGV4dC1hbGlnbjogbGVmdDtcXHJcXG5cXHR0ZXh0LWRlY29yYXRpb246IG5vbmU7XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MD5saTpob3ZlciB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0NDQ0NDQztcXHJcXG59XFxyXFxuXFxyXFxuLyogT24gaG92ZXIsIGRpc3BsYXkgdGhlIG5leHQgbGV2ZWwncyBtZW51ICovXFxyXFxuLmVkaXRUb29sYmFyTWVudTAgbGk6aG92ZXI+dWwge1xcclxcblxcdGRpc3BsYXk6IGlubGluZTtcXHJcXG59XFxyXFxuXFxyXFxuLyogTWVudSBMaW5rIFN0eWxlcyAtIEFwcGx5IHRvIGFsbCBsaW5rcyBpbnNpZGUgdGhlIG11bHRpLWxldmVsIG1lbnUgKi9cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBhIHtcXHJcXG5cXHRmb250OiBub3JtYWwgMTFweCB2ZXJkYW5hLCBhcmlhbCwgc2Fucy1zZXJpZjtcXHJcXG5cXHRjb2xvcjogIzAwMDAwMDtcXHJcXG5cXHR0ZXh0LWRlY29yYXRpb246IG5vbmUgIWltcG9ydGFudDtcXHJcXG5cXHRwYWRkaW5nOiAwcHggNXB4O1xcclxcblxcclxcblxcdC8qIE1ha2UgdGhlIGxpbmsgY292ZXIgdGhlIGVudGlyZSBsaXN0IGl0ZW0tY29udGFpbmVyICovXFxyXFxuXFx0ZGlzcGxheTogYmxvY2s7XFxyXFxuXFx0bGluZS1oZWlnaHQ6IDI0cHg7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwIGE6bGluayB7XFxyXFxuXFx0Y29sb3I6ICMwMDAwMDA7XFxyXFxufVxcclxcblxcclxcbi5lZGl0VG9vbGJhck1lbnUwIGE6aG92ZXIge1xcclxcblxcdGNvbG9yOiAjMDAwMDAwO1xcclxcbn1cXHJcXG5cXHJcXG4uZWRpdFRvb2xiYXJNZW51MCBhOnZpc2l0ZWQge1xcclxcblxcdGNvbG9yOiAjMDAwMDAwICFpbXBvcnRhbnQ7XFxyXFxufVwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIm1lbnUjYXBwc1N1Yk1lbnUge1xcclxcblxcdGRpc3BsYXk6bm9uZTtcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZTtcXHJcXG5cXHR0b3A6MDtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOndoaXRlICFpbXBvcnRhbnQ7XFx0XFxyXFxuXFx0b3ZlcmZsb3c6dmlzaWJsZTtcXHJcXG59XFxyXFxubWVudSNhcHBzU3ViTWVudSBhe1xcclxcblxcdG1hcmdpbi1sZWZ0Oi0xOS4xZW07XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjp3aGl0ZSAhaW1wb3J0YW50O1xcclxcblxcdGJvcmRlcjoxcHggc29saWQgI2NjYztcXHJcXG5cXHR3aWR0aDoxOGVtO1xcclxcblxcdGRpc3BsYXk6YmxvY2s7XFxyXFxuXFx0cGFkZGluZzo1cHg7XFxyXFxuXFx0ZmxvYXQ6bm9uZTtcXHJcXG59XFxyXFxuYm9keS5xYS1ib2R5LWpzLW9uIG1lbnUjYXBwc1N1Yk1lbnUgYXtcXHJcXG5cXHRtYXJnaW4tbGVmdDotMjIuOGVtO1xcclxcbn1cXHJcXG5ib2R5LnFhLWJvZHktanMtb24gbWVudSNhcHBzU3ViTWVudSB7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5tZW51I2FwcHNTdWJNZW51IGE6aG92ZXJ7XFxyXFxuXFx0YmFja2dyb3VuZC1jb2xvcjojZmZlMjcwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9mZWF0dXJlcy9hcHBzTWVudS9hcHBzTWVudS5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7Q0FDQyxZQUFZO0NBQ1osaUJBQWlCO0NBQ2pCLEtBQUs7Q0FDTCxpQ0FBaUM7Q0FDakMsZ0JBQWdCO0FBQ2pCO0FBQ0E7Q0FDQyxtQkFBbUI7Q0FDbkIsaUNBQWlDO0NBQ2pDLHFCQUFxQjtDQUNyQixVQUFVO0NBQ1YsYUFBYTtDQUNiLFdBQVc7Q0FDWCxVQUFVO0FBQ1g7QUFDQTtDQUNDLG1CQUFtQjtBQUNwQjtBQUNBO0NBQ0MsdUNBQXVDO0FBQ3hDO0FBQ0E7Q0FDQyxtQ0FBbUM7QUFDcENcIixcInNvdXJjZXNDb250ZW50XCI6W1wibWVudSNhcHBzU3ViTWVudSB7XFxyXFxuXFx0ZGlzcGxheTpub25lO1xcclxcblxcdHBvc2l0aW9uOmFic29sdXRlO1xcclxcblxcdHRvcDowO1xcclxcblxcdGJhY2tncm91bmQtY29sb3I6d2hpdGUgIWltcG9ydGFudDtcXHRcXHJcXG5cXHRvdmVyZmxvdzp2aXNpYmxlO1xcclxcbn1cXHJcXG5tZW51I2FwcHNTdWJNZW51IGF7XFxyXFxuXFx0bWFyZ2luLWxlZnQ6LTE5LjFlbTtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOndoaXRlICFpbXBvcnRhbnQ7XFxyXFxuXFx0Ym9yZGVyOjFweCBzb2xpZCAjY2NjO1xcclxcblxcdHdpZHRoOjE4ZW07XFxyXFxuXFx0ZGlzcGxheTpibG9jaztcXHJcXG5cXHRwYWRkaW5nOjVweDtcXHJcXG5cXHRmbG9hdDpub25lO1xcclxcbn1cXHJcXG5ib2R5LnFhLWJvZHktanMtb24gbWVudSNhcHBzU3ViTWVudSBhe1xcclxcblxcdG1hcmdpbi1sZWZ0Oi0yMi44ZW07XFxyXFxufVxcclxcbmJvZHkucWEtYm9keS1qcy1vbiBtZW51I2FwcHNTdWJNZW51IHtcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOnRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbm1lbnUjYXBwc1N1Yk1lbnUgYTpob3ZlcntcXHJcXG5cXHRiYWNrZ3JvdW5kLWNvbG9yOiNmZmUyNzAgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiYnV0dG9uLndpa2l0cmVldHVyYm8ge1xcclxcbiAgICBwYWRkaW5nOiAycHggMTBweDtcXHJcXG4gICAgZm9udC1mYW1pbHk6IG1vbm9zcGFjZTtcXHJcXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VlZTtcXHJcXG4gICAgY29sb3I6ICMzMzM7XFxyXFxuXFx0cG9zaXRpb246YWJzb2x1dGUgIWltcG9ydGFudDtcXHJcXG5cXHRtYXJnaW4tbGVmdDotMi44NWVtO1xcclxcblxcdG1hcmdpbi10b3A6IC0wLjI1ZW07XFxyXFxufVxcclxcbmJ1dHRvbi53aWtpdHJlZXR1cmJvLCBidXR0b24ud2lraXRyZWV0dXJibzphY3RpdmUge1xcclxcblxcdHRvcDphdXRvICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbiNkZXNjZW5kYW50c0NvbnRhaW5lciBsaS5jb2xsYXBzZSB7XFxyXFxuXFx0cG9zaXRpb246cmVsYXRpdmU7XFxyXFxufVwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7SUFDSSxpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLHNCQUFzQjtJQUN0QixXQUFXO0NBQ2QsNEJBQTRCO0NBQzVCLG1CQUFtQjtDQUNuQixtQkFBbUI7QUFDcEI7QUFDQTtDQUNDLG1CQUFtQjtBQUNwQjtBQUNBO0NBQ0MsaUJBQWlCO0FBQ2xCXCIsXCJzb3VyY2VzQ29udGVudFwiOltcImJ1dHRvbi53aWtpdHJlZXR1cmJvIHtcXHJcXG4gICAgcGFkZGluZzogMnB4IDEwcHg7XFxyXFxuICAgIGZvbnQtZmFtaWx5OiBtb25vc3BhY2U7XFxyXFxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZWU7XFxyXFxuICAgIGNvbG9yOiAjMzMzO1xcclxcblxcdHBvc2l0aW9uOmFic29sdXRlICFpbXBvcnRhbnQ7XFxyXFxuXFx0bWFyZ2luLWxlZnQ6LTIuODVlbTtcXHJcXG5cXHRtYXJnaW4tdG9wOiAtMC4yNWVtO1xcclxcbn1cXHJcXG5idXR0b24ud2lraXRyZWV0dXJibywgYnV0dG9uLndpa2l0cmVldHVyYm86YWN0aXZlIHtcXHJcXG5cXHR0b3A6YXV0byAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG4jZGVzY2VuZGFudHNDb250YWluZXIgbGkuY29sbGFwc2Uge1xcclxcblxcdHBvc2l0aW9uOnJlbGF0aXZlO1xcclxcbn1cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCJib2R5LmRhcmtNb2RlICosXFxyXFxuYm9keS5kYXJrTW9kZSBodG1sIGJvZHksXFxyXFxuYm9keS5kYXJrTW9kZSAud3JhcHBlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGEsXFxyXFxuYm9keS5kYXJrTW9kZSBhOmxpbmssXFxyXFxuYm9keS5kYXJrTW9kZSBhOnZpc2l0ZWQsXFxyXFxuYm9keS5kYXJrTW9kZSAuU01BTEwsXFxyXFxuYm9keS5kYXJrTW9kZSAuc21hbGwsXFxyXFxuYm9keS5kYXJrTW9kZSAucHVyZUNzc01lbnVtLFxcclxcbmJvZHkuZGFya01vZGUgLmhvbWUsXFxyXFxuYm9keS5kYXJrTW9kZSAucGVyc29uLFxcclxcbmJvZHkuZGFya01vZGUgLmFkZCxcXHJcXG5ib2R5LmRhcmtNb2RlIC5maW5kLFxcclxcbmJvZHkuZGFya01vZGUgLmhlbHAsXFxyXFxuYm9keS5kYXJrTW9kZSBzdHJvbmcsXFxyXFxuYm9keS5kYXJrTW9kZSBhLnZpZXdzaSxcXHJcXG5ib2R5LmRhcmtNb2RlIHVsLnZpZXdzIGEsXFxyXFxuYm9keS5kYXJrTW9kZSB1bC5wdXJlLWNzcy1tZW51LFxcclxcbmJvZHkuZGFya01vZGUgYTpsaW5rLmFjdGl2ZVByb2ZpbGUsXFxyXFxuYm9keS5kYXJrTW9kZSBhOmhvdmVyLmFjdGl2ZVByb2ZpbGUsXFxyXFxuYm9keS5kYXJrTW9kZSBhOnZpc2l0ZWQuYWN0aXZlUHJvZmlsZSBhOmFjdGl2ZS5hY3RpdmVQcm9maWxlLFxcclxcbmJvZHkuZGFya01vZGUgaWZyYW1lLmNrZV93eXNpd3lnX2ZyYW1lLFxcclxcbmJvZHkuZGFya01vZGUgI2NrZV82MV9jb250ZW50cyxcXHJcXG5ib2R5LmRhcmtNb2RlIGJvZHkuYmxhY2tMaW5rcyBzdHJvbmcsXFxyXFxuYm9keS5kYXJrTW9kZSBtZW51I2FwcHNTdWJNZW51IGEsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuc3RyaXBlcy0xLFxcclxcbmJvZHkuZGFya01vZGUge1xcclxcbiAgZm9udC13ZWlnaHQ6IDQwMDtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6ICMzNjM5M2YgIWltcG9ydGFudDtcXHJcXG4gIGNvbG9yOiAjZGNkZGRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgLmJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5wYWQgZm9ybSBidXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5idXR0b24uZ3JlZW4uc2VhcmNoIHtcXHJcXG4gIHBhZGRpbmc6IDEycHggMTJweCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4uc2hvd0hpZGVUcmVlLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbdHlwZT1cXFwic3VibWl0XFxcIl0sXFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuI3Nob3dIaWRlRGVzY2VuZGFudHMge1xcclxcbiAgcGFkZGluZzogNnB4ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgLnFhLXZvdGUtYnV0dG9ucyBpbnB1dCB7XFxyXFxuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgLmxhcmdlLFxcclxcbmJvZHkuZGFya01vZGUgdWwsXFxyXFxuYm9keS5kYXJrTW9kZSBsaSB7XFxyXFxuICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgZGl2LnN0cmlwZXMtMSxcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5zdHJpcGVzLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LmdldHN0YXJ0ZWQge1xcclxcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIG1lbnUjYXBwc1N1Yk1lbnUgYTpob3ZlciB7XFxyXFxuICBiYWNrZ3JvdW5kOiBuYXZ5ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgdWwucHJvZmlsZS10YWJzIGxpLFxcclxcbmJvZHkuZGFya01vZGUge1xcclxcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxyXFxuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSB1bC5wdXJlQ3NzTWVudSB1bCBsaSBhOmhvdmVyIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IG5hdnkgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSAueW91ckNvbm5lY3Rpb24sXFxyXFxuYm9keS5kYXJrTW9kZSAjeW91ckNvbm5lY3Rpb24ge1xcclxcbiAgYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSAjeW91ckNvbm5lY3Rpb24ge1xcclxcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbdHlwZT1cXFwic3VibWl0XFxcIl0sXFxyXFxuYm9keS5kYXJrTW9kZSBidXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dFt0eXBlPVxcXCJidXR0b25cXFwiXSxcXHJcXG5ib2R5LmRhcmtNb2RlIGEuYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgc3Bhbi5zaG93SGlkZVRyZWUsXFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuI3Nob3dIaWRlRGVzY2VuZGFudHMge1xcclxcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBidXR0b24uY29weVdpZGdldCxcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5jb21tZW50LWFjdGlvbnMgYnV0dG9uLmJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4uY29tbWVudENvbnRhaW5lclRvZ2dsZSBidXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtdm90ZS1idXR0b25zIGlucHV0LFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtZmF2b3JpdGUtYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgI3d0SURnb19nbyxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZvcm0tbGlnaHQtYnV0dG9uLXJlc2hvdyxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZvcm0tbGlnaHQtYnV0dG9uLWhpZGUsXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi1lZGl0LFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbbmFtZT1cXFwid3BTZWFyY2hcXFwiXSB7XFxyXFxuICBib3JkZXI6IDAgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dFtuYW1lPVxcXCJ3cFNlYXJjaFxcXCJdIHtcXHJcXG4gIGJhY2tncm91bmQ6IHVybChcXFwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2ltYWdlcy9pY29ucy9zZWFyY2gtc3VibWl0LWljb24ucG5nXFxcIilcXHJcXG4gICAgd2hpdGUgIWltcG9ydGFudDtcXHJcXG4gIGZvbnQtc2l6ZTogMDtcXHJcXG4gIHRvcDogLTVweCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWEtc2VsZWN0LWJ1dHRvbiB7XFxyXFxuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXFxcImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9nMmcvcWEtdGhlbWUvV2lraVRyZWUvc2VsZWN0LXN0YXIucG5nXFxcIilcXHJcXG4gICAgbm8tcmVwZWF0ICFpbXBvcnRhbnQ7XFxyXFxuICBib3JkZXI6IDAgIWltcG9ydGFudDtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtZm9ybS1saWdodC1idXR0b24ucWEtZm9ybS1saWdodC1idXR0b24tZmxhZyxcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS12b3RlLWJ1dHRvbnMgcWEtdm90ZS1idXR0b25zLW5ldCBpbnB1dCB7XFxyXFxuICBib3JkZXI6IDAgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSAjaGVhZGVyLFxcclxcbmJvZHkuZGFya01vZGUgI2Zvb3RlciB7XFxyXFxuICBiYWNrZ3JvdW5kOiAjMzYzOTNmO1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5jb3B5V2lkZ2V0Q29udGFpbmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LmNvcHlXaWRnZXRDb250YWluZXJJbm5lcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5jb3B5V2lkZ2V0Q29udGFpbmVySW5uZXIgYnV0dG9uIHtcXHJcXG4gIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBsaS5HUkVFTi1BUlJPVyB7XFxyXFxuICBiYWNrZ3JvdW5kLWJsZW5kLW1vZGU6IGNvbG9yO1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1xLWl0ZW0tdGl0bGUgYTpsaW5rIC5jaGVja21hcmssXFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuLnFhLXEtaXRlbS1tZXRhIGEucWEtcS1pdGVtLXdoYXQ6bGluayAuY2hlY2ttYXJrIHtcXHJcXG4gIGNvbG9yOiAjMzYzOTNmICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1tYWluIGE6aG92ZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtZm9vdGVyIGE6aG92ZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtbmF2LW1haW4gYTp2aXNpdGVkOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLWZvb3RlciBhOnZpc2l0ZWQ6aG92ZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtbmF2LXN1YiBhOnZpc2l0ZWQ6aG92ZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtbmF2LXN1YiBhOmhvdmVyIHtcXHJcXG4gIGNvbG9yOiAjMzYzOTNmICFpbXBvcnRhbnQ7XFxyXFxuICBiYWNrZ3JvdW5kOiAjZGNkZGRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgYVtocmVmKj1cXFwid2lraS9Qcml2YWN5XFxcIl0gaW1nLFxcclxcbmJvZHkuZGFya01vZGUgaW1nW3NyYyo9XFxcImltYWdlcy9pY29ucy9wcml2YWN5XFxcIl0ge1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogIzkxOTZhMSAhaW1wb3J0YW50O1xcclxcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xcclxcbn1cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvZGFya01vZGUvZGFya01vZGUuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUEyQkUsZ0JBQWdCO0VBQ2hCLG9DQUFvQztFQUNwQyx5QkFBeUI7QUFDM0I7QUFDQTs7O0VBR0UsNkJBQTZCO0FBQy9CO0FBQ0E7OztFQUdFLHVCQUF1QjtBQUN6QjtBQUNBO0VBQ0UscUJBQXFCO0FBQ3ZCO0FBQ0E7OztFQUdFLDJCQUEyQjtBQUM3QjtBQUNBOzs7RUFHRSxpQ0FBaUM7QUFDbkM7QUFDQTtFQUNFLDJCQUEyQjtBQUM3QjtBQUNBOztFQUVFLGlCQUFpQjtFQUNqQix1QkFBdUI7QUFDekI7QUFDQTtFQUNFLGlDQUFpQztBQUNuQztBQUNBOztFQUVFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UsaUJBQWlCO0FBQ25CO0FBQ0E7Ozs7OztFQU1FLGtDQUFrQztBQUNwQztBQUNBOzs7Ozs7Ozs7O0VBVUUsb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRTtvQkFDa0I7RUFDbEIsWUFBWTtFQUNaLG9CQUFvQjtBQUN0QjtBQUNBO0VBQ0U7d0JBQ3NCO0VBQ3RCLG9CQUFvQjtFQUNwQixrQ0FBa0M7QUFDcEM7QUFDQTs7RUFFRSxvQkFBb0I7QUFDdEI7QUFDQTs7RUFFRSxtQkFBbUI7QUFDckI7QUFDQTs7O0VBR0UsMkJBQTJCO0FBQzdCO0FBQ0E7RUFDRSw0QkFBNEI7QUFDOUI7QUFDQTs7RUFFRSx5QkFBeUI7QUFDM0I7QUFDQTs7Ozs7O0VBTUUseUJBQXlCO0VBQ3pCLDhCQUE4QjtBQUNoQztBQUNBOztFQUVFLG9DQUFvQztFQUNwQyxrQkFBa0I7QUFDcEJcIixcInNvdXJjZXNDb250ZW50XCI6W1wiYm9keS5kYXJrTW9kZSAqLFxcclxcbmJvZHkuZGFya01vZGUgaHRtbCBib2R5LFxcclxcbmJvZHkuZGFya01vZGUgLndyYXBwZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBhLFxcclxcbmJvZHkuZGFya01vZGUgYTpsaW5rLFxcclxcbmJvZHkuZGFya01vZGUgYTp2aXNpdGVkLFxcclxcbmJvZHkuZGFya01vZGUgLlNNQUxMLFxcclxcbmJvZHkuZGFya01vZGUgLnNtYWxsLFxcclxcbmJvZHkuZGFya01vZGUgLnB1cmVDc3NNZW51bSxcXHJcXG5ib2R5LmRhcmtNb2RlIC5ob21lLFxcclxcbmJvZHkuZGFya01vZGUgLnBlcnNvbixcXHJcXG5ib2R5LmRhcmtNb2RlIC5hZGQsXFxyXFxuYm9keS5kYXJrTW9kZSAuZmluZCxcXHJcXG5ib2R5LmRhcmtNb2RlIC5oZWxwLFxcclxcbmJvZHkuZGFya01vZGUgc3Ryb25nLFxcclxcbmJvZHkuZGFya01vZGUgYS52aWV3c2ksXFxyXFxuYm9keS5kYXJrTW9kZSB1bC52aWV3cyBhLFxcclxcbmJvZHkuZGFya01vZGUgdWwucHVyZS1jc3MtbWVudSxcXHJcXG5ib2R5LmRhcmtNb2RlIGE6bGluay5hY3RpdmVQcm9maWxlLFxcclxcbmJvZHkuZGFya01vZGUgYTpob3Zlci5hY3RpdmVQcm9maWxlLFxcclxcbmJvZHkuZGFya01vZGUgYTp2aXNpdGVkLmFjdGl2ZVByb2ZpbGUgYTphY3RpdmUuYWN0aXZlUHJvZmlsZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGlmcmFtZS5ja2Vfd3lzaXd5Z19mcmFtZSxcXHJcXG5ib2R5LmRhcmtNb2RlICNja2VfNjFfY29udGVudHMsXFxyXFxuYm9keS5kYXJrTW9kZSBib2R5LmJsYWNrTGlua3Mgc3Ryb25nLFxcclxcbmJvZHkuZGFya01vZGUgbWVudSNhcHBzU3ViTWVudSBhLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnN0cmlwZXMtMSxcXHJcXG5ib2R5LmRhcmtNb2RlIHtcXHJcXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzYzOTNmICFpbXBvcnRhbnQ7XFxyXFxuICBjb2xvcjogI2RjZGRkZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC5idXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucGFkIGZvcm0gYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQuYnV0dG9uLmdyZWVuLnNlYXJjaCB7XFxyXFxuICBwYWRkaW5nOiAxMnB4IDEycHggIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuLnNob3dIaWRlVHJlZSxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W3R5cGU9XFxcInN1Ym1pdFxcXCJdLFxcclxcbmJvZHkuZGFya01vZGUgc3BhbiNzaG93SGlkZURlc2NlbmRhbnRzIHtcXHJcXG4gIHBhZGRpbmc6IDZweCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC5xYS12b3RlLWJ1dHRvbnMgaW5wdXQge1xcclxcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIC5sYXJnZSxcXHJcXG5ib2R5LmRhcmtNb2RlIHVsLFxcclxcbmJvZHkuZGFya01vZGUgbGkge1xcclxcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5zdHJpcGVzLTEsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuc3RyaXBlcyxcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5nZXRzdGFydGVkIHtcXHJcXG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmUgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBtZW51I2FwcHNTdWJNZW51IGE6aG92ZXIge1xcclxcbiAgYmFja2dyb3VuZDogbmF2eSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIHVsLnByb2ZpbGUtdGFicyBsaSxcXHJcXG5ib2R5LmRhcmtNb2RlIHtcXHJcXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgdWwucHVyZUNzc01lbnUgdWwgbGkgYTpob3ZlciB7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiBuYXZ5ICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgLnlvdXJDb25uZWN0aW9uLFxcclxcbmJvZHkuZGFya01vZGUgI3lvdXJDb25uZWN0aW9uIHtcXHJcXG4gIGJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgI3lvdXJDb25uZWN0aW9uIHtcXHJcXG4gIG1hcmdpbi1yaWdodDogNHB4O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W3R5cGU9XFxcInN1Ym1pdFxcXCJdLFxcclxcbmJvZHkuZGFya01vZGUgYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbdHlwZT1cXFwiYnV0dG9uXFxcIl0sXFxyXFxuYm9keS5kYXJrTW9kZSBhLmJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlIHNwYW4uc2hvd0hpZGVUcmVlLFxcclxcbmJvZHkuZGFya01vZGUgc3BhbiNzaG93SGlkZURlc2NlbmRhbnRzIHtcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgYnV0dG9uLmNvcHlXaWRnZXQsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29tbWVudC1hY3Rpb25zIGJ1dHRvbi5idXR0b24sXFxyXFxuYm9keS5kYXJrTW9kZSBzcGFuLmNvbW1lbnRDb250YWluZXJUb2dnbGUgYnV0dG9uLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLXZvdGUtYnV0dG9ucyBpbnB1dCxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZhdm9yaXRlLWJ1dHRvbixcXHJcXG5ib2R5LmRhcmtNb2RlICN3dElEZ29fZ28sXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi1yZXNob3csXFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1mb3JtLWxpZ2h0LWJ1dHRvbi1oaWRlLFxcclxcbmJvZHkuZGFya01vZGUgaW5wdXQucWEtZm9ybS1saWdodC1idXR0b24tZWRpdCxcXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0W25hbWU9XFxcIndwU2VhcmNoXFxcIl0ge1xcclxcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgaW5wdXRbbmFtZT1cXFwid3BTZWFyY2hcXFwiXSB7XFxyXFxuICBiYWNrZ3JvdW5kOiB1cmwoXFxcImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbWFnZXMvaWNvbnMvc2VhcmNoLXN1Ym1pdC1pY29uLnBuZ1xcXCIpXFxyXFxuICAgIHdoaXRlICFpbXBvcnRhbnQ7XFxyXFxuICBmb250LXNpemU6IDA7XFxyXFxuICB0b3A6IC01cHggIWltcG9ydGFudDtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBpbnB1dC5xYS1hLXNlbGVjdC1idXR0b24ge1xcclxcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFxcXCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vZzJnL3FhLXRoZW1lL1dpa2lUcmVlL3NlbGVjdC1zdGFyLnBuZ1xcXCIpXFxyXFxuICAgIG5vLXJlcGVhdCAhaW1wb3J0YW50O1xcclxcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGlucHV0LnFhLWZvcm0tbGlnaHQtYnV0dG9uLnFhLWZvcm0tbGlnaHQtYnV0dG9uLWZsYWcsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtdm90ZS1idXR0b25zIHFhLXZvdGUtYnV0dG9ucy1uZXQgaW5wdXQge1xcclxcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgI2hlYWRlcixcXHJcXG5ib2R5LmRhcmtNb2RlICNmb290ZXIge1xcclxcbiAgYmFja2dyb3VuZDogIzM2MzkzZjtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29weVdpZGdldENvbnRhaW5lcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5jb3B5V2lkZ2V0Q29udGFpbmVySW5uZXIsXFxyXFxuYm9keS5kYXJrTW9kZSBkaXYuY29weVdpZGdldENvbnRhaW5lcklubmVyIGJ1dHRvbiB7XFxyXFxuICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcbmJvZHkuZGFya01vZGUgbGkuR1JFRU4tQVJST1cge1xcclxcbiAgYmFja2dyb3VuZC1ibGVuZC1tb2RlOiBjb2xvcjtcXHJcXG59XFxyXFxuYm9keS5kYXJrTW9kZSBkaXYucWEtcS1pdGVtLXRpdGxlIGE6bGluayAuY2hlY2ttYXJrLFxcclxcbmJvZHkuZGFya01vZGUgc3Bhbi5xYS1xLWl0ZW0tbWV0YSBhLnFhLXEtaXRlbS13aGF0OmxpbmsgLmNoZWNrbWFyayB7XFxyXFxuICBjb2xvcjogIzM2MzkzZiAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1uYXYtbWFpbiBhOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLWZvb3RlciBhOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1tYWluIGE6dmlzaXRlZDpob3ZlcixcXHJcXG5ib2R5LmRhcmtNb2RlIGRpdi5xYS1mb290ZXIgYTp2aXNpdGVkOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1zdWIgYTp2aXNpdGVkOmhvdmVyLFxcclxcbmJvZHkuZGFya01vZGUgZGl2LnFhLW5hdi1zdWIgYTpob3ZlciB7XFxyXFxuICBjb2xvcjogIzM2MzkzZiAhaW1wb3J0YW50O1xcclxcbiAgYmFja2dyb3VuZDogI2RjZGRkZSAhaW1wb3J0YW50O1xcclxcbn1cXHJcXG5ib2R5LmRhcmtNb2RlIGFbaHJlZio9XFxcIndpa2kvUHJpdmFjeVxcXCJdIGltZyxcXHJcXG5ib2R5LmRhcmtNb2RlIGltZ1tzcmMqPVxcXCJpbWFnZXMvaWNvbnMvcHJpdmFjeVxcXCJdIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6ICM5MTk2YTEgIWltcG9ydGFudDtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcXHJcXG59XFxyXFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiI2Rpc3RhbmNlRnJvbVlvdSB7XFxyXFxuICBmb250LXNpemU6IDAuNWVtO1xcclxcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxyXFxuICBwYWRkaW5nOiAwLjJlbTtcXHJcXG4gIGJvcmRlcjogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xcclxcbiAgd2lkdGg6IDNlbTtcXHJcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xcclxcbiAgb3BhY2l0eTogMC44O1xcclxcbiAgei1pbmRleDogMTtcXHJcXG4gIGN1cnNvcjpkZWZhdWx0O1xcclxcbn1cXHJcXG5idXR0b24uY29weVdpZGdldCB7XFxyXFxuICB6LWluZGV4OiAxMDtcXHJcXG59XFxyXFxuXFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0IHtcXHJcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIGdyZWVuO1xcclxcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgYm9yZGVyLXJpZ2h0OiAycHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxuICBwYWRkaW5nOiAwLjVlbTtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xcclxcbiAgbWFyZ2luOiAwLjFlbSAxZW0gMWVtO1xcclxcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxyXFxufVxcclxcbiN5b3VyQ29tbW9uQW5jZXN0b3Ige1xcclxcbiAgbWFyZ2luOiBhdXRvO1xcclxcbiAgcGFkZGluZzogMDtcXHJcXG59XFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0ICN5b3VyQ29tbW9uQW5jZXN0b3IgPiBsaSB7XFxyXFxuICBkaXNwbGF5OiBibG9jaztcXHJcXG4gIG1hcmdpbjogYXV0bztcXHJcXG4gIHBhZGRpbmc6IGF1dG87XFxyXFxuICBsaXN0LXN0eWxlOiBub25lO1xcclxcbn1cXHJcXG4jeW91clJlbGF0aW9uc2hpcFRleHQgI3lvdXJDb21tb25BbmNlc3RvciA+IGxpOm50aC1jaGlsZChuICsgMykge1xcclxcbiAgZGlzcGxheTogbm9uZTtcXHJcXG59XFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0IHtcXHJcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXHJcXG4gIGJhY2tncm91bmQ6IHdoaXRlc21va2U7XFxyXFxufVxcclxcbiNzaG93TW9yZUFuY2VzdG9ycyB7XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICBmb250LXNpemU6IDAuOGVtO1xcclxcbiAgcGFkZGluZzogMC41ZW07XFxyXFxuICB0b3A6IC0wLjVlbTtcXHJcXG4gIHJpZ2h0OiAtMC41ZW07XFxyXFxufVxcclxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9mZWF0dXJlcy9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7RUFDRSxnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCw2QkFBNkI7RUFDN0Isa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixVQUFVO0VBQ1YsY0FBYztBQUNoQjtBQUNBO0VBQ0UsV0FBVztBQUNiOztBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCLHVCQUF1QjtFQUN2QixvQ0FBb0M7RUFDcEMsbUNBQW1DO0VBQ25DLGNBQWM7RUFDZCxvQkFBb0I7RUFDcEIscUJBQXFCO0VBQ3JCLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7QUFDWjtBQUNBO0VBQ0UsY0FBYztFQUNkLFlBQVk7RUFDWixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0FBQ2Y7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLFdBQVc7RUFDWCxhQUFhO0FBQ2ZcIixcInNvdXJjZXNDb250ZW50XCI6W1wiI2Rpc3RhbmNlRnJvbVlvdSB7XFxyXFxuICBmb250LXNpemU6IDAuNWVtO1xcclxcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxyXFxuICBwYWRkaW5nOiAwLjJlbTtcXHJcXG4gIGJvcmRlcjogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xcclxcbiAgd2lkdGg6IDNlbTtcXHJcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xcclxcbiAgb3BhY2l0eTogMC44O1xcclxcbiAgei1pbmRleDogMTtcXHJcXG4gIGN1cnNvcjpkZWZhdWx0O1xcclxcbn1cXHJcXG5idXR0b24uY29weVdpZGdldCB7XFxyXFxuICB6LWluZGV4OiAxMDtcXHJcXG59XFxyXFxuXFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0IHtcXHJcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIGdyZWVuO1xcclxcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcbiAgYm9yZGVyLXJpZ2h0OiAycHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxuICBwYWRkaW5nOiAwLjVlbTtcXHJcXG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xcclxcbiAgbWFyZ2luOiAwLjFlbSAxZW0gMWVtO1xcclxcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxyXFxufVxcclxcbiN5b3VyQ29tbW9uQW5jZXN0b3Ige1xcclxcbiAgbWFyZ2luOiBhdXRvO1xcclxcbiAgcGFkZGluZzogMDtcXHJcXG59XFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0ICN5b3VyQ29tbW9uQW5jZXN0b3IgPiBsaSB7XFxyXFxuICBkaXNwbGF5OiBibG9jaztcXHJcXG4gIG1hcmdpbjogYXV0bztcXHJcXG4gIHBhZGRpbmc6IGF1dG87XFxyXFxuICBsaXN0LXN0eWxlOiBub25lO1xcclxcbn1cXHJcXG4jeW91clJlbGF0aW9uc2hpcFRleHQgI3lvdXJDb21tb25BbmNlc3RvciA+IGxpOm50aC1jaGlsZChuICsgMykge1xcclxcbiAgZGlzcGxheTogbm9uZTtcXHJcXG59XFxyXFxuI3lvdXJSZWxhdGlvbnNoaXBUZXh0IHtcXHJcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXHJcXG4gIGJhY2tncm91bmQ6IHdoaXRlc21va2U7XFxyXFxufVxcclxcbiNzaG93TW9yZUFuY2VzdG9ycyB7XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICBmb250LXNpemU6IDAuOGVtO1xcclxcbiAgcGFkZGluZzogMC41ZW07XFxyXFxuICB0b3A6IC0wLjVlbTtcXHJcXG4gIHJpZ2h0OiAtMC41ZW07XFxyXFxufVxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIiNteURyYWZ0cyB7XFxyXFxuXFx0cG9zaXRpb246IGFic29sdXRlO1xcclxcblxcdHRvcDogMTAwcHg7XFxyXFxuXFx0bGVmdDogNTAlO1xcclxcblxcdHotaW5kZXg6IDExMDAwO1xcclxcblxcdGJhY2tncm91bmQ6IHdoaXRlO1xcclxcblxcdGJvcmRlcjogMnB4IHNvbGlkIGZvcmVzdGdyZWVuO1xcclxcblxcdGJvcmRlci1yYWRpdXM6IDFlbTtcXHJcXG5cXHRib3gtc2hhZG93OiAwLjFlbSAwLjFlbSAwLjFlbSAwLjFlbSBsaWdodGdyZWVuO1xcclxcblxcdHBhZGRpbmc6IDFlbTtcXHJcXG5cXHRkaXNwbGF5OiBub25lO1xcclxcblxcdHRleHQtYWxpZ246IGxlZnQ7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyB4IHtcXHJcXG5cXHRmb250LXdlaWdodDogYm9sZDtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0dG9wOiAwO1xcclxcblxcdHJpZ2h0OiAwLjJlbTtcXHJcXG5cXHRjdXJzb3I6IHBvaW50ZXI7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBoMiB7XFxyXFxuXFx0bWFyZ2luOiAwLjVlbTtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIHRhYmxlIHRkIHtcXHJcXG5cXHRwYWRkaW5nOiAwLjVlbTtcXHJcXG5cXHRsaXN0LXN0eWxlOiBub25lO1xcclxcblxcdHdoaXRlLXNwYWNlOiBub3dyYXA7XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBhIHtcXHJcXG5cXHRtYXJnaW46IDAuMmVtIDAuNWVtO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgYS5idXR0b246YWN0aXZlIHtcXHJcXG5cXHRjb2xvcjogZ29sZDtcXHJcXG5cXHRiYWNrZ3JvdW5kOiByZ2IoMCwgMTAwLCAwKTtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIHAge1xcclxcblxcdHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIGgyIHtcXHJcXG5cXHRwYWRkaW5nOiAwLjVlbTtcXHJcXG59XFxyXFxuXFxyXFxuYm9keS5xYS1ib2R5LWpzLW9uIC5idXR0b24uc21hbGwge1xcclxcblxcdHBhZGRpbmc6IDdweCAxNXB4O1xcclxcblxcdGJhY2tncm91bmQ6ICMyNTQyMmQ7XFxyXFxuXFx0Ym9yZGVyOiAwO1xcclxcblxcdG91dGxpbmU6IG5vbmU7XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcblxcdHRleHQtYWxpZ246IGNlbnRlcjtcXHJcXG5cXHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xcclxcblxcdGJvcmRlci1yYWRpdXM6IDVweDtcXHJcXG5cXHRjb2xvcjogI2ZmZjtcXHJcXG5cXHRmb250LXdlaWdodDogbm9ybWFsO1xcclxcblxcdHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG5cXHRsaW5lLWhlaWdodDogbm9ybWFsO1xcclxcbn1cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvZHJhZnRMaXN0L2RyYWZ0TGlzdC5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7Q0FDQyxrQkFBa0I7Q0FDbEIsVUFBVTtDQUNWLFNBQVM7Q0FDVCxjQUFjO0NBQ2QsaUJBQWlCO0NBQ2pCLDZCQUE2QjtDQUM3QixrQkFBa0I7Q0FDbEIsOENBQThDO0NBQzlDLFlBQVk7Q0FDWixhQUFhO0NBQ2IsZ0JBQWdCO0FBQ2pCOztBQUVBO0NBQ0MsaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixNQUFNO0NBQ04sWUFBWTtDQUNaLGVBQWU7QUFDaEI7O0FBRUE7Q0FDQyxhQUFhO0FBQ2Q7O0FBRUE7Q0FDQyxjQUFjO0NBQ2QsZ0JBQWdCO0NBQ2hCLG1CQUFtQjtBQUNwQjs7QUFFQTtDQUNDLG1CQUFtQjtBQUNwQjs7QUFFQTtDQUNDLFdBQVc7Q0FDWCwwQkFBMEI7QUFDM0I7O0FBRUE7Q0FDQyxrQkFBa0I7QUFDbkI7O0FBRUE7Q0FDQyxjQUFjO0FBQ2Y7O0FBRUE7Q0FDQyxpQkFBaUI7Q0FDakIsbUJBQW1CO0NBQ25CLFNBQVM7Q0FDVCxhQUFhO0NBQ2IsZUFBZTtDQUNmLGtCQUFrQjtDQUNsQix5QkFBeUI7Q0FDekIsa0JBQWtCO0NBQ2xCLFdBQVc7Q0FDWCxtQkFBbUI7Q0FDbkIsZ0NBQWdDO0NBQ2hDLGVBQWU7Q0FDZixtQkFBbUI7QUFDcEJcIixcInNvdXJjZXNDb250ZW50XCI6W1wiI215RHJhZnRzIHtcXHJcXG5cXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuXFx0dG9wOiAxMDBweDtcXHJcXG5cXHRsZWZ0OiA1MCU7XFxyXFxuXFx0ei1pbmRleDogMTEwMDA7XFxyXFxuXFx0YmFja2dyb3VuZDogd2hpdGU7XFxyXFxuXFx0Ym9yZGVyOiAycHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxuXFx0Ym9yZGVyLXJhZGl1czogMWVtO1xcclxcblxcdGJveC1zaGFkb3c6IDAuMWVtIDAuMWVtIDAuMWVtIDAuMWVtIGxpZ2h0Z3JlZW47XFxyXFxuXFx0cGFkZGluZzogMWVtO1xcclxcblxcdGRpc3BsYXk6IG5vbmU7XFxyXFxuXFx0dGV4dC1hbGlnbjogbGVmdDtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIHgge1xcclxcblxcdGZvbnQtd2VpZ2h0OiBib2xkO1xcclxcblxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG5cXHR0b3A6IDA7XFxyXFxuXFx0cmlnaHQ6IDAuMmVtO1xcclxcblxcdGN1cnNvcjogcG9pbnRlcjtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIGgyIHtcXHJcXG5cXHRtYXJnaW46IDAuNWVtO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgdGFibGUgdGQge1xcclxcblxcdHBhZGRpbmc6IDAuNWVtO1xcclxcblxcdGxpc3Qtc3R5bGU6IG5vbmU7XFxyXFxuXFx0d2hpdGUtc3BhY2U6IG5vd3JhcDtcXHJcXG59XFxyXFxuXFxyXFxuI215RHJhZnRzIGEge1xcclxcblxcdG1hcmdpbjogMC4yZW0gMC41ZW07XFxyXFxufVxcclxcblxcclxcbiNteURyYWZ0cyBhLmJ1dHRvbjphY3RpdmUge1xcclxcblxcdGNvbG9yOiBnb2xkO1xcclxcblxcdGJhY2tncm91bmQ6IHJnYigwLCAxMDAsIDApO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgcCB7XFxyXFxuXFx0dGV4dC1hbGlnbjogY2VudGVyO1xcclxcbn1cXHJcXG5cXHJcXG4jbXlEcmFmdHMgaDIge1xcclxcblxcdHBhZGRpbmc6IDAuNWVtO1xcclxcbn1cXHJcXG5cXHJcXG5ib2R5LnFhLWJvZHktanMtb24gLmJ1dHRvbi5zbWFsbCB7XFxyXFxuXFx0cGFkZGluZzogN3B4IDE1cHg7XFxyXFxuXFx0YmFja2dyb3VuZDogIzI1NDIyZDtcXHJcXG5cXHRib3JkZXI6IDA7XFxyXFxuXFx0b3V0bGluZTogbm9uZTtcXHJcXG5cXHRjdXJzb3I6IHBvaW50ZXI7XFxyXFxuXFx0dGV4dC1hbGlnbjogY2VudGVyO1xcclxcblxcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XFxyXFxuXFx0Ym9yZGVyLXJhZGl1czogNXB4O1xcclxcblxcdGNvbG9yOiAjZmZmO1xcclxcblxcdGZvbnQtd2VpZ2h0OiBub3JtYWw7XFxyXFxuXFx0dGV4dC1kZWNvcmF0aW9uOiBub25lICFpbXBvcnRhbnQ7XFxyXFxuXFx0Y3Vyc29yOiBwb2ludGVyO1xcclxcblxcdGxpbmUtaGVpZ2h0OiBub3JtYWw7XFxyXFxufVwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIlwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJcIixcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIiN0aW1lbGluZS53cmFwLCAuZmFtaWx5U2hlZXQud3JhcHtcXHJcXG5cXHR3aWR0aDo4MCU7XFxyXFxuXFx0d2hpdGUtc3BhY2U6bm9ybWFsO1xcclxcbn1cXHJcXG4jdGltZWxpbmUge1xcclxcblxcdHdoaXRlLXNwYWNlOm5vd3JhcDtcXHJcXG5cXHRoZWlnaHQ6YXV0bztcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZTtcXHJcXG5cXHR3aWR0aDphdXRvO1xcclxcblxcdGxlZnQ6MTAlO1xcclxcblxcdHotaW5kZXg6NDAwMDtcXHJcXG5cXHRiYWNrZ3JvdW5kOndoaXRlO1xcclxcblxcdGJvcmRlcjozcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxuXFx0Ym9yZGVyLXJhZGl1czoxZW07XFxyXFxuXFx0Ym94LXNoYWRvdzoxZW0gMWVtIDFlbSAjY2NjO1xcclxcblxcdHBhZGRpbmc6MC4zZW07XFxyXFxuXFx0ZGlzcGxheTpub25lO1xcclxcblxcdGN1cnNvcjptb3ZlO1xcclxcbn1cXHJcXG4jdGltZWxpbmVUYWJsZSB0ZHtcXHJcXG5cXHRwYWRkaW5nOjAuM2VtO1xcclxcbn1cXHJcXG4jdGltZWxpbmVUYWJsZSBjYXB0aW9ue1xcclxcblxcdGZvbnQtc2l6ZToxLjVlbTtcXHJcXG5cXHRmb250LXdlaWdodDpib2xkO1xcclxcbn1cXHJcXG4udGxBZ2UsLnRsQmlvQWdle1xcclxcblxcdHRleHQtYWxpZ246Y2VudGVyO1xcclxcbn1cXHJcXG50aC50bEJpb0FnZXtcXHJcXG5cXHR0ZXh0LWFsaWduOmNlbnRlcjtcXHJcXG59XFxyXFxuLnRsRXZlbnROYW1le1xcclxcblxcdHRleHQtYWxpZ246Y2VudGVyO1xcclxcbn1cXHJcXG4udGxEYXRle1xcclxcblxcdHdoaXRlLXNwYWNlOm5vd3JhcDtcXHJcXG59XFxyXFxuI3RpbWVsaW5lIHgsIC5mYW1pbHlTaGVldCB4e1xcclxcblxcdHBvc2l0aW9uOmFic29sdXRlO1xcclxcblxcdHRvcDowO1xcclxcblxcdHJpZ2h0OjAuNWVtO1xcclxcblxcdGZvbnQtd2VpZ2h0OmJvbGQ7XFxyXFxuXFx0Y3Vyc29yOnBvaW50ZXI7XFxyXFxufVxcclxcbiN0aW1lbGluZSB3LCAuZmFtaWx5U2hlZXQgd3tcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZTtcXHJcXG5cXHR0b3A6MDtcXHJcXG5cXHRsZWZ0OjAuNWVtO1xcclxcblxcdGZvbnQtd2VpZ2h0OmJvbGQ7XFxyXFxuXFx0Y3Vyc29yOnBvaW50ZXI7XFxyXFxufVxcclxcbiN0aW1lbGluZSAuQmlvUGVyc29uLCAjdGltZWxpbmUgLm1hcnJpYWdle1xcclxcblxcdGZvbnQtd2VpZ2h0OmJvbGQ7XFxyXFxufVxcclxcbiN0aW1lbGluZSB0ci5CaW9QZXJzb24uQmlydGh7XFxyXFxuXFx0Ym9yZGVyLXRvcDoxcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxufVxcclxcbiN0aW1lbGluZSB0ci5CaW9QZXJzb24uRGVhdGh7XFxyXFxuXFx0Ym9yZGVyLWJvdHRvbToxcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxufVxcclxcbiN0aW1lbGluZVRhYmxlIHtcXHJcXG5cXHR3aWR0aDo5OCU7XFxyXFxuXFx0bWFyZ2luOmF1dG87XFxyXFxufVwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9mZWF0dXJlcy9mYW1pbHlUaW1lbGluZS9mYW1pbHlUaW1lbGluZS5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7Q0FDQyxTQUFTO0NBQ1Qsa0JBQWtCO0FBQ25CO0FBQ0E7Q0FDQyxrQkFBa0I7Q0FDbEIsV0FBVztDQUNYLGlCQUFpQjtDQUNqQixVQUFVO0NBQ1YsUUFBUTtDQUNSLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsNEJBQTRCO0NBQzVCLGlCQUFpQjtDQUNqQiwyQkFBMkI7Q0FDM0IsYUFBYTtDQUNiLFlBQVk7Q0FDWixXQUFXO0FBQ1o7QUFDQTtDQUNDLGFBQWE7QUFDZDtBQUNBO0NBQ0MsZUFBZTtDQUNmLGdCQUFnQjtBQUNqQjtBQUNBO0NBQ0MsaUJBQWlCO0FBQ2xCO0FBQ0E7Q0FDQyxpQkFBaUI7QUFDbEI7QUFDQTtDQUNDLGlCQUFpQjtBQUNsQjtBQUNBO0NBQ0Msa0JBQWtCO0FBQ25CO0FBQ0E7Q0FDQyxpQkFBaUI7Q0FDakIsS0FBSztDQUNMLFdBQVc7Q0FDWCxnQkFBZ0I7Q0FDaEIsY0FBYztBQUNmO0FBQ0E7Q0FDQyxpQkFBaUI7Q0FDakIsS0FBSztDQUNMLFVBQVU7Q0FDVixnQkFBZ0I7Q0FDaEIsY0FBYztBQUNmO0FBQ0E7Q0FDQyxnQkFBZ0I7QUFDakI7QUFDQTtDQUNDLGdDQUFnQztBQUNqQztBQUNBO0NBQ0MsbUNBQW1DO0FBQ3BDO0FBQ0E7Q0FDQyxTQUFTO0NBQ1QsV0FBVztBQUNaXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIiN0aW1lbGluZS53cmFwLCAuZmFtaWx5U2hlZXQud3JhcHtcXHJcXG5cXHR3aWR0aDo4MCU7XFxyXFxuXFx0d2hpdGUtc3BhY2U6bm9ybWFsO1xcclxcbn1cXHJcXG4jdGltZWxpbmUge1xcclxcblxcdHdoaXRlLXNwYWNlOm5vd3JhcDtcXHJcXG5cXHRoZWlnaHQ6YXV0bztcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZTtcXHJcXG5cXHR3aWR0aDphdXRvO1xcclxcblxcdGxlZnQ6MTAlO1xcclxcblxcdHotaW5kZXg6NDAwMDtcXHJcXG5cXHRiYWNrZ3JvdW5kOndoaXRlO1xcclxcblxcdGJvcmRlcjozcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxuXFx0Ym9yZGVyLXJhZGl1czoxZW07XFxyXFxuXFx0Ym94LXNoYWRvdzoxZW0gMWVtIDFlbSAjY2NjO1xcclxcblxcdHBhZGRpbmc6MC4zZW07XFxyXFxuXFx0ZGlzcGxheTpub25lO1xcclxcblxcdGN1cnNvcjptb3ZlO1xcclxcbn1cXHJcXG4jdGltZWxpbmVUYWJsZSB0ZHtcXHJcXG5cXHRwYWRkaW5nOjAuM2VtO1xcclxcbn1cXHJcXG4jdGltZWxpbmVUYWJsZSBjYXB0aW9ue1xcclxcblxcdGZvbnQtc2l6ZToxLjVlbTtcXHJcXG5cXHRmb250LXdlaWdodDpib2xkO1xcclxcbn1cXHJcXG4udGxBZ2UsLnRsQmlvQWdle1xcclxcblxcdHRleHQtYWxpZ246Y2VudGVyO1xcclxcbn1cXHJcXG50aC50bEJpb0FnZXtcXHJcXG5cXHR0ZXh0LWFsaWduOmNlbnRlcjtcXHJcXG59XFxyXFxuLnRsRXZlbnROYW1le1xcclxcblxcdHRleHQtYWxpZ246Y2VudGVyO1xcclxcbn1cXHJcXG4udGxEYXRle1xcclxcblxcdHdoaXRlLXNwYWNlOm5vd3JhcDtcXHJcXG59XFxyXFxuI3RpbWVsaW5lIHgsIC5mYW1pbHlTaGVldCB4e1xcclxcblxcdHBvc2l0aW9uOmFic29sdXRlO1xcclxcblxcdHRvcDowO1xcclxcblxcdHJpZ2h0OjAuNWVtO1xcclxcblxcdGZvbnQtd2VpZ2h0OmJvbGQ7XFxyXFxuXFx0Y3Vyc29yOnBvaW50ZXI7XFxyXFxufVxcclxcbiN0aW1lbGluZSB3LCAuZmFtaWx5U2hlZXQgd3tcXHJcXG5cXHRwb3NpdGlvbjphYnNvbHV0ZTtcXHJcXG5cXHR0b3A6MDtcXHJcXG5cXHRsZWZ0OjAuNWVtO1xcclxcblxcdGZvbnQtd2VpZ2h0OmJvbGQ7XFxyXFxuXFx0Y3Vyc29yOnBvaW50ZXI7XFxyXFxufVxcclxcbiN0aW1lbGluZSAuQmlvUGVyc29uLCAjdGltZWxpbmUgLm1hcnJpYWdle1xcclxcblxcdGZvbnQtd2VpZ2h0OmJvbGQ7XFxyXFxufVxcclxcbiN0aW1lbGluZSB0ci5CaW9QZXJzb24uQmlydGh7XFxyXFxuXFx0Ym9yZGVyLXRvcDoxcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxufVxcclxcbiN0aW1lbGluZSB0ci5CaW9QZXJzb24uRGVhdGh7XFxyXFxuXFx0Ym9yZGVyLWJvdHRvbToxcHggc29saWQgZm9yZXN0Z3JlZW47XFxyXFxufVxcclxcbiN0aW1lbGluZVRhYmxlIHtcXHJcXG5cXHR3aWR0aDo5OCU7XFxyXFxuXFx0bWFyZ2luOmF1dG87XFxyXFxufVwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi53cm9uZ1BlcmlvZCB7XFxyXFxuXFx0YmFja2dyb3VuZDogI2ZmZTZlYTtcXHJcXG59XFxyXFxuXFxyXFxuLmZhbWlseUxvYy5yaWdodFBlcmlvZCB7XFxyXFxuXFx0YmFja2dyb3VuZDogI0RBRjdBNjtcXHJcXG59XFxyXFxuXFxyXFxuLmZhbWlseUxvYzIucmlnaHRQZXJpb2Qge1xcclxcblxcdGJhY2tncm91bmQ6IGxpZ2h0Z3JlZW47XFxyXFxufVxcclxcblxcclxcbi5hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnMgZGl2LmN1cnJlbnRTZWxlY3RlZExvY2F0aW9uIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjRENEQ0RDICFpbXBvcnRhbnQ7XFxyXFxufVxcclxcblxcclxcbmlucHV0W25hbWU9J21NYXJyaWFnZUxvY2F0aW9uJ10ge1xcclxcblxcdHdpZHRoOiAxMDAlO1xcclxcbn1cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvbG9jYXRpb25zSGVscGVyL2xvY2F0aW9uc0hlbHBlci5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyw4QkFBOEI7QUFDL0I7O0FBRUE7Q0FDQyxXQUFXO0FBQ1pcIixcInNvdXJjZXNDb250ZW50XCI6W1wiLndyb25nUGVyaW9kIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjZmZlNmVhO1xcclxcbn1cXHJcXG5cXHJcXG4uZmFtaWx5TG9jLnJpZ2h0UGVyaW9kIHtcXHJcXG5cXHRiYWNrZ3JvdW5kOiAjREFGN0E2O1xcclxcbn1cXHJcXG5cXHJcXG4uZmFtaWx5TG9jMi5yaWdodFBlcmlvZCB7XFxyXFxuXFx0YmFja2dyb3VuZDogbGlnaHRncmVlbjtcXHJcXG59XFxyXFxuXFxyXFxuLmF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucyBkaXYuY3VycmVudFNlbGVjdGVkTG9jYXRpb24ge1xcclxcblxcdGJhY2tncm91bmQ6ICNEQ0RDREMgIWltcG9ydGFudDtcXHJcXG59XFxyXFxuXFxyXFxuaW5wdXRbbmFtZT0nbU1hcnJpYWdlTG9jYXRpb24nXSB7XFxyXFxuXFx0d2lkdGg6IDEwMCU7XFxyXFxufVwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIlxcclxcbnRyLnRyU2VsZWN0OmhvdmVyIHsgXFxyXFxuICBiYWNrZ3JvdW5kOiAjZmZlMjcwOzsgXFxyXFxufVxcclxcblxcclxcbnRyLnRyU2VsZWN0ZWQgeyBcXHJcXG4gIGJhY2tncm91bmQ6ICNDQ0NDQ0MgIWltcG9ydGFudDsgXFxyXFxufVxcclxcblxcclxcbjo6cGxhY2Vob2xkZXIge1xcclxcbiAgY29sb3I6ICAgICNiYmI7XFxyXFxufVxcclxcblxcclxcbi8qIGRpYWxvZyBmb3JtYXR0aW5nICAqL1xcclxcblxcclxcbmRpYWxvZyB7XFxyXFxuICBtYXgtd2lkdGg6IDYwMHB4O1xcclxcbn0gIFxcclxcblxcclxcbmRpYWxvZyBpbnB1dFt0eXBlPVxcXCJ0ZXh0XFxcIl0ge1xcclxcbiAgbWluLXdpZHRoOiAzNTBweDtcXHJcXG4gIHBhZGRpbmc6IDRweCA0cHg7XFxyXFxuICBtYXJnaW46IDJweDtcXHJcXG59XFxyXFxuZGlhbG9nIGJ1dHRvbiwgZGlhbG9nIC5idXR0b257XFxyXFxuICBwYWRkaW5nOiA4cHggMjBweDtcXHJcXG4gIG1hcmdpbjogNXB4O1xcclxcbn1cXHJcXG50ZCBidXR0b257XFxyXFxuICBwYWRkaW5nOiA1cHggNXB4O1xcclxcbiAgbWFyZ2luOiAzcHg7XFxyXFxuICBmb250LXNpemU6IDE0cHg7XFxyXFxufVxcclxcbmRpYWxvZyBzZWxlY3R7XFxyXFxuICBvdmVyZmxvdzogYXV0bztcXHJcXG4gIGJhY2tncm91bmQ6IHVuc2V0OyAgXFxyXFxufVxcclxcbmRpYWxvZyB0ZXh0YXJlYXtcXHJcXG4gIHdpZHRoOiAxMDAlO1xcclxcbiAgbWFyZ2luOiA1cHg7XFxyXFxufVxcclxcblxcclxcbi53dFBsdXNSZXF1aXJlZCB7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiBwYWxldmlvbGV0cmVkO1xcclxcbn1cXHJcXG4ud3RQbHVzUHJlZmVycmVkIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHBhbGVncmVlbjtcXHJcXG59XFxyXFxuLnd0UGx1c09wdGlvbmFsIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHBhbGVnb2xkZW5yb2Q7XFxyXFxufVxcclxcbi53dFBsdXNEZXByZWNhdGVke1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogIGxpZ2h0Z3JleTtcXHJcXG4gIHRleHQtZGVjb3JhdGlvbi1saW5lOiBsaW5lLXRocm91Z2g7XFxyXFxufVxcclxcblxcclxcbi53dFBsdXNMZWdlbmR7XFxyXFxuICBkaXNwbGF5OiBub25lO1xcclxcbiAgYmFja2dyb3VuZDogd2hpdGU7XFxyXFxuICBjb2xvcjogYmxhY2s7XFxyXFxuICB0ZXh0LWFsaWduOiBsZWZ0O1xcclxcbiAgZm9udC1zaXplOiAxNHB4O1xcclxcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XFxyXFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxyXFxuICBib3R0b206IDY1cHg7XFxyXFxuICBsZWZ0OiAyNXB4O1xcclxcbiAgcGFkZGluZzogMTBweDtcXHJcXG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xcclxcbiAgbGluZS1oZWlnaHQ6IDM1cHg7XFxyXFxufVxcclxcblxcclxcbiN3dFBsdXNMZWdlbmRCdG46aG92ZXIgLnd0UGx1c0xlZ2VuZHtcXHJcXG4gIGRpc3BsYXk6IGJsb2NrO1xcclxcbn1cXHJcXG5cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvZmVhdHVyZXMvd3QrL3d0UGx1cy5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIjtBQUNBO0VBQ0UsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0UsY0FBYztBQUNoQjs7QUFFQSx1QkFBdUI7O0FBRXZCO0VBQ0UsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixXQUFXO0FBQ2I7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsY0FBYztFQUNkLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0UsV0FBVztFQUNYLFdBQVc7QUFDYjs7QUFFQTtFQUNFLCtCQUErQjtBQUNqQztBQUNBO0VBQ0UsMkJBQTJCO0FBQzdCO0FBQ0E7RUFDRSwrQkFBK0I7QUFDakM7QUFDQTtFQUNFLDRCQUE0QjtFQUM1QixrQ0FBa0M7QUFDcEM7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGNBQWM7QUFDaEJcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxyXFxudHIudHJTZWxlY3Q6aG92ZXIgeyBcXHJcXG4gIGJhY2tncm91bmQ6ICNmZmUyNzA7OyBcXHJcXG59XFxyXFxuXFxyXFxudHIudHJTZWxlY3RlZCB7IFxcclxcbiAgYmFja2dyb3VuZDogI0NDQ0NDQyAhaW1wb3J0YW50OyBcXHJcXG59XFxyXFxuXFxyXFxuOjpwbGFjZWhvbGRlciB7XFxyXFxuICBjb2xvcjogICAgI2JiYjtcXHJcXG59XFxyXFxuXFxyXFxuLyogZGlhbG9nIGZvcm1hdHRpbmcgICovXFxyXFxuXFxyXFxuZGlhbG9nIHtcXHJcXG4gIG1heC13aWR0aDogNjAwcHg7XFxyXFxufSAgXFxyXFxuXFxyXFxuZGlhbG9nIGlucHV0W3R5cGU9XFxcInRleHRcXFwiXSB7XFxyXFxuICBtaW4td2lkdGg6IDM1MHB4O1xcclxcbiAgcGFkZGluZzogNHB4IDRweDtcXHJcXG4gIG1hcmdpbjogMnB4O1xcclxcbn1cXHJcXG5kaWFsb2cgYnV0dG9uLCBkaWFsb2cgLmJ1dHRvbntcXHJcXG4gIHBhZGRpbmc6IDhweCAyMHB4O1xcclxcbiAgbWFyZ2luOiA1cHg7XFxyXFxufVxcclxcbnRkIGJ1dHRvbntcXHJcXG4gIHBhZGRpbmc6IDVweCA1cHg7XFxyXFxuICBtYXJnaW46IDNweDtcXHJcXG4gIGZvbnQtc2l6ZTogMTRweDtcXHJcXG59XFxyXFxuZGlhbG9nIHNlbGVjdHtcXHJcXG4gIG92ZXJmbG93OiBhdXRvO1xcclxcbiAgYmFja2dyb3VuZDogdW5zZXQ7ICBcXHJcXG59XFxyXFxuZGlhbG9nIHRleHRhcmVhe1xcclxcbiAgd2lkdGg6IDEwMCU7XFxyXFxuICBtYXJnaW46IDVweDtcXHJcXG59XFxyXFxuXFxyXFxuLnd0UGx1c1JlcXVpcmVkIHtcXHJcXG4gIGJhY2tncm91bmQtY29sb3I6IHBhbGV2aW9sZXRyZWQ7XFxyXFxufVxcclxcbi53dFBsdXNQcmVmZXJyZWQge1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogcGFsZWdyZWVuO1xcclxcbn1cXHJcXG4ud3RQbHVzT3B0aW9uYWwge1xcclxcbiAgYmFja2dyb3VuZC1jb2xvcjogcGFsZWdvbGRlbnJvZDtcXHJcXG59XFxyXFxuLnd0UGx1c0RlcHJlY2F0ZWR7XFxyXFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAgbGlnaHRncmV5O1xcclxcbiAgdGV4dC1kZWNvcmF0aW9uLWxpbmU6IGxpbmUtdGhyb3VnaDtcXHJcXG59XFxyXFxuXFxyXFxuLnd0UGx1c0xlZ2VuZHtcXHJcXG4gIGRpc3BsYXk6IG5vbmU7XFxyXFxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcXHJcXG4gIGNvbG9yOiBibGFjaztcXHJcXG4gIHRleHQtYWxpZ246IGxlZnQ7XFxyXFxuICBmb250LXNpemU6IDE0cHg7XFxyXFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXHJcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXHJcXG4gIGJvdHRvbTogNjVweDtcXHJcXG4gIGxlZnQ6IDI1cHg7XFxyXFxuICBwYWRkaW5nOiAxMHB4O1xcclxcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XFxyXFxuICBsaW5lLWhlaWdodDogMzVweDtcXHJcXG59XFxyXFxuXFxyXFxuI3d0UGx1c0xlZ2VuZEJ0bjpob3ZlciAud3RQbHVzTGVnZW5ke1xcclxcbiAgZGlzcGxheTogYmxvY2s7XFxyXFxufVxcclxcblxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZWRpdFRvb2xiYXIuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9lZGl0VG9vbGJhci5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vYXBwc01lbnUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9hcHBzTWVudS5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZGFya01vZGUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9kYXJrTW9kZS5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZHJhZnRMaXN0LmNzc1wiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZHJhZnRMaXN0LmNzc1wiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9mYW1pbHlHcm91cC5jc3NcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2ZhbWlseUdyb3VwLmNzc1wiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9mYW1pbHlUaW1lbGluZS5jc3NcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2ZhbWlseVRpbWVsaW5lLmNzc1wiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9sb2NhdGlvbnNIZWxwZXIuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9sb2NhdGlvbnNIZWxwZXIuY3NzXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3d0UGx1cy5jc3NcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3d0UGx1cy5jc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJpbXBvcnQge2NyZWF0ZVRvcE1lbnV9IGZyb20gJy4vY29yZS9jb21tb24nO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvYWthTmFtZUxpbmtzL2FrYU5hbWVMaW5rcyc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9hcHBzTWVudS9hcHBzTWVudSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZS9jb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9kYXJrTW9kZS9kYXJrTW9kZSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcC9kaXN0YW5jZUFuZFJlbGF0aW9uc2hpcCc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9kcmFmdExpc3QvZHJhZnRMaXN0JztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2ZhbWlseUdyb3VwL2ZhbWlseUdyb3VwJztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2ZhbWlseVRpbWVsaW5lL2ZhbWlseVRpbWVsaW5lJztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL2xvY2F0aW9uc0hlbHBlci9sb2NhdGlvbnNIZWxwZXInO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvcHJpbnRlcmZyaWVuZGx5L3ByaW50ZXJmcmllbmRseSc7XHJcbmltcG9ydCAnLi9mZWF0dXJlcy9yYW5kb21Qcm9maWxlL3JhbmRvbVByb2ZpbGUnO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvc291cmNlcHJldmlldy9zb3VyY2VwcmV2aWV3JztcclxuaW1wb3J0ICcuL2ZlYXR1cmVzL3NwYWNlcHJldmlldy9zcGFjZXByZXZpZXcnO1xyXG5pbXBvcnQgJy4vZmVhdHVyZXMvd3QrL2NvbnRlbnRFZGl0JztcclxuaW1wb3J0ICcuL2NvcmUvZWRpdFRvb2xiYXInO1xyXG5cclxuY3JlYXRlVG9wTWVudSgpO1xyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuZXhwb3J0IGxldCBwYWdlUHJvZmlsZSA9IGZhbHNlO1xyXG5leHBvcnQgbGV0IHBhZ2VIZWxwID0gZmFsc2U7XHJcbmV4cG9ydCBsZXQgcGFnZVNwZWNpYWwgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlQ2F0ZWdvcnkgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlVGVtcGxhdGUgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlU3BhY2UgPSBmYWxzZTtcclxuZXhwb3J0IGxldCBwYWdlRzJHID0gZmFsc2U7XHJcblxyXG5pZiAoXHJcbiAgICB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUubWF0Y2goLyhcXC93aWtpXFwvKVxcd1teOl0qLVswLTldKi9nKSB8fFxyXG4gICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcP3RpdGxlXFw9XFx3W146XSstWzAtOV0rL2cpXHJcbiAgKSB7XHJcbiAgICAgIC8vIElzIGEgUHJvZmlsZSBQYWdlXHJcblx0cGFnZVByb2ZpbGUgPSB0cnVlO1xyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5tYXRjaCgvKFxcL3dpa2lcXC8pSGVscDoqL2cpKSB7XHJcblx0Ly8gSXMgYSBIZWxwIFBhZ2VcclxuXHRwYWdlSGVscCA9IHRydWU7XHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLm1hdGNoKC8oXFwvd2lraVxcLylTcGVjaWFsOiovZykpIHtcclxuXHQvLyBJcyBhIFNwZWNpYWwgUGFnZVxyXG5cdHBhZ2VTcGVjaWFsID0gdHJ1ZTtcclxufSBlbHNlIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUubWF0Y2goLyhcXC93aWtpXFwvKUNhdGVnb3J5OiovZykpIHtcclxuXHQvLyBJcyBhIENhdGVnb3J5IFBhZ2VcclxuXHRwYWdlQ2F0ZWdvcnkgPSB0cnVlO1xyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5tYXRjaCgvKFxcL3dpa2lcXC8pVGVtcGxhdGU6Ki9nKSkge1xyXG5cdC8vIElzIGEgVGVtcGxhdGUgUGFnZVxyXG5cdHBhZ2VUZW1wbGF0ZSA9IHRydWU7XHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLm1hdGNoKC8oXFwvd2lraVxcLylTcGFjZToqL2cpKSB7XHJcblx0Ly8gSXMgYSBTcGFjZSBQYWdlXHJcblx0cGFnZVNwYWNlID0gdHJ1ZTtcclxufSBlbHNlIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUubWF0Y2goL1xcL2cyZ1xcLy9nKSkge1xyXG5cdC8vIElzIGEgRzJHIHBhZ2VcclxuXHRwYWdlRzJHID0gdHJ1ZTtcclxufVxyXG5cclxuLy8gQWRkIHd0ZSBjbGFzcyB0byBib2R5IHRvIGxldCBXaWtpVHJlZSBCRUUga25vdyBub3QgdG8gYWRkIHRoZSBzYW1lIGZ1bmN0aW9uc1xyXG5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYm9keVwiKS5jbGFzc0xpc3QuYWRkKFwid3RlXCIpO1xyXG5cclxuLyoqXHJcbiAqIENyZWF0ZXMgYSBuZXcgbWVudSBpdGVtIGluIHRoZSBBcHBzIGRyb3Bkb3duIG1lbnUuXHJcbiAqXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVG9wTWVudUl0ZW0ob3B0aW9ucykge1xyXG4gIGxldCB0aXRsZSA9IG9wdGlvbnMudGl0bGU7XHJcbiAgbGV0IG5hbWUgPSBvcHRpb25zLm5hbWU7XHJcbiAgbGV0IGlkID0gb3B0aW9ucy5pZDtcclxuICBsZXQgdXJsID0gb3B0aW9ucy51cmw7XHJcblxyXG4gICQoXCIjd3RlLXRvcE1lbnVcIikuYXBwZW5kKGA8bGk+XHJcbiAgICAgICAgPGEgaWQ9XCIke2lkfVwiIGNsYXNzPVwicHVyZUNzc01lbnVpXCIgdGl0bGU9XCIke3RpdGxlfVwiPiR7bmFtZX08L2E+XHJcbiAgICA8L2xpPmApO1xyXG59XHJcblxyXG4vLyBBZGQgYSBsaW5rIHRvIHRoZSBzaG9ydCBsaXN0IG9mIGxpbmtzIGJlbG93IHRoZSB0YWJzXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVQcm9maWxlU3VibWVudUxpbmsob3B0aW9ucykge1xyXG4gICQoXCJ1bC52aWV3cy52aWV3c21cIilcclxuICAgIC5lcSgwKVxyXG4gICAgLmFwcGVuZChcclxuICAgICAgJChcclxuICAgICAgICBgPGxpIGNsYXNzPSd2aWV3c2knPjxhIHRpdGxlPScke29wdGlvbnMudGl0bGV9JyBocmVmPScke29wdGlvbnMudXJsfScgaWQ9JyR7b3B0aW9ucy5pZH0nPiR7b3B0aW9ucy50ZXh0fTwvYT48L2xpPmBcclxuICAgICAgKVxyXG4gICAgKTtcclxuICBsZXQgbGlua3MgPSAkKFwidWwudmlld3Mudmlld3NtOmZpcnN0IGxpXCIpO1xyXG4gIC8vIFJlLXNvcnQgdGhlIGxpbmtzIGludG8gYWxwaGFiZXRpY2FsIG9yZGVyXHJcbiAgbGlua3Muc29ydChmdW5jdGlvbiAoYSwgYikge1xyXG4gICAgcmV0dXJuICQoYSkudGV4dCgpLmxvY2FsZUNvbXBhcmUoJChiKS50ZXh0KCkpO1xyXG4gIH0pO1xyXG4gICQoXCJ1bC52aWV3cy52aWV3c21cIikuZXEoMCkuYXBwZW5kKGxpbmtzKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVRvcE1lbnUoKSB7XHJcbiAgY29uc3QgbmV3VUwgPSAkKFwiPHVsIGNsYXNzPSdwdXJlQ3NzTWVudScgaWQ9J3d0ZS10b3BNZW51VUwnPjwvdWw+XCIpO1xyXG4gICQoXCJ1bC5wdXJlQ3NzTWVudVwiKS5lcSgwKS5hZnRlcihuZXdVTCk7XHJcbiAgbmV3VUwuYXBwZW5kKGA8bGk+XHJcbiAgICAgICAgPGEgY2xhc3M9XCJwdXJlQ3NzTWVudWkwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuPkFwcCBGZWF0dXJlczwvc3Bhbj5cclxuICAgICAgICA8L2E+XHJcbiAgICAgICAgPHVsIGNsYXNzPVwicHVyZUNzc01lbnVtXCIgaWQ9XCJ3dGUtdG9wTWVudVwiPjwvdWw+XHJcbiAgICA8L2xpPmApO1xyXG59XHJcblxyXG4vLyBVc2VkIGluIGZhbWlseVRpbWVsaW5lLCBmYW1pbHlHcm91cCwgbG9jYXRpb25zSGVscGVyXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWxhdGl2ZXMoaWQsIGZpZWxkcyA9IFwiKlwiKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0ICQuYWpheCh7XHJcbiAgICAgIHVybDogXCJodHRwczovL2FwaS53aWtpdHJlZS5jb20vYXBpLnBocFwiLFxyXG4gICAgICBjcm9zc0RvbWFpbjogdHJ1ZSxcclxuICAgICAgeGhyRmllbGRzOiB7IHdpdGhDcmVkZW50aWFsczogdHJ1ZSB9LFxyXG4gICAgICB0eXBlOiBcIlBPU1RcIixcclxuICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgYWN0aW9uOiBcImdldFJlbGF0aXZlc1wiLFxyXG4gICAgICAgIGtleXM6IGlkLFxyXG4gICAgICAgIGZpZWxkczogZmllbGRzLFxyXG4gICAgICAgIGdldFBhcmVudHM6IDEsXHJcbiAgICAgICAgZ2V0U2libGluZ3M6IDEsXHJcbiAgICAgICAgZ2V0U3BvdXNlczogMSxcclxuICAgICAgICBnZXRDaGlsZHJlbjogMSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlc3VsdFswXS5pdGVtc1swXS5wZXJzb247XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gVXNlZCBpbiBmYW1pbHlUaW1lbGluZSwgZmFtaWx5R3JvdXAsIGxvY2F0aW9uc0hlbHBlclxyXG4vLyBNYWtlIHRoZSBmYW1pbHkgbWVtYmVyIGFycmF5cyBlYXNpZXIgdG8gaGFuZGxlXHJcbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0UmVsYXRpdmVzKHJlbCwgdGhlUmVsYXRpb24gPSBmYWxzZSkge1xyXG4gIGxldCBwZW9wbGUgPSBbXTtcclxuICBpZiAodHlwZW9mIHJlbCA9PSB1bmRlZmluZWQgfHwgcmVsID09IG51bGwpIHtcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcbiAgY29uc3QgcEtleXMgPSBPYmplY3Qua2V5cyhyZWwpO1xyXG4gIHBLZXlzLmZvckVhY2goZnVuY3Rpb24gKHBLZXkpIHtcclxuICAgIHZhciBhUGVyc29uID0gcmVsW3BLZXldO1xyXG4gICAgaWYgKHRoZVJlbGF0aW9uICE9IGZhbHNlKSB7XHJcbiAgICAgIGFQZXJzb24uUmVsYXRpb24gPSB0aGVSZWxhdGlvbjtcclxuICAgIH1cclxuICAgIHBlb3BsZS5wdXNoKGFQZXJzb24pO1xyXG4gIH0pO1xyXG4gIHJldHVybiBwZW9wbGU7XHJcbn1cclxuXHJcbi8vIFVzZWQgaW4gZmFtaWx5VGltZWxpbmUsIGZhbWlseUdyb3VwLCBsb2NhdGlvbnNIZWxwZXJcclxuZXhwb3J0IGZ1bmN0aW9uIGZhbWlseUFycmF5KHBlcnNvbikge1xyXG4gIC8vIFRoaXMgaXMgYSBwZXJzb24gZnJvbSBnZXRSZWxhdGl2ZXMoKVxyXG4gIGNvbnN0IHJlbHMgPSBbXCJQYXJlbnRzXCIsIFwiU2libGluZ3NcIiwgXCJTcG91c2VzXCIsIFwiQ2hpbGRyZW5cIl07XHJcbiAgbGV0IGZhbWlseUFyciA9IFtwZXJzb25dO1xyXG4gIHJlbHMuZm9yRWFjaChmdW5jdGlvbiAocmVsKSB7XHJcbiAgICBjb25zdCByZWxhdGlvbiA9IHJlbC5yZXBsYWNlKC9zJC8sIFwiXCIpLnJlcGxhY2UoL3JlbiQvLCBcIlwiKTtcclxuICAgIGZhbWlseUFyciA9IGZhbWlseUFyci5jb25jYXQoZXh0cmFjdFJlbGF0aXZlcyhwZXJzb25bcmVsXSwgcmVsYXRpb24pKTtcclxuICB9KTtcclxuICByZXR1cm4gZmFtaWx5QXJyO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc051bWVyaWMobikge1xyXG4gIHJldHVybiAhaXNOYU4ocGFyc2VGbG9hdChuKSkgJiYgaXNGaW5pdGUobik7XHJcbn1cclxuXHJcbi8vIENoZWNrIHRoYXQgYSB2YWx1ZSBpcyBPS1xyXG4vLyBVc2VkIGluIGZhbWlseVRpbWVsaW5lIGFuZCBmYW1pbHlHcm91cFxyXG5leHBvcnQgZnVuY3Rpb24gaXNPSyh0aGluZykge1xyXG4gIGNvbnN0IGV4Y2x1ZGVWYWx1ZXMgPSBbXHJcbiAgICBcIlwiLFxyXG4gICAgbnVsbCxcclxuICAgIFwibnVsbFwiLFxyXG4gICAgXCIwMDAwLTAwLTAwXCIsXHJcbiAgICBcInVua25vd25cIixcclxuICAgIFwiVW5rbm93blwiLFxyXG4gICAgXCJ1bmRlZmluZWRcIixcclxuICAgIHVuZGVmaW5lZCxcclxuICAgIFwiMDAwMFwiLFxyXG4gICAgXCIwXCIsXHJcbiAgICAwLFxyXG4gIF07XHJcbiAgaWYgKCFleGNsdWRlVmFsdWVzLmluY2x1ZGVzKHRoaW5nKSkge1xyXG4gICAgaWYgKGlzTnVtZXJpYyh0aGluZykpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoJC50eXBlKHRoaW5nKSA9PT0gXCJzdHJpbmdcIikge1xyXG4gICAgICAgIGNvbnN0IG5hbk1hdGNoID0gdGhpbmcubWF0Y2goL05hTi8pO1xyXG4gICAgICAgIGlmIChuYW5NYXRjaCA9PSBudWxsKSB7XHJcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgZWRpdFRvb2xiYXJDYXRlZ29yeU9wdGlvbnMgZnJvbSAnLi9lZGl0VG9vbGJhckNhdGVnb3J5T3B0aW9ucyc7XHJcbmltcG9ydCBlZGl0VG9vbGJhckdlbmVyaWNPcHRpb25zIGZyb20gJy4vZWRpdFRvb2xiYXJHZW5lcmljT3B0aW9ucyc7XHJcbmltcG9ydCBlZGl0VG9vbGJhclByb2ZpbGVPcHRpb25zIGZyb20gJy4vZWRpdFRvb2xiYXJQcm9maWxlT3B0aW9ucyc7XHJcbmltcG9ydCBlZGl0VG9vbGJhclRlbXBsYXRlT3B0aW9ucyBmcm9tICcuL2VkaXRUb29sYmFyVGVtcGxhdGVPcHRpb25zJztcclxuaW1wb3J0IGVkaXRUb29sYmFyU3BhY2VPcHRpb25zIGZyb20gJy4vZWRpdFRvb2xiYXJTcGFjZU9wdGlvbnMnO1xyXG5pbXBvcnQgJy4vZWRpdFRvb2xiYXIuY3NzJztcclxuXHJcbmxldCBlZGl0VG9vbGJhck9wdGlvbnMgPSBbXVxyXG5cclxuLyogQ29tbW9uIGV2ZW50cyBmb3IgbGlua3MgKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVkaXRUb29sYmFyV2lraShwYXJhbXMpIHtcclxuXHR3aW5kb3cub3BlbignaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvJyArIHBhcmFtcy53aWtpLCAnX2JsYW5rJylcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGVkaXRUb29sYmFyQXBwKHBhcmFtcykge1xyXG5cdGxldCB3ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaDEgPiAuY29weVdpZGdldCcpIFxyXG5cdGxldCB3aWtpdHJlZUlEID0gdy5nZXRBdHRyaWJ1dGUoJ2RhdGEtY29weS10ZXh0Jyk7XHJcblx0d2luZG93Lm9wZW4oJ2h0dHBzOi8vYXBwcy53aWtpdHJlZS5jb20vYXBwcy8nICsgcGFyYW1zLmFwcCArICc/d2lraXRyZWVpZD0nICsgd2lraXRyZWVJRCwgJ19ibGFuaycpXHJcbn1cclxuXHJcbi8qIEZpbmRzIHRoZSBjbGlja2VkIGl0ZW0gaW4gZWRpdFRvb2xiYXJPcHRpb25zICovXHJcbmZ1bmN0aW9uIGVkaXRUb29sYmFyRmluZEl0ZW0oaXRlbXMsIG5hbWUpIHtcclxuXHRpZiAoaXRlbXMgJiYgaXRlbXMubGVuZ3RoKSB7XHJcblx0XHRmb3IgKHZhciBpdGVtIG9mIGl0ZW1zKSB7XHJcblx0XHRcdGlmIChpdGVtLmJ1dHRvbikge1xyXG5cdFx0XHRcdGxldCByZXN1bHQgPSBlZGl0VG9vbGJhckZpbmRJdGVtKGl0ZW0uaXRlbXMsIG5hbWUpXHJcblx0XHRcdFx0aWYgKHJlc3VsdCkgeyByZXR1cm4gcmVzdWx0IH1cclxuXHRcdFx0fSBlbHNlIGlmIChuYW1lLnRvVXBwZXJDYXNlKCkgPT09IGl0ZW0udGl0bGUudG9VcHBlckNhc2UoKSkge1xyXG5cdFx0XHRcdHJldHVybiBpdGVtXHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0bGV0IHJlc3VsdCA9IGVkaXRUb29sYmFyRmluZEl0ZW0oaXRlbS5pdGVtcywgbmFtZSlcclxuXHRcdFx0XHRpZiAocmVzdWx0KSB7IHJldHVybiByZXN1bHQgfVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4vKiBtYWluIGV2ZW50IGhhbmRsZXIgKi9cclxuZnVuY3Rpb24gZWRpdFRvb2xiYXJFdmVudChldmVudCkge1xyXG5cdGxldCBlbGVtZW50ID0gZXZlbnQuc3JjRWxlbWVudFxyXG5cdGNvbnN0IGlkID0gZWxlbWVudC5kYXRhc2V0LmlkXHJcblx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHRsZXQgaXRlbSA9IGVkaXRUb29sYmFyRmluZEl0ZW0oZWRpdFRvb2xiYXJPcHRpb25zLCBpZCk7XHJcblx0aWYgKGl0ZW0pIHtcclxuXHRcdHJldHVybiBpdGVtLmNhbGwoaXRlbS5wYXJhbXMgfHwge30pXHJcblx0fSBlbHNlIHtcclxuXHRcdGFsZXJ0KFwiVW5rbm93biBldmVudCBcIiArIGlkKVxyXG5cdH1cclxufVxyXG5cclxuLyogY3JlYXRlcyBodG1sIG9mIHRoZSBkcm9wIGRvd24gbWVudSAqL1xyXG5mdW5jdGlvbiBlZGl0VG9vbGJhckNyZWF0ZUh0bWwoaXRlbXMsIGZlYXR1cmVFbmFibGVkLCBsZXZlbCkge1xyXG5cdGxldCByZXN1bHQgPSAnJztcclxuXHRpZiAoaXRlbXMgJiYgaXRlbXMubGVuZ3RoKSB7XHJcblx0XHRmb3IgKHZhciBpdGVtIG9mIGl0ZW1zKSB7XHJcblx0XHRcdGlmICgoIWl0ZW0uZmVhdHVyZWlkKSB8fCBmZWF0dXJlRW5hYmxlZFtpdGVtLmZlYXR1cmVpZF0pIHtcclxuXHRcdFx0XHRsZXQgcyA9IGVkaXRUb29sYmFyQ3JlYXRlSHRtbChpdGVtLml0ZW1zLCBmZWF0dXJlRW5hYmxlZCwgbGV2ZWwgKyAxKVxyXG5cdFx0XHRcdGlmIChzIHx8IGl0ZW0uY2FsbCkge1xyXG5cdFx0XHRcdFx0aWYgKGl0ZW0uYnV0dG9uKSB7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPVxyXG5cdFx0XHRcdFx0XHRcdCc8ZGl2IGlkPVwiZWRpdFRvb2xiYXJEaXZcIj4nICtcclxuXHRcdFx0XHRcdFx0XHQnPHAgaWQ9XCJlZGl0VG9vbGJhckJ1dHRvblwiPicgKyBpdGVtLmJ1dHRvbiArICc8L3A+JyArXHJcblx0XHRcdFx0XHRcdFx0Ly8gJzxpbWcgc3JjPVwiL3Bob3RvLnBocC84Lzg5L1dpa2lUcmVlX0ltYWdlcy0yMi5wbmdcIiBoZWlnaHQ9XCIyMlwiIGlkPVwiZWRpdFRvb2xiYXJCdXR0b25cIiAvPicgKyBcclxuXHRcdFx0XHRcdFx0XHRzICtcclxuXHRcdFx0XHRcdFx0XHQnPC9kaXY+JztcclxuXHRcdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPSAnPGxpPjxhICdcclxuXHRcdFx0XHRcdFx0cmVzdWx0ICs9IChpdGVtLmhpbnQgPyAndGl0bGU9IFwiJyArIGl0ZW0uaGludCArICdcIicgOiBcIlwiKTtcclxuXHRcdFx0XHRcdFx0cmVzdWx0ICs9ICdocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApO1wiIGNsYXNzPVwiZWRpdFRvb2xiYXJDbGlja1wiIGRhdGEtaWQ9XCInICsgaXRlbS50aXRsZSArICdcIic7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPSAnPicgKyBpdGVtLnRpdGxlICsgKGl0ZW0uaXRlbXMgPyBcIiAmZ3Q7Jmd0O1wiIDogXCJcIikgKyBcIjwvYT5cIjtcclxuXHRcdFx0XHRcdFx0cmVzdWx0ICs9IHM7XHJcblx0XHRcdFx0XHRcdHJlc3VsdCArPSAnPC9saT4nO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0aWYgKChsZXZlbCA+PSAwKSAmJiAocmVzdWx0KSlcclxuXHRcdFx0cmVzdWx0ID0gJzx1bCBjbGFzcz1cImVkaXRUb29sYmFyTWVudScgKyBsZXZlbCArICdcIj4nICsgcmVzdWx0ICsgJzwvdWw+JztcclxuXHR9XHJcblx0cmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyogY3JlYXRlcyBtZW51IG5leHQgdG8gdGhlIHRvb2xiYXIgICovXHJcbmZ1bmN0aW9uIGVkaXRUb29sYmFyQ3JlYXRlKG9wdGlvbnMpIHtcclxuXHRlZGl0VG9vbGJhck9wdGlvbnMgPSBvcHRpb25zXHJcblx0Y2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQobnVsbCwgKGZlYXR1cmVFbmFibGVkKSA9PiB7XHJcblx0XHR2YXIgbWVudUhUTUwgPSBlZGl0VG9vbGJhckNyZWF0ZUh0bWwoZWRpdFRvb2xiYXJPcHRpb25zLCBmZWF0dXJlRW5hYmxlZCwgLTEpO1xyXG5cdFx0ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0b29sYmFyXCIpLmluc2VydEFkamFjZW50SFRNTCgnYWZ0ZXJlbmQnLCAnPGRpdiBpZD1cImVkaXRUb29sYmFyRXh0XCI+JyArIG1lbnVIVE1MICsgJzwvZGl2PicpXHJcblx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdhLmVkaXRUb29sYmFyQ2xpY2snKS5mb3JFYWNoKGkgPT4gaS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGV2ZW50ID0+IGVkaXRUb29sYmFyRXZlbnQoZXZlbnQpKSlcclxuXHR9KVxyXG59XHJcblxyXG5pZiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVNwZWNpYWw6RWRpdFBlcnNvbiYuKi9nKSkge1xyXG4gICAgZWRpdFRvb2xiYXJDcmVhdGUoZWRpdFRvb2xiYXJQcm9maWxlT3B0aW9ucyk7XHJcblxyXG59IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKC9cXC9pbmRleC5waHBcXD90aXRsZT1DYXRlZ29yeTouKiZhY3Rpb249ZWRpdC4qL2cpIHx8XHJcbiAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPUNhdGVnb3J5Oi4qJmFjdGlvbj1zdWJtaXQuKi9nKSkge1xyXG5cdGVkaXRUb29sYmFyQ3JlYXRlKGVkaXRUb29sYmFyQ2F0ZWdvcnlPcHRpb25zKTtcclxuXHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVRlbXBsYXRlOi4qJmFjdGlvbj1lZGl0LiovZykgfHxcclxuICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9VGVtcGxhdGU6LiomYWN0aW9uPXN1Ym1pdC4qL2cpKSB7XHJcblx0ZWRpdFRvb2xiYXJDcmVhdGUoZWRpdFRvb2xiYXJUZW1wbGF0ZU9wdGlvbnMpO1xyXG5cclxufSBlbHNlIGlmICh3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9U3BhY2U6LiomYWN0aW9uPWVkaXQuKi9nKSB8fFxyXG5cdFx0ICAgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPVNwYWNlOi4qJmFjdGlvbj1zdWJtaXQuKi9nKSkge1xyXG5cdGVkaXRUb29sYmFyQ3JlYXRlKGVkaXRUb29sYmFyU3BhY2VPcHRpb25zKTtcclxuXHJcbn0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL1xcL2luZGV4LnBocFxcP3RpdGxlPS4qJmFjdGlvbj1lZGl0LiovZykgfHxcclxuICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9LiomYWN0aW9uPXN1Ym1pdC4qL2cpKSB7XHJcblx0ZWRpdFRvb2xiYXJDcmVhdGUoZWRpdFRvb2xiYXJHZW5lcmljT3B0aW9ucyk7XHJcbn1cclxuIiwiaW1wb3J0IHt3dFBsdXN9IGZyb20gJy4uL2ZlYXR1cmVzL3d0Ky9jb250ZW50RWRpdCc7XHJcbmltcG9ydCB7ZWRpdFRvb2xiYXJBcHAsIGVkaXRUb29sYmFyV2lraX0gZnJvbSAnLi9lZGl0VG9vbGJhcic7XHJcbmV4cG9ydCBkZWZhdWx0IFtcclxuXHR7XHJcblx0XHRidXR0b246IFwiVGVtcGxhdGVzXCIsIGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJFZGl0IFRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJFZGl0VGVtcGxhdGVcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgYW55IHRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIkNhdGVnb3J5IHRlbXBsYXRlc1wiLCBpdGVtczogW1xyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFrYVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJBa2FcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiVG9wIExldmVsXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIlRvcCBMZXZlbFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJHZW9ncmFwaGljIExvY2F0aW9uXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkdlb2dyYXBoaWMgTG9jYXRpb25cIiB9IH1cclxuXHRcdFx0XHRdXHJcblx0XHRcdH0sXHJcblx0XHRcdHsgXCJmZWF0dXJlaWRcIjogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRm9ybWF0IFRlbXBsYXRlIFBhcmFtc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b0Zvcm1hdFwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIkNJQlwiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQ2VtZXRlcnlcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IENlbWV0ZXJ5XCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiTG9jYXRpb25cIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IExvY2F0aW9uXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQWRkIGFueSBDSUJcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIsIGRhdGE6IFwiQ2F0ZWdvcnlJbmZvQm94XCIgfSB9LFxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGl0bGU6IFwiQ2VtZXRlcmllc1wiLCBpdGVtczogW1xyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkNlbWV0ZXJ5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBDZW1ldGVyeVwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJDZW1ldGVyeSBHcm91cFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggQ2VtZXRlcnlHcm91cFwiIH0gfVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0fSxcclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRpdGxlOiBcIlJlbGlnaW9uXCIsIGl0ZW1zOiBbXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiUmVsaWdpb3VzIEluc3RpdHV0aW9uIEdyb3VwXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBSZWxpZ2lvdXNJbnN0aXR1dGlvbkdyb3VwXCIgfSB9XHJcblx0XHRcdFx0XVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGl0bGU6IFwiTWFpbnRlbmFuY2VcIiwgaXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJNYWludGVuYW5jZVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggTWFpbnRlbmFuY2VcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiTmVlZHNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IE5lZWRzXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIk5lZWRzIEdFRENPTSBDbGVhbnVwXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBOZWVkc0dFRENPTUNsZWFudXBcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiVW5jb25uZWN0ZWRcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IFVuY29ubmVjdGVkXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIlVuc291cmNlZFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggVW5zb3VyY2VkXCIgfSB9XHJcblx0XHRcdFx0XVxyXG5cdFx0XHR9LFxyXG5cdFx0XHR7XHJcblx0XHRcdFx0dGl0bGU6IFwiT3RoZXJzXCIsIGl0ZW1zOiBbXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiTG9jYXRpb25cIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiQ2F0ZWdvcnlJbmZvQm94IExvY2F0aW9uXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIk1pZ3JhdGlvblwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3ggTWlncmF0aW9uXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIk9uZSBOYW1lIFN0dWR5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBPbmVOYW1lU3R1ZHlcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiT25lIFBsYWNlIFN0dWR5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkNhdGVnb3J5SW5mb0JveCBPbmVQbGFjZVN0dWR5XCIgfSB9LFxyXG5cdFx0XHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkNhdGVnb3J5SW5mb0JveFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJDYXRlZ29yeUluZm9Cb3hcIiB9IH1cclxuXHRcdFx0XHRdXHJcblx0XHRcdH1cclxuXHRcdF1cclxuXHR9LFxyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJDb250ZW50XCIsIGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBdXRvbWF0ZWQgY29ycmVjdGlvbnNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9VcGRhdGVcIiB9IH0sXHJcblx0XHRdXHJcblx0fSxcclxuXHR7XHJcblx0XHRidXR0b246IFwiRWRpdEJPVFwiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiUmVuYW1lIENhdGVnb3J5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIlJlbmFtZSBDYXRlZ29yeVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIk1lcmdlIENhdGVnb3J5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIk1lcmdlIENhdGVnb3J5XCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRGVsZXRlIENhdGVnb3J5XCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkRlbGV0ZSBDYXRlZ29yeVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkNvbmZpcm0gZm9yIEVkaXRCT1RcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkVkaXRCT1RDb25maXJtXCIgfSB9XHJcblx0XHRdXHJcblx0fSxcclxuXHR7XHJcblx0XHRidXR0b246IFwiTWlzY1wiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiSGVscFwiLCBjYWxsOiBlZGl0VG9vbGJhcldpa2ksIHBhcmFtczogeyB3aWtpOiBcIlNwYWNlOldpa2lUcmVlX1BsdXNfQ2hyb21lX0V4dGVuc2lvbiNPbl9DYXRlZ29yeV9wYWdlc1wiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcbl07XHJcbiIsImltcG9ydCB7d3RQbHVzfSBmcm9tICcuLi9mZWF0dXJlcy93dCsvY29udGVudEVkaXQnO1xyXG5pbXBvcnQge2VkaXRUb29sYmFyQXBwLCBlZGl0VG9vbGJhcldpa2l9IGZyb20gJy4vZWRpdFRvb2xiYXInO1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIlRlbXBsYXRlc1wiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgXHJcblx0XHRcdHRpdGxlOiBcIkVkaXQgVGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkVkaXRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBhbnkgdGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRm9ybWF0IFRlbXBsYXRlIFBhcmFtc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b0Zvcm1hdFwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIkNvbnRlbnRcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkF1dG9tYXRlZCBjb3JyZWN0aW9uc1wiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQXV0b1VwZGF0ZVwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIk1pc2NcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkhlbHBcIiwgY2FsbDogZWRpdFRvb2xiYXJXaWtpLCBwYXJhbXM6IHsgd2lraTogXCJTcGFjZTpXaWtpVHJlZV9QbHVzX0Nocm9tZV9FeHRlbnNpb24jT25fT3RoZXJfcGFnZXNcIiB9IH1cclxuXHRcdF1cclxuXHR9XHJcbl07XHJcbiIsImltcG9ydCB7d3RQbHVzfSBmcm9tICcuLi9mZWF0dXJlcy93dCsvY29udGVudEVkaXQnO1xyXG5pbXBvcnQge2VkaXRUb29sYmFyQXBwLCBlZGl0VG9vbGJhcldpa2l9IGZyb20gJy4vZWRpdFRvb2xiYXInO1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcblx0e1xyXG5cdFx0YnV0dG9uOiBcIlNvdXJjZXNcIixcclxuXHRcdGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJQYXN0ZSBzb3VyY2VzXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJQYXN0ZVNvdXJjZVwiIH0gfVxyXG5cdFx0XVxyXG5cdH0sIHtcclxuXHRcdGJ1dHRvbjogXCJUZW1wbGF0ZXNcIixcclxuXHRcdGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJFZGl0IFRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJFZGl0VGVtcGxhdGVcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgYW55IHRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBQcm9qZWN0IEJveFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiQWRkVGVtcGxhdGVcIiwgZGF0YTogXCJQcm9qZWN0IEJveFwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBTdGlja2VyXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiLCBkYXRhOiBcIlN0aWNrZXJcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgUmVzZWFyY2ggTm90ZSBCb3hcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIsIGRhdGE6IFwiUHJvZmlsZSBCb3hcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgRXh0ZXJuYWwgbGlua3NcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIsIGRhdGE6IFwiRXh0ZXJuYWwgTGlua1wiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkZvcm1hdCBUZW1wbGF0ZSBQYXJhbXNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9Gb3JtYXRcIiB9IH1cclxuXHRcdF1cclxuXHR9LCB7XHJcblx0XHRidXR0b246IFwiQmlvZ3JhcGh5XCIsXHJcblx0XHRpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQXV0b21hdGVkIGNvcnJlY3Rpb25zXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBdXRvVXBkYXRlXCIgfSB9XHJcblx0XHRdXHJcblx0fSwge1xyXG5cdFx0YnV0dG9uOiBcIk1pc2NcIixcclxuXHRcdGl0ZW1zOiBbXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aXRsZTogXCJXaWtpVHJlZSBBcHBzXCIsXHJcblx0XHRcdFx0aXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgdGl0bGU6IFwiRE5BIENvbmZpcm1hdGlvblwiLCBoaW50OiBcIkROQSBDb25maXJtYXRpb24gYnkgR3JlZyBDbGFya2VcIiwgY2FsbDogZWRpdFRvb2xiYXJBcHAsIHBhcmFtczogeyBhcHA6IFwiY2xhcmtlMTEwMDcvRE5BY29uZi5waHBcIiB9IH0sXHJcblx0XHRcdFx0XHR7IHRpdGxlOiBcIkFuY2VzdHJ5IENpdGF0aW9uXCIsIGhpbnQ6IFwiQW5jZXN0cnkgQ2l0YXRpb24gYnkgR3JlZyBDbGFya2VcIiwgY2FsbDogZWRpdFRvb2xiYXJBcHAsIHBhcmFtczogeyBhcHA6IFwiY2xhcmtlMTEwMDcvYW5jaXRlLnBocFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgdGl0bGU6IFwiRHJvdWluIENpdGVyXCIsIGhpbnQ6IFwiRHJvdWluIENpdGVyIGJ5IEdyZWcgQ2xhcmtlXCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcImNsYXJrZTExMDA3L2Ryb3VpbkNpdGUucGhwXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyB0aXRsZTogXCJTdXJuYW1lcyBHZW5lcmF0b3JcIiwgaGludDogXCJTdXJuYW1lcyBHZW5lcmF0b3IgYnkgR3JlZyBDbGFya2VcIiwgY2FsbDogZWRpdFRvb2xiYXJBcHAsIHBhcmFtczogeyBhcHA6IFwiY2xhcmtlMTEwMDcvc3VybmFtZXMucGhwXCIgfSB9LFxyXG5cdFx0XHRcdFx0eyB0aXRsZTogXCJSaWtzYXJraXZldCBTVkFSIHNvdXJjZXNcIiwgaGludDogXCJSaWtzYXJraXZldCBTVkFSIHNvdXJjZXMgYnkgTWFyaWEgTHVuZGhvbG1cIiwgY2FsbDogZWRpdFRvb2xiYXJBcHAsIHBhcmFtczogeyBhcHA6IFwibHVuZGhvbG0yNC9yZWYtbWFraW5nL3JhLXJlZi5waHBcIiB9IH0sXHJcblx0XHRcdFx0XHR7IHRpdGxlOiBcIkFya2l2IERpZ2l0YWwgc291cmNlc1wiLCBoaW50OiBcIkFya2l2IERpZ2l0YWwgc291cmNlcyBieSBNYXJpYSBMdW5kaG9sbVwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJsdW5kaG9sbTI0L3JlZi1tYWtpbmcvYWQtcmVmLnBocFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgdGl0bGU6IFwiU3ZlcmlnZXMgRMO2ZGJvayBzb3VyY2VzXCIsIGhpbnQ6IFwiU3ZlcmlnZXMgRMO2ZGJvayBzb3VyY2VzIGJ5IE1hcmlhIEx1bmRob2xtXCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcImx1bmRob2xtMjQvcmVmLW1ha2luZy9zZGItcmVmLnBocFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgdGl0bGU6IFwiQmlvZ3JhcGh5IEdlbmVyYXRvclwiLCBoaW50OiBcIkJpb2dyYXBoeSBHZW5lcmF0b3IgKGZvciBPcGVuIHByLikgYnkgR3JlZyBTaGlwbGV5XCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcInNoaXBsZXkxMjIzL0Jpby5odG1sXCIgfSB9LFxyXG5cdFx0XHRcdFx0e1xyXG5cdFx0XHRcdFx0XHR0aXRsZTogXCJPdGhlciBBcHBzXCIsXHJcblx0XHRcdFx0XHRcdGl0ZW1zOiBbXHJcblx0XHRcdFx0XHRcdFx0eyB0aXRsZTogXCJCaW8gQ2hlY2tcIiwgaGludDogXCJCaW8gQ2hlY2sgYnkgS2F5IEtuaWdodFwiLCBjYWxsOiBlZGl0VG9vbGJhckFwcCwgcGFyYW1zOiB7IGFwcDogXCJzYW5kczE4NjUvYmlvY2hlY2svXCIgfSB9LFxyXG5cdFx0XHRcdFx0XHRcdHsgdGl0bGU6IFwiRmFuIENoYXJ0XCIsIGhpbnQ6IFwiRmFuIENoYXJ0IGJ5IEdyZWcgQ2xhcmtlXCIsIGNhbGw6IGVkaXRUb29sYmFyQXBwLCBwYXJhbXM6IHsgYXBwOiBcImNsYXJrZTExMDA3L2Zhbi5waHBcIiB9IH1cclxuXHRcdFx0XHRcdFx0XVxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0fSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkhlbHBcIiwgY2FsbDogZWRpdFRvb2xiYXJXaWtpLCBwYXJhbXM6IHsgd2lraTogXCJTcGFjZTpXaWtpVHJlZV9QbHVzX0Nocm9tZV9FeHRlbnNpb24jT25fUHJvZmlsZV9wYWdlc1wiIH0gfVxyXG5cdFx0XVxyXG5cdH1cclxuXTtcclxuIiwiaW1wb3J0IHt3dFBsdXN9IGZyb20gJy4uL2ZlYXR1cmVzL3d0Ky9jb250ZW50RWRpdCc7XHJcbmltcG9ydCB7ZWRpdFRvb2xiYXJBcHAsIGVkaXRUb29sYmFyV2lraX0gZnJvbSAnLi9lZGl0VG9vbGJhcic7XHJcbmV4cG9ydCBkZWZhdWx0IFtcclxuXHR7XHJcblx0XHRidXR0b246IFwiVGVtcGxhdGVzXCIsIGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJFZGl0IFRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJFZGl0VGVtcGxhdGVcIiB9IH0sXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBZGQgYW55IHRlbXBsYXRlXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBZGRUZW1wbGF0ZVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkZvcm1hdCBUZW1wbGF0ZSBQYXJhbXNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9Gb3JtYXRcIiB9IH1cclxuXHRcdF1cclxuXHR9LFxyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJDb250ZW50XCIsIGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJBdXRvbWF0ZWQgY29ycmVjdGlvbnNcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkF1dG9VcGRhdGVcIiB9IH1cclxuXHRcdF1cclxuXHR9LFxyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJNaXNjXCIsIGl0ZW1zOiBbXHJcblx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJIZWxwXCIsIGNhbGw6IGVkaXRUb29sYmFyV2lraSwgcGFyYW1zOiB7IHdpa2k6IFwiU3BhY2U6V2lraVRyZWVfUGx1c19DaHJvbWVfRXh0ZW5zaW9uI09uX090aGVyX3BhZ2VzXCIgfSB9XHJcblx0XHRdXHJcblx0fVxyXG5dO1xyXG4iLCJpbXBvcnQge3d0UGx1c30gZnJvbSAnLi4vZmVhdHVyZXMvd3QrL2NvbnRlbnRFZGl0JztcclxuaW1wb3J0IHtlZGl0VG9vbGJhckFwcCwgZWRpdFRvb2xiYXJXaWtpfSBmcm9tICcuL2VkaXRUb29sYmFyJztcclxuZXhwb3J0IGRlZmF1bHQgW1xyXG5cdHtcclxuXHRcdGJ1dHRvbjogXCJUZW1wbGF0ZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkZvcm1hdCBQYXJhbWV0ZXJzXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IGFjdGlvbjogXCJBdXRvRm9ybWF0XCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiRWRpdCBUZW1wbGF0ZVwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyBhY3Rpb246IFwiRWRpdFRlbXBsYXRlXCIgfSB9LFxyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiQWRkIFRlbXBsYXRlUGFyYW1cIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiVGVtcGxhdGVQYXJhbVwiIH0gfSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBEb2N1bWVudGF0aW9uXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIkRvY3VtZW50YXRpb25cIiB9IH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aXRsZTogXCJBZGQgQmFzZSBUZW1wbGF0ZXNcIiwgaXRlbXM6IFtcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJQcm9qZWN0IEJveFwiLCBjYWxsOiB3dFBsdXMsIHBhcmFtczogeyB0ZW1wbGF0ZTogXCJQcm9qZWN0IEJveFwiIH0gfSxcclxuXHRcdFx0XHRcdHsgZmVhdHVyZWlkOiBcInd0cGx1c1wiLCB0aXRsZTogXCJTdGlja2VyXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIlN0aWNrZXJcIiB9IH0sXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiUmVzZWFyY2ggTm90ZSBCb3hcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgdGVtcGxhdGU6IFwiUmVzZWFyY2ggTm90ZSBCb3hcIiB9IH1cclxuXHRcdFx0XHRdXHJcblx0XHRcdH0sXHJcblx0XHRcdHtcclxuXHRcdFx0XHR0aXRsZTogXCJBZGQgT3RoZXIgVGVtcGxhdGVzXCIsIGl0ZW1zOiBbXHJcblx0XHRcdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiUHJvamVjdCBCb3ggSW5zdHJ1Y3Rpb25zXCIsIGNhbGw6IHd0UGx1cywgcGFyYW1zOiB7IHRlbXBsYXRlOiBcIlByb2plY3QgQm94IEluc3RydWN0aW9uc1wiIH0gfVxyXG5cdFx0XHRcdF1cclxuXHRcdFx0fSxcclxuXHRcdFx0eyBmZWF0dXJlaWQ6IFwid3RwbHVzXCIsIHRpdGxlOiBcIkFkZCBhbnkgdGVtcGxhdGVcIiwgY2FsbDogd3RQbHVzLCBwYXJhbXM6IHsgYWN0aW9uOiBcIkFkZFRlbXBsYXRlXCIgfSB9XHJcblx0XHRdXHJcblx0fSxcclxuXHR7XHJcblx0XHRidXR0b246IFwiTWlzY1wiLCBpdGVtczogW1xyXG5cdFx0XHR7IGZlYXR1cmVpZDogXCJ3dHBsdXNcIiwgdGl0bGU6IFwiSGVscFwiLCBjYWxsOiBlZGl0VG9vbGJhcldpa2ksIHBhcmFtczogeyB3aWtpOiBcIlNwYWNlOldpa2lUcmVlX1BsdXNfQ2hyb21lX0V4dGVuc2lvbiNPbl9UZW1wbGF0ZV9wYWdlc1wiIH0gfVxyXG5cdFx0XVxyXG5cdH1cclxuXTtcclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IHtwYWdlUHJvZmlsZX0gZnJvbSAnLi4vLi4vY29yZS9jb21tb24nO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gYWthTmFtZXMoKXtcclxuLy8gTWFrZSBBS0EgbGFzdCBuYW1lcyBjbGlja2FibGVcclxuICAgIGlmICgkKFwiYm9keS5wcm9maWxlXCIpLmxlbmd0aCl7XHJcbiAgICAgICAgY29uc3QgbmFtZUJpdCA9ICQoXCIuVklUQUxTXCIpLmVxKDApLmZpbmQoXCIubGFyZ2VcIik7XHJcbiAgICAgICAgY29uc3QgbmFtZVRleHQgPSBuYW1lQml0LnRleHQoKTtcclxuICAgICAgICBpZiAobmFtZVRleHQubWF0Y2goXCJha2EgXCIpKXtcclxuICAgICAgICAgICAgY29uc3Qgc3Ryb25ncyA9IG5hbWVCaXQuZmluZChcInN0cm9uZ1wiKTtcclxuICAgICAgICAgICAgY29uc3QgbGFzdFN0cm9uZyA9IHN0cm9uZ3MuZXEoc3Ryb25ncy5sZW5ndGgtMSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGFrYVRleHQgPSBsYXN0U3Ryb25nLnRleHQoKTtcclxuICAgICAgICAgICAgY29uc3Qgb0FrYU5hbWVzID0gYWthVGV4dC5zcGxpdChcIixcIik7XHJcbiAgICAgICAgICAgIGxhc3RTdHJvbmcudGV4dChcIlwiKTtcclxuICAgICAgICAgICAgb0FrYU5hbWVzLmZvckVhY2goZnVuY3Rpb24oYWthTmFtZSxpKXtcclxuICAgICAgICAgICAgICAgICQoXCI8YSBocmVmPSdodHRwczovL3d3dy53aWtpdHJlZS5jb20vZ2VuZWFsb2d5L1wiK2FrYU5hbWUudHJpbSgpK1wiJz5cIitha2FOYW1lLnRyaW0oKStcIjwvYT5cIikuYXBwZW5kVG8obGFzdFN0cm9uZyk7XHJcbiAgICAgICAgICAgICAgICBpZiAoaSsxPG9Ba2FOYW1lcy5sZW5ndGgpe1xyXG4gICAgICAgICAgICAgICAgICAgICQoXCI8c3Bhbj4sIDwvc3Bhbj5cIikuYXBwZW5kVG8obGFzdFN0cm9uZyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldCgnYWthTmFtZUxpbmtzJywgKHJlc3VsdCkgPT4ge1xyXG5cdGlmIChyZXN1bHQuYWthTmFtZUxpbmtzICYmIHBhZ2VQcm9maWxlID09IHRydWUpIHsgXHJcbiAgICAgICAgYWthTmFtZXMoKTtcclxuICAgIH1cclxufSkiLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQgQ29va2llcyBmcm9tICdqcy1jb29raWUnO1xyXG5pbXBvcnQgJy4vYXBwc01lbnUuY3NzJztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCdhcHBzTWVudScsIChyZXN1bHQpID0+IHtcclxuXHRpZiAocmVzdWx0LmFwcHNNZW51KSB7XHJcblx0XHQvLyBBZGQgYSBtZW51IGlmIFdpa2lUcmVlIEJFRSBoYXNuJ3QgYWxyZWFkeSBkb25lIHNvLiBcclxuXHRcdGlmICgkKFwiI2FwcHNTdWJNZW51XCIpLmxlbmd0aD09MCl7XHJcbiAgICAgICAgICAgIGFkZEFwcHNNZW51KCk7XHJcbiAgICAgICAgfVxyXG5cdH1cclxufSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRBcHBzTWVudSgpe1xyXG5cdHRyeXtcclxuXHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0ICQuYWpheCh7dXJsOiBcImh0dHBzOi8vd2lraXRyZWViZWUuY29tL0JFRS5waHA/cT1hcHBzX21lbnVcIiwgY3Jvc3NEb21haW46IHRydWUsIHR5cGU6ICdQT1NUJywgZGF0YVR5cGU6ICdqc29uJ30pXHJcblx0XHRyZXR1cm4gcmVzdWx0LmFwcHNfbWVudTtcclxuXHR9IGNhdGNoIChlcnJvcikge1xyXG5cdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XHJcblx0fVxyXG59XHJcblxyXG5mdW5jdGlvbiBhdHRhY2hBcHBzTWVudShtZW51KXtcclxuXHRjb25zdCBtV1RJRCA9IENvb2tpZXMuZ2V0KFwid2lraXRyZWVfd3RiX1VzZXJOYW1lXCIpO1xyXG5cdGNvbnN0IGFwcHNMaXN0ID0gJChcIjxtZW51IGNsYXNzPSdzdWJNZW51JyBpZD0nYXBwc1N1Yk1lbnUnPjwvbWVudT5cIik7XHJcblx0bWVudS5mb3JFYWNoKGZ1bmN0aW9uKGFwcCl7XHJcblx0XHRjb25zdCBhcHBzTGkgPSAkKFwiPGEgY2xhc3M9J3B1cmVDc3NNZW51aScgaHJlZj0nXCIrYXBwLlVSTC5yZXBsYWNlKC9tV1RJRC8sbVdUSUQpK1wiJz5cIithcHAudGl0bGUrXCI8L2E+XCIpO1xyXG5cdFx0YXBwc0xpLmFwcGVuZFRvKGFwcHNMaXN0KTtcclxuXHR9KVxyXG5cdGFwcHNMaXN0LmFwcGVuZFRvKCQoXCJ1bC5wdXJlQ3NzTWVudS5wdXJlQ3NzTWVudW0gYVtocmVmPScvd2lraS9IZWxwOkFwcHMnXVwiKS5wYXJlbnQoKSk7XHJcblx0Y29uc3QgYXBwc0xpbmsgPSAkKFwidWwucHVyZUNzc01lbnUucHVyZUNzc01lbnVtIGFbaHJlZj0nL3dpa2kvSGVscDpBcHBzJ11cIikucGFyZW50KCk7XHJcblx0JChcInVsLnB1cmVDc3NNZW51LnB1cmVDc3NNZW51bSBhW2hyZWY9Jy93aWtpL0hlbHA6QXBwcyddXCIpLnRleHQoXCLCqyBBcHBzXCIpO1xyXG5cdGFwcHNMaW5rLmhvdmVyKGZ1bmN0aW9uKCl7YXBwc0xpc3Quc2hvdygpO30sZnVuY3Rpb24oKXthcHBzTGlzdC5oaWRlKCk7fSlcclxufVxyXG5cclxuZnVuY3Rpb24gYWRkQXBwc01lbnUoKXtcdFxyXG5cdGNvbnN0IGQgPSBuZXcgRGF0ZSgpO1xyXG5cdGxldCBkYXkgPSBkLmdldFVUQ0RhdGUoKTtcclxuXHRsZXQgZ2V0TWVudSA9IGZhbHNlO1xyXG5cdC8vIFN0b3JlIHRoZSBkYXRlIGlmIGl0IGhhc24ndCBiZWVuIHN0b3JlZFxyXG5cdGlmICghbG9jYWxTdG9yYWdlLmFwcHNNZW51Q2hlY2spe1xyXG5cdFx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJhcHBzTWVudUNoZWNrXCIsZGF5KTtcclxuXHR9XHJcblx0Ly8gU3RvcmUgdGhlIGRhdGUgYW5kIHVwZGF0ZSB0aGUgbWVudSBpZiBpdCdzIGEgbmV3IGRheS5cclxuXHRlbHNlIGlmIChkYXkhPWxvY2FsU3RvcmFnZS5hcHBzTWVudUNoZWNrKXtcclxuXHRcdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYXBwc01lbnVDaGVja1wiLGRheSk7XHJcblx0XHRnZXRNZW51ID0gdHJ1ZTtcclxuXHR9XHJcblx0aWYgKCFsb2NhbFN0b3JhZ2UuYXBwc01lbnUgfHwgZ2V0TWVudSA9PSB0cnVlKXtcclxuXHRcdGdldEFwcHNNZW51KCkudGhlbigobWVudSk9PntcclxuXHRcdFx0YXR0YWNoQXBwc01lbnUobWVudSk7XHJcblx0XHRcdC8vIFN0b3JlIHRoZSBtZW51LlxyXG5cdFx0XHRsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImFwcHNNZW51XCIsSlNPTi5zdHJpbmdpZnkobWVudSkpO1xyXG5cdFx0fSlcclxuXHR9IGVsc2UgeyAgLy8gT3IgdXNlIHRoZSBzdG9yZWQgbWVudS5cclxuXHRcdGF0dGFjaEFwcHNNZW51KEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmFwcHNNZW51KSk7XHJcblx0fVxyXG59IiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IHtwYWdlUHJvZmlsZX0gZnJvbSAnLi4vLi4vY29yZS9jb21tb24nO1xyXG5pbXBvcnQgJy4vY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWUuY3NzJztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KCdjb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZScsIChyZXN1bHQpID0+IHtcclxuXHRpZiAocmVzdWx0LmNvbGxhcHNpYmxlRGVzY2VuZGFudHNUcmVlICYmIHBhZ2VQcm9maWxlID09IHRydWUpIHsgXHJcblxyXG4gICAgLy8gTG9vayBvdXQgZm9yIHRoZSBhcHBlYXJhbmNlIG9mIG5ldyBsaXN0IGl0ZW1zIGluIHRoZSBkZXNjZW5kYW50c0NvbnRhaW5lclxyXG4gICAgY29uc3QgZGVzY2VuZGFudHNPYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGZ1bmN0aW9uIChtdXRhdGlvbnNfbGlzdCkge1xyXG4gICAgICBtdXRhdGlvbnNfbGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChtdXRhdGlvbikge1xyXG4gICAgICBtdXRhdGlvbi5hZGRlZE5vZGVzLmZvckVhY2goZnVuY3Rpb24gKGFkZGVkX25vZGUpIHtcclxuICAgICAgICBpZiAoYWRkZWRfbm9kZS50YWdOYW1lID09IFwiT0xcIikge1xyXG4gICAgICAgIHRoZUxJUyA9ICQoYWRkZWRfbm9kZSkuZmluZChcImxpXCIpO1xyXG4gICAgICAgIHRoZUxJUy5lYWNoKGZ1bmN0aW9uIChpbmRleCwgdGhpbmcpIHtcclxuICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGNyZWF0ZURlc2NlbmRhbnRzQnV0dG9uKGluZGV4LCB0aGluZyk7XHJcbiAgICAgICAgICAgICAgfSwgMTApO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICgkKFwiI2Rlc2NlbmRhbnRzQ29udGFpbmVyXCIpLmxlbmd0aCkge1xyXG4gICAgICAgIGRlc2NlbmRhbnRzT2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2Rlc2NlbmRhbnRzQ29udGFpbmVyXCIpLFxyXG4gICAgICAgIHsgc3VidHJlZTogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEFkZCBidXR0b25zXHJcbiAgICBpZiAoJChcImJvZHkucGFnZS1TcGVjaWFsX0Rlc2NlbmRhbnRzXCIpLmxlbmd0aCkge1xyXG4gICAgICBpZiAoJChcIm9sXCIpLmxlbmd0aCkge1xyXG4gICAgICAgICQoXCJvbCBsaVwiKS5lYWNoKGZ1bmN0aW9uIChpbmRleCwgdGhpbmcpIHtcclxuICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBjcmVhdGVEZXNjZW5kYW50c0J1dHRvbihpbmRleCwgdGhpbmcpO1xyXG4gICAgICAgICAgfSwgMTApO1xyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVEZXNjZW5kYW50c0J1dHRvbihuLCBsaSkge1xyXG4gICAgLy8gQXR0YWNoIGNsYXNzIHRvIGF2b2lkIGFkZGluZyBidXR0b24gbW9yZSB0aGFuIG9uY2VcclxuICAgICAgaWYgKGxpLmNsYXNzTGlzdC5jb250YWlucygnY29sbGFwc2UnKSkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIWlzTmV4dFNpYmxpbmdEaXYobGkpKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgICQobGkpLmFkZENsYXNzKCdjb2xsYXBzZScpO1xyXG4gICAgICBjb25zdCBidXR0b24gPSAkKFwiPGJ1dHRvbiBjbGFzcz0nd2lraXRyZWV0dXJibyc+LTwvYnV0dG9uPlwiKTtcclxuICAgICAgJChidXR0b24pLmNsaWNrKHRvZ2dsZUNvbGxhcHNlKTtcclxuICAgICAgJChsaSkucHJlcGVuZChidXR0b24pO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGlzTmV4dFNpYmxpbmdEaXYoZWwpIHtcclxuICAgICAgaWYoZWwubmV4dEVsZW1lbnRTaWJsaW5nKSB7XHJcbiAgICAgICAgaWYgKGVsLm5leHRFbGVtZW50U2libGluZy50YWdOYW1lPT1cIkRJVlwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHRvZ2dsZUNvbGxhcHNlKGUpIHtcclxuICAgICAgY29uc3QgcyA9ICQoZS50YXJnZXQpLnRleHQoKTtcclxuICAgICAgJChlLnRhcmdldCkudGV4dChzPT0nLScgPyAnKycgOiAnLScpO1xyXG4gICAgICAkKGUudGFyZ2V0LnBhcmVudEVsZW1lbnQubmV4dEVsZW1lbnRTaWJsaW5nKS50b2dnbGUoKTtcclxuICAgIH1cclxuICAgIFxyXG4gIH1cclxufSk7XHJcbiIsImltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCAnLi9kYXJrTW9kZS5jc3MnO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJkYXJrTW9kZVwiLCAocmVzdWx0KSA9PiB7XHJcbiAgaWYgKHJlc3VsdC5kYXJrTW9kZSkge1xyXG4gICAgJChcImJvZHlcIikuYWRkQ2xhc3MoXCJkYXJrTW9kZVwiKTtcclxuICAgICQoXCJpbWdbc3JjKj0nd2lraXRyZWUtbG9nby5wbmcnXVwiKS5hdHRyKFxyXG4gICAgICBcInNyY1wiLFxyXG4gICAgICBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWFnZXMvd2lraXRyZWUtbG9nby13aGl0ZS5wbmdcIilcclxuICAgICk7XHJcbiAgICAkKFwiaW1nW3NyYyo9J3dpa2l0cmVlLXNtYWxsLnBuZyddXCIpLmF0dHIoXHJcbiAgICAgIFwic3JjXCIsXHJcbiAgICAgIGNocm9tZS5ydW50aW1lLmdldFVSTChcImltYWdlcy93aWtpdHJlZS1sb2dvLXNtYWxsLXdoaXRlLnBuZ1wiKVxyXG4gICAgKTtcclxuICAgICQoXCJpbWdbc3JjKj0nV2lraS1UcmVlLmdpZiddXCIpLmF0dHIoXHJcbiAgICAgIFwic3JjXCIsXHJcbiAgICAgIGNocm9tZS5ydW50aW1lLmdldFVSTChcImltYWdlcy93aWtpdHJlZS1sb2dvLXdoaXRlLUcyRy5wbmdcIilcclxuICAgICk7XHJcbiAgICAkKFwiaW1nW3NyYyo9J0cyRy5naWYnXVwiKS5hdHRyKFxyXG4gICAgICBcInNyY1wiLFxyXG4gICAgICBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWFnZXMvRzJHLXRyYW5zcGFyZW50LnBuZ1wiKVxyXG4gICAgKTtcclxuICAgICQoXCJoMTpjb250YWlucyhDb25uZWN0aW9uIEZpbmRlcilcIikucGFyZW50KCkuY3NzKFwiYmFja2dyb3VuZC1pbWFnZVwiLCBcIlwiKTtcclxuICAgICQoXCJib2R5LmRhcmtNb2RlLnBhZ2UtTWFpbl9QYWdlIGRpdi5zaXh0ZWVuLmNvbHVtbnMudG9wXCIpLmNzcyhcclxuICAgICAgXCJiYWNrZ3JvdW5kLWltYWdlXCIsXHJcbiAgICAgIFwidXJsKFwiICsgY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwiaW1hZ2VzL3RyZWUtd2hpdGUucG5nXCIpICsgXCIpXCJcclxuICAgICk7XHJcblxyXG4gICAgLy8gQWRkIGNvZGUgdG8gaWZyYW1lcyBvbiBtZXJnaW5nIGNvbXBhcmlzb24gcGFnZS5cclxuICAgIGlmICh3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaChcIlNwZWNpYWw6TWVyZ2VQZXJzb25cIikpIHtcclxuICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGlmcmFtZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaWZyYW1lXCIpO1xyXG4gICAgICAgIGlmcmFtZXMuZm9yRWFjaChmdW5jdGlvbiAoZnJhbWUpIHtcclxuICAgICAgICAgIGxldCBsaW5rRWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlua1wiKTtcclxuICAgICAgICAgIGxpbmtFbC5yZWwgPSBcInN0eWxlc2hlZXRcIjtcclxuICAgICAgICAgIGxpbmtFbC5ocmVmID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwiZmVhdHVyZXMvZGFya01vZGUvZGFya01vZGUuY3NzXCIpO1xyXG4gICAgICAgICAgbGlua0VsLnR5cGUgPSBcInRleHQvY3NzXCI7XHJcbiAgICAgICAgICBsZXQgb0RvY3VtZW50ID0gZnJhbWUuY29udGVudFdpbmRvdy5kb2N1bWVudDtcclxuICAgICAgICAgIGxldCB0aGVIZWFkID0gb0RvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiaGVhZFwiKVswXTtcclxuICAgICAgICAgIHRoZUhlYWQuYXBwZW5kQ2hpbGQobGlua0VsKTtcclxuICAgICAgICAgIG9Eb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJvZHlcIilbMF0uY2xhc3NMaXN0LmFkZChcImRhcmtNb2RlXCIpO1xyXG4gICAgICAgICAgbGV0IGxvZ28gPSBvRG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImltZ1tzcmMqPSd3aWtpdHJlZS1zbWFsbC5wbmcnXVwiKTtcclxuICAgICAgICAgIGlmIChsb2dvKSB7XHJcbiAgICAgICAgICAgIGxvZ28uc2V0QXR0cmlidXRlKFxyXG4gICAgICAgICAgICAgIFwic3JjXCIsXHJcbiAgICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwiaW1hZ2VzL3dpa2l0cmVlLWxvZ28tc21hbGwtd2hpdGUucG5nXCIpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sIDcwMCk7XHJcbiAgICB9XHJcbiAgfVxyXG59KTtcclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IENvb2tpZXMgZnJvbSAnanMtY29va2llJztcclxuaW1wb3J0IERleGllIGZyb20gJ2RleGllJztcclxuaW1wb3J0ICcuL2Rpc3RhbmNlQW5kUmVsYXRpb25zaGlwLmNzcyc7XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldChcImRpc3RhbmNlQW5kUmVsYXRpb25zaGlwXCIsIChyZXN1bHQpID0+IHtcclxuICBpZiAoXHJcbiAgICByZXN1bHQuZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAgJiZcclxuICAgICQoXCJib2R5LkJFRVwiKS5sZW5ndGggPT0gMCAmJlxyXG4gICAgJChcImJvZHkucHJvZmlsZVwiKS5sZW5ndGggJiZcclxuICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKFwiU3BhY2U6XCIpID09IG51bGxcclxuICApIHtcclxuICAgIGNvbnN0IHByb2ZpbGVJRCA9ICQoXCJhLnB1cmVDc3NNZW51aTAgc3Bhbi5wZXJzb25cIikudGV4dCgpO1xyXG4gICAgY29uc3QgdXNlcklEID0gQ29va2llcy5nZXQoXCJ3aWtpdHJlZV93dGJfVXNlck5hbWVcIik7XHJcbiAgICB2YXIgZGIgPSBuZXcgRGV4aWUoXCJDb25uZWN0aW9uRmluZGVyUmVzdWx0c1wiKTtcclxuICAgIGRiLnZlcnNpb24oMSkuc3RvcmVzKHtcclxuICAgICAgZGlzdGFuY2U6IFwiW3VzZXJJZCtpZF1cIixcclxuICAgICAgY29ubmVjdGlvbjogXCJbdXNlcklkK2lkXVwiLFxyXG4gICAgfSk7XHJcbiAgICBkYi5vcGVuKCkudGhlbihmdW5jdGlvbiAoZGIpIHtcclxuICAgICAgZGIuZGlzdGFuY2VcclxuICAgICAgICAuZ2V0KHsgdXNlcklkOiB1c2VySUQsIGlkOiBwcm9maWxlSUQgfSlcclxuICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICAgICAgICBpZiAocmVzdWx0ID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBpbml0RGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAodXNlcklELCBwcm9maWxlSUQpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKCQoXCIjZGlzdGFuY2VGcm9tWW91XCIpLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgcHJvZmlsZU5hbWUgPSAkKFwiaDEgc3BhbltpdGVtcHJvcD0nbmFtZSddXCIpLnRleHQoKTtcclxuICAgICAgICAgICAgICAkKFwiaDFcIikuYXBwZW5kKFxyXG4gICAgICAgICAgICAgICAgJChcclxuICAgICAgICAgICAgICAgICAgYDxzcGFuIGlkPSdkaXN0YW5jZUZyb21Zb3UnIHRpdGxlPScke3Byb2ZpbGVOYW1lfSBpcyAke3Jlc3VsdC5kaXN0YW5jZX0gZGVncmVlcyBmcm9tIHlvdS4gXFxuQ2xpY2sgdG8gcmVmcmVzaC4nPiR7cmVzdWx0LmRpc3RhbmNlfcKwPC9zcGFuPmBcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAkKFwiI2Rpc3RhbmNlRnJvbVlvdVwiKS5jbGljayhmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgJCh0aGlzKS5mYWRlT3V0KFwic2xvd1wiKS5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgICQoXCIjeW91clJlbGF0aW9uc2hpcFRleHRcIikuZmFkZU91dChcInNsb3dcIikucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICBpbml0RGlzdGFuY2VBbmRSZWxhdGlvbnNoaXAodXNlcklELCBwcm9maWxlSUQpO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICB2YXIgcmRiID0gbmV3IERleGllKFwiUmVsYXRpb25zaGlwRmluZGVyUmVzdWx0c1wiKTtcclxuICAgICAgICAgICAgICByZGIudmVyc2lvbigxKS5zdG9yZXMoe1xyXG4gICAgICAgICAgICAgICAgcmVsYXRpb25zaGlwOiBcIlt1c2VySWQraWRdXCIsXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgcmRiLm9wZW4oKS50aGVuKGZ1bmN0aW9uIChyZGIpIHtcclxuICAgICAgICAgICAgICAgIHJkYi5yZWxhdGlvbnNoaXBcclxuICAgICAgICAgICAgICAgICAgLmdldCh7IHVzZXJJZDogdXNlcklELCBpZDogcHJvZmlsZUlEIH0pXHJcbiAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0ICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5yZWxhdGlvbnNoaXAgIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJChcIiN5b3VyUmVsYXRpb25zaGlwVGV4dFwiKS5sZW5ndGggPT0gMCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICQoXCIuYW5jZXN0b3JUZXh0VGV4dFwiKS5sZW5ndGggPT0gMCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICQoXCIjYW5jZXN0b3JMaXN0Qm94XCIpLmxlbmd0aCA9PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICQoXCIjeW91clJlbGF0aW9uc2hpcFRleHRcIikucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkUmVsYXRpb25zaGlwVGV4dChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5yZWxhdGlvbnNoaXAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuY29tbW9uQW5jZXN0b3JzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBkb1JlbGF0aW9uc2hpcFRleHQodXNlcklELCBwcm9maWxlSUQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRQcm9maWxlKGlkLCBmaWVsZHMgPSBcIipcIikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCAkLmFqYXgoe1xyXG4gICAgICB1cmw6IFwiaHR0cHM6Ly9hcGkud2lraXRyZWUuY29tL2FwaS5waHBcIixcclxuICAgICAgY3Jvc3NEb21haW46IHRydWUsXHJcbiAgICAgIHhockZpZWxkczogeyB3aXRoQ3JlZGVudGlhbHM6IHRydWUgfSxcclxuICAgICAgdHlwZTogXCJQT1NUXCIsXHJcbiAgICAgIGRhdGFUeXBlOiBcImpzb25cIixcclxuICAgICAgZGF0YTogeyBhY3Rpb246IFwiZ2V0UHJvZmlsZVwiLCBrZXk6IGlkLCBmaWVsZHM6IGZpZWxkcyB9LFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gcmVzdWx0WzBdLnByb2ZpbGU7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbkZpbmRlclJlc3VsdChpZDEsIGlkMiwgcmVsYXRpdmVzID0gMCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCAkLmFqYXgoe1xyXG4gICAgICB1cmw6IFwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2luZGV4LnBocFwiLFxyXG4gICAgICBjcm9zc0RvbWFpbjogdHJ1ZSxcclxuICAgICAgeGhyRmllbGRzOiB7IHdpdGhDcmVkZW50aWFsczogdHJ1ZSB9LFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgdGl0bGU6IFwiU3BlY2lhbDpDb25uZWN0aW9uXCIsXHJcbiAgICAgICAgYWN0aW9uOiBcImNvbm5lY3RcIixcclxuICAgICAgICBwZXJzb24xTmFtZTogaWQxLFxyXG4gICAgICAgIHBlcnNvbjJOYW1lOiBpZDIsXHJcbiAgICAgICAgcmVsYXRpb246IHJlbGF0aXZlcyxcclxuICAgICAgICBpZ25vcmVJZHM6IFwiXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHR5cGU6IFwiUE9TVFwiLFxyXG4gICAgICBkYXRhVHlwZTogXCJqc29uXCIsXHJcbiAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uIChkYXRhKSB7fSxcclxuICAgICAgZXJyb3I6IGZ1bmN0aW9uIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSZWxhdGlvbnNoaXBGaW5kZXJSZXN1bHQoaWQxLCBpZDIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgJC5hamF4KHtcclxuICAgICAgdXJsOiBcImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbmRleC5waHBcIixcclxuICAgICAgY3Jvc3NEb21haW46IHRydWUsXHJcbiAgICAgIHhockZpZWxkczogeyB3aXRoQ3JlZGVudGlhbHM6IHRydWUgfSxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIHRpdGxlOiBcIlNwZWNpYWw6UmVsYXRpb25zaGlwXCIsXHJcbiAgICAgICAgYWN0aW9uOiBcImdldFJlbGF0aW9uc2hpcFwiLFxyXG4gICAgICAgIHBlcnNvbjFfbmFtZTogaWQxLFxyXG4gICAgICAgIHBlcnNvbjJfbmFtZTogaWQyLFxyXG4gICAgICB9LFxyXG4gICAgICB0eXBlOiBcIlBPU1RcIixcclxuICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbiAoZGF0YSkge30sXHJcbiAgICAgIGVycm9yOiBmdW5jdGlvbiAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gYWRkUmVsYXRpb25zaGlwVGV4dChvVGV4dCwgY29tbW9uQW5jZXN0b3JzKSB7XHJcbiAgY29uc3QgY29tbW9uQW5jZXN0b3JUZXh0T3V0ID0gY29tbW9uQW5jZXN0b3JUZXh0KGNvbW1vbkFuY2VzdG9ycyk7XHJcbiAgY29uc3QgY291c2luVGV4dCA9ICQoXHJcbiAgICBcIjxkaXYgaWQ9J3lvdXJSZWxhdGlvbnNoaXBUZXh0JyB0aXRsZT0nQ2xpY2sgdG8gcmVmcmVzaCcgY2xhc3M9J3JlbGF0aW9uc2hpcEZpbmRlcic+WW91ciBcIiArXHJcbiAgICAgIG9UZXh0ICtcclxuICAgICAgXCI8dWwgaWQ9J3lvdXJDb21tb25BbmNlc3Rvcicgc3R5bGU9J3doaXRlLXNwYWNlOm5vd3JhcCc+XCIgK1xyXG4gICAgICBjb21tb25BbmNlc3RvclRleHRPdXQgK1xyXG4gICAgICBcIjwvdWw+PC9kaXY+XCJcclxuICApO1xyXG4gICQoXCJoMVwiKS5hZnRlcihjb3VzaW5UZXh0KTtcclxuICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XHJcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgbGV0IGlkMSA9IENvb2tpZXMuZ2V0KFwid2lraXRyZWVfd3RiX1VzZXJOYW1lXCIpO1xyXG4gICAgbGV0IGlkMiA9ICQoXCJhLnB1cmVDc3NNZW51aTAgc3Bhbi5wZXJzb25cIikudGV4dCgpO1xyXG4gICAgaW5pdERpc3RhbmNlQW5kUmVsYXRpb25zaGlwKGlkMSwgaWQyKTtcclxuICB9KTtcclxuICBpZiAoY29tbW9uQW5jZXN0b3JzLmxlbmd0aCA+IDIpIHtcclxuICAgICQoXCIjeW91clJlbGF0aW9uc2hpcFRleHRcIikuYXBwZW5kKFxyXG4gICAgICAkKFwiPGJ1dHRvbiBjbGFzcz0nc21hbGwnIGlkPSdzaG93TW9yZUFuY2VzdG9ycyc+TW9yZTwvYnV0dG9uPlwiKVxyXG4gICAgKTtcclxuICAgICQoXCIjc2hvd01vcmVBbmNlc3RvcnNcIikuY2xpY2soZnVuY3Rpb24gKGUpIHtcclxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAkKFwiI3lvdXJDb21tb25BbmNlc3RvciBsaTpudGgtY2hpbGQobiszKVwiKS50b2dnbGUoKTtcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY29tbW9uQW5jZXN0b3JUZXh0KGNvbW1vbkFuY2VzdG9ycykge1xyXG4gIGxldCBhbmNlc3RvclRleHRPdXQgPSBcIlwiO1xyXG4gIGNvbnN0IHByb2ZpbGVHZW5kZXIgPSAkKFwiYm9keVwiKVxyXG4gICAgLmZpbmQoXCJtZXRhW2l0ZW1wcm9wPSdnZW5kZXInXVwiKVxyXG4gICAgLmF0dHIoXCJjb250ZW50XCIpO1xyXG4gIGxldCBwb3NzZXNzaXZlQWRqID0gXCJ0aGVpclwiO1xyXG4gIGlmIChwcm9maWxlR2VuZGVyID09IFwibWFsZVwiKSB7XHJcbiAgICBwb3NzZXNzaXZlQWRqID0gXCJoaXNcIjtcclxuICB9XHJcbiAgaWYgKHByb2ZpbGVHZW5kZXIgPT0gXCJmZW1hbGVcIikge1xyXG4gICAgcG9zc2Vzc2l2ZUFkaiA9IFwiaGVyXCI7XHJcbiAgfVxyXG4gIGNvbW1vbkFuY2VzdG9ycy5mb3JFYWNoKGZ1bmN0aW9uIChjb21tb25BbmNlc3Rvcikge1xyXG4gICAgY29uc3QgdGhpc0FuY2VzdG9yVHlwZSA9IGFuY2VzdG9yVHlwZShcclxuICAgICAgY29tbW9uQW5jZXN0b3IucGF0aDJMZW5ndGggLSAxLFxyXG4gICAgICBjb21tb25BbmNlc3Rvci5hbmNlc3Rvci5tR2VuZGVyXHJcbiAgICApLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBhbmNlc3RvclRleHRPdXQgKz1cclxuICAgICAgJzxsaT5Zb3VyIGNvbW1vbiBhbmNlc3RvciwgPGEgaHJlZj1cImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpLycgK1xyXG4gICAgICBjb21tb25BbmNlc3Rvci5hbmNlc3Rvci5tTmFtZSArXHJcbiAgICAgICdcIj4nICtcclxuICAgICAgY29tbW9uQW5jZXN0b3IuYW5jZXN0b3IubURlcml2ZWQuTG9uZ05hbWVXaXRoRGF0ZXMgK1xyXG4gICAgICBcIjwvYT4sIGlzIFwiICtcclxuICAgICAgcG9zc2Vzc2l2ZUFkaiArXHJcbiAgICAgIFwiIFwiICtcclxuICAgICAgdGhpc0FuY2VzdG9yVHlwZSArXHJcbiAgICAgIFwiLjwvbGk+XCI7XHJcbiAgfSk7XHJcbiAgcmV0dXJuIGFuY2VzdG9yVGV4dE91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gZG9SZWxhdGlvbnNoaXBUZXh0KHVzZXJJRCwgcHJvZmlsZUlEKSB7XHJcbiAgZ2V0UmVsYXRpb25zaGlwRmluZGVyUmVzdWx0KHVzZXJJRCwgcHJvZmlsZUlEKS50aGVuKGZ1bmN0aW9uIChkYXRhKSB7XHJcbiAgICBpZiAoZGF0YSkge1xyXG4gICAgICBsZXQgb3V0ID0gXCJcIjtcclxuICAgICAgdmFyIGFSZWxhdGlvbnNoaXAgPSB0cnVlO1xyXG4gICAgICBjb25zdCBjb21tb25BbmNlc3RvcnMgPSBbXTtcclxuICAgICAgbGV0IHJlYWxPdXQgPSBcIlwiO1xyXG4gICAgICBsZXQgZHVtbXkgPSAkKFwiPGh0bWw+PC9odG1sPlwiKTtcclxuICAgICAgZHVtbXkuYXBwZW5kKCQoZGF0YS5odG1sKSk7XHJcbiAgICAgIGlmIChkdW1teS5maW5kKFwiaDFcIikubGVuZ3RoKSB7XHJcbiAgICAgICAgaWYgKGR1bW15LmZpbmQoXCJoMVwiKS5lcSgwKS50ZXh0KCkgPT0gXCJObyBSZWxhdGlvbnNoaXAgRm91bmRcIikge1xyXG4gICAgICAgICAgYVJlbGF0aW9uc2hpcCA9IGZhbHNlO1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJObyBSZWxhdGlvbnNoaXAgRm91bmRcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGlmIChkdW1teS5maW5kKFwiaDJcIikubGVuZ3RoICYmIGFSZWxhdGlvbnNoaXAgPT0gdHJ1ZSkge1xyXG4gICAgICAgIGxldCBvaDIgPSBkdW1teVxyXG4gICAgICAgICAgLmZpbmQoXCJoMlwiKVxyXG4gICAgICAgICAgLmVxKDApXHJcbiAgICAgICAgICAudGV4dCgpXHJcbiAgICAgICAgICAucmVwbGFjZUFsbCgvW1xcdFxcbl0vZywgXCJcIik7XHJcbiAgICAgICAgaWYgKGRhdGEuY29tbW9uQW5jZXN0b3JzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICBvdXQgPSBkdW1teS5maW5kKFwiYlwiKS50ZXh0KCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGNvbnN0IHByb2ZpbGVHZW5kZXIgPSAkKFwiYm9keVwiKVxyXG4gICAgICAgICAgICAuZmluZChcIm1ldGFbaXRlbXByb3A9J2dlbmRlciddXCIpXHJcbiAgICAgICAgICAgIC5hdHRyKFwiY29udGVudFwiKTtcclxuICAgICAgICAgIGlmIChvaDIubWF0Y2goXCJpcyB0aGVcIikpIHtcclxuICAgICAgICAgICAgb3V0ID0gb2gyLnNwbGl0KFwiaXMgdGhlIFwiKVsxXS5zcGxpdChcIiBvZlwiKVswXTtcclxuICAgICAgICAgIH0gZWxzZSBpZiAob2gyLm1hdGNoKFwiIGFyZSBcIikpIHtcclxuICAgICAgICAgICAgb3V0ID0gb2gyLnNwbGl0KFwiYXJlIFwiKVsxXS5yZXBsYWNlKC9jb3VzaW5zLywgXCJjb3VzaW5cIik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBpZiAob3V0Lm1hdGNoKC9uZXBoZXd8bmllY2UvKSkge1xyXG4gICAgICAgICAgICBpZiAocHJvZmlsZUdlbmRlciA9PSBcIm1hbGVcIikge1xyXG4gICAgICAgICAgICAgIG91dCA9IG91dC5yZXBsYWNlKC9uZXBoZXd8bmllY2UvLCBcInVuY2xlXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChwcm9maWxlR2VuZGVyID09IFwiZmVtYWxlXCIpIHtcclxuICAgICAgICAgICAgICBvdXQgPSBvdXQucmVwbGFjZSgvbmVwaGV3fG5pZWNlLywgXCJhdW50XCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBvdXRTcGxpdCA9IG91dC5zcGxpdChcIiBcIik7XHJcbiAgICAgICAgb3V0U3BsaXRbMF0gPSBvcmRpbmFsV29yZFRvTnVtYmVyQW5kU3VmZml4KG91dFNwbGl0WzBdKTtcclxuICAgICAgICBvdXQgPSBvdXRTcGxpdC5qb2luKFwiIFwiKTtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLmxlbmd0aCA9PSAwICYmXHJcbiAgICAgICAgICAkKFwiLmFuY2VzdG9yVGV4dFRleHRcIikubGVuZ3RoID09IDAgJiZcclxuICAgICAgICAgICQoXCIjYW5jZXN0b3JMaXN0Qm94XCIpLmxlbmd0aCA9PSAwXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLnJlbW92ZSgpO1xyXG4gICAgICAgICAgYWRkUmVsYXRpb25zaGlwVGV4dChvdXQsIGRhdGEuY29tbW9uQW5jZXN0b3JzKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHZhciByZGIgPSBuZXcgRGV4aWUoXCJSZWxhdGlvbnNoaXBGaW5kZXJSZXN1bHRzXCIpO1xyXG4gICAgICByZGIudmVyc2lvbigxKS5zdG9yZXMoe1xyXG4gICAgICAgIHJlbGF0aW9uc2hpcDogXCJbdXNlcklkK2lkXVwiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmRiXHJcbiAgICAgICAgLm9wZW4oKVxyXG4gICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZGIpIHtcclxuICAgICAgICAgIHJkYi5yZWxhdGlvbnNoaXAucHV0KHtcclxuICAgICAgICAgICAgdXNlcklkOiB1c2VySUQsXHJcbiAgICAgICAgICAgIGlkOiBwcm9maWxlSUQsXHJcbiAgICAgICAgICAgIHJlbGF0aW9uc2hpcDogb3V0LFxyXG4gICAgICAgICAgICBjb21tb25BbmNlc3RvcnM6IGRhdGEuY29tbW9uQW5jZXN0b3JzLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICAvLyBEYXRhYmFzZSBvcGVuZWQgc3VjY2Vzc2Z1bGx5XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgICAgLy8gRXJyb3Igb2NjdXJyZWRcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICB9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYWRkRGlzdGFuY2UoZGF0YSkge1xyXG4gIGlmICgkKFwiI2RlZ3JlZXNGcm9tWW91XCIpLmxlbmd0aCA9PSAwKSB7XHJcbiAgICB3aW5kb3cuZGlzdGFuY2UgPSBkYXRhLnBhdGgubGVuZ3RoO1xyXG4gICAgY29uc3QgcHJvZmlsZU5hbWUgPSAkKFwiaDEgc3BhbltpdGVtcHJvcD0nbmFtZSddXCIpLnRleHQoKTtcclxuICAgICQoXCJoMVwiKS5hcHBlbmQoXHJcbiAgICAgICQoXHJcbiAgICAgICAgYDxzcGFuIGlkPSdkaXN0YW5jZUZyb21Zb3UnIHRpdGxlPScke3Byb2ZpbGVOYW1lfSBpcyAke3dpbmRvdy5kaXN0YW5jZX0gZGVncmVlcyBmcm9tIHlvdS4nPiR7d2luZG93LmRpc3RhbmNlfcKwPC9zcGFuPmBcclxuICAgICAgKVxyXG4gICAgKTtcclxuICAgIHZhciBkYiA9IG5ldyBEZXhpZShcIkNvbm5lY3Rpb25GaW5kZXJSZXN1bHRzXCIpO1xyXG4gICAgZGIudmVyc2lvbigxKS5zdG9yZXMoe1xyXG4gICAgICBkaXN0YW5jZTogXCJbdXNlcklkK2lkXVwiLFxyXG4gICAgICBjb25uZWN0aW9uOiBcIlt1c2VySWQraWRdXCIsXHJcbiAgICB9KTtcclxuICAgIGRiLm9wZW4oKVxyXG4gICAgICAudGhlbihmdW5jdGlvbiAoZGIpIHtcclxuICAgICAgICBkYi5kaXN0YW5jZS5wdXQoe1xyXG4gICAgICAgICAgdXNlcklkOiBDb29raWVzLmdldChcIndpa2l0cmVlX3d0Yl9Vc2VyTmFtZVwiKSxcclxuICAgICAgICAgIGlkOiAkKFwiYS5wdXJlQ3NzTWVudWkwIHNwYW4ucGVyc29uXCIpLnRleHQoKSxcclxuICAgICAgICAgIGRpc3RhbmNlOiB3aW5kb3cuZGlzdGFuY2UsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gRGF0YWJhc2Ugb3BlbmVkIHN1Y2Nlc3NmdWxseVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgIC8vIEVycm9yIG9jY3VycmVkXHJcbiAgICAgIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0RGlzdGFuY2UoKSB7XHJcbiAgY29uc3QgaWQxID0gQ29va2llcy5nZXQoXCJ3aWtpdHJlZV93dGJfVXNlck5hbWVcIik7XHJcbiAgY29uc3QgaWQyID0gJChcImEucHVyZUNzc01lbnVpMCBzcGFuLnBlcnNvblwiKS50ZXh0KCk7XHJcbiAgY29uc3QgZGF0YSA9IGF3YWl0IGdldENvbm5lY3Rpb25GaW5kZXJSZXN1bHQoaWQxLCBpZDIpO1xyXG4gIGFkZERpc3RhbmNlKGRhdGEpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvcmRpbmFsKGkpIHtcclxuICB2YXIgaiA9IGkgJSAxMCxcclxuICAgIGsgPSBpICUgMTAwO1xyXG4gIGlmIChqID09IDEgJiYgayAhPSAxMSkge1xyXG4gICAgcmV0dXJuIGkgKyBcInN0XCI7XHJcbiAgfVxyXG4gIGlmIChqID09IDIgJiYgayAhPSAxMikge1xyXG4gICAgcmV0dXJuIGkgKyBcIm5kXCI7XHJcbiAgfVxyXG4gIGlmIChqID09IDMgJiYgayAhPSAxMykge1xyXG4gICAgcmV0dXJuIGkgKyBcInJkXCI7XHJcbiAgfVxyXG4gIHJldHVybiBpICsgXCJ0aFwiO1xyXG59XHJcblxyXG5mdW5jdGlvbiBhbmNlc3RvclR5cGUoZ2VuZXJhdGlvbiwgZ2VuZGVyKSB7XHJcbiAgbGV0IHJlbFR5cGU7XHJcbiAgaWYgKGdlbmVyYXRpb24gPiAwIHx8IGdlbmVyYXRpb24gPT0gMCkge1xyXG4gICAgaWYgKGdlbmRlciA9PSBcIkZlbWFsZVwiKSB7XHJcbiAgICAgIHJlbFR5cGUgPSBcIk1vdGhlclwiO1xyXG4gICAgfSBlbHNlIGlmIChnZW5kZXIgPT0gXCJNYWxlXCIpIHtcclxuICAgICAgcmVsVHlwZSA9IFwiRmF0aGVyXCI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZWxUeXBlID0gXCJQYXJlbnRcIjtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGdlbmVyYXRpb24gPiAxKSB7XHJcbiAgICByZWxUeXBlID0gXCJHcmFuZFwiICsgcmVsVHlwZS50b0xvd2VyQ2FzZSgpO1xyXG4gIH1cclxuICBpZiAoZ2VuZXJhdGlvbiA+IDIpIHtcclxuICAgIHJlbFR5cGUgPSBcIkdyZWF0LVwiICsgcmVsVHlwZS50b0xvd2VyQ2FzZSgpO1xyXG4gIH1cclxuICBpZiAoZ2VuZXJhdGlvbiA+IDMpIHtcclxuICAgIHJlbFR5cGUgPSBvcmRpbmFsKGdlbmVyYXRpb24gLSAyKSArIFwiIFwiICsgcmVsVHlwZTtcclxuICB9XHJcbiAgcmV0dXJuIHJlbFR5cGU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG9yZGluYWxXb3JkVG9OdW1iZXJBbmRTdWZmaXgod29yZCkge1xyXG4gIGNvbnN0IG9yZGluYWxzQXJyYXkgPSBbXHJcbiAgICBbXCJmaXJzdFwiLCBcIjFzdFwiXSxcclxuICAgIFtcInNlY29uZFwiLCBcIjJuZFwiXSxcclxuICAgIFtcInRoaXJkXCIsIFwiM3JkXCJdLFxyXG4gICAgW1wiZm91cnRoXCIsIFwiNHRoXCJdLFxyXG4gICAgW1wiZmlmdGhcIiwgXCI1dGhcIl0sXHJcbiAgICBbXCJzaXh0aFwiLCBcIjZ0aFwiXSxcclxuICAgIFtcInNldmVudGhcIiwgXCI3dGhcIl0sXHJcbiAgICBbXCJlaWd0aFwiLCBcIjh0aFwiXSxcclxuICAgIFtcIm5pbnRoXCIsIFwiOXRoXCJdLFxyXG4gICAgW1widGVudGhcIiwgXCIxMHRoXCJdLFxyXG4gICAgW1wiZWxldmVudGhcIiwgXCIxMXRoXCJdLFxyXG4gICAgW1widHdlbGZ0aFwiLCBcIjEydGhcIl0sXHJcbiAgICBbXCJ0aGlydGVlbnRoXCIsIFwiMTN0aFwiXSxcclxuICAgIFtcImZvdXJ0ZWVudGhcIiwgXCIxNHRoXCJdLFxyXG4gICAgW1wiZmlmdGVlbnRoXCIsIFwiMTV0aFwiXSxcclxuICAgIFtcInNpeHRlZW50aFwiLCBcIjE2dGhcIl0sXHJcbiAgICBbXCJzZXZlbnRlZW50aFwiLCBcIjE3dGhcIl0sXHJcbiAgICBbXCJlaWdodGVlbnRoXCIsIFwiMTh0aFwiXSxcclxuICAgIFtcIm5pbmV0ZWVudGhcIiwgXCIxOXRoXCJdLFxyXG4gICAgW1widHdlbnRpZXRoXCIsIFwiMjB0aFwiXSxcclxuICAgIFtcInR3ZW50eS1maXJzdFwiLCBcIjIxc3RcIl0sXHJcbiAgICBbXCJ0d2VudHktc2Vjb25kXCIsIFwiMjJuZFwiXSxcclxuICAgIFtcInR3ZW50eS10aGlyZFwiLCBcIjIzcmRcIl0sXHJcbiAgICBbXCJ0d2VudHktZm91cnRoXCIsIFwiMjR0aFwiXSxcclxuICAgIFtcInR3ZW50eS1maWZ0aFwiLCBcIjI1dGhcIl0sXHJcbiAgXTtcclxuICBvcmRpbmFsc0FycmF5LmZvckVhY2goZnVuY3Rpb24gKGFycikge1xyXG4gICAgaWYgKHdvcmQgPT0gYXJyWzBdKSB7XHJcbiAgICAgIHdvcmQgPSBhcnJbMV07XHJcbiAgICAgIHJldHVybiBhcnJbMV07XHJcbiAgICB9XHJcbiAgfSk7XHJcbiAgcmV0dXJuIHdvcmQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGluaXREaXN0YW5jZUFuZFJlbGF0aW9uc2hpcCh1c2VySUQsIHByb2ZpbGVJRCkge1xyXG4gICQoXCIjZGlzdGFuY2VGcm9tWW91XCIpLmZhZGVPdXQoKS5yZW1vdmUoKTtcclxuICAkKFwiI3lvdXJSZWxhdGlvbnNoaXBUZXh0XCIpLmZhZGVPdXQoKS5yZW1vdmUoKTtcclxuICBnZXRQcm9maWxlKHByb2ZpbGVJRCkudGhlbigocGVyc29uKSA9PiB7XHJcbiAgICBjb25zdCBub3dUaW1lID0gRGF0ZS5wYXJzZShEYXRlKCkpO1xyXG4gICAgY29uc3QgY3JlYXRlZCA9IERhdGUucGFyc2UoXHJcbiAgICAgIHBlcnNvbi5DcmVhdGVkLnN1YnN0cigwLCA4KS5yZXBsYWNlKC8oLi4uLikoLi4pKC4uKS8sIFwiJDEtJDItJDNcIilcclxuICAgICk7XHJcbiAgICBjb25zdCB0aW1lRGlmZmVyZW5jZSA9IG5vd1RpbWUgLSBjcmVhdGVkO1xyXG4gICAgY29uc3QgbmluZURheXMgPSA3Nzc2MDAwMDA7XHJcbiAgICBpZiAoXHJcbiAgICAgIHBlcnNvbi5Qcml2YWN5ID4gMjkgJiZcclxuICAgICAgcGVyc29uLkNvbm5lY3RlZCA9PSAxICYmXHJcbiAgICAgIHRpbWVEaWZmZXJlbmNlID4gbmluZURheXNcclxuICAgICkge1xyXG4gICAgICBnZXREaXN0YW5jZSgpO1xyXG4gICAgICBkb1JlbGF0aW9uc2hpcFRleHQodXNlcklELCBwcm9maWxlSUQpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59XHJcbiIsImltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCB7aXNPS30gZnJvbSAnLi4vLi4vY29yZS9jb21tb24nO1xyXG5pbXBvcnQgJy4vZHJhZnRMaXN0LmNzcyc7XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldChcImRyYWZ0TGlzdFwiLCAocmVzdWx0KSA9PiB7XHJcbiAgaWYgKHJlc3VsdC5kcmFmdExpc3QpIHtcclxuICAgIC8vIENoZWNrIHRoYXQgV2lraVRyZWUgQkVFIGhhc24ndCBhZGRlZCB0aGlzIGFscmVhZHlcclxuICAgIGlmICgkKFwiYS5kcmFmdHNcIikubGVuZ3RoID09IDApIHtcclxuY29uc29sZS5sb2cgKCdkcmFmdHMnKVxyXG4gICAgICBhZGREcmFmdHNUb0ZpbmRNZW51KCk7XHJcbiAgICB9XHJcbiAgICBpZiAoJChcImJvZHkucGFnZS1TcGVjaWFsX0VkaXRQZXJzb25cIikubGVuZ3RoICYmICQoXCJhLmRyYWZ0c1wiKS5sZW5ndGgpIHtcclxuICAgICAgc2F2ZURyYWZ0TGlzdCgpO1xyXG4gICAgfVxyXG4gIH1cclxufSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVEcmFmdExpc3QoKSB7XHJcbiAgY29uc3QgcHJvZmlsZVdUSUQgPSAkKFwiYS5wdXJlQ3NzTWVudWkwIHNwYW4ucGVyc29uXCIpLnRleHQoKTtcclxuICBsZXQgYWRkRHJhZnQgPSBmYWxzZTtcclxuICBsZXQgdGltZU5vdyA9IERhdGUubm93KCk7XHJcbiAgbGV0IGxhc3RXZWVrID0gdGltZU5vdyAtIDYwNDgwMDAwMDtcclxuICBsZXQgaXNFZGl0UGFnZSA9IGZhbHNlO1xyXG4gIGlmIChcclxuICAgICQoXCIjZHJhZnRTdGF0dXM6Y29udGFpbnMoc2F2ZWQpLCNzdGF0dXM6Y29udGFpbnMoU3RhcnRpbmcgd2l0aCBwcmV2aW91cylcIilcclxuICAgICAgLmxlbmd0aFxyXG4gICkge1xyXG4gICAgYWRkRHJhZnQgPSB0cnVlO1xyXG4gICAgdGhlTmFtZSA9ICQoXCJoMVwiKVxyXG4gICAgICAudGV4dCgpXHJcbiAgICAgIC5yZXBsYWNlKFwiRWRpdCBQcm9maWxlIG9mIFwiLCBcIlwiKVxyXG4gICAgICAucmVwbGFjZUFsbCgvXFwvL2csIFwiXCIpXHJcbiAgICAgIC5yZXBsYWNlQWxsKC9JRHxMSU5LfFVSTC9nLCBcIlwiKTtcclxuICB9IGVsc2UgaWYgKCQoXCJib2R5LnBhZ2UtU3BlY2lhbF9FZGl0UGVyc29uXCIpLmxlbmd0aCkge1xyXG4gICAgaXNFZGl0UGFnZSA9IHRydWU7XHJcbiAgfVxyXG4gIGlmIChsb2NhbFN0b3JhZ2UuZHJhZnRzKSB7XHJcbiAgICBsZXQgZHJhZnRzQXJyID0gW107XHJcbiAgICBsZXQgZHJhZnRzQXJySURzID0gW107XHJcbiAgICBsZXQgZHJhZnRzID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZHJhZnRzKTtcclxuICAgIGRyYWZ0cy5mb3JFYWNoKGZ1bmN0aW9uIChkcmFmdCkge1xyXG4gICAgICBpZiAoIWRyYWZ0c0FycklEcy5pbmNsdWRlcyhkcmFmdFswXSkpIHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAoYWRkRHJhZnQgPT0gZmFsc2UgfHwgd2luZG93LmZ1bGxTYXZlID09IHRydWUpICYmXHJcbiAgICAgICAgICBkcmFmdFswXSA9PSBwcm9maWxlV1RJRCAmJlxyXG4gICAgICAgICAgaXNFZGl0UGFnZSA9PSB0cnVlXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmIChkcmFmdFsxXSA+IGxhc3RXZWVrKSB7XHJcbiAgICAgICAgICAgIGRyYWZ0c0Fyci5wdXNoKGRyYWZ0KTtcclxuICAgICAgICAgICAgZHJhZnRzQXJySURzLnB1c2goZHJhZnRbMF0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFkcmFmdHNBcnJJRHMuaW5jbHVkZXMocHJvZmlsZVdUSUQpICYmIGFkZERyYWZ0ID09IHRydWUpIHtcclxuICAgICAgZHJhZnRzQXJyLnB1c2goW3Byb2ZpbGVXVElELCB0aW1lTm93LCB0aGVOYW1lXSk7XHJcbiAgICB9XHJcblxyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJkcmFmdHNcIiwgSlNPTi5zdHJpbmdpZnkoZHJhZnRzQXJyKSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGlmIChhZGREcmFmdCA9PSB0cnVlICYmIHdpbmRvdy5mdWxsU2F2ZSAhPSB0cnVlKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxyXG4gICAgICAgIFwiZHJhZnRzXCIsXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoW1twcm9maWxlV1RJRCwgdGltZU5vdywgdGhlTmFtZV1dKVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gdHJ1ZTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2hvd0RyYWZ0TGlzdCgpIHtcclxuICBpZiAobG9jYWxTdG9yYWdlLmRyYWZ0cykge1xyXG4gICAgYXdhaXQgdXBkYXRlRHJhZnRMaXN0KCk7XHJcbiAgfVxyXG4gICQoXCIjbXlEcmFmdHNcIikucmVtb3ZlKCk7XHJcbiAgJChcImJvZHlcIikuYXBwZW5kKFxyXG4gICAgJChcIjxkaXYgaWQ9J215RHJhZnRzJz48aDI+TXkgRHJhZnRzPC9oMj48eD54PC94Pjx0YWJsZT48L3RhYmxlPjwvZGl2PlwiKVxyXG4gICk7XHJcbiAgJChcIiNteURyYWZ0c1wiKS5kYmxjbGljayhmdW5jdGlvbiAoKSB7XHJcbiAgICAkKHRoaXMpLnNsaWRlVXAoKTtcclxuICB9KTtcclxuICAkKFwiI215RHJhZnRzIHhcIikuY2xpY2soZnVuY3Rpb24gKCkge1xyXG4gICAgJCh0aGlzKS5wYXJlbnQoKS5zbGlkZVVwKCk7XHJcbiAgfSk7XHJcbiAgJChcIiNteURyYWZ0c1wiKS5kcmFnZ2FibGUoKTtcclxuXHJcbiAgaWYgKGxvY2FsU3RvcmFnZS5kcmFmdHMgIT0gdW5kZWZpbmVkICYmIGxvY2FsU3RvcmFnZS5kcmFmdHMgIT0gXCJbXVwiKSB7XHJcbiAgICB3aW5kb3cuZHJhZnRzID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZHJhZnRzKTtcclxuICAgIHdpbmRvdy5kcmFmdENhbGxzID0gMDtcclxuICAgIHdpbmRvdy50ZW1wRHJhZnRBcnIgPSBbXTtcclxuICAgIHdpbmRvdy5kcmFmdHMuZm9yRWFjaChmdW5jdGlvbiAoZHJhZnQsIGluZGV4KSB7XHJcbiAgICAgIGNvbnN0IHRoZVdUSUQgPSBkcmFmdFswXTtcclxuICAgICAgaWYgKCFpc09LKHRoZVdUSUQpKSB7XHJcbiAgICAgICAgZGVsZXRlIHdpbmRvdy5kcmFmdHNbaW5kZXhdO1xyXG4gICAgICAgIHdpbmRvdy5kcmFmdENhbGxzKys7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgJC5hamF4KHtcclxuICAgICAgICAgIHVybDpcclxuICAgICAgICAgICAgXCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vaW5kZXgucGhwP3RpdGxlPVwiICtcclxuICAgICAgICAgICAgdGhlV1RJRCArXHJcbiAgICAgICAgICAgIFwiJmRpc3BsYXlEcmFmdD0xXCIsXHJcbiAgICAgICAgICB0eXBlOiBcIkdFVFwiLFxyXG4gICAgICAgICAgZGF0YVR5cGU6IFwiaHRtbFwiLCAvLyBhZGRlZCBkYXRhIHR5cGVcclxuICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uIChyZXMpIHtcclxuICAgICAgICAgICAgd2luZG93LmRyYWZ0Q2FsbHMrKztcclxuICAgICAgICAgICAgbGV0IGR1bW15ID0gJChyZXMpOyBcclxuICAgICAgICAgICAgYVdUSUQgPSBkdW1teVxyXG4gICAgICAgICAgICAgIC5maW5kKFwiaDEgYnV0dG9uW2FyaWEtbGFiZWw9J0NvcHkgSUQnXVwiKVxyXG4gICAgICAgICAgICAgIC5kYXRhKFwiY29weS10ZXh0XCIpO1xyXG4gICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgZHVtbXkuZmluZChcImRpdi5zdGF0dXM6Y29udGFpbnMoJ1lvdSBoYXZlIGFuIHVuY29tbWl0dGVkJylcIilcclxuICAgICAgICAgICAgICAgIC5sZW5ndGhcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgd2luZG93LnRlbXBEcmFmdEFyci5wdXNoKGFXVElEKTtcclxuICAgICAgICAgICAgICB1c2VMaW5rID0gZHVtbXkuZmluZChcImE6Y29udGFpbnMoVXNlIHRoZSBEcmFmdClcIikuYXR0cihcImhyZWZcIik7XHJcbiAgICAgICAgICAgICAgaWYgKHVzZUxpbmsgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBwZXJzb25JRCA9IHVzZUxpbmsubWF0Y2goLyZ1PVswLTldKy8pWzBdLnJlcGxhY2UoXCImdT1cIiwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICBkcmFmdElEID0gdXNlTGluay5tYXRjaCgvJnVkPVswLTldKy8pWzBdLnJlcGxhY2UoXCImdWQ9XCIsIFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgd2luZG93LmRyYWZ0cy5mb3JFYWNoKGZ1bmN0aW9uICh5RHJhZnQpIHtcclxuICAgICAgICAgICAgICAgICAgaWYgKHlEcmFmdFswXSA9PSBhV1RJRCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHlEcmFmdFszXSA9IHBlcnNvbklEO1xyXG4gICAgICAgICAgICAgICAgICAgIHlEcmFmdFs0XSA9IGRyYWZ0SUQ7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAod2luZG93LmRyYWZ0Q2FsbHMgPT0gd2luZG93LmRyYWZ0cy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICB3aW5kb3cubmV3RHJhZnRBcnIgPSBbXTtcclxuICAgICAgICAgICAgICB3aW5kb3cuZHJhZnRzLmZvckVhY2goZnVuY3Rpb24gKGFEcmFmdCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICB3aW5kb3cudGVtcERyYWZ0QXJyLmluY2x1ZGVzKGFEcmFmdFswXSkgJiZcclxuICAgICAgICAgICAgICAgICAgaXNPSyhhRHJhZnRbMF0pXHJcbiAgICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgICAgd2luZG93Lm5ld0RyYWZ0QXJyLnB1c2goYURyYWZ0KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgbmV3RHJhZnRBcnIuZm9yRWFjaChmdW5jdGlvbiAoeERyYWZ0KSB7XHJcbiAgICAgICAgICAgICAgICBkQnV0dG9ucyA9IFwiPHRkPjwvdGQ+PHRkPjwvdGQ+XCI7XHJcbiAgICAgICAgICAgICAgICBpZiAoeERyYWZ0WzNdICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICBkQnV0dG9ucyA9XHJcbiAgICAgICAgICAgICAgICAgICAgXCI8dGQ+PGEgaHJlZj0naHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2luZGV4LnBocD90aXRsZT1TcGVjaWFsOkVkaXRQZXJzb24mdT1cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgeERyYWZ0WzNdICtcclxuICAgICAgICAgICAgICAgICAgICBcIiZ1ZD1cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgeERyYWZ0WzRdICtcclxuICAgICAgICAgICAgICAgICAgICBcIicgY2xhc3M9J3NtYWxsIGJ1dHRvbic+VVNFPC9hPjwvdGQ+PHRkPjxhIGhyZWY9J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbmRleC5waHA/dGl0bGU9U3BlY2lhbDpFZGl0UGVyc29uJnU9XCIgK1xyXG4gICAgICAgICAgICAgICAgICAgIHhEcmFmdFszXSArXHJcbiAgICAgICAgICAgICAgICAgICAgXCImZGQ9XCIgK1xyXG4gICAgICAgICAgICAgICAgICAgIHhEcmFmdFs0XSArXHJcbiAgICAgICAgICAgICAgICAgICAgXCInIGNsYXNzPSdzbWFsbCBidXR0b24nPkRJU0NBUkQ8L2E+PC90ZD5cIjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAkKFwiI215RHJhZnRzIHRhYmxlXCIpLmFwcGVuZChcclxuICAgICAgICAgICAgICAgICAgJChcclxuICAgICAgICAgICAgICAgICAgICBcIjx0cj48dGQ+PGEgaHJlZj0naHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2luZGV4LnBocD90aXRsZT1cIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICB4RHJhZnRbMF0gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCImZGlzcGxheURyYWZ0PTEnPlwiICtcclxuICAgICAgICAgICAgICAgICAgICAgIHhEcmFmdFsyXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIjwvYT48L3RkPlwiICtcclxuICAgICAgICAgICAgICAgICAgICAgIGRCdXR0b25zICtcclxuICAgICAgICAgICAgICAgICAgICAgIFwiPC90cj5cIlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICQoXCIjbXlEcmFmdHNcIikuc2xpZGVEb3duKCk7XHJcbiAgICAgICAgICAgICAgaWYgKG5ld0RyYWZ0QXJyLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAkKFwiI215RHJhZnRzXCIpLmFwcGVuZCgkKFwiPHA+Tm8gZHJhZnRzITwvcD5cIikpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImRyYWZ0c1wiLCBKU09OLnN0cmluZ2lmeShuZXdEcmFmdEFycikpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZXJyb3I6IGZ1bmN0aW9uIChyZXMpIHt9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgJChcIiNteURyYWZ0c1wiKS5hcHBlbmQoJChcIjxwPk5vIGRyYWZ0cyE8L3A+XCIpKTtcclxuICAgICQoXCIjbXlEcmFmdHNcIikuc2xpZGVEb3duKCk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBzYXZlRHJhZnRMaXN0KCkge1xyXG4gIHdpbmRvdy5mdWxsU2F2ZSA9IGZhbHNlO1xyXG4gICQoXCIjd3BTYXZlXCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgIHdpbmRvdy5mdWxsU2F2ZSA9IHRydWU7XHJcbiAgfSk7XHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJiZWZvcmV1bmxvYWRcIiwgKGV2ZW50KSA9PiB7XHJcbiAgICB1cGRhdGVEcmFmdExpc3QoKTtcclxuICB9KTtcclxuICAkKFwiI3dwU2F2ZURyYWZ0XCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgIHVwZGF0ZURyYWZ0TGlzdCgpO1xyXG4gIH0pO1xyXG4gIHNldEludGVydmFsKHVwZGF0ZURyYWZ0TGlzdCwgNjAwMDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBhZGREcmFmdHNUb0ZpbmRNZW51KCkge1xyXG4gIGxldCBjb25uZWN0aW9uTGkgPSAkKFwibGkgYS5wdXJlQ3NzTWVudWlbaHJlZj0nL3dpa2kvU3BlY2lhbDpDb25uZWN0aW9uJ11cIik7XHJcbiAgbGV0IG5ld0xpID0gJChcclxuICAgIFwiPGxpPjxhIGNsYXNzPSdwdXJlQ3NzTWVudWkgZHJhZnRzJyBpZD0nZHJhZnRzTGluaycgdGl0bGU9J1NlZSB5b3VyIHVuY29tbWl0dGVkIGRyYWZ0cyc+RHJhZnRzPC9saT5cIlxyXG4gICk7XHJcbiAgbmV3TGkuaW5zZXJ0QWZ0ZXIoY29ubmVjdGlvbkxpLnBhcmVudCgpKTtcclxuICAkKFwibGkgYS5kcmFmdHNcIikuY2xpY2soZnVuY3Rpb24gKGUpIHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNob3dEcmFmdExpc3QoKTtcclxuICB9KTtcclxufVxyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQge2NyZWF0ZVByb2ZpbGVTdWJtZW51TGluaywgZmFtaWx5QXJyYXksIGdldFJlbGF0aXZlcywgaXNPS30gZnJvbSAnLi4vLi4vY29yZS9jb21tb24nO1xyXG5pbXBvcnQgJy4vZmFtaWx5R3JvdXAuY3NzJztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwiZmFtaWx5R3JvdXBcIiwgKHJlc3VsdCkgPT4ge1xyXG4gIGlmIChcclxuICAgIHJlc3VsdC5mYW1pbHlHcm91cCAmJlxyXG4gICAgJChcImJvZHkucHJvZmlsZVwiKS5sZW5ndGggJiZcclxuICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKFwiU3BhY2U6XCIpID09IG51bGxcclxuICApIHtcclxuICAgIC8vIEFkZCBhIGxpbmsgdG8gdGhlIHNob3J0IGxpc3Qgb2YgbGlua3MgYmVsb3cgdGhlIHRhYnNcclxuICAgIGNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgICAgIHRpdGxlOiBcIkRpc3BsYXkgZmFtaWx5IGdyb3VwIGRhdGVzIGFuZCBsb2NhdGlvbnNcIixcclxuICAgICAgaWQ6IFwiZmFtaWx5R3JvdXBCdXR0b25cIixcclxuICAgICAgdGV4dDogXCJGYW1pbHkgR3JvdXBcIixcclxuICAgICAgdXJsOiBcIiNuXCIsXHJcbiAgICB9O1xyXG4gICAgY3JlYXRlUHJvZmlsZVN1Ym1lbnVMaW5rKG9wdGlvbnMpO1xyXG4gICAgJChcIiNcIiArIG9wdGlvbnMuaWQpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgY29uc3QgcHJvZmlsZUlEID0gJChcImEucHVyZUNzc01lbnVpMCBzcGFuLnBlcnNvblwiKS50ZXh0KCk7XHJcbiAgICAgIHNob3dGYW1pbHlTaGVldCgkKHRoaXMpWzBdLCBwcm9maWxlSUQpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2hvd0ZhbWlseVNoZWV0KHRoZUNsaWNrZWQsIHByb2ZpbGVJRCkge1xyXG4gICAgICAvLyBJZiB0aGUgdGFibGUgYWxyZWFkeSBleGlzdHMgdG9nZ2xlIGl0LlxyXG4gICAgICBpZiAoJChcIiNcIiArIHByb2ZpbGVJRC5yZXBsYWNlKFwiIFwiLCBcIl9cIikgKyBcIl9mYW1pbHlcIikubGVuZ3RoKSB7XHJcbiAgICAgICAgJChcIiNcIiArIHByb2ZpbGVJRC5yZXBsYWNlKFwiIFwiLCBcIl9cIikgKyBcIl9mYW1pbHlcIikuZmFkZVRvZ2dsZSgpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE1ha2UgdGhlIHRhYmxlIGFuZCBkbyBvdGhlciB0aGluZ3NcclxuICAgICAgICBnZXRSZWxhdGl2ZXMocHJvZmlsZUlEKS50aGVuKChwZXJzb24pID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVQZW9wbGUgPSBmYW1pbHlBcnJheShwZXJzb24pO1xyXG4gICAgICAgICAgLy8gTWFrZSB0aGUgdGFibGVcclxuICAgICAgICAgIGNvbnN0IGZhbWlseVRhYmxlID0gcGVvcGxlVG9UYWJsZSh1UGVvcGxlKTtcclxuICAgICAgICAgIC8vIEF0dGFjaCB0aGUgdGFibGUgdG8gdGhlIGJvZHksIHBvc2l0aW9uIGl0IGFuZCBtYWtlIGl0IGRyYWdnYWJsZSBhbmQgdG9nZ2xlYWJsZVxyXG4gICAgICAgICAgZmFtaWx5VGFibGUucHJlcGVuZFRvKFwiYm9keVwiKTtcclxuICAgICAgICAgIGZhbWlseVRhYmxlLmF0dHIoXCJpZFwiLCBwcm9maWxlSUQucmVwbGFjZShcIiBcIiwgXCJfXCIpICsgXCJfZmFtaWx5XCIpO1xyXG4gICAgICAgICAgZmFtaWx5VGFibGUuZHJhZ2dhYmxlKCk7XHJcbiAgICAgICAgICBmYW1pbHlUYWJsZS5vbihcImRibGNsaWNrXCIsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgJCh0aGlzKS5mYWRlT3V0KCk7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGxldCB0aGVMZWZ0ID0gZ2V0T2Zmc2V0KCQoXCJkaXYudGVuLmNvbHVtbnNcIilbMF0pLmxlZnQ7XHJcbiAgICAgICAgICBmYW1pbHlUYWJsZS5jc3Moe1xyXG4gICAgICAgICAgICB0b3A6IGdldE9mZnNldCh0aGVDbGlja2VkKS50b3AgKyA1MCxcclxuICAgICAgICAgICAgbGVmdDogdGhlTGVmdCxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgLy8gQWRqdXN0IHRoZSBwb3NpdGlvbiBvZiB0aGUgdGFibGUgb24gd2luZG93IHJlc2l6ZVxyXG4gICAgICAgICAgJCh3aW5kb3cpLnJlc2l6ZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmIChmYW1pbHlUYWJsZS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICB0aGVMZWZ0ID0gZ2V0T2Zmc2V0KCQoXCJkaXYudGVuLmNvbHVtbnNcIilbMF0pLmxlZnQ7XHJcbiAgICAgICAgICAgICAgZmFtaWx5VGFibGUuY3NzKHtcclxuICAgICAgICAgICAgICAgIHRvcDogZ2V0T2Zmc2V0KHRoZUNsaWNrZWQpLnRvcCArIDUwLFxyXG4gICAgICAgICAgICAgICAgbGVmdDogdGhlTGVmdCxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgJChcIi5mYW1pbHlTaGVldCB4XCIpLnVuYmluZCgpO1xyXG4gICAgICAgICAgJChcIi5mYW1pbHlTaGVldCB4XCIpLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgJCh0aGlzKS5wYXJlbnQoKS5mYWRlT3V0KCk7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgICQoXCIuZmFtaWx5U2hlZXQgd1wiKS51bmJpbmQoKTtcclxuICAgICAgICAgICQoXCIuZmFtaWx5U2hlZXQgd1wiKS5jbGljayhmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICQodGhpcykucGFyZW50KCkudG9nZ2xlQ2xhc3MoXCJ3cmFwXCIpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBQdXQgYSBncm91cCBvZiBwZW9wbGUgaW4gYSB0YWJsZVxyXG4gICAgZnVuY3Rpb24gcGVvcGxlVG9UYWJsZShrUGVvcGxlKSB7XHJcbiAgICAgIGNvbnN0IGtUYWJsZSA9ICQoXHJcbiAgICAgICAgXCI8ZGl2IGNsYXNzPSdmYW1pbHlTaGVldCc+PHc+4oaUPC93Pjx4Png8L3g+PHRhYmxlPjxjYXB0aW9uPjwvY2FwdGlvbj48dGhlYWQ+PHRyPjx0aD5SZWxhdGlvbjwvdGg+PHRoPk5hbWU8L3RoPjx0aD5CaXJ0aCBEYXRlPC90aD48dGg+QmlydGggUGxhY2U8L3RoPjx0aD5EZWF0aCBEYXRlPC90aD48dGg+RGVhdGggUGxhY2U8L3RoPjwvdHI+PC90aGVhZD48dGJvZHk+PC90Ym9keT48L3RhYmxlPjwvZGl2PlwiXHJcbiAgICAgICk7XHJcbiAgICAgIGtQZW9wbGUuZm9yRWFjaChmdW5jdGlvbiAoa1BlcnMpIHtcclxuICAgICAgICBsZXQgckNsYXNzID0gXCJcIjtcclxuICAgICAgICBsZXQgaXNEZWNhZGVzID0gZmFsc2U7XHJcbiAgICAgICAga1BlcnMuUmVsYXRpb25TaG93ID0ga1BlcnMuUmVsYXRpb247XHJcbiAgICAgICAgaWYgKGtQZXJzLlJlbGF0aW9uID09IHVuZGVmaW5lZCB8fCBrUGVycy5BY3RpdmUpIHtcclxuICAgICAgICAgIGtQZXJzLlJlbGF0aW9uID0gXCJTaWJsaW5nXCI7XHJcbiAgICAgICAgICBrUGVycy5SZWxhdGlvblNob3cgPSBcIlwiO1xyXG4gICAgICAgICAgckNsYXNzID0gXCJzZWxmXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYkRhdGU7XHJcbiAgICAgICAgaWYgKGtQZXJzLkJpcnRoRGF0ZSkge1xyXG4gICAgICAgICAgYkRhdGUgPSBrUGVycy5CaXJ0aERhdGU7XHJcbiAgICAgICAgfSBlbHNlIGlmIChrUGVycy5CaXJ0aERhdGVEZWNhZGUpIHtcclxuICAgICAgICAgIGJEYXRlID0ga1BlcnMuQmlydGhEYXRlRGVjYWRlLnNsaWNlKDAsIC0xKSArIFwiLTAwLTAwXCI7XHJcbiAgICAgICAgICBpc0RlY2FkZXMgPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBiRGF0ZSA9IFwiMDAwMC0wMC0wMFwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGREYXRlO1xyXG4gICAgICAgIGlmIChrUGVycy5EZWF0aERhdGUpIHtcclxuICAgICAgICAgIGREYXRlID0ga1BlcnMuRGVhdGhEYXRlO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoa1BlcnMuRGVhdGhEYXRlRGVjYWRlKSB7XHJcbiAgICAgICAgICBpZiAoa1BlcnMuRGVhdGhEYXRlRGVjYWRlID09IFwidW5rbm93blwiKSB7XHJcbiAgICAgICAgICAgIGREYXRlID0gXCIwMDAwLTAwLTAwXCI7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBkRGF0ZSA9IGtQZXJzLkRlYXRoRGF0ZURlY2FkZS5zbGljZSgwLCAtMSkgKyBcIi0wMC0wMFwiO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBkRGF0ZSA9IFwiMDAwMC0wMC0wMFwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGtQZXJzLkJpcnRoTG9jYXRpb24gPT0gbnVsbCB8fCBrUGVycy5CaXJ0aExvY2F0aW9uID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAga1BlcnMuQmlydGhMb2NhdGlvbiA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoa1BlcnMuRGVhdGhMb2NhdGlvbiA9PSBudWxsIHx8IGtQZXJzLkRlYXRoTG9jYXRpb24gPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICBrUGVycy5EZWF0aExvY2F0aW9uID0gXCJcIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChrUGVycy5NaWRkbGVOYW1lID09IG51bGwpIHtcclxuICAgICAgICAgIGtQZXJzLk1pZGRsZU5hbWUgPSBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBvTmFtZSA9IGRpc3BsYXlOYW1lKGtQZXJzKVswXTtcclxuXHJcbiAgICAgICAgaWYgKGtQZXJzLlJlbGF0aW9uKSB7XHJcbiAgICAgICAgICAvLyBUaGUgcmVsYXRpb24gaXMgc3RvcmVkIGFzIFwiUGFyZW50c1wiLCBcIlNwb3VzZXNcIiwgZXRjLiwgc28uLi5cclxuICAgICAgICAgIGtQZXJzLlJlbGF0aW9uID0ga1BlcnMuUmVsYXRpb24ucmVwbGFjZSgvcyQvLCBcIlwiKS5yZXBsYWNlKC9yZW4kLywgXCJcIik7XHJcbiAgICAgICAgICBpZiAockNsYXNzICE9IFwic2VsZlwiKSB7XHJcbiAgICAgICAgICAgIGtQZXJzLlJlbGF0aW9uU2hvdyA9IGtQZXJzLlJlbGF0aW9uO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAob05hbWUpIHtcclxuICAgICAgICAgIGxldCBvQkRhdGUgPSB5bWRGaXgoYkRhdGUpO1xyXG4gICAgICAgICAgbGV0IG9ERGF0ZSA9IHltZEZpeChkRGF0ZSk7XHJcbiAgICAgICAgICBpZiAoaXNEZWNhZGVzID09IHRydWUpIHtcclxuICAgICAgICAgICAgb0JEYXRlID0ga1BlcnMuQmlydGhEYXRlRGVjYWRlO1xyXG4gICAgICAgICAgICBpZiAob0REYXRlICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICBvRERhdGUgPSBrUGVycy5EZWF0aERhdGVEZWNhZGU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNvbnN0IGFMaW5lID0gJChcclxuICAgICAgICAgICAgXCI8dHIgZGF0YS1uYW1lPSdcIiArXHJcbiAgICAgICAgICAgICAga1BlcnMuTmFtZSArXHJcbiAgICAgICAgICAgICAgXCInIGRhdGEtYmlydGhkYXRlPSdcIiArXHJcbiAgICAgICAgICAgICAgYkRhdGUucmVwbGFjZUFsbCgvXFwtL2csIFwiXCIpICtcclxuICAgICAgICAgICAgICBcIicgZGF0YS1yZWxhdGlvbj0nXCIgK1xyXG4gICAgICAgICAgICAgIGtQZXJzLlJlbGF0aW9uICtcclxuICAgICAgICAgICAgICBcIicgY2xhc3M9J1wiICtcclxuICAgICAgICAgICAgICByQ2xhc3MgK1xyXG4gICAgICAgICAgICAgIFwiIFwiICtcclxuICAgICAgICAgICAgICBrUGVycy5HZW5kZXIgK1xyXG4gICAgICAgICAgICAgIFwiJz48dGQ+XCIgK1xyXG4gICAgICAgICAgICAgIGtQZXJzLlJlbGF0aW9uU2hvdyArXHJcbiAgICAgICAgICAgICAgXCI8L3RkPjx0ZD48YSBocmVmPSdodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9cIiArXHJcbiAgICAgICAgICAgICAgaHRtbEVudGl0aWVzKGtQZXJzLk5hbWUpICtcclxuICAgICAgICAgICAgICBcIic+XCIgK1xyXG4gICAgICAgICAgICAgIG9OYW1lICtcclxuICAgICAgICAgICAgICBcIjwvdGQ+PHRkIGNsYXNzPSdhRGF0ZSc+XCIgK1xyXG4gICAgICAgICAgICAgIG9CRGF0ZSArXHJcbiAgICAgICAgICAgICAgXCI8L3RkPjx0ZD5cIiArXHJcbiAgICAgICAgICAgICAga1BlcnMuQmlydGhMb2NhdGlvbiArXHJcbiAgICAgICAgICAgICAgXCI8L3RkPjx0ZCBjbGFzcz0nYURhdGUnPlwiICtcclxuICAgICAgICAgICAgICBvRERhdGUgK1xyXG4gICAgICAgICAgICAgIFwiPC90ZD48dGQ+XCIgK1xyXG4gICAgICAgICAgICAgIGtQZXJzLkRlYXRoTG9jYXRpb24gK1xyXG4gICAgICAgICAgICAgIFwiPC90ZD48L3RyPlwiXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGtUYWJsZS5maW5kKFwidGJvZHlcIikuYXBwZW5kKGFMaW5lKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChrUGVycy5SZWxhdGlvbiA9PSBcIlNwb3VzZVwiKSB7XHJcbiAgICAgICAgICBsZXQgbWFycmlhZ2VEZWV0cyA9IFwibS5cIjtcclxuICAgICAgICAgIGNvbnN0IGRNZGF0ZSA9IHltZEZpeChrUGVycy5tYXJyaWFnZV9kYXRlKTtcclxuICAgICAgICAgIGlmIChkTWRhdGUgIT0gXCJcIikge1xyXG4gICAgICAgICAgICBtYXJyaWFnZURlZXRzICs9IFwiIFwiICsgZE1kYXRlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaWYgKGlzT0soa1BlcnMubWFycmlhZ2VfbG9jYXRpb24pKSB7XHJcbiAgICAgICAgICAgIG1hcnJpYWdlRGVldHMgKz0gXCIgXCIgKyBrUGVycy5tYXJyaWFnZV9sb2NhdGlvbjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmIChtYXJyaWFnZURlZXRzICE9IFwibS5cIikge1xyXG4gICAgICAgICAgICBsZXQga0dlbmRlcjtcclxuICAgICAgICAgICAgaWYgKGtQZXJzLkRhdGFTdGF0dXMuR2VuZGVyID09IFwiYmxhbmtcIikge1xyXG4gICAgICAgICAgICAgIGtHZW5kZXIgPSBcIlwiO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIGtHZW5kZXIgPSBrUGVycy5HZW5kZXI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY29uc3Qgc3BvdXNlTGluZSA9ICQoXHJcbiAgICAgICAgICAgICAgXCI8dHIgY2xhc3M9J21hcnJpYWdlUm93IFwiICtcclxuICAgICAgICAgICAgICAgIGtHZW5kZXIgK1xyXG4gICAgICAgICAgICAgICAgXCInIGRhdGEtc3BvdXNlPSdcIiArXHJcbiAgICAgICAgICAgICAgICBrUGVycy5OYW1lICtcclxuICAgICAgICAgICAgICAgIFwiJz48dGQ+Jm5ic3A7PC90ZD48dGQgY29sc3Bhbj0nMyc+XCIgK1xyXG4gICAgICAgICAgICAgICAgbWFycmlhZ2VEZWV0cyArXHJcbiAgICAgICAgICAgICAgICBcIjwvdGQ+PHRkPjwvdGQ+PHRkPjwvdGQ+PC90cj5cIlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBrVGFibGUuZmluZChcInRib2R5XCIpLmFwcGVuZChzcG91c2VMaW5lKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zdCByb3dzID0ga1RhYmxlLmZpbmQoXCJ0Ym9keSB0clwiKTtcclxuICAgICAgcm93cy5zb3J0KChhLCBiKSA9PlxyXG4gICAgICAgICQoYikuZGF0YShcImJpcnRoZGF0ZVwiKSA8ICQoYSkuZGF0YShcImJpcnRoZGF0ZVwiKSA/IDEgOiAtMVxyXG4gICAgICApO1xyXG4gICAgICBrVGFibGUuZmluZChcInRib2R5XCIpLmFwcGVuZChyb3dzKTtcclxuXHJcbiAgICAgIGNvbnN0IGZhbWlseU9yZGVyID0gW1wiUGFyZW50XCIsIFwiU2libGluZ1wiLCBcIlNwb3VzZVwiLCBcIkNoaWxkXCJdO1xyXG4gICAgICBmYW1pbHlPcmRlci5mb3JFYWNoKGZ1bmN0aW9uIChyZWxXb3JkKSB7XHJcbiAgICAgICAga1RhYmxlLmZpbmQoXCJ0cltkYXRhLXJlbGF0aW9uPSdcIiArIHJlbFdvcmQgKyBcIiddXCIpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgJCh0aGlzKS5hcHBlbmRUbyhrVGFibGUuZmluZChcInRib2R5XCIpKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBrVGFibGUuZmluZChcIi5tYXJyaWFnZVJvd1wiKS5lYWNoKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAkKHRoaXMpLmluc2VydEFmdGVyKFxyXG4gICAgICAgICAga1RhYmxlLmZpbmQoXCJ0cltkYXRhLW5hbWU9J1wiICsgJCh0aGlzKS5kYXRhKFwic3BvdXNlXCIpICsgXCInXVwiKVxyXG4gICAgICAgICk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgcmV0dXJuIGtUYWJsZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBGaW5kIGdvb2QgbmFtZXMgdG8gZGlzcGxheSAoYXMgdGhlIEFQSSBkb2Vzbid0IHJldHVybiB0aGUgc2FtZSBmaWVsZHMgYWxsIHByb2ZpbGVzKVxyXG4gICAgZnVuY3Rpb24gZGlzcGxheU5hbWUoZlBlcnNvbikge1xyXG4gICAgICBpZiAoZlBlcnNvbiAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICBsZXQgZk5hbWUxID0gXCJcIjtcclxuICAgICAgICBpZiAodHlwZW9mIGZQZXJzb25bXCJMb25nTmFtZVwiXSAhPSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICBpZiAoZlBlcnNvbltcIkxvbmdOYW1lXCJdICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgZk5hbWUxID0gZlBlcnNvbltcIkxvbmdOYW1lXCJdLnJlcGxhY2UoL1xcc1xccy8sIFwiIFwiKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGZOYW1lMiA9IFwiXCI7XHJcbiAgICAgICAgbGV0IGZOYW1lNCA9IFwiXCI7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBmUGVyc29uW1wiTWlkZGxlTmFtZVwiXSAhPSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGZQZXJzb25bXCJNaWRkbGVOYW1lXCJdID09IFwiXCIgJiZcclxuICAgICAgICAgICAgdHlwZW9mIGZQZXJzb25bXCJMb25nTmFtZVByaXZhdGVcIl0gIT0gXCJ1bmRlZmluZWRcIlxyXG4gICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIGlmIChmUGVyc29uW1wiTG9uZ05hbWVQcml2YXRlXCJdICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICBmTmFtZTIgPSBmUGVyc29uW1wiTG9uZ05hbWVQcml2YXRlXCJdLnJlcGxhY2UoL1xcc1xccy8sIFwiIFwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBpZiAodHlwZW9mIGZQZXJzb25bXCJMb25nTmFtZVByaXZhdGVcIl0gIT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICBpZiAoZlBlcnNvbltcIkxvbmdOYW1lUHJpdmF0ZVwiXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgZk5hbWU0ID0gZlBlcnNvbltcIkxvbmdOYW1lUHJpdmF0ZVwiXS5yZXBsYWNlKC9cXHNcXHMvLCBcIiBcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBmTmFtZTMgPSBcIlwiO1xyXG4gICAgICAgIGNvbnN0IGNoZWNrcyA9IFtcclxuICAgICAgICAgIFwiUHJlZml4XCIsXHJcbiAgICAgICAgICBcIkZpcnN0TmFtZVwiLFxyXG4gICAgICAgICAgXCJSZWFsTmFtZVwiLFxyXG4gICAgICAgICAgXCJNaWRkbGVOYW1lXCIsXHJcbiAgICAgICAgICBcIkxhc3ROYW1lQXRCaXJ0aFwiLFxyXG4gICAgICAgICAgXCJMYXN0TmFtZUN1cnJlbnRcIixcclxuICAgICAgICAgIFwiU3VmZml4XCIsXHJcbiAgICAgICAgXTtcclxuICAgICAgICBjaGVja3MuZm9yRWFjaChmdW5jdGlvbiAoZENoZWNrKSB7XHJcbiAgICAgICAgICBpZiAodHlwZW9mIGZQZXJzb25bXCJcIiArIGRDaGVjayArIFwiXCJdICE9IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgIGZQZXJzb25bXCJcIiArIGRDaGVjayArIFwiXCJdICE9IFwiXCIgJiZcclxuICAgICAgICAgICAgICBmUGVyc29uW1wiXCIgKyBkQ2hlY2sgKyBcIlwiXSAhPSBudWxsXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgIGlmIChkQ2hlY2sgPT0gXCJMYXN0TmFtZUF0QmlydGhcIikge1xyXG4gICAgICAgICAgICAgICAgaWYgKGZQZXJzb25bXCJMYXN0TmFtZUF0QmlydGhcIl0gIT0gZlBlcnNvbi5MYXN0TmFtZUN1cnJlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgZk5hbWUzICs9IFwiKFwiICsgZlBlcnNvbltcIkxhc3ROYW1lQXRCaXJ0aFwiXSArIFwiKSBcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGRDaGVjayA9PSBcIlJlYWxOYW1lXCIpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZlBlcnNvbltcIkZpcnN0TmFtZVwiXSAhPSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICBmTmFtZTMgKz0gZlBlcnNvbltcIlJlYWxOYW1lXCJdICsgXCIgXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGZOYW1lMyArPSBmUGVyc29uW1wiXCIgKyBkQ2hlY2sgKyBcIlwiXSArIFwiIFwiO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBhcnIgPSBbZk5hbWUxLCBmTmFtZTIsIGZOYW1lMywgZk5hbWU0XTtcclxuICAgICAgICB2YXIgbG9uZ2VzdCA9IGFyci5yZWR1Y2UoZnVuY3Rpb24gKGEsIGIpIHtcclxuICAgICAgICAgIHJldHVybiBhLmxlbmd0aCA+IGIubGVuZ3RoID8gYSA6IGI7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGZOYW1lID0gbG9uZ2VzdDtcclxuXHJcbiAgICAgICAgbGV0IHNOYW1lO1xyXG4gICAgICAgIGlmIChmUGVyc29uW1wiU2hvcnROYW1lXCJdKSB7XHJcbiAgICAgICAgICBzTmFtZSA9IGZQZXJzb25bXCJTaG9ydE5hbWVcIl07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNOYW1lID0gZk5hbWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGZOYW1lID0gZnVsbCBuYW1lOyBzTmFtZSA9IHNob3J0IG5hbWVcclxuICAgICAgICByZXR1cm4gW2ZOYW1lLnRyaW0oKSwgc05hbWUudHJpbSgpXTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIENvbnZlcnQgZGF0ZXMgdG8gSVNPIGZvcm1hdCAoWVlZWS1NTS1ERClcclxuICAgIGZ1bmN0aW9uIHltZEZpeChkYXRlKSB7XHJcbiAgICAgIGxldCBvdXREYXRlO1xyXG4gICAgICBpZiAoZGF0ZSA9PSB1bmRlZmluZWQgfHwgZGF0ZSA9PSBcIlwiKSB7XHJcbiAgICAgICAgb3V0RGF0ZSA9IFwiXCI7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgZGF0ZUJpdHMxID0gZGF0ZS5zcGxpdChcIiBcIik7XHJcbiAgICAgICAgaWYgKGRhdGVCaXRzMVsyXSkge1xyXG4gICAgICAgICAgY29uc3Qgc01vbnRocyA9IFtcclxuICAgICAgICAgICAgXCJKYW5cIixcclxuICAgICAgICAgICAgXCJGZWJcIixcclxuICAgICAgICAgICAgXCJNYXJcIixcclxuICAgICAgICAgICAgXCJBcHJcIixcclxuICAgICAgICAgICAgXCJNYXlcIixcclxuICAgICAgICAgICAgXCJKdW5cIixcclxuICAgICAgICAgICAgXCJKdWxcIixcclxuICAgICAgICAgICAgXCJBdWdcIixcclxuICAgICAgICAgICAgXCJTZXBcIixcclxuICAgICAgICAgICAgXCJPY3RcIixcclxuICAgICAgICAgICAgXCJOb3ZcIixcclxuICAgICAgICAgICAgXCJEZWNcIixcclxuICAgICAgICAgIF07XHJcbiAgICAgICAgICBjb25zdCBsTW9udGhzID0gW1xyXG4gICAgICAgICAgICBcIkphbnVhcnlcIixcclxuICAgICAgICAgICAgXCJGZWJydWFyeVwiLFxyXG4gICAgICAgICAgICBcIk1hcmNoXCIsXHJcbiAgICAgICAgICAgIFwiQXByaWxcIixcclxuICAgICAgICAgICAgXCJNYXlcIixcclxuICAgICAgICAgICAgXCJKdW5lXCIsXHJcbiAgICAgICAgICAgIFwiSnVseVwiLFxyXG4gICAgICAgICAgICBcIkF1Z3VzdFwiLFxyXG4gICAgICAgICAgICBcIlNlcHRlbWJlclwiLFxyXG4gICAgICAgICAgICBcIk9jdG9iZXJcIixcclxuICAgICAgICAgICAgXCJOb3ZlbWJlclwiLFxyXG4gICAgICAgICAgICBcIkRlY2VtYmVyXCIsXHJcbiAgICAgICAgICBdO1xyXG4gICAgICAgICAgY29uc3QgZE1vbnRoID0gZGF0ZS5tYXRjaCgvW0Etel0rL2kpO1xyXG4gICAgICAgICAgbGV0IGRNb250aE51bTtcclxuICAgICAgICAgIGlmIChkTW9udGggIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBzTW9udGhzLmZvckVhY2goZnVuY3Rpb24gKGFTTSwgaSkge1xyXG4gICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIGRNb250aFswXS50b0xvd2VyQ2FzZSgpID09IGFTTS50b0xvd2VyQ2FzZSgpIHx8XHJcbiAgICAgICAgICAgICAgICBkTW9udGhbMF0udG9Mb3dlckNhc2UoKSA9PSBhU00gKyBcIi5cIi50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICBkTW9udGhOdW0gPSAoaSArIDEpLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zdCBkRGF0ZSA9IGRhdGUubWF0Y2goL1xcYlswLTldezEsMn1cXGIvKTtcclxuICAgICAgICAgIGNvbnN0IGREYXRlTnVtID0gZERhdGVbMF07XHJcbiAgICAgICAgICBjb25zdCBkWWVhciA9IGRhdGUubWF0Y2goL1xcYlswLTldezR9XFxiLyk7XHJcbiAgICAgICAgICBjb25zdCBkWWVhck51bSA9IGRZZWFyWzBdO1xyXG4gICAgICAgICAgcmV0dXJuIGRZZWFyTnVtICsgXCItXCIgKyBkTW9udGhOdW0gKyBcIi1cIiArIGREYXRlTnVtO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjb25zdCBkYXRlQml0cyA9IGRhdGUuc3BsaXQoXCItXCIpO1xyXG4gICAgICAgICAgb3V0RGF0ZSA9IGRhdGU7XHJcbiAgICAgICAgICBpZiAoZGF0ZUJpdHNbMV0gPT0gXCIwMFwiICYmIGRhdGVCaXRzWzJdID09IFwiMDBcIikge1xyXG4gICAgICAgICAgICBpZiAoZGF0ZUJpdHNbMF0gPT0gXCIwMDAwXCIpIHtcclxuICAgICAgICAgICAgICBvdXREYXRlID0gXCJcIjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICBvdXREYXRlID0gZGF0ZUJpdHNbMF07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIG91dERhdGU7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUmVwbGFjZSBjZXJ0YWluIGNoYXJhY3RlcnMgd2l0aCBIVE1MIGVudGl0aWVzXHJcbiAgICBmdW5jdGlvbiBodG1sRW50aXRpZXMoc3RyKSB7XHJcbiAgICAgIHJldHVybiBTdHJpbmcoc3RyKVxyXG4gICAgICAgIC5yZXBsYWNlQWxsKC8mL2csIFwiJmFtcDtcIilcclxuICAgICAgICAucmVwbGFjZUFsbCgvPC9nLCBcIiZsdDtcIilcclxuICAgICAgICAucmVwbGFjZUFsbCgvPi9nLCBcIiZndDtcIilcclxuICAgICAgICAucmVwbGFjZUFsbCgvXCIvZywgXCImcXVvdDtcIilcclxuICAgICAgICAucmVwbGFjZUFsbCgvJy9nLCBcIiZhcG9zO1wiKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBHZXQgdGhlIHBvc2l0aW9uIG9mIGFuIGVsZW1lbnRcclxuICAgIGZ1bmN0aW9uIGdldE9mZnNldChlbCkge1xyXG4gICAgICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgbGVmdDogcmVjdC5sZWZ0ICsgd2luZG93LnNjcm9sbFgsXHJcbiAgICAgICAgdG9wOiByZWN0LnRvcCArIHdpbmRvdy5zY3JvbGxZLFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gIH1cclxufSk7XHJcbiIsImltcG9ydCAqIGFzICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0ICdqcXVlcnktdWkvdWkvd2lkZ2V0cy9kcmFnZ2FibGUnO1xyXG5pbXBvcnQge2NyZWF0ZVByb2ZpbGVTdWJtZW51TGluaywgZXh0cmFjdFJlbGF0aXZlcywgaXNPS30gZnJvbSAnLi4vLi4vY29yZS9jb21tb24nO1xyXG5pbXBvcnQgJy4vZmFtaWx5VGltZWxpbmUuY3NzJztcclxuXHJcbmNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwiZmFtaWx5VGltZWxpbmVcIiwgKHJlc3VsdCkgPT4ge1xyXG4gIGlmIChcclxuICAgIHJlc3VsdC5mYW1pbHlUaW1lbGluZSAmJlxyXG4gICAgJChcImJvZHkucHJvZmlsZVwiKS5sZW5ndGggJiZcclxuICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKFwiU3BhY2U6XCIpID09IG51bGxcclxuICApIHtcclxuICAgIC8vIEFkZCBhIGxpbmsgdG8gdGhlIHNob3J0IGxpc3Qgb2YgbGlua3MgYmVsb3cgdGhlIHRhYnNcclxuICAgIGNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgICAgIHRpdGxlOiBcIkRpc3BsYXkgYSBmYW1pbHkgdGltZWxpbmVcIixcclxuICAgICAgaWQ6IFwiZmFtaWx5VGltZUxpbmVCdXR0b25cIixcclxuICAgICAgdGV4dDogXCJGYW1pbHkgVGltZWxpbmVcIixcclxuICAgICAgdXJsOiBcIiNuXCIsXHJcbiAgICB9O1xyXG4gICAgY3JlYXRlUHJvZmlsZVN1Ym1lbnVMaW5rKG9wdGlvbnMpO1xyXG4gICAgJChcIiNcIiArIG9wdGlvbnMuaWQpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgdGltZWxpbmUoKTtcclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSZWxhdGl2ZXMoaWQsIGZpZWxkcyA9IFwiKlwiKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0ICQuYWpheCh7XHJcbiAgICAgIHVybDogXCJodHRwczovL2FwaS53aWtpdHJlZS5jb20vYXBpLnBocFwiLFxyXG4gICAgICBjcm9zc0RvbWFpbjogdHJ1ZSxcclxuICAgICAgeGhyRmllbGRzOiB7IHdpdGhDcmVkZW50aWFsczogdHJ1ZSB9LFxyXG4gICAgICB0eXBlOiBcIlBPU1RcIixcclxuICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgYWN0aW9uOiBcImdldFJlbGF0aXZlc1wiLFxyXG4gICAgICAgIGtleXM6IGlkLFxyXG4gICAgICAgIGZpZWxkczogZmllbGRzLFxyXG4gICAgICAgIGdldFBhcmVudHM6IDEsXHJcbiAgICAgICAgZ2V0U2libGluZ3M6IDEsXHJcbiAgICAgICAgZ2V0U3BvdXNlczogMSxcclxuICAgICAgICBnZXRDaGlsZHJlbjogMSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlc3VsdFswXS5pdGVtc1swXS5wZXJzb247XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gTWFrZSB0aGUgZmFtaWx5IG1lbWJlciBhcnJheXMgZWFzaWVyIHRvIGhhbmRsZVxyXG5mdW5jdGlvbiBnZXRSZWxzKHJlbCwgcGVyc29uLCB0aGVSZWxhdGlvbiA9IGZhbHNlKSB7XHJcbiAgbGV0IHBlb3BsZSA9IFtdO1xyXG4gIGlmICh0eXBlb2YgcmVsID09IHVuZGVmaW5lZCB8fCByZWwgPT0gbnVsbCkge1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuICBjb25zdCBwS2V5cyA9IE9iamVjdC5rZXlzKHJlbCk7XHJcbiAgcEtleXMuZm9yRWFjaChmdW5jdGlvbiAocEtleSkge1xyXG4gICAgdmFyIGFQZXJzb24gPSByZWxbcEtleV07XHJcbiAgICBpZiAodGhlUmVsYXRpb24gIT0gZmFsc2UpIHtcclxuICAgICAgYVBlcnNvbi5SZWxhdGlvbiA9IHRoZVJlbGF0aW9uO1xyXG4gICAgfVxyXG4gICAgcGVvcGxlLnB1c2goYVBlcnNvbik7XHJcbiAgfSk7XHJcbiAgcmV0dXJuIHBlb3BsZTtcclxufVxyXG5cclxuLy8gR2V0IGEgeWVhciBmcm9tIHRoZSBwZXJzb24ncyBkYXRhXHJcbmZ1bmN0aW9uIGdldFRoZVllYXIodGhlRGF0ZSwgZXYsIHBlcnNvbikge1xyXG4gIGlmICghaXNPSyh0aGVEYXRlKSkge1xyXG4gICAgaWYgKGV2ID09IFwiQmlydGhcIiB8fCBldiA9PSBcIkRlYXRoXCIpIHtcclxuICAgICAgdGhlRGF0ZSA9IHBlcnNvbltldiArIFwiRGF0ZURlY2FkZVwiXTtcclxuICAgIH1cclxuICB9XHJcbiAgY29uc3QgdGhlRGF0ZU0gPSB0aGVEYXRlLm1hdGNoKC9bMC05XXs0fS8pO1xyXG4gIGlmIChpc09LKHRoZURhdGVNKSkge1xyXG4gICAgcmV0dXJuIHBhcnNlSW50KHRoZURhdGVNWzBdKTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxufVxyXG5cclxuLy8gQ29udmVydCBhIGRhdGUgdG8gWVlZWS1NTS1ERFxyXG5mdW5jdGlvbiBkYXRlVG9ZTUQoZW50ZXJlZERhdGUpIHtcclxuICBsZXQgZW50ZXJlZEQ7XHJcbiAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9bMC05XXszLDR9XFwtWzAtOV17Mn1cXC1bMC05XXsyfS8pKSB7XHJcbiAgICBlbnRlcmVkRCA9IGVudGVyZWREYXRlO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBsZXQgZURNb250aCA9IFwiMDBcIjtcclxuICAgIGxldCBlRFllYXIgPSBlbnRlcmVkRGF0ZS5tYXRjaCgvWzAtOV17Myw0fS8pO1xyXG4gICAgaWYgKGVEWWVhciAhPSBudWxsKSB7XHJcbiAgICAgIGVEWWVhciA9IGVEWWVhclswXTtcclxuICAgIH1cclxuICAgIGxldCBlRERhdGUgPSBlbnRlcmVkRGF0ZS5tYXRjaCgvXFxiWzAtOV17MSwyfVxcYi8pO1xyXG4gICAgaWYgKGVERGF0ZSAhPSBudWxsKSB7XHJcbiAgICAgIGVERGF0ZSA9IGVERGF0ZVswXS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICB9XHJcbiAgICBpZiAoZUREYXRlID09IG51bGwpIHtcclxuICAgICAgZUREYXRlID0gXCIwMFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9qYW4vaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwMVwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9mZWIvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwMlwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9tYXIvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwM1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9hcHIvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwNFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9tYXkvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwNVwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9qdW4vaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwNlwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9qdWwvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwN1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9hdWcvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwOFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9zZXAvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIwOVwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9vY3QvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIxMFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9ub3YvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIxMVwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGVudGVyZWREYXRlLm1hdGNoKC9kZWMvaSkgIT0gbnVsbCkge1xyXG4gICAgICBlRE1vbnRoID0gXCIxMlwiO1xyXG4gICAgfVxyXG4gICAgZW50ZXJlZEQgPSBlRFllYXIgKyBcIi1cIiArIGVETW9udGggKyBcIi1cIiArIGVERGF0ZTtcclxuICB9XHJcbiAgcmV0dXJuIGVudGVyZWREO1xyXG59XHJcblxyXG4vLyBVc2UgYW4gYXBwcm94aW1hdGUgZGF0ZSBpbnN0ZWFkIG9mIGFzc3VtaW5nIHRoYXQgZGF0ZXMgYXJlIEphbiAxIG9yIHRoZSAxc3Qgb2YgYSBtb250aFxyXG5mdW5jdGlvbiBnZXRBcHByb3hEYXRlKHRoZURhdGUpIHtcclxuICBsZXQgYXBwcm94ID0gZmFsc2U7XHJcbiAgbGV0IGFEYXRlO1xyXG4gIGlmICh0aGVEYXRlLm1hdGNoKC8wcyQvKSAhPSBudWxsKSB7XHJcbiAgICAvLyBDaGFuZ2UgYSBkZWNhZGUgZGF0ZSB0byBhIHllYXIgZW5kaW5nIGluICc1J1xyXG4gICAgYURhdGUgPSB0aGVEYXRlLnJlcGxhY2UoLzBzLywgXCI1XCIpO1xyXG4gICAgYXBwcm94ID0gdHJ1ZTtcclxuICB9IGVsc2Uge1xyXG4gICAgLy8gSWYgd2Ugb25seSBoYXZlIHRoZSB5ZWFyLCBhc3N1bWUgdGhlIGRhdGUgdG8gYmUgSnVseSAyICh0aGUgbWlkd2F5IGRhdGUpXHJcbiAgICBjb25zdCBiaXRzID0gdGhlRGF0ZS5zcGxpdChcIi1cIik7XHJcbiAgICBpZiAodGhlRGF0ZS5tYXRjaCgvMDBcXC0wMCQvKSAhPSBudWxsKSB7XHJcbiAgICAgIGFEYXRlID0gYml0c1swXSArIFwiLTA3LTAyXCI7XHJcbiAgICAgIGFwcHJveCA9IHRydWU7XHJcbiAgICB9IGVsc2UgaWYgKHRoZURhdGUubWF0Y2goLy0wMCQvKSAhPSBudWxsKSB7XHJcbiAgICAgIC8vIElmIHdlIGhhdmUgYSBtb250aCwgYnV0IG5vdCBhIGRheS9kYXRlLCBhc3N1bWUgdGhlIGRhdGUgdG8gYmUgMTYgKHRoZSBtaWR3YXkgZGF0ZSlcclxuICAgICAgYURhdGUgPSBiaXRzWzBdICsgXCItXCIgKyBiaXRzWzFdICsgXCItXCIgKyBcIjE2XCI7XHJcbiAgICAgIGFwcHJveCA9IHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhRGF0ZSA9IHRoZURhdGU7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiB7IERhdGU6IGFEYXRlLCBBcHByb3g6IGFwcHJveCB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRBZ2UoYmlydGgsIGRlYXRoKSB7XHJcbiAgLy8gbXVzdCBiZSBkYXRlIG9iamVjdHNcclxuICB2YXIgYWdlID0gZGVhdGguZ2V0RnVsbFllYXIoKSAtIGJpcnRoLmdldEZ1bGxZZWFyKCk7XHJcbiAgdmFyIG0gPSBkZWF0aC5nZXRNb250aCgpIC0gYmlydGguZ2V0TW9udGgoKTtcclxuICBpZiAobSA8IDAgfHwgKG0gPT09IDAgJiYgZGVhdGguZ2V0RGF0ZSgpIDwgYmlydGguZ2V0RGF0ZSgpKSkge1xyXG4gICAgYWdlLS07XHJcbiAgfVxyXG4gIHJldHVybiBhZ2U7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNhcGl0YWxpemVGaXJzdExldHRlcihzdHJpbmcpIHtcclxuICBzdHJpbmcgPSBzdHJpbmcudG9Mb3dlckNhc2UoKTtcclxuICBjb25zdCBiaXRzID0gc3RyaW5nLnNwbGl0KFwiIFwiKTtcclxuICBsZXQgb3V0ID0gXCJcIjtcclxuICBiaXRzLmZvckVhY2goZnVuY3Rpb24gKGFiaXQpIHtcclxuICAgIG91dCArPSBhYml0LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgYWJpdC5zbGljZSgxKSArIFwiIFwiO1xyXG4gIH0pO1xyXG4gIGZ1bmN0aW9uIHJlcGxhY2VyKG1hdGNoLCBwMSkge1xyXG4gICAgcmV0dXJuIFwiLVwiICsgcDEudG9VcHBlckNhc2UoKTtcclxuICB9XHJcbiAgb3V0ID0gb3V0LnJlcGxhY2UoL1xcLShbYS16XSkvLCByZXBsYWNlcik7XHJcbiAgcmV0dXJuIG91dC50cmltKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRpbWVsaW5lKCkge1xyXG4gICQoXCIjdGltZWxpbmVcIikucmVtb3ZlKCk7XHJcbiAgY29uc3QgZmllbGRzID1cclxuICAgIFwiQmlydGhEYXRlLEJpcnRoTG9jYXRpb24sQmlydGhOYW1lLEJpcnRoRGF0ZURlY2FkZSxEZWF0aERhdGUsRGVhdGhEYXRlRGVjYWRlLERlYXRoTG9jYXRpb24sSXNMaXZpbmcsRmF0aGVyLEZpcnN0TmFtZSxHZW5kZXIsSWQsTGFzdE5hbWVBdEJpcnRoLExhc3ROYW1lQ3VycmVudCxQcmVmaXgsU3VmZml4LExhc3ROYW1lT3RoZXIsRGVyaXZlZC5Mb25nTmFtZSxEZXJpdmVkLkxvbmdOYW1lUHJpdmF0ZSxNYW5hZ2VyLE1pZGRsZU5hbWUsTW90aGVyLE5hbWUsUGhvdG8sUmVhbE5hbWUsU2hvcnROYW1lLFRvdWNoZWQsRGF0YVN0YXR1cyxEZXJpdmVkLkJpcnRoTmFtZSxCaW9cIjtcclxuICBjb25zdCBpZCA9ICQoXCJhLnB1cmVDc3NNZW51aTAgc3Bhbi5wZXJzb25cIikudGV4dCgpO1xyXG4gIGdldFJlbGF0aXZlcyhpZCwgZmllbGRzKS50aGVuKChwZXJzb25EYXRhKSA9PiB7XHJcbiAgICB2YXIgcGVyc29uID0gcGVyc29uRGF0YTtcclxuICAgIGNvbnN0IHBhcmVudHMgPSBleHRyYWN0UmVsYXRpdmVzKHBlcnNvbi5QYXJlbnRzLCBcIlBhcmVudFwiKTtcclxuICAgIGNvbnN0IHNpYmxpbmdzID0gZXh0cmFjdFJlbGF0aXZlcyhwZXJzb24uU2libGluZ3MsIFwiU2libGluZ1wiKTtcclxuICAgIGNvbnN0IHNwb3VzZXMgPSBleHRyYWN0UmVsYXRpdmVzKHBlcnNvbi5TcG91c2VzLCBcIlNwb3VzZVwiKTtcclxuICAgIGNvbnN0IGNoaWxkcmVuID0gZXh0cmFjdFJlbGF0aXZlcyhwZXJzb24uQ2hpbGRyZW4sIFwiQ2hpbGRcIik7XHJcbiAgICBjb25zdCBmYW1pbHkgPSBbcGVyc29uXTtcclxuICAgIGNvbnN0IGZhbWlseUFyciA9IFtwYXJlbnRzLCBzaWJsaW5ncywgc3BvdXNlcywgY2hpbGRyZW5dO1xyXG4gICAgLy8gTWFrZSBhbiBhcnJheSBvZiBmYW1pbHkgbWVtYmVyc1xyXG4gICAgZmFtaWx5QXJyLmZvckVhY2goZnVuY3Rpb24gKGFuQXJyKSB7XHJcbiAgICAgIGlmIChhbkFycikge1xyXG4gICAgICAgIGlmIChhbkFyci5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBmYW1pbHkucHVzaCguLi5hbkFycik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIGxldCBmYW1pbHlGYWN0cyA9IFtdO1xyXG4gICAgY29uc3Qgc3RhcnREYXRlID0gZ2V0VGhlWWVhcihwZXJzb24uQmlydGhEYXRlLCBcIkJpcnRoXCIsIHBlcnNvbik7XHJcbiAgICAvLyBHZXQgYWxsIEJNRCBldmVudHMgZm9yIGVhY2ggZmFtaWx5IG1lbWJlclxyXG4gICAgZmFtaWx5LmZvckVhY2goZnVuY3Rpb24gKGFQZXJzb24pIHtcclxuICAgICAgY29uc3QgZXZlbnRzID0gW1wiQmlydGhcIiwgXCJEZWF0aFwiLCBcIm1hcnJpYWdlXCJdO1xyXG4gICAgICBldmVudHMuZm9yRWFjaChmdW5jdGlvbiAoZXYpIHtcclxuICAgICAgICBsZXQgZXZEYXRlID0gXCJcIjtcclxuICAgICAgICBsZXQgZXZMb2NhdGlvbjtcclxuICAgICAgICBpZiAoYVBlcnNvbltldiArIFwiRGF0ZVwiXSkge1xyXG4gICAgICAgICAgZXZEYXRlID0gYVBlcnNvbltldiArIFwiRGF0ZVwiXTtcclxuICAgICAgICAgIGV2TG9jYXRpb24gPSBhUGVyc29uW2V2ICsgXCJMb2NhdGlvblwiXTtcclxuICAgICAgICB9IGVsc2UgaWYgKGFQZXJzb25bZXYgKyBcIkRhdGVEZWNhZGVcIl0pIHtcclxuICAgICAgICAgIGV2RGF0ZSA9IGFQZXJzb25bZXYgKyBcIkRhdGVEZWNhZGVcIl07XHJcbiAgICAgICAgICBldkxvY2F0aW9uID0gYVBlcnNvbltldiArIFwiTG9jYXRpb25cIl07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChldiA9PSBcIm1hcnJpYWdlXCIpIHtcclxuICAgICAgICAgIGlmIChhUGVyc29uW2V2ICsgXCJfZGF0ZVwiXSkge1xyXG4gICAgICAgICAgICBldkRhdGUgPSBhUGVyc29uW2V2ICsgXCJfZGF0ZVwiXTtcclxuICAgICAgICAgICAgZXZMb2NhdGlvbiA9IGFQZXJzb25bZXYgKyBcIl9sb2NhdGlvblwiXTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGFQZXJzb24uUmVsYXRpb24pIHtcclxuICAgICAgICAgIGFQZXJzb24uUmVsYXRpb24gPSBhUGVyc29uLlJlbGF0aW9uLnJlcGxhY2UoL3MkLywgXCJcIikucmVwbGFjZShcclxuICAgICAgICAgICAgL3JlbiQvLFxyXG4gICAgICAgICAgICBcIlwiXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZXZEYXRlICE9IFwiXCIgJiYgZXZEYXRlICE9IFwiMDAwMFwiICYmIGlzT0soZXZEYXRlKSkge1xyXG4gICAgICAgICAgbGV0IGZOYW1lID0gYVBlcnNvbi5GaXJzdE5hbWU7XHJcbiAgICAgICAgICBpZiAoIWFQZXJzb24uRmlyc3ROYW1lKSB7XHJcbiAgICAgICAgICAgIGZOYW1lID0gYVBlcnNvbi5SZWFsTmFtZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGxldCBiRGF0ZSA9IGFQZXJzb24uQmlydGhEYXRlO1xyXG4gICAgICAgICAgaWYgKCFhUGVyc29uLkJpcnRoRGF0ZSkge1xyXG4gICAgICAgICAgICBiRGF0ZSA9IGFQZXJzb24uQmlydGhEYXRlRGVjYWRlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgbGV0IG1CaW8gPSBhUGVyc29uLmJpbztcclxuICAgICAgICAgIGlmICghYVBlcnNvbi5iaW8pIHtcclxuICAgICAgICAgICAgbUJpbyA9IFwiXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBpZiAoZXZMb2NhdGlvbiA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgZXZMb2NhdGlvbiA9IFwiXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBmYW1pbHlGYWN0cy5wdXNoKFtcclxuICAgICAgICAgICAgZXZEYXRlLFxyXG4gICAgICAgICAgICBldkxvY2F0aW9uLFxyXG4gICAgICAgICAgICBmTmFtZSxcclxuICAgICAgICAgICAgYVBlcnNvbi5MYXN0TmFtZUF0QmlydGgsXHJcbiAgICAgICAgICAgIGFQZXJzb24uTGFzdE5hbWVDdXJyZW50LFxyXG4gICAgICAgICAgICBiRGF0ZSxcclxuICAgICAgICAgICAgYVBlcnNvbi5SZWxhdGlvbixcclxuICAgICAgICAgICAgbUJpbyxcclxuICAgICAgICAgICAgZXYsXHJcbiAgICAgICAgICAgIGFQZXJzb24uTmFtZSxcclxuICAgICAgICAgIF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIC8vIExvb2sgZm9yIG1pbGl0YXJ5IGV2ZW50cyBpbiBiaW9zXHJcbiAgICAgIGlmIChhUGVyc29uLmJpbykge1xyXG4gICAgICAgIGNvbnN0IHRsVGVtcGxhdGVzID0gYVBlcnNvbi5iaW8ubWF0Y2goL1xce1xce1teXSo/XFx9XFx9L2dtKTtcclxuICAgICAgICBpZiAodGxUZW1wbGF0ZXMgIT0gbnVsbCkge1xyXG4gICAgICAgICAgY29uc3Qgd2FyVGVtcGxhdGVzID0gW1xyXG4gICAgICAgICAgICBcIlRoZSBHcmVhdCBXYXJcIixcclxuICAgICAgICAgICAgXCJLb3JlYW4gV2FyXCIsXHJcbiAgICAgICAgICAgIFwiVmlldG5hbSBXYXJcIixcclxuICAgICAgICAgICAgXCJXb3JsZCBXYXIgSUlcIixcclxuICAgICAgICAgICAgXCJVUyBDaXZpbCBXYXJcIixcclxuICAgICAgICAgICAgXCJXYXIgb2YgMTgxMlwiLFxyXG4gICAgICAgICAgICBcIk1leGljYW4tQW1lcmljYW4gV2FyXCIsXHJcbiAgICAgICAgICAgIFwiRnJlbmNoIGFuZCBJbmRpYW4gV2FyXCIsXHJcbiAgICAgICAgICAgIFwiU3BhbmlzaC1BbWVyaWNhbiBXYXJcIixcclxuICAgICAgICAgIF07XHJcbiAgICAgICAgICB0bFRlbXBsYXRlcy5mb3JFYWNoKGZ1bmN0aW9uIChhVGVtcCkge1xyXG4gICAgICAgICAgICBsZXQgZXZEYXRlID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGV2TG9jYXRpb24gPSBcIlwiO1xyXG4gICAgICAgICAgICBsZXQgZXYgPSBcIlwiO1xyXG4gICAgICAgICAgICBsZXQgZXZEYXRlU3RhcnQgPSBcIlwiO1xyXG4gICAgICAgICAgICBsZXQgZXZEYXRlRW5kID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGV2U3RhcnQ7XHJcbiAgICAgICAgICAgIGxldCBldkVuZDtcclxuICAgICAgICAgICAgYVRlbXAgPSBhVGVtcC5yZXBsYWNlQWxsKC9be31dL2csIFwiXCIpO1xyXG4gICAgICAgICAgICBjb25zdCBiaXRzID0gYVRlbXAuc3BsaXQoXCJ8XCIpO1xyXG4gICAgICAgICAgICBjb25zdCB0ZW1wbGF0ZVRpdGxlID0gYml0c1swXS5yZXBsYWNlQWxsKC9cXG4vZywgXCJcIikudHJpbSgpO1xyXG4gICAgICAgICAgICBiaXRzLmZvckVhY2goZnVuY3Rpb24gKGFCaXQpIHtcclxuICAgICAgICAgICAgICBjb25zdCBhQml0Qml0cyA9IGFCaXQuc3BsaXQoXCI9XCIpO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGFCaXRGaWVsZCA9IGFCaXRCaXRzWzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgICBpZiAoYUJpdEJpdHNbMV0pIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGFCaXRGYWN0ID0gYUJpdEJpdHNbMV0udHJpbSgpLnJlcGxhY2VBbGwoL1xcbi9nLCBcIlwiKTtcclxuICAgICAgICAgICAgICAgIGlmICh3YXJUZW1wbGF0ZXMuaW5jbHVkZXModGVtcGxhdGVUaXRsZSkgJiYgaXNPSyhhQml0RmFjdCkpIHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGFCaXRGaWVsZCA9PSBcInN0YXJ0ZGF0ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZEYXRlU3RhcnQgPSBkYXRlVG9ZTUQoYUJpdEZhY3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIGV2U3RhcnQgPSBcIkpvaW5lZCBcIiArIHRlbXBsYXRlVGl0bGU7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgaWYgKGFCaXRGaWVsZCA9PSBcImVuZGRhdGVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGV2RGF0ZUVuZCA9IGRhdGVUb1lNRChhQml0RmFjdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZFbmQgPSBcIkxlZnQgXCIgKyB0ZW1wbGF0ZVRpdGxlO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGlmIChhQml0RmllbGQgPT0gXCJlbmxpc3RlZFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZEYXRlU3RhcnQgPSBkYXRlVG9ZTUQoYUJpdEZhY3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIGV2U3RhcnQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbmxpc3RlZCBmb3IgXCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVUaXRsZS5yZXBsYWNlKFwiYW1lcmljYW5cIiwgXCJBbWVyaWNhblwiKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpZiAoYUJpdEZpZWxkID09IFwiZGlzY2hhcmdlZFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZEYXRlRW5kID0gZGF0ZVRvWU1EKGFCaXRGYWN0KTtcclxuICAgICAgICAgICAgICAgICAgICBldkVuZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkRpc2NoYXJnZWQgZnJvbSBcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVRpdGxlLnJlcGxhY2UoXCJhbWVyaWNhblwiLCBcIkFtZXJpY2FuXCIpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGlmIChhQml0RmllbGQgPT0gXCJicmFuY2hcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGV2TG9jYXRpb24gPSBhQml0RmFjdDtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGlmIChpc09LKGV2RGF0ZVN0YXJ0KSkge1xyXG4gICAgICAgICAgICAgIGV2RGF0ZSA9IGV2RGF0ZVN0YXJ0O1xyXG4gICAgICAgICAgICAgIGV2ID0gZXZTdGFydDtcclxuICAgICAgICAgICAgICBmYW1pbHlGYWN0cy5wdXNoKFtcclxuICAgICAgICAgICAgICAgIGV2RGF0ZSxcclxuICAgICAgICAgICAgICAgIGV2TG9jYXRpb24sXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLkZpcnN0TmFtZSxcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uTGFzdE5hbWVBdEJpcnRoLFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5MYXN0TmFtZUN1cnJlbnQsXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLkJpcnRoRGF0ZSxcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uUmVsYXRpb24sXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLmJpbyxcclxuICAgICAgICAgICAgICAgIGV2LFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5OYW1lLFxyXG4gICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpc09LKGV2RGF0ZUVuZCkpIHtcclxuICAgICAgICAgICAgICBldkRhdGUgPSBldkRhdGVFbmQ7XHJcbiAgICAgICAgICAgICAgZXYgPSBldkVuZDtcclxuICAgICAgICAgICAgICBmYW1pbHlGYWN0cy5wdXNoKFtcclxuICAgICAgICAgICAgICAgIGV2RGF0ZSxcclxuICAgICAgICAgICAgICAgIGV2TG9jYXRpb24sXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLkZpcnN0TmFtZSxcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uTGFzdE5hbWVBdEJpcnRoLFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5MYXN0TmFtZUN1cnJlbnQsXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLkJpcnRoRGF0ZSxcclxuICAgICAgICAgICAgICAgIGFQZXJzb24uUmVsYXRpb24sXHJcbiAgICAgICAgICAgICAgICBhUGVyc29uLmJpbyxcclxuICAgICAgICAgICAgICAgIGV2LFxyXG4gICAgICAgICAgICAgICAgYVBlcnNvbi5OYW1lLFxyXG4gICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgLy8gU29ydCB0aGUgZXZlbnRzXHJcbiAgICBmYW1pbHlGYWN0cy5zb3J0KCk7XHJcbiAgICBpZiAoIXBlcnNvbi5GaXJzdE5hbWUpIHtcclxuICAgICAgcGVyc29uLkZpcnN0TmFtZSA9IHBlcnNvbi5SZWFsTmFtZTtcclxuICAgIH1cclxuICAgIC8vIE1ha2UgYSB0YWJsZVxyXG4gICAgY29uc3QgdGltZWxpbmVUYWJsZSA9ICQoXHJcbiAgICAgIGA8ZGl2IGNsYXNzPSd3cmFwJyBpZD0ndGltZWxpbmUnIGRhdGEtd3RpZD0nJHtwZXJzb24uTmFtZX0nPjx3PuKGlDwvdz48eD54PC94Pjx0YWJsZSBpZD0ndGltZWxpbmVUYWJsZSc+YCArXHJcbiAgICAgICAgYDxjYXB0aW9uPkV2ZW50cyBpbiB0aGUgbGlmZSBvZiAke3BlcnNvbi5GaXJzdE5hbWV9J3MgZmFtaWx5PC9jYXB0aW9uPjx0aGVhZD48dGggY2xhc3M9J3RsRGF0ZSc+RGF0ZTwvdGg+PHRoIGNsYXNzPSd0bEJpb0FnZSc+QWdlICgke3BlcnNvbi5GaXJzdE5hbWV9KTwvdGg+YCArXHJcbiAgICAgICAgYDx0aCBjbGFzcz0ndGxSZWxhdGlvbic+UmVsYXRpb248L3RoPjx0aCBjbGFzcz0ndGxOYW1lJz5OYW1lPC90aD48dGggY2xhc3M9J3RsQWdlJz5BZ2U8L3RoPjx0aCBjbGFzcz0ndGxFdmVudE5hbWUnPkV2ZW50PC90aD48dGggY2xhc3M9J3RsRXZlbnRMb2NhdGlvbic+TG9jYXRpb248L3RoPmAgK1xyXG4gICAgICAgIGA8L3RoZWFkPjwvdGFibGU+PC9kaXY+YFxyXG4gICAgKTtcclxuICAgIC8vIEF0dGFjaCB0aGUgdGFibGUgdG8gdGhlIGNvbnRhaW5lciBkaXZcclxuICAgIHRpbWVsaW5lVGFibGUucHJlcGVuZFRvKCQoXCJkaXYuY29udGFpbmVyLmZ1bGwtd2lkdGhcIikpO1xyXG4gICAgaWYgKCQoXCIjY29ubmVjdGlvbkxpc3RcIikubGVuZ3RoKSB7XHJcbiAgICAgIHRpbWVsaW5lVGFibGUucHJlcGVuZFRvKCQoXCIjY29udGVudFwiKSk7XHJcbiAgICAgIHRpbWVsaW5lVGFibGUuY3NzKHsgdG9wOiB3aW5kb3cucG9pbnRlclkgLSAzMCwgbGVmdDogMTAgfSk7XHJcbiAgICB9XHJcbiAgICBsZXQgYnBEZWFkID0gZmFsc2U7XHJcbiAgICBsZXQgYnBEZWFkQWdlO1xyXG5cclxuICAgIGZhbWlseUZhY3RzLmZvckVhY2goZnVuY3Rpb24gKGFGYWN0KSB7XHJcbiAgICAgIC8vIEFkZCBldmVudHMgdG8gdGhlIHRhYmxlXHJcbiAgICAgIGNvbnN0IHNob3dEYXRlID0gYUZhY3RbMF0ucmVwbGFjZShcIi0wMC0wMFwiLCBcIlwiKS5yZXBsYWNlKFwiLTAwXCIsIFwiXCIpO1xyXG4gICAgICBjb25zdCB0bERhdGUgPSBcIjx0ZCBjbGFzcz0ndGxEYXRlJz5cIiArIHNob3dEYXRlICsgXCI8L3RkPlwiO1xyXG4gICAgICBsZXQgYWJvdXRBZ2UgPSBcIlwiO1xyXG4gICAgICBsZXQgYnBCZGF0ZSA9IHBlcnNvbi5CaXJ0aERhdGU7XHJcbiAgICAgIGlmICghcGVyc29uLkJpcnRoRGF0ZSkge1xyXG4gICAgICAgIGJwQmRhdGUgPSBwZXJzb24uQmlydGhEYXRlRGVjYWRlLnJlcGxhY2UoLzBzLywgXCI1XCIpO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCBoYXNCZGF0ZSA9IHRydWU7XHJcbiAgICAgIGlmIChicEJkYXRlID09IFwiMDAwMC0wMC0wMFwiKSB7XHJcbiAgICAgICAgaGFzQmRhdGUgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCBicEJEID0gZ2V0QXBwcm94RGF0ZShicEJkYXRlKTtcclxuICAgICAgY29uc3QgZXZEYXRlID0gZ2V0QXBwcm94RGF0ZShhRmFjdFswXSk7XHJcbiAgICAgIGNvbnN0IGFQZXJzb25CRCA9IGdldEFwcHJveERhdGUoYUZhY3RbNV0pO1xyXG4gICAgICBpZiAoYnBCRC5BcHByb3ggPT0gdHJ1ZSkge1xyXG4gICAgICAgIGFib3V0QWdlID0gXCJ+XCI7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGV2RGF0ZS5BcHByb3ggPT0gdHJ1ZSkge1xyXG4gICAgICAgIGFib3V0QWdlID0gXCJ+XCI7XHJcbiAgICAgIH1cclxuICAgICAgbGV0IGJwQWdlID0gZ2V0QWdlKG5ldyBEYXRlKGJwQkQuRGF0ZSksIG5ldyBEYXRlKGV2RGF0ZS5EYXRlKSk7XHJcbiAgICAgIGlmIChicEFnZSA9PSAwKSB7XHJcbiAgICAgICAgYnBBZ2UgPSBcIlwiO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChicERlYWQgPT0gdHJ1ZSkge1xyXG4gICAgICAgIGNvbnN0IHRoZURpZmYgPSBwYXJzZUludChicEFnZSAtIGJwRGVhZEFnZSk7XHJcbiAgICAgICAgYnBBZ2UgPSBicEFnZSArIFwiIChcIiArIGJwRGVhZEFnZSArIFwiICsgXCIgKyB0aGVEaWZmICsgXCIpXCI7XHJcbiAgICAgIH1cclxuICAgICAgbGV0IHRoZUJQQWdlO1xyXG4gICAgICBpZiAoYWJvdXRBZ2UgIT0gXCJcIiAmJiBicEFnZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgdGhlQlBBZ2UgPSBcIihcIiArIGJwQWdlICsgXCIpXCI7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhlQlBBZ2UgPSBicEFnZTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoaGFzQmRhdGUgPT0gZmFsc2UpIHtcclxuICAgICAgICB0aGVCUEFnZSA9IFwiXCI7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdGxCaW9BZ2UgPSBcIjx0ZCBjbGFzcz0ndGxCaW9BZ2UnPlwiICsgdGhlQlBBZ2UgKyBcIjwvdGQ+XCI7XHJcbiAgICAgIGlmIChhRmFjdFs2XSA9PSB1bmRlZmluZWQgfHwgYUZhY3RbOV0gPT0gcGVyc29uLk5hbWUpIHtcclxuICAgICAgICBhRmFjdFs2XSA9IFwiXCI7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdGxSZWxhdGlvbiA9XHJcbiAgICAgICAgXCI8dGQgY2xhc3M9J3RsUmVsYXRpb24nPlwiICsgYUZhY3RbNl0ucmVwbGFjZSgvcyQvLCBcIlwiKSArIFwiPC90ZD5cIjtcclxuICAgICAgbGV0IGZOYW1lcyA9IGFGYWN0WzJdO1xyXG4gICAgICBpZiAoYUZhY3RbOF0gPT0gXCJtYXJyaWFnZVwiKSB7XHJcbiAgICAgICAgZk5hbWVzID0gcGVyc29uLkZpcnN0TmFtZSArIFwiIGFuZCBcIiArIGFGYWN0WzJdO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHRsRmlyc3ROYW1lID1cclxuICAgICAgICBcIjx0ZCBjbGFzcz0ndGxGaXJzdE5hbWUnPjxhIGhyZWY9J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL1wiICtcclxuICAgICAgICBhRmFjdFs5XSArXHJcbiAgICAgICAgXCInPlwiICtcclxuICAgICAgICBmTmFtZXMgK1xyXG4gICAgICAgIFwiPC9hPjwvdGQ+XCI7XHJcbiAgICAgIGNvbnN0IHRsRXZlbnROYW1lID1cclxuICAgICAgICBcIjx0ZCBjbGFzcz0ndGxFdmVudE5hbWUnPlwiICtcclxuICAgICAgICBjYXBpdGFsaXplRmlyc3RMZXR0ZXIoYUZhY3RbOF0pXHJcbiAgICAgICAgICAucmVwbGFjZUFsbCgvVXNcXGIvZywgXCJVU1wiKVxyXG4gICAgICAgICAgLnJlcGxhY2VBbGwoL0lpXFxiL2csIFwiSUlcIikgK1xyXG4gICAgICAgIFwiPC90ZD5cIjtcclxuICAgICAgY29uc3QgdGxFdmVudExvY2F0aW9uID0gXCI8dGQgY2xhc3M9J3RsRXZlbnRMb2NhdGlvbic+XCIgKyBhRmFjdFsxXSArIFwiPC90ZD5cIjtcclxuXHJcbiAgICAgIGlmIChhUGVyc29uQkQuQXBwcm94ID09IHRydWUpIHtcclxuICAgICAgICBhYm91dEFnZSA9IFwiflwiO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCBhUGVyc29uQWdlID0gZ2V0QWdlKG5ldyBEYXRlKGFQZXJzb25CRC5EYXRlKSwgbmV3IERhdGUoZXZEYXRlLkRhdGUpKTtcclxuICAgICAgaWYgKGFQZXJzb25BZ2UgPT0gMCB8fCBhUGVyc29uQkQuRGF0ZS5tYXRjaCgvMDAwMC8pICE9IG51bGwpIHtcclxuICAgICAgICBhUGVyc29uQWdlID0gXCJcIjtcclxuICAgICAgICBhYm91dEFnZSA9IFwiXCI7XHJcbiAgICAgIH1cclxuICAgICAgbGV0IHRoZUFnZTtcclxuICAgICAgaWYgKGFib3V0QWdlICE9IFwiXCIgJiYgYVBlcnNvbkFnZSAhPSBcIlwiKSB7XHJcbiAgICAgICAgdGhlQWdlID0gXCIoXCIgKyBhUGVyc29uQWdlICsgXCIpXCI7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhlQWdlID0gYVBlcnNvbkFnZTtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCB0bEFnZSA9IFwiPHRkIGNsYXNzPSd0bEFnZSc+XCIgKyB0aGVBZ2UgKyBcIjwvdGQ+XCI7XHJcbiAgICAgIGxldCBjbGFzc1RleHQgPSBcIlwiO1xyXG4gICAgICBpZiAoYUZhY3RbOV0gPT0gcGVyc29uLk5hbWUpIHtcclxuICAgICAgICBjbGFzc1RleHQgKz0gXCJCaW9QZXJzb24gXCI7XHJcbiAgICAgIH1cclxuICAgICAgY2xhc3NUZXh0ICs9IGFGYWN0WzhdICsgXCIgXCI7XHJcbiAgICAgIGNvbnN0IHRsVFIgPSAkKFxyXG4gICAgICAgIFwiPHRyIGNsYXNzPSdcIiArXHJcbiAgICAgICAgICBjbGFzc1RleHQgK1xyXG4gICAgICAgICAgXCInPlwiICtcclxuICAgICAgICAgIHRsRGF0ZSArXHJcbiAgICAgICAgICB0bEJpb0FnZSArXHJcbiAgICAgICAgICB0bFJlbGF0aW9uICtcclxuICAgICAgICAgIHRsRmlyc3ROYW1lICtcclxuICAgICAgICAgIHRsQWdlICtcclxuICAgICAgICAgIHRsRXZlbnROYW1lICtcclxuICAgICAgICAgIHRsRXZlbnRMb2NhdGlvbiArXHJcbiAgICAgICAgICBcIjwvdHI+XCJcclxuICAgICAgKTtcclxuICAgICAgJChcIiN0aW1lbGluZVRhYmxlXCIpLmFwcGVuZCh0bFRSKTtcclxuICAgICAgaWYgKGFGYWN0WzhdID09IFwiRGVhdGhcIiAmJiBhRmFjdFs5XSA9PSBwZXJzb24uTmFtZSkge1xyXG4gICAgICAgIGJwRGVhZCA9IHRydWU7XHJcbiAgICAgICAgYnBEZWFkQWdlID0gYnBBZ2U7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgICQoXCIjdGltZWxpbmVcIikuc2xpZGVEb3duKFwic2xvd1wiKTtcclxuICAgICQoXCIjdGltZWxpbmUgeFwiKS5jbGljayhmdW5jdGlvbiAoKSB7XHJcbiAgICAgICQoXCIjdGltZWxpbmVcIikuc2xpZGVVcCgpO1xyXG4gICAgfSk7XHJcbiAgICAkKFwiI3RpbWVsaW5lIHdcIikuY2xpY2soZnVuY3Rpb24gKCkge1xyXG4gICAgICAkKFwiI3RpbWVsaW5lXCIpLnRvZ2dsZUNsYXNzKFwid3JhcFwiKTtcclxuICAgIH0pO1xyXG4gICAgLy8gVXNlIGpxdWVyeS11aSB0byBtYWtlIHRoZSB0YWJsZSBkcmFnZ2FibGVcclxuICAgICQoXCIjdGltZWxpbmVcIikuZHJhZ2dhYmxlKCk7XHJcbiAgICAkKFwiI3RpbWVsaW5lXCIpLmRibGNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgICAgJCh0aGlzKS5zbGlkZVVwKFwic3dpbmdcIik7XHJcbiAgICB9KTtcclxuICB9KTtcclxufVxyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQge2V4dHJhY3RSZWxhdGl2ZXMsIGZhbWlseUFycmF5LCBnZXRSZWxhdGl2ZXN9IGZyb20gJy4uLy4uL2NvcmUvY29tbW9uJztcclxuaW1wb3J0ICcuL2xvY2F0aW9uc0hlbHBlci5jc3MnO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoJ2xvY2F0aW9uc0hlbHBlcicsIChyZXN1bHQpID0+IHtcclxuXHRpZiAocmVzdWx0LmxvY2F0aW9uc0hlbHBlciAmJiAkKFwiYm9keS5CRUVcIikubGVuZ3RoPT0wICYmIFxyXG4gICAgICAgICgkKFwiYm9keS5wYWdlLVNwZWNpYWxfRWRpdFBlcnNvblwiKS5sZW5ndGggfHwgJChcImJvZHkucGFnZS1TcGVjaWFsX0VkaXRGYW1pbHlcIikubGVuZ3RoKSkge1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBhZGRSZWxBcnJheXNUb1BlcnNvbih6UGVyc29uKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHpTcG91c2VzID0gZXh0cmFjdFJlbGF0aXZlcyh6UGVyc29uLlNwb3VzZXMsIFwiU3BvdXNlXCIpOyBcclxuICAgICAgICAgICAgelBlcnNvbi5TcG91c2UgPSB6U3BvdXNlcztcclxuICAgICAgICAgICAgY29uc3QgekNoaWxkcmVuID0gZXh0cmFjdFJlbGF0aXZlcyh6UGVyc29uLkNoaWxkcmVuLCBcIkNoaWxkXCIpOyBcclxuICAgICAgICAgICAgelBlcnNvbi5DaGlsZCA9IHpDaGlsZHJlbjtcclxuICAgICAgICAgICAgY29uc3QgelNpYmxpbmdzID0gZXh0cmFjdFJlbGF0aXZlcyh6UGVyc29uLlNpYmxpbmdzLCBcIlNpYmxpbmdcIik7IFxyXG4gICAgICAgICAgICB6UGVyc29uLlNpYmxpbmcgPSB6U2libGluZ3M7XHJcbiAgICAgICAgICAgIGNvbnN0IHpQYXJlbnRzID0gZXh0cmFjdFJlbGF0aXZlcyh6UGVyc29uLlBhcmVudHMsIFwiUGFyZW50XCIpOyBcclxuICAgICAgICAgICAgelBlcnNvbi5QYXJlbnQgPSB6UGFyZW50cztcclxuICAgICAgICAgICAgcmV0dXJuIHpQZXJzb247XHJcbiAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgZnVuY3Rpb24gZWRpdERpc3RhbmNlKHMxLCBzMikge1xyXG4gICAgICAgICAgICBzMSA9IHMxLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgIHMyID0gczIudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgbGV0IGNvc3RzID0gbmV3IEFycmF5KCk7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDw9IHMxLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgbGFzdFZhbHVlID0gaTtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDw9IHMyLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkgPT0gMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29zdHNbal0gPSBqO1xyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaiA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuZXdWYWx1ZSA9IGNvc3RzW2ogLSAxXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzMS5jaGFyQXQoaSAtIDEpICE9IHMyLmNoYXJBdChqIC0gMSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3VmFsdWUgPSBNYXRoLm1pbihNYXRoLm1pbihuZXdWYWx1ZSwgbGFzdFZhbHVlKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29zdHNbal0pICsgMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvc3RzW2ogLSAxXSA9IGxhc3RWYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RWYWx1ZSA9IG5ld1ZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGkgPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvc3RzW3MyLmxlbmd0aF0gPSBsYXN0VmFsdWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGNvc3RzW3MyLmxlbmd0aF07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBzaW1pbGFyaXR5KHMxLCBzMikge1xyXG4gICAgICAgICAgICBzMSA9IHMxLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgIHMyID0gczIudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgdmFyIGxvbmdlciA9IHMxO1xyXG4gICAgICAgICAgICB2YXIgc2hvcnRlciA9IHMyO1xyXG4gICAgICAgICAgICBpZiAoczEubGVuZ3RoIDwgczIubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICBsb25nZXIgPSBzMjtcclxuICAgICAgICAgICAgICAgIHNob3J0ZXIgPSBzMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgbG9uZ2VyTGVuZ3RoID0gbG9uZ2VyLmxlbmd0aDtcclxuICAgICAgICAgICAgaWYgKGxvbmdlckxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gMS4wO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAobG9uZ2VyTGVuZ3RoIC0gZWRpdERpc3RhbmNlKGxvbmdlciwgc2hvcnRlcikpIC8gcGFyc2VGbG9hdChsb25nZXJMZW5ndGgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gbG9jYXRpb25zSGVscGVyKCkge1xyXG4gICAgICAgICAgICBsZXQgdGhlSUQ7XHJcbiAgICAgICAgICAgIGlmICgkKFwiYm9keS5wYWdlLVNwZWNpYWxfRWRpdEZhbWlseVwiKS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIHRoZUlEID0gJChcImEucHVyZUNzc01lbnVpMCBzcGFuLnBlcnNvblwiKS50ZXh0KCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGVJRCA9ICQoXCJhLnB1cmVDc3NNZW51aTpDb250YWlucyhFZGl0KVwiKS5hdHRyKFwiaHJlZlwiKS5zcGxpdChcInU9XCIpWzFdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGdldFJlbGF0aXZlcyh0aGVJRCkudGhlbigocmVzdWx0KT0+e1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdGhpc0ZhbWlseSA9IGZhbWlseUFycmF5KHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICB3aW5kb3cuYmRMb2NhdGlvbnMgPSBbXTtcclxuICAgICAgICAgICAgICAgIHRoaXNGYW1pbHkuZm9yRWFjaChmdW5jdGlvbiAoYVBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFQZS5CaXJ0aExvY2F0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5iZExvY2F0aW9ucy5wdXNoKGFQZS5CaXJ0aExvY2F0aW9uKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFQZS5EZWF0aExvY2F0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5iZExvY2F0aW9ucy5wdXNoKGFQZS5EZWF0aExvY2F0aW9uKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IG9ic2VydmVyMiA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGZ1bmN0aW9uIChtdXRhdGlvbnNfbGlzdCkge1xyXG4gICAgICAgICAgICAgICAgbXV0YXRpb25zX2xpc3QuZm9yRWFjaChmdW5jdGlvbiAobXV0YXRpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICBtdXRhdGlvbi5hZGRlZE5vZGVzLmZvckVhY2goZnVuY3Rpb24gKGFkZGVkX25vZGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFkZGVkX25vZGUuY2xhc3NOYW1lID09IFwiYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb24tY29udGFpbmVyXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhY3RpdmVFbCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgd2hpY2hMb2NhdGlvbiA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYWN0aXZlRWwuaWQgPT0gXCJtQmlydGhMb2NhdGlvblwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2hpY2hMb2NhdGlvbiA9IFwiQmlydGhcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhY3RpdmVFbC5pZCA9PSBcIm1EZWF0aExvY2F0aW9uXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aGljaExvY2F0aW9uID0gXCJEZWF0aFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFjdGl2ZUVsLm5hbWUgPT0gXCJtTWFycmlhZ2VMb2NhdGlvblwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2hpY2hMb2NhdGlvbiA9IFwiTWFycmlhZ2VcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkVGV4dCA9IGFkZGVkX25vZGUudGV4dENvbnRlbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50QmlydGhZZWFyTWF0Y2ggPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudERlYXRoWWVhck1hdGNoID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRNYXJyaWFnZVllYXJNYXRjaCA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoJChcIiNtQmlydGhEYXRlXCIpLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRCaXJ0aFllYXJNYXRjaCA9ICQoXCIjbUJpcnRoRGF0ZVwiKS52YWwoKS5tYXRjaCgvWzAtOV17Myw0fS8pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQoXCIjbURlYXRoRGF0ZVwiKS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50RGVhdGhZZWFyTWF0Y2ggPSAkKFwiI21EZWF0aERhdGVcIikudmFsKCkubWF0Y2goL1swLTldezMsNH0vKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgkKFwiI21NYXJyaWFnZURhdGVcIikubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudE1hcnJpYWdlWWVhck1hdGNoID0gJChcIiNtTWFycmlhZ2VEYXRlXCIpLnZhbCgpLm1hdGNoKC9bMC05XXszLDR9Lyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRZZWFyID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRZZWFyID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBnb29kRGF0ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGZhbWlseUxvYyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGZhbWlseUxvYzIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHllYXJzTWF0Y2ggPSBkVGV4dC5tYXRjaCgvXFwoW15BLXpdKlswLTldezMsNH0uKlxcKS9nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh5ZWFyc01hdGNoICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5ZWFycyA9IHllYXJzTWF0Y2hbMF0ucmVwbGFjZUFsbCgvWygpXS9nLCBcIlwiKS5zcGxpdChcIi1cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyh5ZWFycyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHllYXJzWzBdLnRyaW0oKSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0WWVhciA9IHllYXJzWzBdLnRyaW0oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHllYXJzWzFdLnRyaW0oKSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZFllYXIgPSB5ZWFyc1sxXS50cmltKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ29vZERhdGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG15WWVhciA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudEJpcnRoWWVhck1hdGNoICE9IG51bGwgJiYgd2hpY2hMb2NhdGlvbiA9PSBcIkJpcnRoXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBteVllYXIgPSBjdXJyZW50QmlydGhZZWFyTWF0Y2hbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjdXJyZW50RGVhdGhZZWFyTWF0Y2ggIT0gbnVsbCAmJiB3aGljaExvY2F0aW9uID09IFwiRGVhdGhcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG15WWVhciA9IGN1cnJlbnREZWF0aFllYXJNYXRjaFswXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGN1cnJlbnRNYXJyaWFnZVllYXJNYXRjaCAhPSBudWxsICYmIHdoaWNoTG9jYXRpb24gPT0gXCJNYXJyaWFnZVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXlZZWFyID0gY3VycmVudE1hcnJpYWdlWWVhck1hdGNoWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG15WWVhciAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHN0YXJ0WWVhciA9PSBcIlwiICYmIHBhcnNlSW50KG15WWVhcikgPCBwYXJzZUludChlbmRZZWFyKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnb29kRGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGVuZFllYXIgPT0gXCJcIiAmJiBwYXJzZUludChteVllYXIpID4gcGFyc2VJbnQoc3RhcnRZZWFyKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnb29kRGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHBhcnNlSW50KG15WWVhcikgPiBwYXJzZUludChzdGFydFllYXIpICYmIHBhcnNlSW50KG15WWVhcikgPCBwYXJzZUludChlbmRZZWFyKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnb29kRGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ29vZERhdGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LmJkTG9jYXRpb25zLmZvckVhY2goZnVuY3Rpb24gKGFMb2MpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkVGV4dCA9IGRUZXh0LnNwbGl0KFwiKFwiKVswXS50cmltKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNpbWlsYXJpdHkoYUxvYywgZFRleHQpID4gMC44KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZhbWlseUxvYyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzaW1pbGFyaXR5KGFMb2MsIGRUZXh0KSA+IDAuOTUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmFtaWx5TG9jMiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRoZUNvbnRhaW5lciA9ICQoYWRkZWRfbm9kZSkuY2xvc2VzdChcIi5hdXRvY29tcGxldGUtc3VnZ2VzdGlvbi1jb250YWluZXJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZ29vZERhdGUgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoZUNvbnRhaW5lci5hZGRDbGFzcyhcInJpZ2h0UGVyaW9kXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmYW1pbHlMb2MyID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhlQ29udGFpbmVyLmFkZENsYXNzKFwiZmFtaWx5TG9jMlwiKS5wcmVwZW5kVG8oJChcIi5hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnNcIikpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChmYW1pbHlMb2MgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGVDb250YWluZXIuYWRkQ2xhc3MoXCJmYW1pbHlMb2MxXCIpLnByZXBlbmRUbygkKFwiLmF1dG9jb21wbGV0ZS1zdWdnZXN0aW9uc1wiKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhlQ29udGFpbmVyLmFkZENsYXNzKFwid3JvbmdQZXJpb2RcIikuYXBwZW5kVG8oJChcIi5hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnNcIikpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyMi5vYnNlcnZlKCQoXCIuYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zXCIpLmVxKDApWzBdLCB7IHN1YnRyZWU6IGZhbHNlLCBjaGlsZExpc3Q6IHRydWUgfSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoJChcIiNtRGVhdGhMb2NhdGlvblwiKS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBvYnNlcnZlcjIub2JzZXJ2ZSgkKFwiLmF1dG9jb21wbGV0ZS1zdWdnZXN0aW9uc1wiKS5lcSgxKVswXSwgeyBzdWJ0cmVlOiBmYWxzZSwgY2hpbGRMaXN0OiB0cnVlIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCAzMDAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbG9jYXRpb25zSGVscGVyKCk7XHJcbiAgICB9XHJcbn0pO1xyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQge2NyZWF0ZVRvcE1lbnVJdGVtfSBmcm9tICcuLi8uLi9jb3JlL2NvbW1vbic7XHJcblxyXG5jaHJvbWUuc3RvcmFnZS5zeW5jLmdldCgncHJpbnRlckZyaWVuZGx5JywgKHJlc3VsdCkgPT4ge1xyXG5cdGlmIChyZXN1bHQucHJpbnRlckZyaWVuZGx5KSB7XHJcblx0XHQvLyBjcmVhdGUgYSB0b3AgbWVudSBpdGVtXHJcblx0XHRjcmVhdGVUb3BNZW51SXRlbSh7XHJcblx0XHRcdHRpdGxlOiAnQ2hhbmdlcyB0aGUgZm9ybWF0IHRvIGEgcHJpbnRlci1mcmllbmRseSBvbmUuJyxcclxuXHRcdFx0bmFtZTogJ1ByaW50ZXIgRnJpZW5kbHkgQmlvJyxcclxuXHRcdFx0aWQ6ICd3dGUtdG0tcHJpbnRlci1mcmllbmRseSdcclxuXHRcdH0pO1xyXG5cclxuXHRcdCQoYCN3dGUtdG0tcHJpbnRlci1mcmllbmRseWApLm9uKCdjbGljaycsICgpID0+IHtcclxuXHRcdFx0cHJpbnRCaW8oKTtcclxuXHRcdH0pO1xyXG5cdH1cclxufSk7XHJcblxyXG4vLyBtb2RpZmllZCBjb2RlIGZyb20gU3RldmVuJ3MgV2lraVRyZWUgVG9vbGtpdFxyXG5mdW5jdGlvbiBwcmludEJpbygpIHtcclxuXHR2YXIgcFRpdGxlQ2xlYW4gPSAkKGRvY3VtZW50KS5hdHRyKCd0aXRsZScpO1xyXG5cdHZhciBwVGl0bGVDbGVhbmVyID0gcFRpdGxlQ2xlYW4ucmVwbGFjZSgnIHwgV2lraVRyZWUgRlJFRSBGYW1pbHkgVHJlZScsICcnKTtcclxuXHR2YXIgcFRpdGxlID0gcFRpdGxlQ2xlYW5lci5yZXBsYWNlKCcgLSBXaWtpVHJlZSBQcm9maWxlJywgJycpO1xyXG5cdHZhciBwSW1hZ2UgPSAkKFwiaW1nW3NyY149Jy9waG90by5waHAvJ11cIikuYXR0cignc3JjJyk7XHJcblx0dmFyIHBUaXRsZUluc2VydCA9ICQoJ2gyJykuZmlyc3QoKTtcclxuXHRwVGl0bGVJbnNlcnQuYmVmb3JlKFxyXG5cdFx0YDxkaXY+XHJcblx0XHRcdDxpbWcgc3R5bGU9XCJmbG9hdDpsZWZ0O1wiIHNyYz1cImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbSR7cEltYWdlfVwiIHdpZHRoPVwiNzVcIiBoZWlnaHQ9XCI3NVwiPlxyXG5cdFx0XHQ8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAyLjE0MjllbTsgbGluZS1oZWlnaHQ6IDEuNGVtOyBtYXJnaW4tYm90dG9tOjUwcHg7IHBhZGRpbmc6IDIwcHggMTAwcHg7XCI+XHJcblx0XHRcdFx0JHtwVGl0bGV9XHJcblx0XHRcdDwvZGl2PlxyXG5cdFx0PC9kaXY+YFxyXG5cdCk7XHJcblxyXG5cdCQoXCJhW3RhcmdldD0nX0hlbHAnXVwiKS5wYXJlbnQoKS5yZW1vdmUoKTtcclxuXHQkKFwic3Bhblt0aXRsZSo9J2ZvciB0aGUgcHJvZmlsZSBhbmQnXVwiKS5wYXJlbnQoKS5yZW1vdmUoKTtcclxuXHQkKFwiZGl2W3N0eWxlPSdiYWNrZ3JvdW5kLWNvbG9yOiNlMWVmYmI7J11cIikucmVtb3ZlKCk7XHJcblx0JChcImRpdltzdHlsZT0nYmFja2dyb3VuZC1jb2xvcjojZWVlOyddXCIpLnJlbW92ZSgpO1xyXG5cdCQoXCJhW2hyZWZePScvdHJlZXdpZGdldC8nXVwiKS5yZW1vdmUoKTtcclxuXHQkKFwiYVtocmVmPScvZzJnLyddXCIpLnJlbW92ZSgpO1xyXG5cdCQoXCJhW2NsYXNzPSdub2hvdmVyJ11cIikucmVtb3ZlKCk7XHJcblxyXG5cdCQoJ2RpdicpLnJlbW92ZUNsYXNzKCd0ZW4gY29sdW1ucycpO1xyXG5cdCQoJy5WSVRBTFMnKS5yZW1vdmUoKTtcclxuXHQkKCcuc3RhcicpLnJlbW92ZSgpO1xyXG5cdCQoJy5wcm9maWxlLXRhYnMnKS5yZW1vdmUoKTtcclxuXHQvLyQoXCIuU01BTExcIikucmVtb3ZlKCk7XHJcblx0JCgnLnNob3doaWRldHJlZScpLnJlbW92ZSgpO1xyXG5cdCQoJy5yb3cnKS5yZW1vdmUoKTtcclxuXHQkKCcuYnV0dG9uJykucmVtb3ZlKCk7XHJcblx0JCgnLmxhcmdlJykucmVtb3ZlKCk7XHJcblx0JCgnLnNpeHRlZW4nKS5yZW1vdmUoKTtcclxuXHQkKCcuZml2ZScpLnJlbW92ZSgpO1xyXG5cdCQoJy5lZGl0c2VjdGlvbicpLnJlbW92ZSgpO1xyXG5cdCQoJy5FRElUJykucmVtb3ZlKCk7XHJcblx0JCgnLmNvbW1lbnQtYWJzZW50JykucmVtb3ZlKCk7XHJcblx0JCgnLmJveCcpLnJlbW92ZSgpO1xyXG5cclxuXHQkKCcjdmlld3Mtd3JhcCcpLnJlbW92ZSgpO1xyXG5cdCQoJyNmb290ZXInKS5yZW1vdmUoKTtcclxuXHQkKCcjY29tbWVudFBvc3REaXYnKS5yZW1vdmUoKTtcclxuXHQkKCcjY29tbWVudHMnKS5yZW1vdmUoKTtcclxuXHQkKCcjY29tbWVudEVkaXREaXYnKS5yZW1vdmUoKTtcclxuXHQkKCcjY29tbWVudEcyR0RpdicpLnJlbW92ZSgpO1xyXG5cdCQoJyNoZWFkZXInKS5yZW1vdmUoKTtcclxuXHQkKCcjc2hvd0hpZGVEZXNjZW5kYW50cycpLnJlbW92ZSgpO1xyXG5cclxuXHR3aW5kb3cucHJpbnQoKTtcclxuXHRsb2NhdGlvbi5yZWxvYWQoKTtcclxufVxyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoJ3JhbmRvbVByb2ZpbGUnLCAocmVzdWx0KSA9PiB7XHJcblx0aWYgKHJlc3VsdC5yYW5kb21Qcm9maWxlICYmICQoXCJib2R5LkJFRVwiKS5sZW5ndGg9PTApIHtcclxuICAgICAgICBmdW5jdGlvbiBnZXRSYW5kb21Qcm9maWxlKCkge1xyXG4gICAgICAgICAgICB2YXIgcmFuZG9tUHJvZmlsZUlEID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMzYwNjU5ODgpO1xyXG4gICAgICAgICAgICB2YXIgbGluayA9ICcnO1xyXG4gICAgICAgICAgICAvLyBjaGVjayBpZiBleGlzdHNcclxuICAgICAgICAgICAgJC5nZXRKU09OKCdodHRwczovL2FwaS53aWtpdHJlZS5jb20vYXBpLnBocD9hY3Rpb249Z2V0UGVyc29uJmtleT0nICsgcmFuZG9tUHJvZmlsZUlEKVxyXG4gICAgICAgICAgICAgICAgLmRvbmUoZnVuY3Rpb24gKGpzb24pIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjaGVjayB0byBzZWUgaWYgdGhlIHByb2ZpbGUgaXMgT3BlblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChqc29uWzBdWydzdGF0dXMnXSA9PSAwICYmICdQcml2YWN5X0lzT3BlbicgaW4ganNvblswXVsncGVyc29uJ10gJiYganNvblswXVsncGVyc29uJ11bJ1ByaXZhY3lfSXNPcGVuJ10pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGluayA9ICdodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS8nICsgcmFuZG9tUHJvZmlsZUlEO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24gPSBsaW5rO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7IC8vIElmIGl0IGlzbid0IG9wZW4sIGZpbmQgYSBuZXcgcHJvZmlsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRSYW5kb21Qcm9maWxlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5mYWlsKGZ1bmN0aW9uIChqcVhIUiwgdGV4dFN0YXR1cywgZXJyb3JUaHJvd24pIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZ2V0SlNPTiByZXF1ZXN0IGZhaWxlZCEgJyArIHRleHRTdGF0dXMgKyAnICcgKyBlcnJvclRocm93bik7XHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0UmFuZG9tUHJvZmlsZSgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBhZGQgcmFuZG9tIG9wdGlvbiB0byAnRmluZCdcclxuICAgICAgICBhc3luYyBmdW5jdGlvbiBhZGRSYW5kb21Ub0ZpbmRNZW51KCkge1xyXG4gICAgICAgICAgICBjb25zdCByZWxhdGlvbnNoaXBMaSA9ICQoXCJsaSBhLnB1cmVDc3NNZW51aVtocmVmPScvd2lraS9TcGVjaWFsOlJlbGF0aW9uc2hpcCddXCIpO1xyXG4gICAgICAgICAgICBjb25zdCBuZXdMaSA9ICQoXCI8bGk+PGEgY2xhc3M9J3B1cmVDc3NNZW51aSByYW5kb21Qcm9maWxlJyB0aXRsZT0nR28gdG8gYSByYW5kb20gcHJvZmlsZSc+UmFuZG9tIFByb2ZpbGU8L2xpPlwiKTtcclxuICAgICAgICAgICAgbmV3TGkuaW5zZXJ0QmVmb3JlKHJlbGF0aW9uc2hpcExpLnBhcmVudCgpKTtcclxuICAgICAgICAgICAgJChcIi5yYW5kb21Qcm9maWxlXCIpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICBnZXRSYW5kb21Qcm9maWxlKClcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgYWRkUmFuZG9tVG9GaW5kTWVudSgpO1xyXG4gICAgfVxyXG59KVxyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoJ3NQcmV2aWV3cycsIGZ1bmN0aW9uIChyZXN1bHQpIHtcclxuICAgIGlmIChyZXN1bHQuc1ByZXZpZXdzID09IHRydWUpIHtcclxuICAgICAgICBzb3VyY2VQcmV2aWV3KCk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIHNvdXJjZVByZXZpZXcoKSB7XHJcbiAgICAgICAgICAgIGlmICgkKCcucmVmZXJlbmNlJykubGVuZ3RoKSB7IC8vIGFuZCBvbmx5IGlmIGlubGluZSBjaXRhdGlvbnMgYXJlIGZvdW5kXHJcbiAgICAgICAgICAgICAgICAkKCcucmVmZXJlbmNlJykuaG92ZXIoZnVuY3Rpb24gKGUpIHsgLy8ganF1ZXJ5LmhvdmVyKCkgaGFuZGxlckluIChzaG93IHNvdXJjZVByZXZpZXcpXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNvdXJjZUlEID0gdGhpcy5pZC5yZXBsYWNlKCdyZWYnLCAnbm90ZScpLnJlcGxhY2UoLyhfWzAtOV0rJCkvZywgJycpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBzUHJldmlldyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNQcmV2aWV3LnNldEF0dHJpYnV0ZSgnaWQnLCAnc291cmNlUHJldmlldycpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNQcmV2aWV3LnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnYm94IHJvdW5kZWQnKTtcclxuICAgICAgICAgICAgICAgICAgICBzUHJldmlldy5zZXRBdHRyaWJ1dGUoJ3N0eWxlJywgJ3otaW5kZXg6OTk5OyB3aWR0aDogNDUwcHg7IHBvc2l0aW9uOmFic29sdXRlOycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHRoaXMuaWQpLmFwcGVuZENoaWxkKHNQcmV2aWV3KTtcclxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc291cmNlUHJldmlldycpLmlubmVySFRNTCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHNvdXJjZUlEKS5pbm5lckhUTUw7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGpxZXVyeS5ob3ZlcigpIGhhbmRsZXJPdXQgKHJlbW92ZSBzb3VyY2VQcmV2aWV3KVxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJCgnI3NvdXJjZVByZXZpZXcnKS5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgdGFyZ2V0Tm9kZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwcmV2aWV3Ym94Jyk7XHJcbiAgICAgICAgY29uc3QgY29uZmlnID0geyBjaGlsZExpc3Q6IHRydWUgfTtcclxuICAgICAgICBjb25zdCBjYWxsYmFjayA9IChtdXRhdGlvbkxpc3QsIG9ic2VydmVyKSA9PiB7XHJcbiAgICAgICAgICAgIGZvciAoY29uc3QgbXV0YXRpb24gb2YgbXV0YXRpb25MaXN0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAobXV0YXRpb24udHlwZSA9PT0gJ2NoaWxkTGlzdCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBzb3VyY2VQcmV2aWV3KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoY2FsbGJhY2spO1xyXG4gICAgICAgIGlmICgkKCcjcHJldmlld2JveCcpLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZSh0YXJnZXROb2RlLCBjb25maWcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSlcclxuIiwiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0ICcuLi8uLi90aGlyZHBhcnR5L2pxdWVyeS5ob3ZlckRlbGF5J1xyXG5cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJzcGFjZVByZXZpZXdzXCIsIGZ1bmN0aW9uIChyZXN1bHQpIHtcclxuICBpZiAocmVzdWx0LnNwYWNlUHJldmlld3MgPT0gdHJ1ZSkge1xyXG4gICAgJCgnLnRlbi5jb2x1bW5zIGFbaHJlZio9XCIvd2lraS9TcGFjZTpcIl0sIC5zaXh0ZWVuLmNvbHVtbnMgYVtocmVmKj1cIi93aWtpL1NwYWNlOlwiXScpLmhvdmVyRGVsYXkoe1xyXG4gICAgICBkZWxheUluOiAxMDAwLFxyXG4gICAgICBkZWxheU91dDogMCxcclxuICAgICAgaGFuZGxlckluOiBmdW5jdGlvbiAoJGVsZW1lbnQpIHtcclxuICAgICAgICAkKFwiI3NwYWNlUHJldmlld1wiKS5yZW1vdmUoKTtcclxuICAgICAgICAkKFwiI3NwYWNlSG92ZXJcIikuYXR0cihcImlkXCIsIFwiXCIpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCRlbGVtZW50WzBdLmhyZWYpO1xyXG4gICAgICAgICRlbGVtZW50LmF0dHIoXCJpZFwiLCBcInNwYWNlSG92ZXJcIik7XHJcbiAgICAgICAgdmFyIHNQcmV2aWV3ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgICBzUHJldmlldy5zZXRBdHRyaWJ1dGUoXCJpZFwiLCBcInNwYWNlUHJldmlld1wiKTtcclxuICAgICAgICBzUHJldmlldy5zZXRBdHRyaWJ1dGUoXCJjbGFzc1wiLCBcImJveCByb3VuZGVkXCIpO1xyXG4gICAgICAgIHNQcmV2aWV3LnNldEF0dHJpYnV0ZShcclxuICAgICAgICAgIFwic3R5bGVcIixcclxuICAgICAgICAgIGB6LWluZGV4Ojk5OTk7IG1heC1oZWlnaHQ6NDUwcHg7IG92ZXJmbG93OiBzY3JvbGw7IHBvc2l0aW9uOmFic29sdXRlOyBwYWRkaW5nOiAxMHB4OyBtYXJnaW4tdG9wOi0yMHB4O2BcclxuICAgICAgICApO1xyXG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic3BhY2VIb3ZlclwiKS5wYXJlbnRFbGVtZW50LmFwcGVuZENoaWxkKHNQcmV2aWV3KTtcclxuICAgICAgICAkLmFqYXgoe1xyXG4gICAgICAgICAgdXJsOiAkZWxlbWVudFswXS5ocmVmLFxyXG4gICAgICAgICAgY29udGV4dDogZG9jdW1lbnQuYm9keSxcclxuICAgICAgICB9KS5kb25lKGZ1bmN0aW9uIChyZXN1bHQpIHtcclxuICAgICAgICAgIHZhciBwYWdlQ29udGVudCA9ICQocmVzdWx0KS5maW5kKFwiLnRlbi5jb2x1bW5zXCIpLmh0bWwoKTtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFxyXG4gICAgICAgICAgICAgIFwic3BhY2VQcmV2aWV3XCJcclxuICAgICAgICAgICAgKS5pbm5lckhUTUwgPSBgPHNwYW4gc3R5bGU9XCJmbG9hdDpyaWdodDsgZm9udC13ZWlnaHQ6NzAwO1wiPmNsaWNrIG91dHNpZGUgdG8gY2xvc2U8L3NwYW4+JHtwYWdlQ29udGVudH1gO1xyXG4gICAgICAgICAgfSBjYXRjaCB7fVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gICQoZG9jdW1lbnQpLm9uKFwiY2xpY2tcIiwgZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICBpZiAoJChldmVudC50YXJnZXQpLmNsb3Nlc3QoXCIjc3BhY2VQcmV2aWV3XCIpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAkKFwiI3NwYWNlUHJldmlld1wiKS5yZW1vdmUoKTtcclxuICAgICAgJChcIiNzcGFjZUhvdmVyXCIpLmF0dHIoXCJpZFwiLCBcIlwiKTtcclxuICAgIH1cclxuICB9KTtcclxufSk7XHJcbiIsImltcG9ydCAnLi93dFBsdXMuY3NzJztcclxuXHJcbmxldCB0YiA9IHt9O1xyXG5cclxuZnVuY3Rpb24gaXRlbXNGaW5kQnlUZW1wbGF0ZShuYW1lKSB7XHJcblx0cmV0dXJuIHRiLnRlbXBsYXRlcy5maWx0ZXIoaXRlbSA9PiBpdGVtLm5hbWUudG9VcHBlckNhc2UoKSA9PT0gbmFtZS50b1VwcGVyQ2FzZSgpKVswXVxyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJhbXNDb3B5ICh0ZW1wbGF0ZU5hbWUpe1xyXG5cdHRiLnRlbXBsYXRlID0gaXRlbXNGaW5kQnlUZW1wbGF0ZSh0ZW1wbGF0ZU5hbWUpOyBcclxuXHR0Yi50ZW1wbGF0ZWl0ZW1zID0gdGIudGVtcGxhdGUucHJvcC5tYXAoaXRlbSA9PiB7ICAgICAgICBcclxuXHRcdHJldHVybiB7XHJcblx0XHRcdG5hbWU6IGl0ZW0ubmFtZSxcclxuXHRcdFx0dHlwZTogaXRlbS50eXBlLFxyXG5cdFx0XHR1c2FnZTogaXRlbS51c2FnZSxcclxuXHRcdFx0bnVtYmVyZWQ6IGl0ZW0ubnVtYmVyZWQsXHJcblx0XHRcdGluaXRpYWw6IGl0ZW0uaW5pdGlhbCxcclxuXHRcdFx0aGVscDogaXRlbS5oZWxwLFxyXG5cdFx0XHRleGFtcGxlOiBpdGVtLmV4YW1wbGUsXHJcblx0XHRcdGdyb3VwOiBpdGVtLmdyb3VwLFxyXG5cdFx0XHR2YWx1ZXM6IGl0ZW0udmFsdWVzIHx8IFtdLCBcclxuXHRcdFx0dmFsdWU6ICcnXHJcblx0XHR9XHJcblx0fSlcclxuXHR0Yi51bmtub3duUGFyYW1zID0gJydcclxufVxyXG5cclxuZnVuY3Rpb24gcGFyYW1zRnJvbVNlbGVjdGlvbigpe1xyXG5cdC8vZmluZHMgbWVudSBpdGVtXHJcbi8vICAgIHZhciBwYXJhbXMgPSB0Yi50ZXh0U2VsZWN0ZWQuc3BsaXQoLy4qP1xcfFxccyooW157fVtcXF18XSo/KD86XFxbXFxbW157fVtcXF18XSo/KD86XFx8W157fVtcXF18XSo/KSo/W157fVtcXF18XSo/XFxdXFxdW157fVtcXF18XSo/fFxce1xce1tee31bXFxdfF0qPyg/OlxcfFtee31bXFxdfF0qPykqP1tee31bXFxdfF0qP1xcfVxcfVtee31bXFxdfF0qPykqP1tee31bXFxdfF0qPylcXHMqKD86KD89XFx8KXx9fSkvZykubWFwKHBhciA9PiBwYXIudHJpbSgpKS5maWx0ZXIocGFyID0+IHBhciAhPSAnJyk7XHJcblx0dmFyIHBhcmFtcyA9IHRiLnRleHRTZWxlY3RlZC5zcGxpdCgvXFx8XFxzKihbXnt9W1xcXXxdKj8oPzpcXFtcXFtbXnt9W1xcXXxdKj8oPzpcXHxbXnt9W1xcXXxdKj8pKj9bXnt9W1xcXXxdKj9cXF1cXF1bXnt9W1xcXXxdKj98XFx7XFx7W157fVtcXF18XSo/KD86XFx8W157fVtcXF18XSo/KSo/W157fVtcXF18XSo/XFx9XFx9W157fVtcXF18XSo/KSo/W157fVtcXF18XSo/KVxccyooPzooPz1cXHwpfH19KS9nKS5tYXAocGFyID0+IHBhci50cmltKCkpLmZpbHRlcihwYXIgPT4gcGFyICE9ICcnKTtcclxuXHR0Yi50ZXh0U2VsZWN0ZWQgPSB0Yi50ZXh0U2VsZWN0ZWQucmVwbGFjZSgne3snLCAnJykucmVwbGFjZSgnfX0nLCAnJyk7XHJcblx0cGFyYW1zWzBdID0gcGFyYW1zWzBdLnJlcGxhY2UoJ3t7JywgJycpLnJlcGxhY2UoJ319JywgJycpLnJlcGxhY2UoJ18nLCAnICcpXHJcblx0dGIudGVtcGxhdGUgPSBpdGVtc0ZpbmRCeVRlbXBsYXRlKHBhcmFtc1swXSk7IFxyXG5cdGlmICh0Yi50ZW1wbGF0ZSkge1xyXG5cdFx0cGFyYW1zLnNwbGljZSgwLCAxKTtcclxuXHRcdHZhciBwYXJhbXNOdW1iZXJlZCA9IHBhcmFtcy5maWx0ZXIocGFyID0+ICEocGFyLmluY2x1ZGVzKCc9JykpKTtcclxuXHRcdHZhciBwYXJhbXNOYW1lZCA9IHBhcmFtcy5maWx0ZXIocGFyID0+IHBhci5pbmNsdWRlcygnPScpKS5tYXAoaXRlbSA9PiBpdGVtLnNwbGl0KFwiPVwiKS5tYXAocGFyID0+IHBhci50cmltKCkpKTtcclxuXHRcdHRiLnRlbXBsYXRlaXRlbXMgPSB0Yi50ZW1wbGF0ZS5wcm9wLm1hcChpdGVtID0+IHtcclxuXHRcdFx0dmFyIHg7XHJcblx0XHRcdGlmIChpdGVtLm51bWJlcmVkKSB7XHJcblx0XHRcdFx0eCA9IHBhcmFtc051bWJlcmVkW2l0ZW0ubnVtYmVyZWQtMV1cclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHR4ID0gcGFyYW1zTmFtZWQuZmlsdGVyKHBhciA9PiBwYXJbMF0udG9VcHBlckNhc2UoKSA9PT0gaXRlbS5uYW1lLnRvVXBwZXJDYXNlKCkpLm1hcChwYXIgPT4gcGFyWzFdKS5qb2luKCcnKTtcclxuXHRcdFx0fTtcclxuXHRcdFx0aWYgKCF4KSB7eCA9ICcnfTtcclxuXHRcdFx0cmV0dXJuIHtcclxuXHRcdFx0XHRuYW1lOiBpdGVtLm5hbWUsXHJcblx0XHRcdFx0dHlwZTogaXRlbS50eXBlLFxyXG5cdFx0XHRcdHVzYWdlOiBpdGVtLnVzYWdlLFxyXG5cdFx0XHRcdG51bWJlcmVkOiBpdGVtLm51bWJlcmVkLFxyXG5cdFx0XHRcdGluaXRpYWw6IGl0ZW0uaW5pdGlhbCxcclxuXHRcdFx0XHRoZWxwOiBpdGVtLmhlbHAsXHJcblx0XHRcdFx0ZXhhbXBsZTogaXRlbS5leGFtcGxlLFxyXG5cdFx0XHRcdGdyb3VwOiBpdGVtLmdyb3VwLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcblx0XHRcdFx0dmFsdWVzOiBpdGVtLnZhbHVlcyB8fCBbXSwgXHJcblx0XHRcdFx0dmFsdWU6IHgudHJpbSgpXHJcblx0XHRcdH0gICAgICAgICAgICBcclxuXHRcdH0pXHJcblx0XHR2YXIgdW5rbm93bk5hbWVkID0gcGFyYW1zTmFtZWQuZmlsdGVyKHBhciA9PiAhQm9vbGVhbih0Yi50ZW1wbGF0ZWl0ZW1zLmZpbmQodGkgPT4gdGkubmFtZS50b1VwcGVyQ2FzZSgpID09PSBwYXJbMF0udG9VcHBlckNhc2UoKSkpKSAgICAgICAgXHJcblx0XHR2YXIgdW5rbm93bk51bWJlcmVkID0gcGFyYW1zTnVtYmVyZWQuZmlsdGVyKChwYXIsIGkpID0+ICFCb29sZWFuKHRiLnRlbXBsYXRlaXRlbXMuZmluZCh0aSA9PiB0aS5udW1iZXJlZCA9PT0gaSsxKSkpXHJcblx0XHR0Yi51bmtub3duUGFyYW1zID0gdW5rbm93bk5hbWVkLm1hcChpID0+ICd8JyArIGlbMF0gKyAnPSAnICsgaVsxXSkuY29uY2F0KHVua25vd25OdW1iZXJlZC5tYXAoaSA9PiAnfCcgKyBpKSkuam9pbignXFxuJylcclxuXHR9IGVsc2Uge1xyXG5cdFx0YWxlcnQgKCdUZW1wbGF0ZSBcIicgKyBwYXJhbXNbMF0gKyAnXCIgaXMgbm90IHJlY29nbmlzZWQgYnkgdGhlIGV4dGVuc2lvbicpXHJcblx0fSAgIFxyXG59O1xyXG5cclxuZnVuY3Rpb24gcGFyYW1zSW5pdGlhbFZhbHVlcyAoKXtcclxuXHRpZiAodGIudGVtcGxhdGVpdGVtcyAmJiB0Yi50ZW1wbGF0ZWl0ZW1zLmxlbmd0aCkge1xyXG5cdFx0Zm9yIChsZXQgcHJvcCBvZiB0Yi50ZW1wbGF0ZWl0ZW1zKSB7XHJcblx0XHRcdGlmIChwcm9wLnZhbHVlID09PSAnJyAmJiBwcm9wLmluaXRpYWwpIHtcclxuXHRcdFx0XHRpZiAocHJvcC5pbml0aWFsLnN0YXJ0c1dpdGgoXCJUaXRsZTpcIikpIHtcclxuXHRcdFx0XHRcdHByb3AudmFsdWUgPSBkb2N1bWVudC50aXRsZS5yZXBsYWNlKFJlZ0V4cChwcm9wLmluaXRpYWwuc3Vic3RyaW5nKDYpKSwgJyQxJyk7XHJcblx0XHRcdFx0fSAgICBcclxuXHRcdFx0XHRpZiAocHJvcC5pbml0aWFsLnN0YXJ0c1dpdGgoXCJDYXRlZ29yeTpcIikgJiYgKHRiLmNhdGVnb3JpZXMpKSB7XHJcblx0XHRcdFx0XHR2YXIgciA9IFJlZ0V4cChwcm9wLmluaXRpYWwuc3Vic3RyaW5nKDkpLCAnbWcnKVxyXG5cdFx0XHRcdFx0dmFyIGEgPSB0Yi5jYXRlZ29yaWVzLm1hdGNoKHIpXHJcblx0XHRcdFx0XHRwcm9wLnZhbHVlID0gKChhKSA/IGEuam9pbignXFxuJykucmVwbGFjZShyLCAnJDEnKSA6ICcnIClcclxuXHRcdFx0XHR9ICAgIFxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG5mdW5jdGlvbiByZWZvcm1hdENvb3J0b1VSTCAocykge1xyXG5cdHJldHVybiAnaHR0cHM6Ly93d3cub3BlbnN0cmVldG1hcC5vcmcvI21hcD0xOC8nICsgcy5yZXBsYWNlICgnLCcsICcvJykucmVwbGFjZSAoJyUyMCcsICcnKVxyXG59XHJcblxyXG5mdW5jdGlvbiByZWZvcm1hdFVSTHRvQ29vciAocykge1xyXG5cdGlmIChzLm1hdGNoICggL14gKltcXGRdKiAqwrAgKltcXGRdKiAqW+KAsiddICooW1xcZC5dKiAqW+KAs+KAnVwiXSk/ICpbTlNdWywgXSpbXFxkXSogKsKwICpbXFxkXSogKlvigLInXSAqKFtcXGQuXSogKlvigLPigJ1cIl0pPyAqW0VXXSAqJC9tZ2kpKSB7XHJcblx0XHQvLyAzMsKwNDInMTYuMDJcIk4sIDE3wrA4JzAuNjdcIldcclxuXHRcdGxldCBzMSA9IHMucmVwbGFjZShcclxuXHRcdFx0L14gKihbXFxkXXsxLDJ9KSAqwrAgKihbXFxkXXsxLDJ9KSAqW+KAsiddICooKFtcXGQuXXsxLDV9KSAqW+KAs+KAnVwiXSk/ICooW05TXSlbLCBdKihbXFxkXXsxLDN9KSAqwrAgKihbXFxkXXsxLDJ9KSAqW+KAsiddICooKFtcXGQuXXsxLDV9KSAqW+KAs+KAnVwiXSk/ICooW0VXXSkgKiQvbWdpLFxyXG5cdFx0XHQnJDE7JDI7JDQ7JDU7JDY7JDc7JDk7JDEwJylcclxuXHRcdGxldCBhcnIgPSBzMS5zcGxpdCgnOycpXHJcblx0XHR2YXIgbG9uLCBsYXRcclxuXHRcdGxhdCA9IChhcnJbM10gPT0gJ1MnID8gLTEgOiAxKSAqIChOdW1iZXIoYXJyWzBdKSArIE51bWJlcihhcnJbMV0pIC8gNjAgKyBOdW1iZXIoYXJyWzJdKSAvIDM2MDApXHJcblx0XHRsb24gPSAoYXJyWzddID09ICdXJyA/IC0xIDogMSkgKiAoTnVtYmVyKGFycls0XSkgKyBOdW1iZXIoYXJyWzVdKSAvIDYwICsgTnVtYmVyKGFycls2XSkgLyAzNjAwKVxyXG5cdFx0cmV0dXJuIHBhcnNlRmxvYXQobGF0LnRvRml4ZWQoNikpICsgJywgJyArIHBhcnNlRmxvYXQobG9uLnRvRml4ZWQoNikpXHJcblx0fSBlbHNlIGlmIChzLm1hdGNoICgvXmh0dHBzOlxcL1xcL3d3d1xcLm9wZW5zdHJlZXRtYXBcXC5vcmdcXC8jbWFwPVtcXGRdKlxcL1tcXGQuLV0qXFwvW1xcZC4tXSokL21naSkpIHtcclxuXHRcdC8vIGh0dHBzOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnLyNtYXA9MTUvMzIuNzA1MS8tMTcuMTIyMFxyXG5cdFx0bGV0IHMxID0gcy5yZXBsYWNlKFxyXG5cdFx0XHQvXmh0dHBzOlxcL1xcL3d3d1xcLm9wZW5zdHJlZXRtYXBcXC5vcmdcXC8jbWFwPVtcXGRdezEsMn1cXC8oW1xcZC4tXSopXFwvKFtcXGQuLV0qKSQvbWdpLFxyXG5cdFx0XHQnJDEsICQyJylcclxuXHRcdHJldHVybiBzMVxyXG5cdH0gZWxzZSB7ICBcclxuXHRcdHJldHVybiBzLnJlcGxhY2UgKCcvJywgJywgJylcclxuXHR9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlZm9ybWF0VGV4dHRvV2lraSAocykge1xyXG5cdHJldHVybiBzLnJlcGxhY2UgKC8gL2csICdfJyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlZm9ybWF0V2lraXRvVGV4dCAgKHMpIHtcclxuXHRyZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50IChzLnJlcGxhY2UgKC9fL2csICcgJykpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXROdW1iZXJ0b1NsYXNoICAocykge1xyXG5cdHJldHVybiBzLnJlcGxhY2UgKC8oXFxkKilcXC8uKi9nLCAnJDEnKTtcclxufVxyXG5cclxuY29uc3QgdXJsTWFwcGluZ3MgPSBbXHJcblx0e3R5cGU6IFwiXCIsIHBsYWNlaG9sZGVyOlwiVW5kZWZpbmVkIHR5cGVcIn0sXHJcblx0e3R5cGU6IFwidHlwZVRleHRcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciB0ZXh0XCJ9LFxyXG5cdHt0eXBlOiBcInR5cGVOdW1iZXJcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBhIG51bWJlclwifSxcclxuXHR7dHlwZTogXCJ0eXBlWWVhclwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIHllYXJcIn0sXHJcblx0e3R5cGU6IFwidHlwZVllc1wiLCBwbGFjZWhvbGRlcjpcIkVudGVyIHllc1wifSxcclxuXHR7dHlwZTogXCJ0eXBlTm9cIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBub1wifSxcclxuXHR7dHlwZTogXCJ0eXBlVVJMXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgVVJMIGh0dHBzOi8vLi4uXCIsIHByZWZpeFVSTDonJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnfSxcclxuXHR7dHlwZTogXCJ0eXBlV2lraXRyZWVJRFwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIHByb2ZpbGUncyBXaWtpdHJlZUlEXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnLCB0b1VSTDpyZWZvcm1hdFRleHR0b1dpa2ksIGZyb21VUkw6cmVmb3JtYXRXaWtpdG9UZXh0fSxcclxuXHR7dHlwZTogXCJ0eXBlUGFnZVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFBhZ2UgbmFtZSB3aXRoIE5hbWVzcGFjZVwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpLycsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJywgdG9VUkw6cmVmb3JtYXRUZXh0dG9XaWtpLCBmcm9tVVJMOnJlZm9ybWF0V2lraXRvVGV4dH0sXHJcblx0e3R5cGU6IFwidHlwZUNhdGVnb3J5XCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgQ2F0ZWdvcnkgb24gV2lraVRyZWVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9DYXRlZ29yeTonLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6JycsIHRvVVJMOnJlZm9ybWF0VGV4dHRvV2lraSwgZnJvbVVSTDpyZWZvcm1hdFdpa2l0b1RleHR9LFxyXG5cdHt0eXBlOiBcInR5cGVQcm9qZWN0TmVlZHNDYXRlZ29yeVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFByb2plY3QgTmVlZHMgY2F0ZWdvcnlcIiwgcHJlZml4VVJMOicnLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6Jyd9LFxyXG5cdHt0eXBlOiBcInR5cGVQcm9qZWN0XCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgUHJvamVjdCBvbiBXaWtpVHJlZVwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL1Byb2plY3Q6Jywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnLCB0b1VSTDpyZWZvcm1hdFRleHR0b1dpa2ksIGZyb21VUkw6cmVmb3JtYXRXaWtpdG9UZXh0fSxcclxuXHR7dHlwZTogXCJ0eXBlVGVhbVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFRlYW0gb2YgdGhlIHByb2plY3Qgb24gV2lraVRyZWVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9TcGFjZTonLCBzdWZpeFVSTDonIFRlYW0nLCBlbXB0eVVSTDonJywgdG9VUkw6cmVmb3JtYXRUZXh0dG9XaWtpLCBmcm9tVVJMOnJlZm9ybWF0V2lraXRvVGV4dH0sXHJcblx0e3R5cGU6IFwidHlwZVNwYWNlXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgU3BhY2UgcGFnZSBvbiBXaWtpVHJlZVwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL1NwYWNlOicsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJywgdG9VUkw6cmVmb3JtYXRUZXh0dG9XaWtpLCBmcm9tVVJMOnJlZm9ybWF0V2lraXRvVGV4dH0sXHJcblx0e3R5cGU6IFwidHlwZUltYWdlXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgSW1hZ2UgbmFtZVwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS93aWtpL0ltYWdlOicsIHN1Zml4VVJMOicnLCBlbXB0eVVSTDonJywgdG9VUkw6cmVmb3JtYXRUZXh0dG9XaWtpLCBmcm9tVVJMOnJlZm9ybWF0V2lraXRvVGV4dH0sXHJcblx0e3R5cGU6IFwidHlwZUcyR1wiLCBwbGFjZWhvbGRlcjpcIkVudGVyIHF1ZXN0aW9uIElEXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL2cyZy8nLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6JycsIGZyb21VUkw6Z2V0TnVtYmVydG9TbGFzaH0sXHJcblx0e3R5cGU6IFwidHlwZVdpa2lUcmVlQmxvZ1wiLCBwbGFjZWhvbGRlcjpcIkVudGVyIGJsb2cgbmFtZVwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9ibG9nLycsIHN1Zml4VVJMOicvJywgZW1wdHlVUkw6Jyd9LFxyXG5cdHt0eXBlOiBcInR5cGVXaWtpRGF0YVwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIFdpa2lEYXRhIGNvZGVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy53aWtpZGF0YS5vcmcvd2lraS8nLCBzdWZpeFVSTDonJ30sXHJcblx0e3R5cGU6IFwidHlwZVlvdVR1YmVcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBZb3VUdWJlIGNvZGVcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy55b3V0dWJlLmNvbS93YXRjaD92PScsIHN1Zml4VVJMOicnfSxcclxuXHR7dHlwZTogXCJ0eXBlRkFHSURcIiwgcGxhY2Vob2xkZXI6XCJFbnRlciBGaW5kQUdyYXZlIElEXCIsIHByZWZpeFVSTDonaHR0cHM6Ly93d3cuZmluZGFncmF2ZS5jb20vbWVtb3JpYWwvJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOicnLCBmcm9tVVJMOmdldE51bWJlcnRvU2xhc2h9LFxyXG5cdHt0eXBlOiBcInR5cGVGQUdDZW1JRFwiLCBwbGFjZWhvbGRlcjpcIkVudGVyIEZpbmRBR3JhdmUgQ2VtZXRlcnkgSURcIiwgcHJlZml4VVJMOidodHRwczovL3d3dy5maW5kYWdyYXZlLmNvbS9jZW1ldGVyeS8nLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6JycsIGZyb21VUkw6Z2V0TnVtYmVydG9TbGFzaH0sXHJcblx0e3R5cGU6IFwidHlwZUZBR0xvY0lEXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgRmluZEFHcmF2ZSBMb2NhdGlvbiBJRFwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vd3d3LmZpbmRhZ3JhdmUuY29tL2NlbWV0ZXJ5L3NlYXJjaD9sb2NhdGlvbklkPSd9LFxyXG5cdHt0eXBlOiBcInR5cGVCR0lEXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgQmlsbGlvbkdyYXZlcyBJRFwiLCBwcmVmaXhVUkw6J2h0dHBzOi8vYmlsbGlvbmdyYXZlcy5jb20vY2VtZXRlcnkvQ2VtZXRlcnkvJywgc3VmaXhVUkw6JycsIGVtcHR5VVJMOidodHRwczovL2JpbGxpb25ncmF2ZXMuY29tLyd9LFxyXG5cdHt0eXBlOiBcInR5cGVDb29yXCIsIHBsYWNlaG9sZGVyOlwiRW50ZXIgY29vcmRpbmF0ZSAxNS4xMjMsIC0zMy4yMTNcIiwgcHJlZml4VVJMOicnLCBzdWZpeFVSTDonJywgZW1wdHlVUkw6J2h0dHBzOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnLycsIHRvVVJMOnJlZm9ybWF0Q29vcnRvVVJMLCBmcm9tVVJMOnJlZm9ybWF0VVJMdG9Db29yfSxcclxuXHR7dHlwZTogXCJ0eXBlVE9DXCIsIHBsYWNlaG9sZGVyOlwiTm90IGVub3VnaCBwcmZpbGVzXCJ9LFxyXG5cdHt0eXBlOiBcInR5cGVSZWFkT25seVwifSxcclxuXTtcclxuXHJcbi8qIFNldHRpbmcgcmVzdWx0ICovXHJcblxyXG5mdW5jdGlvbiB1cGRhdGVFZGl0ICgpe1xyXG5cdGlmICh0Yi5lbEVuaGFuY2VkQWN0aXZlKSB7XHJcblx0XHR0Yi5lbEVuaGFuY2VkLmNsaWNrKCk7XHJcblx0fVxyXG5cdHRiLmVsVGV4dC52YWx1ZSA9IHRiLnRleHRSZXN1bHQ7XHJcblx0aWYgKHRiLmVsRW5oYW5jZWRBY3RpdmUpIHtcclxuXHRcdHRiLmVsRW5oYW5jZWQuY2xpY2soKTtcclxuXHR9XHJcblx0dGIuZWxUZXh0LnNldFNlbGVjdGlvblJhbmdlKHRiLnNlbFN0YXJ0LCB0Yi5zZWxFbmQpO1xyXG5cclxuXHRpZiAodGIuYmlydGhMb2NhdGlvblJlc3VsdCkge1xyXG5cdFx0dGIuZWxCaXJ0aExvY2F0aW9uLnZhbHVlID0gdGIuYmlydGhMb2NhdGlvblJlc3VsdFxyXG5cdH1cclxuXHRpZiAodGIuZGVhdGhMb2NhdGlvblJlc3VsdCkge1xyXG5cdFx0dGIuZWxEZWF0aExvY2F0aW9uLnZhbHVlID0gdGIuZGVhdGhMb2NhdGlvblJlc3VsdFxyXG5cdH1cclxuXHJcblx0aWYgKHRiLmVsU3VtbWFyeSkge1xyXG5cdFx0dGIuZWxTdW1tYXJ5LmZvY3VzKCk7XHJcblx0XHR2YXIgcyA9IHRiLmVsU3VtbWFyeS52YWx1ZTtcclxuXHRcdGlmIChzKSB7XHJcblx0XHRcdGlmIChzLmluZGV4T2YodGIuYWRkVG9TdW1tYXJ5KSA9PSAtMSkge1xyXG5cdFx0XHRcdHMgKz0gJywgJyArIHRiLmFkZFRvU3VtbWFyeVxyXG5cdFx0XHR9XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRzID0gdGIuYWRkVG9TdW1tYXJ5XHJcblx0XHR9O1xyXG5cdFx0dGIuZWxTdW1tYXJ5LnZhbHVlID0gcztcclxuXHR9XHJcblx0dGIuZWxUZXh0LmZvY3VzKCk7XHJcblx0dGIuYWRkVG9TdW1tYXJ5ID0gJydcclxuXHJcblx0Ly8gTGV0IHRoZSBwYWdlIGtub3cgdGhhdCBjaGFuZ2VzIGhhdmUgYmVlbiBtYWRlIHNvIHRoYXQgdGhlIFwiU2F2ZSBDaGFuZ2VzXCIgYnV0dG9uIHdvcmtzXHJcbi8vICAgIGlmIChcImNyZWF0ZUV2ZW50XCIgaW4gZG9jdW1lbnQpIHtcclxuXHR2YXIgZXZ0ID0gZG9jdW1lbnQuY3JlYXRlRXZlbnQoXCJIVE1MRXZlbnRzXCIpO1xyXG5cdGV2dC5pbml0RXZlbnQoXCJjaGFuZ2VcIiwgZmFsc2UsIHRydWUpO1xyXG5cdHRiLmVsVGV4dC5kaXNwYXRjaEV2ZW50KGV2dCk7XHJcbi8vICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgIHRleHRib3guZmlyZUV2ZW50KFwib25jaGFuZ2VcIik7XHJcbi8vICAgICAgfVxyXG59XHJcblxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4vKiBlZGl0IFRlbXBsYXRlICAgICAgICAgICovXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbmZ1bmN0aW9uIGVkaXRUZW1wbGF0ZSAoc3VtbWFyeVByZWZpeCl7XHJcblx0aWYgKHRiLnRlbXBsYXRlKSB7XHJcblx0XHR2YXIgZ3JvdXAsIGdyb3VwRXhwYW5kZWQgXHJcblx0XHR0Yi5lbERsZy5pbm5lckhUTUwgPSBcclxuXHRcdFx0JzxoMyBzdHlsZT1cIm1hcmdpbjogMCAwIDAgMTBweDtcIj5FZGl0aW5nICcgKyAnPGEgaHJlZj1cIi93aWtpL1RlbXBsYXRlOicgKyB0Yi50ZW1wbGF0ZS5uYW1lICsgJ1wiIHRhcmdldD1cIl9ibGFua1wiPlRlbXBsYXRlOicgKyB0Yi50ZW1wbGF0ZS5uYW1lICsgJzwvYT48L2gzPicgKyBcclxuXHRcdFx0Jzx0YWJsZSBzdHlsZT1cIm1hcmdpbi1ib3R0b206IDEwcHg7XCI+PHRyPjx0ZCBzdHlsZT1cIndoaXRlLXNwYWNlOiBub3dyYXA7cGFkZGluZy1yaWdodDogMTBweDtcIj4nICtcclxuXHRcdFx0KHRiLnRlbXBsYXRlLnR5cGUgPyAnVHlwZTogPGI+JyArIHRiLnRlbXBsYXRlLnR5cGUgKyAnPC9iPjxicj4nIDogJycpICsgXHJcblx0XHRcdCh0Yi50ZW1wbGF0ZS5ncm91cCA/ICdHcm91cDogPGI+JyArIHRiLnRlbXBsYXRlLmdyb3VwICsgJzwvYj48YnI+JyA6ICcnKSArIFxyXG5cdFx0XHQodGIudGVtcGxhdGUuc3ViZ3JvdXAgPyAnU3ViR3JvdXA6IDxiPicgKyB0Yi50ZW1wbGF0ZS5zdWJncm91cCArICc8L2I+JyA6ICcnKSArIFxyXG5cdFx0XHQnPC90ZD48dGQ+JyArIHRiLnRlbXBsYXRlLmhlbHAgKyAnPC90ZD48L3RyPjwvdGFibGU+JyArIFxyXG5cdFx0XHQnPGRpdiBpZD1cInd0UGx1c0RsZ1BhcmFtc1wiPicrXHJcblx0XHRcdCc8dGFibGUgc3R5bGU9XCJ3aWR0aDogMTAwJTtcIj4nICsgXHJcblx0XHRcdHRiLnRlbXBsYXRlaXRlbXMubWFwKChpdGVtLCBpKSA9PiB7XHJcblx0XHRcdFx0dmFyIGl0ZW1EZWYgPSB1cmxNYXBwaW5ncy5maWx0ZXIoYT0+YS50eXBlID09IGl0ZW0udHlwZSlbMF0gXHJcblx0XHRcdFx0aWYgKCFpdGVtRGVmKSB7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZygnTWlzc2luZyAnICsgaXRlbS50eXBlICsgJyB0eXBlJykgXHJcblx0XHRcdFx0XHRpdGVtRGVmID0gdXJsTWFwcGluZ3NbMF07XHJcblx0XHRcdFx0fTtcclxuXHRcdFx0XHQvLyBTZXRzIFRPQyBwYXJhbWV0ZXJcclxuXHRcdFx0XHRpZiAoaXRlbS50eXBlID09PSBcInR5cGVUT0NcIikge1xyXG5cdFx0XHRcdFx0dmFyIGhhc19saW5rID0gW10uc29tZS5jYWxsKGRvY3VtZW50LmxpbmtzLCBmdW5jdGlvbihsaW5rKSB7XHJcblx0XHRcdFx0XHRcdHJldHVybiBsaW5rLmlubmVySFRNTC5lbmRzV2l0aCgnIDIwMCcpO1xyXG5cdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHRpdGVtLnZhbHVlID0gKGhhc19saW5rKSA/ICd5ZXMnOiAnJ1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR2YXIgeCA9ICcnXHJcblx0XHRcdFx0Ly8gR3JvdXBcclxuXHRcdFx0XHRpZiAoaXRlbS5ncm91cCAhPT0gZ3JvdXApIHtcclxuXHRcdFx0XHRcdGlmIChpdGVtLmdyb3VwKSB7XHJcblx0XHRcdFx0XHRcdGdyb3VwRXhwYW5kZWQgPSBCb29sZWFuICh0Yi50ZW1wbGF0ZWl0ZW1zLmZpbmQoYT0+IGEuZ3JvdXAgPT0gaXRlbS5ncm91cCAmJiBhLnZhbHVlKSkgXHJcblx0XHRcdFx0XHRcdHggKz0gJzx0ciBjbGFzcz1cInd0UGx1cycgKyBpdGVtLmdyb3VwICsgJ1wiPjx0ZCBjb2xzcGFuPVwiMlwiPjxsYWJlbD4nICsgaXRlbS5ncm91cCArICc6PC9sYWJlbD48L3RkPjx0ZD4nICsgXHJcblx0XHRcdFx0XHRcdFx0JzxidXR0b24gaWQ9XCJncm91cEJ0bicgKyBpdGVtLmdyb3VwICsgJ1wiIHRpdGxlPVwiRXhwYW5kL0NvbGxhcHNlXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ0VkaXRUZW1wbGF0ZUV4cENvbFwiIGRhdGEtaWQ9XCInICsgaXRlbS5ncm91cCArICdcIj4nICsgXHJcblx0XHRcdFx0XHRcdFx0KGdyb3VwRXhwYW5kZWQgPyAnQ29sbGFwc2UnIDogJ0V4cGFuZCcpICsgJzwvYnV0dG9uPjwvdGQ+PHRkIGNvbHNwYW49XCIzXCI+PC90ZD48L3RyPicgXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRncm91cCA9IGl0ZW0uZ3JvdXBcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0eCAgKz0gJzx0ciBjbGFzcz1cInd0UGx1cycgKyBpdGVtLnVzYWdlICsgKGl0ZW0uZ3JvdXAgPyAnIGdyb3VwJyArIGl0ZW0uZ3JvdXAgKyAnXCIgJyArIChncm91cEV4cGFuZGVkID8gJycgOiAnc3R5bGU9XCJ2aXNpYmlsaXR5OiBjb2xsYXBzZTsnKSA6ICcnICkgKyAnXCI+JztcclxuXHRcdFx0XHQvLyBOYW1lXHJcblx0XHRcdFx0eCArPSAnPHRkPjxsYWJlbD4nICsgaXRlbS5uYW1lICsgJzo8L2xhYmVsPjwvdGQ+JyBcclxuXHRcdFx0XHQvLyBIZWxwXHJcblx0XHRcdFx0eCArPSAnPHRkPicgKyAoaXRlbS5oZWxwID8gXHJcblx0XHRcdFx0XHQnPGltZyBzcmM9XCIvaW1hZ2VzL2ljb25zL2hlbHAuZ2lmXCIgYm9yZGVyPVwiMFwiIHdpZHRoPVwiMjJcIiBoZWlnaHQ9XCIyMlwiIGFsdD1cIkhlbHBcIiB0aXRsZT1cIlVzYWdlOiAnICsgaXRlbS51c2FnZSArICdcXG4nICsgaXRlbS5oZWxwICsgKGl0ZW0uZXhhbXBsZSA/ICdcXG5FeGFtcGxlOiAnICsgaXRlbS5leGFtcGxlIDogJycgKSArICdcIiAvPic6ICcnKSArICc8L3RkPic7XHJcblx0XHRcdFx0Ly8gSW5wdXRcclxuXHRcdFx0XHR4ICs9ICc8dGQ+PGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInd0cGFyYW0nICsgaSArICdcIiBjbGFzcz1cImRsZ1Bhc3RlJyArIC8qKChpdGVtLnR5cGUgPT09IFwidHlwZUNhdGVnb3J5XCIpID8gJyBkbGdDYXQnIDogJycgKSArICovJ1wiICcgK1xyXG5cdFx0XHRcdFx0ICdkYXRhLW9wPVwib25EbGdFZGl0VGVtcGxhdGVQYXN0ZVwiIGRhdGEtaWQ9XCInICsgaSArICdcIiB2YWx1ZT1cIicgKyBpdGVtLnZhbHVlICsgJ1wiICc7XHJcblx0XHRcdFx0eCArPSAncGxhY2Vob2xkZXI9XCInICsgaXRlbURlZi5wbGFjZWhvbGRlciArICdcIiAnXHJcblx0XHRcdFx0eCArPSAnbGlzdD1cInd0UGx1c0F1dG9Db21wbGV0ZScgKyBpICsgJ1wiICdcclxuXHRcdFx0XHRpZiAoKGl0ZW0udHlwZSA9PT0gXCJ0eXBlUmVhZE9ubHlcIikgfHwgKGl0ZW0udHlwZSA9PT0gXCJ0eXBlVE9DXCIpKSB7XHJcblx0XHRcdFx0XHR4ICs9ICdyZWFkb25seSAnXHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGlmIChpID09PSAwKSB7XHJcblx0XHRcdFx0XHR4ICs9ICdhdXRvZm9jdXMgJ1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR4ICs9ICcvPjxkYXRhbGlzdCBpZD1cInd0UGx1c0F1dG9Db21wbGV0ZScgKyBpICsgJ1wiPicgXHJcblx0XHRcdFx0eCArPSBpdGVtLnZhbHVlcy5tYXAoaXRlbSA9PiAnPG9wdGlvbiB2YWx1ZT1cIicgKyBpdGVtICsgJ1wiLz4nICkuam9pbignXFxuJylcclxuXHRcdFx0XHR4ICs9JzwvZGF0YWxpc3Q+PC90ZD4nO1xyXG5cdFx0XHRcdC8vQnV0dG9uc1xyXG5cdFx0XHRcdHggKz0nPHRkPicgKyAoKGl0ZW0udHlwZSAhPSBcInR5cGVSZWFkT25seVwiKSAmJiAoaXRlbS50eXBlICE9IFwidHlwZVRPQ1wiKSA/IFxyXG5cdFx0XHRcdFx0JzxidXR0b24gdGl0bGU9XCJSZXN0b3JlIHZhbHVlXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ0VkaXRUZW1wbGF0ZVJlc3RvcmVcIiBkYXRhLWlkPVwiJyArIGkgKyAnXCIgdGFiaW5kZXg9XCItMVwiPlI8L2J1dHRvbj4nIDogJycpICsgJzwvdGQ+JyBcclxuXHRcdFx0XHR4ICs9Jzx0ZD4nICsgKChpdGVtLmluaXRpYWwpID8gXHJcblx0XHRcdFx0XHQnPGJ1dHRvbiB0aXRsZT1cIkF1dG8gdmFsdWVcIiBjbGFzcz1cImRsZ0NsaWNrXCIgZGF0YS1vcD1cIm9uRGxnRWRpdFRlbXBsYXRlSW5pdGlhbFwiIGRhdGEtaWQ9XCInICsgaSArICdcIiB0YWJpbmRleD1cIi0xXCI+QTwvYnV0dG9uPicgOiAnJykgKyAnPC90ZD4nIFxyXG5cdFx0XHRcdHggKz0nPHRkPicgKyAoKHVybE1hcHBpbmdzLmZpbHRlcihhPT5hLnByZWZpeFVSTCAhPT0gdW5kZWZpbmVkKS5tYXAoYT0+YS50eXBlKS5pbmNsdWRlcyhpdGVtLnR5cGUpKSA/IFxyXG5cdFx0XHRcdFx0JzxidXR0b24gdGl0bGU9XCJPcGVuIGxpbmtcIiBjbGFzcz1cImRsZ0NsaWNrXCIgZGF0YS1vcD1cIm9uRGxnRWRpdFRlbXBsYXRlRm9sbG93XCIgZGF0YS1pZD1cIicgKyBpICsgJ1wiIHRhYmluZGV4PVwiLTFcIj5PPC9idXR0b24+JyA6ICcnKSArICc8L3RkPicgXHJcblx0XHRcdFx0eCArPSc8L3RyPic7XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0cmV0dXJuIHhcclxuXHRcdFx0fSkuam9pbignJykgKyBcclxuXHRcdFx0JzwvdGFibGU+JyArXHJcblx0XHRcdCc8L2Rpdj4nICtcclxuXHRcdFx0JzxkaXYgc3R5bGU9XCJkaXNwbGF5OmZsZXhcIj4nKyAgICAgICAgXHJcblx0XHRcdC8vTGVnZW5kXHJcblx0XHRcdCc8YnV0dG9uIGlkPVwid3RQbHVzTGVnZW5kQnRuXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ05vbmVcIiB0YWJpbmRleD1cIi0xXCI+TGVnZW5kJytcclxuXHRcdFx0Jzx0YWJsZSBjbGFzcz1cInd0UGx1c0xlZ2VuZFwiPicgKyBcclxuXHRcdFx0Jzx0cj48dGQgY29sc3Bhbj1cIjJcIiBjbGFzcz1cInd0UGx1c1JlcXVpcmVkXCI+UmVxdWlyZWQ8L3RkPjwvdHI+JyArXHJcblx0XHRcdCc8dHI+PHRkIGNvbHNwYW49XCIyXCIgY2xhc3M9XCJ3dFBsdXNQcmVmZXJyZWRcIj5QcmVmZXJyZWQ8L3RkPjwvdHI+JyArXHJcblx0XHRcdCc8dHI+PHRkIGNvbHNwYW49XCIyXCIgY2xhc3M9XCJ3dFBsdXNPcHRpb25hbFwiPk9wdGlvbmFsPC90ZD48L3RyPicgK1xyXG5cdFx0XHQnPHRyPjx0ZD48aW1nIHNyYz1cIi9pbWFnZXMvaWNvbnMvaGVscC5naWZcIiBib3JkZXI9XCIwXCIgd2lkdGg9XCIyMlwiIGhlaWdodD1cIjIyXCIgYWx0PVwiSGVscFwiIC8+PC90ZD48dGQ+SG93ZXIgZm9yIGhpbnQ8L3RkPjwvdHI+JyArXHJcblx0XHRcdCc8dHI+PHRkPjxidXR0b24gdGl0bGU9XCJSZXN0b3JlIHZhbHVlXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ05vbmVcIj5SPC9idXR0b24+PC90ZD48dGQ+UmVzdG9yZSB2YWx1ZTwvdGQ+PC90cj4nICtcclxuXHRcdFx0Jzx0cj48dGQ+PGJ1dHRvbiB0aXRsZT1cIkF1dG8gdmFsdWVcIiBjbGFzcz1cImRsZ0NsaWNrXCIgZGF0YS1vcD1cIm9uRGxnTm9uZVwiPkE8L2J1dHRvbj48L3RkPjx0ZD5BdXRvIHZhbHVlPC90ZD48L3RyPicgK1xyXG5cdFx0XHQnPHRyPjx0ZD48YnV0dG9uIHRpdGxlPVwiT3BlbiBsaW5rXCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ05vbmVcIj5PPC9idXR0b24+PC90ZD48dGQ+T3BlbiBsaW5rPC90ZD48L3RyPicgK1xyXG5cdFx0XHQnPC90YWJsZT4nICtcclxuXHRcdFx0JzwvYnV0dG9uPicgK1xyXG5cdFx0XHQnPGRpdiBzdHlsZT1cImZsZXg6MVwiPjwvZGl2PicgK1xyXG5cdFx0XHQnPGEgY2xhc3M9XCJidXR0b25cIiBocmVmPVwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvU3BhY2U6V2lraVRyZWVfUGx1c19DaHJvbWVfRXh0ZW5zaW9uI0VkaXRfVGVtcGxhdGVcIiB0YXJnZXQ9XCJfYmxhbmtcIj5IZWxwPC9hPicgK1xyXG5cdFx0XHQvL09LLCBDYW5jZWxcclxuXHRcdFx0JzxidXR0b24gc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ0VkaXRUZW1wbGF0ZUJ0blwiIGRhdGEtaWQ9XCIwXCI+Q2xvc2U8L2J1dHRvbj4nICtcclxuXHRcdFx0JzxidXR0b24gc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ0VkaXRUZW1wbGF0ZUJ0blwiIGRhdGEtaWQ9XCIxXCIgdmFsdWU9XCJkZWZhdWx0XCI+VXBkYXRlIGNoYW5nZXM8L2J1dHRvbj4nICtcclxuXHRcdFx0JzwvZGl2PicgXHJcblxyXG5cdFx0dGIuZWxEbGdQYXJhbXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInd0UGx1c0RsZ1BhcmFtc1wiKTtcclxuXHRcdFx0XHQgIFxyXG5cdFx0YXR0YWNoRXZlbnRzKCdidXR0b24uZGxnQ2xpY2snLCAnY2xpY2snKVxyXG5cdFx0YXR0YWNoRXZlbnRzKCdpbnB1dC5kbGdQYXN0ZScsICdwYXN0ZScpXHJcblx0XHRhdHRhY2hFdmVudHMoJ2lucHV0LmRsZ1Bhc3RlJywgJ2tleXByZXNzJylcclxuXHRcdFxyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gc3VtbWFyeVByZWZpeCArIFwiIFRlbXBsYXRlOlwiICsgdGIudGVtcGxhdGUubmFtZTtcclxuXHRcdGlmICh0Yi51bmtub3duUGFyYW1zKSBcclxuXHRcdCAgYWxlcnQoJ1VucmVjb2duaXplZCBwYXJhbWV0ZXJzOlxcbicgKyB0Yi51bmtub3duUGFyYW1zICsgJ1xcblxcblRoZXkgd2lsbCBiZSByZW1vdmVkLCB1bmxlc3MgeW91IGNhbmNlbC4nKVxyXG5cdFx0dGIuZWxEbGcuc2hvd01vZGFsKCk7XHJcblx0fSAgICBcclxufTtcclxuLypcclxuXHJcblx0aWYgKCQoJyNhZGRDYXRlZ29yeUlucHV0JykubGVuZ3RoKSB7XHJcblx0XHQkKCcjYWRkQ2F0ZWdvcnlJbnB1dCcpLmF1dG9Db21wbGV0ZSh7XHJcblx0XHRcdGNhY2hlOiBmYWxzZSxcclxuXHRcdFx0c291cmNlOiBmdW5jdGlvbih0ZXJtLCBzdWdnZXN0KSB7XHJcblx0XHRcdFx0d3RDYXRlZ29yeVN1Z2dlc3Rpb24odGVybSwgc3VnZ2VzdCk7XHJcblx0XHRcdH0sXHJcblx0XHRcdHJlbmRlckl0ZW06IGZ1bmN0aW9uKGNhdGVnb3J5LCBzZWFyY2gpIHtcclxuXHRcdFx0XHRyZXR1cm4gd3RDYXRlZ29yeVN1Z2dlc3Rpb25JdGVtUmVuZGVyKGNhdGVnb3J5LCBzZWFyY2gpO1xyXG5cdFx0XHR9LFxyXG5cdFx0XHRvblNlbGVjdDogZnVuY3Rpb24oZSwgdGVybSwgaXRlbSkge1xyXG5cdFx0XHRcdGNoYW5nZXNNYWRlID0gMTtcclxuXHRcdFx0XHR2YXIgY2F0ZWdvcnlUZXh0ID0gXCJbW0NhdGVnb3J5OlwiICsgdGVybSArIFwiXV1cXG5cIjtcclxuXHRcdFx0XHRjYXRlZ29yeVRleHQgPSBjYXRlZ29yeVRleHQucmVwbGFjZSgvXy9nLCAnICcpO1xyXG5cdFx0XHRcdGlmICgodHlwZW9mIGNvbG9yZWRFZGl0b3IgIT09ICd1bmRlZmluZWQnKSAmJiAoY29sb3JlZEVkaXRvcikpIHtcclxuXHRcdFx0XHRcdGNvbG9yZWRFZGl0b3Iuc2V0Q3Vyc29yKDAsIDApO1xyXG5cdFx0XHRcdFx0dmFyIGN1cnNvciA9IGNvbG9yZWRFZGl0b3IuZ2V0Q3Vyc29yKCk7XHJcblx0XHRcdFx0XHRjb2xvcmVkRWRpdG9yLnJlcGxhY2VSYW5nZShjYXRlZ29yeVRleHQsIGN1cnNvciwgY3Vyc29yKTtcclxuXHRcdFx0XHRcdGNvbG9yZWRFZGl0b3IuZm9jdXMoKTtcclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0dmFyIHRleHRBcmVhID0gZG9jdW1lbnQuZWRpdGZvcm0ud3BUZXh0Ym94MTtcclxuXHRcdFx0XHRcdHZhciB0ZXh0U2Nyb2xsID0gdGV4dEFyZWEuc2Nyb2xsVG9wO1xyXG5cdFx0XHRcdFx0dGV4dEFyZWEudmFsdWUgPSBjYXRlZ29yeVRleHQgKyB0ZXh0QXJlYS52YWx1ZTtcclxuXHRcdFx0XHRcdHRleHRBcmVhLnNlbGVjdGlvblN0YXJ0ID0gMDtcclxuXHRcdFx0XHRcdHRleHRBcmVhLnNlbGVjdGlvbkVuZCA9IGNhdGVnb3J5VGV4dC5sZW5ndGg7XHJcblx0XHRcdFx0XHR0ZXh0QXJlYS5zY3JvbGxUb3AgPSB0ZXh0U2Nyb2xsO1xyXG5cdFx0XHRcdFx0dGV4dEFyZWEuZm9jdXMoKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0JCgnI2FkZENhdGVnb3J5SW5wdXQnKS52YWwoJycpLmhpZGUoKTtcclxuXHRcdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xyXG5cdFx0XHR9LFxyXG5cdFx0fSk7XHJcblx0fVxyXG59KTtcclxuZnVuY3Rpb24gd3RDYXRlZ29yeVN1Z2dlc3Rpb24odGVybSwgc3VnZ2VzdCkge1xyXG5cdHZhciBpbmNsdWRlQWxsID0gMDtcclxuXHRpZiAoJCgnI2NhdGVnb3J5U3VnZ2VzdGlvbkluY2x1ZGVBbGwnKS5sZW5ndGggJiYgJCgnI2NhdGVnb3J5U3VnZ2VzdGlvbkluY2x1ZGVBbGwnKS52YWwoKSkge1xyXG5cdFx0aW5jbHVkZUFsbCA9IDE7XHJcblx0fVxyXG5cdHNhamF4X2RvX2NhbGwoXCJUaXRsZTo6YWpheENhdGVnb3J5U2VhcmNoXCIsIFt0ZXJtLCBpbmNsdWRlQWxsXSwgZnVuY3Rpb24ocmVzdWx0KSB7XHJcblx0XHR2YXIgc3VnZ2VzdGlvbnMgPSBKU09OLnBhcnNlKHJlc3VsdC5yZXNwb25zZVRleHQpO1xyXG5cdFx0c3VnZ2VzdChzdWdnZXN0aW9ucyk7XHJcblx0fSk7XHJcbn1cclxuZnVuY3Rpb24gd3RDYXRlZ29yeVN1Z2dlc3Rpb25JdGVtUmVuZGVyKGl0ZW0sIHNlYXJjaCkge1xyXG5cdHNlYXJjaCA9IHNlYXJjaC5yZXBsYWNlKC9bLVxcL1xcXFxeJCorPy4oKXxbXFxde31dL2csICdcXFxcJCYnKTtcclxuXHR2YXIgcmUgPSBuZXcgUmVnRXhwKFwiKFwiICsgc2VhcmNoLnNwbGl0KCcgJykuam9pbignfCcpICsgXCIpXCIsXCJnaVwiKTtcclxuXHR2YXIgaHRtbCA9ICcnO1xyXG5cdGh0bWwgKz0gJzxkaXYgY2xhc3M9XCJhdXRvY29tcGxldGUtc3VnZ2VzdGlvblwiIGRhdGEtdmFsPVwiJyArIGl0ZW0gKyAnXCI+JztcclxuXHRodG1sICs9IGl0ZW0ucmVwbGFjZShyZSwgXCI8Yj4kMTwvYj5cIik7XHJcblx0aHRtbCArPSAnPC9kaXY+JztcclxuXHRyZXR1cm4gaHRtbDtcclxufVxyXG5cclxuKi9cclxuZnVuY3Rpb24gb25EbGdFZGl0VGVtcGxhdGVCdG4odXBkYXRlKSB7XHJcblx0dGIuZWxEbGcuY2xvc2UoKTtcclxuXHRpZiAodXBkYXRlPT09JzEnKSB7XHJcblx0XHR2YXIgYSA9IHRiLmVsRGxnUGFyYW1zLnF1ZXJ5U2VsZWN0b3JBbGwoJ2lucHV0Jyk7XHJcblx0XHRmb3IgKHZhciBpIGluIHRiLnRlbXBsYXRlaXRlbXMpIHt0Yi50ZW1wbGF0ZWl0ZW1zW2ldLnZhbHVlID0gYVtpXS52YWx1ZS50cmltKCl9O1xyXG5cdFx0dGIuaW5zZXJ0dGV4dCA9ICcnO1xyXG5cdFx0dmFyIGxpbmUgPSAnJztcclxuXHRcdGlmICh0Yi50ZW1wbGF0ZWl0ZW1zICYmIHRiLnRlbXBsYXRlaXRlbXMubGVuZ3RoKSB7XHJcblx0XHRcdHZhciBsaW5lID0gJ1xcbic7XHJcblx0XHRcdGZvciAobGV0IHByb3Agb2YgdGIudGVtcGxhdGVpdGVtcykge1xyXG5cdFx0XHRcdGlmIChwcm9wLm51bWJlcmVkKSB7XHJcblx0XHRcdFx0XHRsaW5lID0gJyc7XHJcblx0XHRcdFx0XHRpZiAocHJvcC52YWx1ZSkge1xyXG5cdFx0XHRcdFx0XHR0Yi5pbnNlcnR0ZXh0ICs9ICd8JyArIHByb3AudmFsdWU7XHJcblx0XHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0XHRzd2l0Y2gocHJvcC51c2FnZSkge1xyXG5cdFx0XHRcdFx0XHRjYXNlIFwiUmVxdWlyZWRcIjpcclxuXHRcdFx0XHRcdFx0Y2FzZSBcIlByZWZlcnJlZFwiOlxyXG5cdFx0XHRcdFx0XHR0Yi5pbnNlcnR0ZXh0ICs9ICd8JztcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdH0gXHJcblx0XHRcdFx0XHR9ICAgIFxyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRpZiAocHJvcC52YWx1ZSkge1xyXG5cdFx0XHRcdFx0XHR0Yi5pbnNlcnR0ZXh0ICs9ICdcXG58JyArIHByb3AubmFtZSArICc9ICcgKyBwcm9wLnZhbHVlO1xyXG5cdFx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdFx0c3dpdGNoKHByb3AudXNhZ2UpIHtcclxuXHRcdFx0XHRcdFx0XHRjYXNlIFwiUmVxdWlyZWRcIjpcclxuXHRcdFx0XHRcdFx0XHRjYXNlIFwiUHJlZmVycmVkXCI6XHJcblx0XHRcdFx0XHRcdFx0dGIuaW5zZXJ0dGV4dCArPSAnXFxufCcgKyBwcm9wLm5hbWUgKyAnPSAnO1xyXG5cdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHR9IFxyXG5cdFx0XHRcdFx0fSAgICBcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdHRiLmluc2VydHRleHQgPSAne3snICsgdGIudGVtcGxhdGUubmFtZSArIHRiLmluc2VydHRleHQgKyBsaW5lICsgJ319JyA7XHJcblx0XHR0Yi5pbnNlcnR0ZXh0ICs9ICh0Yi50ZXh0QWZ0ZXJbMF09PT0nXFxuJykgPyAnJzogbGluZTtcclxuXHRcdFxyXG5cdFx0dGIudGV4dFJlc3VsdCA9IHRiLnRleHRCZWZvcmUgKyB0Yi5pbnNlcnR0ZXh0ICsgdGIudGV4dEFmdGVyO1xyXG5cdFx0dGIuc2VsU3RhcnQgPSB0Yi50ZXh0QmVmb3JlLmxlbmd0aFxyXG5cdFx0dGIuc2VsRW5kID0gdGIuc2VsU3RhcnQgKyAgdGIuaW5zZXJ0dGV4dC5sZW5ndGg7XHJcblx0XHR0Yi5iaXJ0aExvY2F0aW9uUmVzdWx0ID0gJyc7XHJcblx0XHR0Yi5kZWF0aExvY2F0aW9uUmVzdWx0ID0gJyc7XHJcblx0XHR1cGRhdGVFZGl0KCk7XHJcblx0fTtcclxuXHR0Yi5lbERsZy5pbm5lckhUTUwgPSAnJztcclxuXHR0Yi5hZGRUb1N1bW1hcnkgPSAnJ1xyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuLy9saXN0ZW5lciBmb3IgcGFzdGUgZXZlbnRcclxuZnVuY3Rpb24gb25EbGdFZGl0VGVtcGxhdGVQYXN0ZShpLCBldnQpIHtcclxuXHRpZiAoZXZ0LnR5cGUgPT0gJ2tleXByZXNzJykge1xyXG5cdFx0dmFyIGtleSA9IGV2dC53aGljaCB8fCBldnQua2V5Q29kZTtcclxuXHRcdGlmIChrZXkgPT09IDEzKSB7IFxyXG5cdFx0XHRvbkRsZ0VkaXRUZW1wbGF0ZUJ0bignMScpXHJcblx0XHR9IFxyXG5cdH0gXHJcblx0aWYgKGV2dC50eXBlID09ICdwYXN0ZScpIHtcclxuXHRcdGxldCBjbGlwZGF0YSA9IGV2dC5jbGlwYm9hcmREYXRhIHx8IHdpbmRvdy5jbGlwYm9hcmREYXRhO1xyXG5cdFx0dmFyIHMgPSBjbGlwZGF0YS5nZXREYXRhKCd0ZXh0L3BsYWluJyk7XHJcblx0XHRzID0gZGVjb2RlVVJJQ29tcG9uZW50IChzKTtcclxuXHRcdGZvcihjb25zdCBqIG9mIHVybE1hcHBpbmdzKSB7XHJcblx0XHRcdGlmICh0Yi50ZW1wbGF0ZWl0ZW1zW2ldLnR5cGUgPT09IGoudHlwZSkge1xyXG5cdFx0XHRcdGlmIChzLnN0YXJ0c1dpdGgoai5wcmVmaXhVUkwpKSB7XHJcblx0XHRcdFx0XHRzID0gcy5yZXBsYWNlKGoucHJlZml4VVJMLCAnJyk7XHJcblx0XHRcdFx0XHRpZiAoKGouc3VmaXhVUkwhPScnKSAmJiAocy5lbmRzV2l0aChqLnN1Zml4VVJMKSkpIHtcclxuXHRcdFx0XHRcdFx0cyA9IHMucmVwbGFjZShqLnN1Zml4VVJMLCAnJyk7XHJcblx0XHRcdFx0XHR9ICAgIFxyXG5cdFx0XHRcdFx0cyA9IGouZnJvbVVSTCA/IGouZnJvbVVSTChzKSA6IHNcclxuXHRcdFx0XHRcdGRvY3VtZW50LmV4ZWNDb21tYW5kKFwiaW5zZXJ0SFRNTFwiLCBmYWxzZSwgcyk7XHJcblx0XHRcdFx0XHRldnQucHJldmVudERlZmF1bHQoKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG9uRGxnRWRpdFRlbXBsYXRlRm9sbG93KGkpIHtcclxuXHR2YXIgaXRlbT10Yi50ZW1wbGF0ZWl0ZW1zW2ldO1xyXG5cdHZhciBlPXRiLmVsRGxnUGFyYW1zLnF1ZXJ5U2VsZWN0b3JBbGwoJ2lucHV0JylbaV07XHJcblx0dmFyIHMgPSBlLnZhbHVlO1xyXG5cclxuXHRmb3IoY29uc3QgaSBvZiB1cmxNYXBwaW5ncykge1xyXG5cdFx0aWYgKGl0ZW0udHlwZSA9PT0gaS50eXBlKSB7XHJcblx0XHRcdGlmIChzKSB7XHJcblx0XHRcdFx0cyA9IChpLnByZWZpeFVSTCA9PT0gJycpID8gZW5jb2RlVVJJIChzKSA6IGVuY29kZVVSSUNvbXBvbmVudCAocylcclxuXHRcdFx0XHRzID0gaS50b1VSTCA/IGkudG9VUkwocykgOiBzXHJcblx0XHRcdFx0cyA9IGkucHJlZml4VVJMICsgcyArIGkuc3VmaXhVUkxcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRzID0gaS5lbXB0eVVSTCAhPT0gdW5kZWZpbmVkID8gaS5lbXB0eVVSTCA6IGkucHJlZml4VVJMXHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcbiAgIFxyXG5cdGlmIChzLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xyXG5cdFx0d2luZG93Lm9wZW4ocywgJ19ibGFuaycpO1xyXG5cdH1cclxuXHRyZXR1cm4gZmFsc2VcclxufTtcclxuXHJcbmZ1bmN0aW9uIG9uRGxnRWRpdFRlbXBsYXRlSW5pdGlhbChpKSB7XHJcblx0dmFyIGl0ZW09dGIudGVtcGxhdGVpdGVtc1tpXTtcclxuXHR2YXIgZT10Yi5lbERsZ1BhcmFtcy5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dCcpW2ldO1xyXG5cdGlmIChpdGVtLmluaXRpYWwuc3RhcnRzV2l0aChcIlRpdGxlOlwiKSkge1xyXG5cdFx0ZS52YWx1ZSA9IGRvY3VtZW50LnRpdGxlLnJlcGxhY2UoUmVnRXhwKGl0ZW0uaW5pdGlhbC5zdWJzdHJpbmcoNikpLCAnJDEnKTtcclxuXHR9ICAgIFxyXG5cdGlmIChpdGVtLmluaXRpYWwuc3RhcnRzV2l0aChcIkNhdGVnb3J5OlwiKSAmJiAodGIuY2F0ZWdvcmllcykpIHtcclxuXHRcdHZhciByPVJlZ0V4cChpdGVtLmluaXRpYWwuc3Vic3RyaW5nKDkpLCAnbWcnKVxyXG5cdFx0ZS52YWx1ZSA9IHRiLmNhdGVnb3JpZXMubWF0Y2gocikuam9pbignXFxuJykucmVwbGFjZShyLCAnJDEnKTtcclxuXHR9XHJcblx0cmV0dXJuIGZhbHNlXHJcbn07XHJcblxyXG5mdW5jdGlvbiBvbkRsZ0VkaXRUZW1wbGF0ZVJlc3RvcmUoaSkge1xyXG5cdHZhciBpdGVtPXRiLnRlbXBsYXRlaXRlbXNbaV07XHJcblx0dmFyIGUgPSB0Yi5lbERsZ1BhcmFtcy5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dCcpW2ldO1xyXG5cdGUudmFsdWUgPSBpdGVtLnZhbHVlO1xyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuZnVuY3Rpb24gb25EbGdFZGl0VGVtcGxhdGVFeHBDb2woZ05hbWUpIHtcclxuXHR2YXIgZSA9IHRiLmVsRGxnLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2dyb3VwJyArIGdOYW1lKTtcclxuXHR2YXIgYiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdncm91cEJ0bicgKyBnTmFtZSk7XHJcblx0aWYgKGIuaW5uZXJIVE1MID09ICdFeHBhbmQnKSB7XHJcblx0XHRiLmlubmVySFRNTCA9ICdDb2xsYXBzZSdcclxuXHRcdGZvcih2YXIgZWkgb2YgZSkge2VpLnN0eWxlLnZpc2liaWxpdHkgPSAndmlzaWJsZSc7fVxyXG5cdH0gZWxzZSB7XHJcblx0XHRiLmlubmVySFRNTCA9ICdFeHBhbmQnXHJcblx0XHRmb3IodmFyIGVpIG9mIGUpIHtlaS5zdHlsZS52aXNpYmlsaXR5ID0gJ2NvbGxhcHNlJzt9XHJcblx0fVxyXG5cdHJldHVybiBmYWxzZVxyXG59O1xyXG5cclxuZnVuY3Rpb24gV2lraVRyZWVHZXRDYXRlZ29yeSAocXVlcnksIGZpeGVkKXtcclxuXHRmZXRjaChcImh0dHBzOi8vd3d3Lndpa2l0cmVlLmNvbS9pbmRleC5waHA/YWN0aW9uPWFqYXgmcnM9VGl0bGU6OmFqYXhDYXRlZ29yeVNlYXJjaCZyc2FyZ3NbXT1cIiArIHF1ZXJ5ICsgXCImcnNhcmdzW109MVwiKVxyXG5cdC50aGVuKChyZXNwKSA9PiByZXNwLmpzb24oKSlcclxuXHQudGhlbihqc29uRGF0YSA9PiB7XHJcblx0XHRjb25zb2xlLmxvZygnY2F0OiAnICsganNvbkRhdGEpO1xyXG5cdFx0cmV0dXJuIChqc29uRGF0YSk7XHJcblx0fSlcclxufTtcclxuXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuLyogU2VsZWN0IHRlbXBsYXRlIHRvIGFkZCAqL1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiBcclxuZnVuY3Rpb24gc2VsZWN0VGVtcGxhdGUgKGRhdGEpIHtcclxuXHR0Yi5lbERsZy5pbm5lckhUTUwgPSBcclxuXHRcdCc8aDM+U2VsZWN0IHRlbXBsYXRlPC9oMz4nICsgXHJcblx0XHQnPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzPVwiY2JGaWx0ZXJcIiBpZD1cImNiMVwiIG5hbWU9XCJjYjFcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUZsdFwiIGRhdGEtaWQ9XCIxXCIgdmFsdWU9XCJQcm9qZWN0IEJveFwiJyArIChkYXRhPT1cIlByb2plY3QgQm94XCIgPyAnIGNoZWNrZWQnIDogJycpICsgJz48bGFiZWwgZm9yPVwiY2IxXCI+IFByb2plY3QgQm94PC9sYWJlbD48YnI+JyArXHJcblx0XHQnPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzPVwiY2JGaWx0ZXJcIiBpZD1cImNiMlwiIG5hbWU9XCJjYjJcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUZsdFwiIGRhdGEtaWQ9XCIyXCIgdmFsdWU9XCJTdGlja2VyXCInICsgKGRhdGE9PVwiU3RpY2tlclwiID8gJyBjaGVja2VkJyA6ICcnKSArICc+PGxhYmVsIGZvcj1cImNiMlwiPiBTdGlja2VyPC9sYWJlbD48YnI+JyArXHJcblx0XHQnPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzPVwiY2JGaWx0ZXJcIiBpZD1cImNiM1wiIG5hbWU9XCJjYjNcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUZsdFwiIGRhdGEtaWQ9XCIzXCIgdmFsdWU9XCJQcm9maWxlIEJveFwiJyArIChkYXRhPT1cIlByb2ZpbGUgQm94XCIgPyAnIGNoZWNrZWQnIDogJycpICsgJz48bGFiZWwgZm9yPVwiY2IzXCI+IFJlc2VhcmNoIE5vdGU8L2xhYmVsPjxicj4nICtcclxuXHRcdCc8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJjYkZpbHRlclwiIGlkPVwiY2I0XCIgbmFtZT1cImNiNFwiIGRhdGEtb3A9XCJvbkRsZ1NlbGVjdFRlbXBsYXRlRmx0XCIgZGF0YS1pZD1cIjRcIiB2YWx1ZT1cIkV4dGVybmFsIExpbmtcIicgKyAoZGF0YT09XCJFeHRlcm5hbCBMaW5rXCIgPyAnIGNoZWNrZWQnIDogJycpICsgJz48bGFiZWwgZm9yPVwiY2I0XCI+IEV4dGVybmFsIExpbms8L2xhYmVsPjxicj4nICtcclxuXHRcdCc8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJjYkZpbHRlclwiIGlkPVwiY2I1XCIgbmFtZT1cImNiNVwiIGRhdGEtb3A9XCJvbkRsZ1NlbGVjdFRlbXBsYXRlRmx0XCIgZGF0YS1pZD1cIjVcIiB2YWx1ZT1cIkNhdGVnb3J5SW5mb0JveFwiJyArIChkYXRhPT1cIkNhdGVnb3J5SW5mb0JveFwiID8gJyBjaGVja2VkJyA6ICcnKSArICc+PGxhYmVsIGZvcj1cImNiNVwiPiBDYXRlZ29yeUluZm9Cb3g8L2xhYmVsPjxicj4nICtcclxuXHRcdCc8bGFiZWwgZm9yPVwiZmx0MVwiPkZpbHRlcjogPC9sYWJlbD48aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImNiRmlsdGVyXCIgaWQ9XCJmbHQxXCIgbmFtZT1cImZsdDFcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUZsdFwiIGRhdGEtaWQ9XCI5XCI+PGJyPicgK1xyXG5cdFx0JzxkaXYgc3R5bGU9XCJtaW4td2lkdGg6IDYwMHB4O292ZXJmbG93LXk6YXV0bztoZWlnaHQ6IDQwMHB4O1wiPjx0YWJsZSBzdHlsZT1cIndpZHRoOiAxMDAlO1wiIGlkPVwidGJcIj4nICtcclxuXHRcdHRiLnRlbXBsYXRlcy5tYXAoaXRlbSA9PiAnPHRyIGNsYXNzPVwidHJTZWxlY3RcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZVRyU2VsXCI+PHRkPicgKyBpdGVtLm5hbWUgKyAnPC90ZD48dGQ+JyArIGl0ZW0uZ3JvdXAgKyAnPC90ZD48dGQ+JyArIGl0ZW0uc3ViZ3JvdXAgKyAnPC90ZD48L3RyPicgKS5qb2luKCdcXG4nKSArXHJcblx0XHQnPC90YWJsZT48L2Rpdj4nICtcclxuXHRcdCc8ZGl2IHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiPicrXHJcblx0XHQnPGEgY2xhc3M9XCJidXR0b25cIiBocmVmPVwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvU3BhY2U6V2lraVRyZWVfUGx1c19DaHJvbWVfRXh0ZW5zaW9uI0FkZF9UZW1wbGF0ZVwiIHRhcmdldD1cIl9ibGFua1wiPkhlbHA8L2E+JyArXHJcblx0XHQvL09LLCBDYW5jZWxcclxuXHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUJ0blwiIGRhdGEtaWQ9XCIwXCI+Q2xvc2U8L2J1dHRvbj4nICtcclxuXHRcdCc8YnV0dG9uIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodFwiIGNsYXNzPVwiZGxnQ2xpY2tcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZUJ0blwiIGRhdGEtaWQ9XCIxXCIgdmFsdWU9XCJkZWZhdWx0XCI+U2VsZWN0PC9idXR0b24+JyArXHJcblx0XHQnPC9kaXY+JyBcclxuXHRhdHRhY2hFdmVudHMoJ2J1dHRvbi5kbGdDbGljaycsICdjbGljaycpXHJcblx0YXR0YWNoRXZlbnRzKCdpbnB1dC5jYkZpbHRlcicsICdpbnB1dCcpXHJcblx0YXR0YWNoRXZlbnRzKCd0ci50clNlbGVjdCcsICdjbGljaycpXHJcblx0b25EbGdTZWxlY3RUZW1wbGF0ZUZsdCAoKVxyXG5cdHRiLmVsRGxnLnNob3dNb2RhbCgpO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gb25EbGdTZWxlY3RUZW1wbGF0ZUZsdCAoKSB7XHJcblx0bGV0IGxiID0gdGIuZWxEbGcucXVlcnlTZWxlY3RvcihcIiN0YlwiKVxyXG5cdHZhciBzMCA9ICcnO1xyXG5cdGZvciAobGV0IGk9MTtpPD01O2krKykge1xyXG5cdFx0aWYgKHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3IoXCIjY2JcIitpKS5jaGVja2VkKVxyXG5cdFx0ICBzMCArPSAoczA9PScnID8gJycgOiAnfCcpICsgdGIuZWxEbGcucXVlcnlTZWxlY3RvcihcIiNjYlwiK2kpLnZhbHVlXHJcblx0fVxyXG5cdHZhciByMCA9IG5ldyBSZWdFeHAoJygnK3MwKycpJywnaScpXHJcblx0XHJcblx0dmFyIHMxID0gdGIuZWxEbGcucXVlcnlTZWxlY3RvcihcIiNmbHQxXCIpLnZhbHVlXHJcblx0dmFyIHIxID0gbmV3IFJlZ0V4cChzMSwnaScpXHJcblx0XHJcblx0bGIuaW5uZXJIVE1MID0gdGIudGVtcGxhdGVzLmZpbHRlcihpdGVtPT4gXHJcblx0XHQoKHMwPT09JycpIHx8IGl0ZW0udHlwZS5tYXRjaChyMCkpICYmIFxyXG5cdFx0KChzMT09PScnKSB8fCBpdGVtLm5hbWUubWF0Y2gocjEpIHx8IGl0ZW0uZ3JvdXAubWF0Y2gocjEpIHx8IGl0ZW0uc3ViZ3JvdXAubWF0Y2gocjEpKVxyXG4vLyAgICApLm1hcChpdGVtID0+ICc8b3B0aW9uIHZhbHVlPVwiJyArIGl0ZW0ubmFtZSArICdcIj4nICsgaXRlbS5uYW1lICsgJyAoJyArIGl0ZW0uZ3JvdXAgKyAnOiAnICsgaXRlbS5zdWJncm91cCArICcpPC9vcHRpb24+JyApLmpvaW4oJ1xcbicpIFxyXG5cdFx0KS5tYXAoaXRlbSA9PiAnPHRyIGNsYXNzPVwidHJTZWxlY3RcIiBkYXRhLW9wPVwib25EbGdTZWxlY3RUZW1wbGF0ZVRyU2VsXCI+PHRkPicgKyBpdGVtLm5hbWUgKyAnPC90ZD48dGQ+JyArIGl0ZW0uZ3JvdXAgKyAnPC90ZD48dGQ+JyArIGl0ZW0uc3ViZ3JvdXAgKyAnPC90ZD48L3RyPicgKS5qb2luKCdcXG4nKSBcclxuXHRhdHRhY2hFdmVudHMoJ3RyLnRyU2VsZWN0JywgJ2NsaWNrJylcclxufVxyXG5cclxuZnVuY3Rpb24gb25EbGdTZWxlY3RUZW1wbGF0ZVRyU2VsICh0cikge1xyXG5cdHJlbW92ZUNsYXNzICgndHIudHJTZWxlY3QnLCAndHJTZWxlY3RlZCcpXHJcblx0dHIuY2xhc3NMaXN0LmFkZChcInRyU2VsZWN0ZWRcIilcclxufVxyXG5cclxuZnVuY3Rpb24gb25EbGdTZWxlY3RUZW1wbGF0ZUJ0bih1cGRhdGUpIHtcclxuXHRpZiAodXBkYXRlPT09JzEnKSB7XHJcblx0XHRpZiAodGIuZWxEbGcucXVlcnlTZWxlY3RvckFsbCgnLnRyU2VsZWN0ZWQ+dGQnKS5sZW5ndGggPT09IDApIHtcclxuXHRcdFx0YWxlcnQgKCdObyB0ZW1wbGF0ZSBzZWxlY3RlZDogU2VsZWN0IGEgdGVtcGxhdGUgYmVmb3JlIGNsb3NpbmcgdGhlIGRpYWxvZycpXHJcblx0XHRcdHJldHVybiBmYWxzZVxyXG5cdFx0fVxyXG5cdFx0dGIuZWxEbGcuY2xvc2UoKTtcclxuXHRcdC8vQWRkIHRlbXBsYXRlIFxyXG5cdFx0dmFyIHRlbXBsYXRlTmFtZSA9IHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3JBbGwoJy50clNlbGVjdGVkPnRkJylbMF0uaW5uZXJUZXh0XHJcblx0XHRwYXJhbXNDb3B5ICh0ZW1wbGF0ZU5hbWUpXHJcblx0XHRwYXJhbXNJbml0aWFsVmFsdWVzICgpO1xyXG5cdFx0ZWRpdFRlbXBsYXRlIChcIkFkZGVkXCIpO1xyXG5cdH0gZWxzZSB7XHJcblx0XHR0Yi5lbERsZy5jbG9zZSgpO1xyXG5cdFx0dGIuZWxEbGcuaW5uZXJIVE1MID0gJyc7XHJcblx0XHR0Yi5hZGRUb1N1bW1hcnkgPSAnJ1xyXG5cdH07XHJcblx0cmV0dXJuIGZhbHNlXHJcbn07XHJcblxyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4vKiBBdXRvbWF0aWMgdXBkYXRlIGxpa2UgRWRpdEJPVCAqL1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuZnVuY3Rpb24gQXV0b1VwZGF0ZSAoKSB7XHJcblx0bGV0IHMwID0gJydcclxuXHRsZXQgczEgPSAnJ1xyXG5cdGxldCBzMiA9ICcnXHJcblx0Zm9yICh2YXIgbG9jPTA7bG9jPDM7bG9jKyspIHtcclxuXHRcdGxldCBhY3RBcnIgPSAnJ1xyXG5cdFx0aWYgKGxvYz09MCkge1xyXG5cdFx0XHRpZiAodGIuYmlydGhMb2NhdGlvbikge1xyXG5cdFx0XHRcdHMwID0gJ0JpcnRoIExvY2F0aW9uJ1xyXG5cdFx0XHRcdHMxID0gdGIuYmlydGhMb2NhdGlvblxyXG5cdFx0XHRcdGFjdEFyciA9IHRiLmxvY2F0aW9uc1xyXG5cdFx0XHR9XHJcblx0XHR9IGVsc2UgaWYgKGxvYz09MSkge1xyXG5cdFx0XHRpZiAodGIuZGVhdGhMb2NhdGlvbikge1xyXG5cdFx0XHRcdHMwID0gJ0RlYXRoIExvY2F0aW9uJ1xyXG5cdFx0XHRcdHMxID0gdGIuZGVhdGhMb2NhdGlvblxyXG5cdFx0XHRcdGFjdEFyciA9IHRiLmxvY2F0aW9uc1xyXG5cdFx0XHR9XHJcblx0XHR9IGVsc2UgaWYgKGxvYz09Mikge1xyXG5cdFx0XHRpZiAodGIudGV4dEFsbCkge1xyXG5cdFx0XHRcdHMwID0gJ0JpbydcclxuXHRcdFx0XHRzMSA9IHRiLnRleHRBbGxcclxuXHRcdFx0XHRhY3RBcnIgPSB0Yi5jbGVhbnVwXHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdGlmIChhY3RBcnIpIHtcclxuXHRcdFx0Zm9yICh2YXIgaj0wO2o8YWN0QXJyLmxlbmd0aDtqKyspIHtcclxuXHRcdFx0XHRsZXQgY2xlYW4gPSBhY3RBcnJbal1cclxuXHRcdFx0XHRsZXQgczMgPSAnJ1xyXG5cdFx0XHRcdGZvciAodmFyIGk9MDtpPGNsZWFuLmFjdGlvbnMubGVuZ3RoO2krKykge1xyXG5cdFx0XHRcdFx0bGV0IHMgPSBzMVxyXG5cdFx0XHRcdFx0bGV0IGFjdGlvbiA9IGNsZWFuLmFjdGlvbnNbaV1cclxuXHRcdFx0XHRcdHN3aXRjaChhY3Rpb24uYWN0aW9uKSB7XHJcblx0XHRcdFx0XHRcdGNhc2UgXCJyZXBsYWNlUmVnRXhcIjogXHJcblx0XHRcdFx0XHRcdGxldCByZWcgPSBSZWdFeHAoYWN0aW9uLmZyb20sIGFjdGlvbi5mbGFncylcclxuXHRcdFx0XHRcdFx0czEgPSBzMS5yZXBsYWNlKHJlZywgYWN0aW9uLnRvKVxyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0Y2FzZSBcInJlcGxhY2VcIjogXHJcblx0XHRcdFx0XHRcdHMxID0gczEucmVwbGFjZShhY3Rpb24uZnJvbSwgYWN0aW9uLnRvKVxyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0OiBcclxuXHRcdFx0XHRcdFx0YWxlcnQgKCdVbmtub3duIGFjdGlvbjogJyArIGFjdGlvbi5hY3Rpb24gKyAnIGRlZmluZWQgZm9yIHNvdXJjZTogJyArIGNsZWFuLm5hbWUpXHJcblx0XHRcdFx0XHRcdHMxID0gJydcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdGlmIChzMT09JycpIGJyZWFrXHJcblx0XHRcdFx0XHRpZiAoKHMxIT09JycpICYmIChzICE9PSBzMSkpIHtcclxuXHRcdFx0XHRcdFx0czMgKz0gKHMzIT09JycgPyAnLCAnIDogJycpICsgYWN0aW9uLmRlc2NyaXB0aW9uXHJcblx0XHRcdFx0XHR9ICAgIFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZiAoczMhPT0nJykge1xyXG5cdFx0XHRcdFx0czIgKz0gJzxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzcz1cImNiJyArIGxvYyArICdfJyArIGogKyAnXCIgaWQ9XCJjYicgKyBsb2MgKyAnXycgKyBqICsgJ1wiIG5hbWU9XCJjYicgKyBsb2MgKyAnXycgKyBqICsgJ1wiIGRhdGEtb3A9XCJvbkRsZ1Bhc3RlU291cmNlQ0JcIiBkYXRhLWlkPVwiMVwiIHZhbHVlPVwiJyArIGxvYyArICdfJyArIGogKyAnXCIgY2hlY2tlZD4nICtcclxuXHRcdFx0XHRcdFx0JzxsYWJlbCBmb3I9XCJjYicgKyBsb2MgKyAnXycgKyBqICsgJ1wiPiAnICsgczAgKyAnICcgKyBjbGVhbi5kZXNjcmlwdGlvbiArICcgJyArICcgKCcgKyBzMyArICcpPC9sYWJlbD48YnI+XFxuJyBcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcblx0aWYgKHMyID09ICcnKSB7XHJcblx0XHRhbGVydCAoJ05vdGhpbmcgdG8gY2hhbmdlLicpXHJcblx0fSBlbHNlIHtcclxuXHRcdHRiLmVsRGxnLmlubmVySFRNTCA9IFxyXG5cdFx0XHQnPGgzPkF1dG9tYXRlZCBjbGVhbnVwPC9oMz4nICsgXHJcblx0XHRcdHMyICtcclxuXHRcdFx0JzxkaXYgc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCI+JytcclxuXHRcdFx0Ly9PSywgQ2FuY2VsXHJcblx0XHRcdCc8YSBjbGFzcz1cImJ1dHRvblwiIGhyZWY9XCJodHRwczovL3d3dy53aWtpdHJlZS5jb20vd2lraS9TcGFjZTpXaWtpVHJlZV9QbHVzX0Nocm9tZV9FeHRlbnNpb24jUHJvZmlsZV9DbGVhbnVwXCIgdGFyZ2V0PVwiX2JsYW5rXCI+SGVscDwvYT4nICtcclxuXHRcdFx0JzxidXR0b24gc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ1Byb2ZpbGVDbGVhbnVwQnRuXCIgZGF0YS1pZD1cIjBcIj5DbG9zZTwvYnV0dG9uPicgK1xyXG5cdFx0XHQnPGJ1dHRvbiBzdHlsZT1cInRleHQtYWxpZ246cmlnaHRcIiBjbGFzcz1cImRsZ0NsaWNrXCIgZGF0YS1vcD1cIm9uRGxnUHJvZmlsZUNsZWFudXBCdG5cIiBkYXRhLWlkPVwiMVwiIHZhbHVlPVwiZGVmYXVsdFwiPlNlbGVjdDwvYnV0dG9uPicgK1xyXG5cdFx0XHQnPC9kaXY+JyBcclxuXHRcdGF0dGFjaEV2ZW50cygnYnV0dG9uLmRsZ0NsaWNrJywgJ2NsaWNrJylcclxuXHRcdGF0dGFjaEV2ZW50cygnaW5wdXQuY2JJbmxpbmUnLCAnaW5wdXQnKVxyXG5cdFx0dGIuZWxEbGcuc2hvd01vZGFsKCk7XHJcblx0fVxyXG59O1xyXG5cclxuZnVuY3Rpb24gb25EbGdQcm9maWxlQ2xlYW51cEJ0bih1cGRhdGUpIHtcclxuXHR0Yi5lbERsZy5jbG9zZSgpO1xyXG5cdGlmICh1cGRhdGU9PT0nMScpIHtcclxuXHRcdC8vU2V0IHVwZGF0ZWQgdGV4dFxyXG5cclxuXHRcdGxldCBzMCA9ICcnXHJcblx0XHRsZXQgczEgPSAnJ1xyXG5cdFx0bGV0IHMyID0gJydcclxuXHRcdGxldCBhY3RBcnIgPSBbXVxyXG5cdFx0Zm9yICh2YXIgbG9jPTA7bG9jPDM7bG9jKyspIHtcclxuXHRcdFx0aWYgKGxvYz09MCkge1xyXG5cdFx0XHRcdHMwID0gJ0JpcnRoIExvY2F0aW9uJ1xyXG5cdFx0XHRcdHMxID0gdGIuYmlydGhMb2NhdGlvblxyXG5cdFx0XHRcdGFjdEFyciA9IHRiLmxvY2F0aW9uc1xyXG5cdFx0XHR9IGVsc2UgaWYgKGxvYz09MSkge1xyXG5cdFx0XHRcdHMwID0gJ0RlYXRoIExvY2F0aW9uJ1xyXG5cdFx0XHRcdHMxID0gdGIuZGVhdGhMb2NhdGlvblxyXG5cdFx0XHRcdGFjdEFyciA9IHRiLmxvY2F0aW9uc1xyXG5cdFx0XHR9IGVsc2UgaWYgKGxvYz09Mikge1xyXG5cdFx0XHRcdHMwID0gJ0JpbydcclxuXHRcdFx0XHRzMSA9IHRiLnRleHRBbGxcclxuXHRcdFx0XHRhY3RBcnIgPSB0Yi5jbGVhbnVwXHJcblx0XHRcdH1cclxuXHRcdFx0aWYgKGFjdEFycikge1xyXG5cdFx0XHRcdGZvciAodmFyIGo9MDtqPGFjdEFyci5sZW5ndGg7aisrKSB7XHJcblx0XHRcdFx0XHR2YXIgY2IgPSB0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcjY2InK2xvYysnXycrailbMF1cclxuXHRcdFx0XHRcdGlmICgoY2IpICYmIChjYi5jaGVja2VkKSkge1xyXG5cdFx0XHRcdFx0XHRsZXQgY2xlYW4gPSBhY3RBcnJbal1cclxuXHJcblx0XHRcdFx0XHRcdGxldCBzID0gJydcclxuXHRcdFx0XHRcdFx0bGV0IHMxID0gJydcclxuXHRcdFx0XHRcdFx0bGV0IHMzID0gJydcclxuXHRcdFx0XHRcdFx0Zm9yICh2YXIgaT0wO2k8Y2xlYW4uYWN0aW9ucy5sZW5ndGg7aSsrKSB7XHJcblx0XHRcdFx0XHRcdFx0cyA9IHMxXHJcblx0XHRcdFx0XHRcdFx0bGV0IGFjdGlvbiA9IGNsZWFuLmFjdGlvbnNbaV1cclxuXHRcdFx0XHRcdFx0XHRzd2l0Y2goYWN0aW9uLmFjdGlvbikge1xyXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSBcInJlcGxhY2VSZWdFeFwiOiBcclxuXHRcdFx0XHRcdFx0XHRcdGxldCByZWcgPSBSZWdFeHAoYWN0aW9uLmZyb20sIGFjdGlvbi5mbGFncylcclxuXHRcdFx0XHRcdFx0XHRcdHMxID0gczEucmVwbGFjZShyZWcsIGFjdGlvbi50bylcclxuXHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSBcInJlcGxhY2VcIjogXHJcblx0XHRcdFx0XHRcdFx0XHRzMSA9IHMxLnJlcGxhY2UoYWN0aW9uLmZyb20sIGFjdGlvbi50bylcclxuXHRcdFx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0XHRcdFx0ZGVmYXVsdDogXHJcblx0XHRcdFx0XHRcdFx0XHRzMSA9ICcnXHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcdGlmIChzMT09JycpIGJyZWFrXHJcblx0XHRcdFx0XHRcdFx0aWYgKChzMSE9PScnKSAmJiAocyAhPT0gczEpKSB7XHJcblx0XHRcdFx0XHRcdFx0XHRzMyArPSAoczMhPT0nJyA/ICcsICcgOiAnJykgKyBhY3Rpb24uZGVzY3JpcHRpb25cclxuXHRcdFx0XHRcdFx0XHR9ICAgIFxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdGlmIChzMyE9PScnKSB7XHJcblx0XHRcdFx0XHRcdFx0czIgKz0gKHMyIT09JycgPyAnLCAnIDogJycgKSArICcrJyArIHMwICsgJyAnICsgY2xlYW4uZGVzY3JpcHRpb24gKyAnICgnICsgczMgKyAnKScgXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0aWYgKGxvYz09MCkge1xyXG5cdFx0XHRcdHRiLmJpcnRoTG9jYXRpb25SZXN1bHQgPSBzMTtcclxuXHRcdFx0fSBlbHNlIGlmIChsb2M9PTEpIHtcclxuXHRcdFx0XHR0Yi5kZWF0aExvY2F0aW9uUmVzdWx0ID0gczE7XHJcblx0XHRcdH0gZWxzZSBpZiAobG9jPT0yKSB7XHJcblx0XHRcdFx0dGIudGV4dFJlc3VsdCA9IHMxO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHR0Yi5hZGRUb1N1bW1hcnkgPSBzMjtcclxuXHRcdHVwZGF0ZUVkaXQoKTtcclxuXHR9IGVsc2Uge1xyXG5cdFx0dGIuZWxEbGcuaW5uZXJIVE1MID0gJyc7XHJcblx0XHR0Yi5hZGRUb1N1bW1hcnkgPSAnJ1xyXG5cdH07XHJcblx0cmV0dXJuIGZhbHNlXHJcbn07XHJcblxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4vKiBQYXN0ZSBzb3VyY2UgcmVmb3JtYXQgICovXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbmZ1bmN0aW9uIHBhc3RlU291cmNlICgpIHtcclxuXHR0Yi5lbERsZy5pbm5lckhUTUwgPSBcclxuXHRcdCc8aDM+UGFzdGUgc291cmNlPC9oMz4nICsgXHJcblx0XHQnPGxhYmVsIGZvcj1cInNyY1Bhc3RlXCI+Q2xpcGJvYXJkOjwvbGFiZWw+PGJyPicgK1xyXG5cdFx0Jzx0ZXh0YXJlYSBjbGFzcz1cInNyY1Bhc3RlXCIgZGF0YS1vcD1cIm9uRGxnUGFzdGVTb3VyY2VQYXN0ZVwiIGRhdGEtaWQ9XCIxXCIgcGxhY2Vob2xkZXI9XCJQYXN0ZSBhIHNvdXJjZSBvciBVUkwgaGVyZS5cIiByb3dzPVwiNVwiIGNvbHM9XCI4MFwiPjwvdGV4dGFyZWE+PGJyPicgK1xyXG5cdFx0JzxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzcz1cImNiSW5saW5lXCIgaWQ9XCJjYjFcIiBuYW1lPVwiY2IxXCIgZGF0YS1vcD1cIm9uRGxnUGFzdGVTb3VyY2VDQlwiIGRhdGEtaWQ9XCIxXCIgdmFsdWU9XCJJbmxpbmVcIiBjaGVja2VkPjxsYWJlbCBmb3I9XCJjYjFcIj4gSW5saW5lIGNpdGF0aW9uPC9sYWJlbD48YnI+JyArXHJcblx0XHQnPGxhYmVsIGZvcj1cInJlc3VsdEZsZFwiPkNpdGF0aW9uIHRvIGFkZDo8L2xhYmVsPjxicj4nICtcclxuXHRcdCc8dGV4dGFyZWEgY2xhc3M9XCJyZXN1bHRGbGRcIiByb3dzPVwiNVwiIGNvbHM9XCI4MFwiPjwvdGV4dGFyZWE+JyArXHJcblx0XHQnPGRpdiBzdHlsZT1cInRleHQtYWxpZ246cmlnaHRcIj4nK1xyXG5cdFx0Ly9PSywgQ2FuY2VsXHJcblx0XHQnPGEgY2xhc3M9XCJidXR0b25cIiBocmVmPVwiaHR0cHM6Ly93d3cud2lraXRyZWUuY29tL3dpa2kvU3BhY2U6V2lraVRyZWVfUGx1c19DaHJvbWVfRXh0ZW5zaW9uI1Bhc3RlX1NvdXJjZXNcIiB0YXJnZXQ9XCJfYmxhbmtcIj5IZWxwPC9hPicgK1xyXG5cdFx0JzxidXR0b24gc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ1Bhc3RlU291cmNlQnRuXCIgZGF0YS1pZD1cIjBcIj5DbG9zZTwvYnV0dG9uPicgK1xyXG5cdFx0JzxidXR0b24gc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0XCIgY2xhc3M9XCJkbGdDbGlja1wiIGRhdGEtb3A9XCJvbkRsZ1Bhc3RlU291cmNlQnRuXCIgZGF0YS1pZD1cIjFcIiB2YWx1ZT1cImRlZmF1bHRcIj5TZWxlY3Q8L2J1dHRvbj4nICtcclxuXHRcdCc8L2Rpdj4nIFxyXG5cdGF0dGFjaEV2ZW50cygnYnV0dG9uLmRsZ0NsaWNrJywgJ2NsaWNrJylcclxuXHRhdHRhY2hFdmVudHMoJ2lucHV0LmNiSW5saW5lJywgJ2lucHV0JylcclxuXHRhdHRhY2hFdmVudHMoJ3RleHRhcmVhLnNyY1Bhc3RlJywgJ3Bhc3RlJylcclxuXHR0Yi5lbERsZy5zaG93TW9kYWwoKTtcclxufTtcclxuXHJcbmZ1bmN0aW9uIG9uRGxnUGFzdGVTb3VyY2VCdG4odXBkYXRlKSB7XHJcblx0dGIuZWxEbGcuY2xvc2UoKTtcclxuXHRpZiAodXBkYXRlPT09JzEnKSB7XHJcblx0XHQvL0FkZCB0ZW1wbGF0ZSBcclxuXHRcdHRiLmluc2VydHRleHQgPSB0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcucmVzdWx0RmxkJylbMF0udmFsdWU7XHJcblx0XHR0Yi5pbnNlcnR0ZXh0ICs9ICh0Yi50ZXh0QWZ0ZXJbMF09PT0nXFxuJykgPyAnJzogJ1xcbic7XHJcblx0XHR0Yi50ZXh0UmVzdWx0ID0gdGIudGV4dEJlZm9yZSArIHRiLmluc2VydHRleHQgKyB0Yi50ZXh0QWZ0ZXI7XHJcblx0XHR0Yi5zZWxTdGFydCA9IHRiLnRleHRCZWZvcmUubGVuZ3RoXHJcblx0XHR0Yi5zZWxFbmQgPSB0Yi5zZWxTdGFydCArICB0Yi5pbnNlcnR0ZXh0Lmxlbmd0aDtcclxuXHRcdHRiLmJpcnRoTG9jYXRpb25SZXN1bHQgPSAnJztcclxuXHRcdHRiLmRlYXRoTG9jYXRpb25SZXN1bHQgPSAnJztcclxuXHRcdHVwZGF0ZUVkaXQoKTtcclxuXHR9IGVsc2Uge1xyXG5cdFx0dGIuZWxEbGcuaW5uZXJIVE1MID0gJyc7XHJcblx0XHR0Yi5hZGRUb1N1bW1hcnkgPSAnJ1xyXG5cdH07XHJcblx0cmV0dXJuIGZhbHNlXHJcbn07XHJcblxyXG5mdW5jdGlvbiBvbkRsZ1Bhc3RlU291cmNlQ0IoaSwgZXZ0KSB7XHJcblx0dmFyIGUgPSB0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcucmVzdWx0RmxkJylbMF1cclxuXHRsZXQgcyA9IGUudmFsdWUucmVwbGFjZSgnPHJlZj4nLCAnJykucmVwbGFjZSgnPC9yZWY+JywgJycpLnJlcGxhY2UoJyogJywgJycpXHJcblx0aWYgKHRiLmVsRGxnLnF1ZXJ5U2VsZWN0b3JBbGwoJy5jYklubGluZScpWzBdLmNoZWNrZWQpIHtcclxuXHRcdGUudmFsdWUgPSAnPHJlZj4nICsgcyArICc8L3JlZj4nXHJcblx0fSBlbHNlIHtcclxuXHRcdGUudmFsdWUgPSAnKiAnICsgc1xyXG5cdH1cclxufVxyXG5cclxuLy9saXN0ZW5lciBmb3IgcGFzdGUgZXZlbnRcclxuZnVuY3Rpb24gb25EbGdQYXN0ZVNvdXJjZVBhc3RlKGksIGV2dCkge1xyXG5cdGlmIChldnQudHlwZSA9PSAna2V5cHJlc3MnKSB7XHJcblx0XHR2YXIga2V5ID0gZXZ0LndoaWNoIHx8IGV2dC5rZXlDb2RlO1xyXG5cdFx0aWYgKGtleSA9PT0gMTMpIHsgXHJcblx0XHRcdG9uRGxnUGFzdGVTb3VyY2VCdG4oJzEnKVxyXG5cdFx0fSBcclxuXHR9IFxyXG5cdGlmIChldnQudHlwZSA9PSAncGFzdGUnKSB7XHJcblx0XHR2YXIgY2xpcGRhdGEgPSBldnQuY2xpcGJvYXJkRGF0YSB8fCB3aW5kb3cuY2xpcGJvYXJkRGF0YTtcclxuXHRcdHZhciBzID0gY2xpcGRhdGEuZ2V0RGF0YSgndGV4dC9wbGFpbicpO1xyXG5cdFx0dmFyIHMxID0gJyc7XHJcblx0XHRzID0gZGVjb2RlVVJJQ29tcG9uZW50IChzKTtcclxuXHJcblx0XHRpZiAodGIuc291cmNlcykge1xyXG5cdFx0XHRmb3IgKGxldCBzb3VyY2Ugb2YgdGIuc291cmNlcykge1xyXG5cdFx0XHRcdHZhciBiID0gZmFsc2VcclxuXHRcdFx0XHRmb3IgKGxldCBjb25kaXRpb24gb2Ygc291cmNlLmNvbmRpdGlvbnMpIHtcclxuXHRcdFx0XHRcdHN3aXRjaChjb25kaXRpb24uYWN0aW9uKSB7XHJcblx0XHRcdFx0XHRcdGNhc2UgXCJzdGFydHNXaXRoXCI6IFxyXG5cdFx0XHRcdFx0XHRiID0gcy5zdGFydHNXaXRoKGNvbmRpdGlvbi5maW5kKVxyXG5cdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0Y2FzZSBcImluY2x1ZGVzXCI6IFxyXG5cdFx0XHRcdFx0XHRiID0gcy5pbmNsdWRlcyhjb25kaXRpb24uZmluZClcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGFsZXJ0ICgnVW5rbm93biBjb25kaXRpb246ICcgKyBjb25kaXRpb24uYWN0aW9uICsgJyBkZWZpbmVkIGZvciBzb3VyY2U6ICcgKyBzb3VyY2UubmFtZSlcclxuXHRcdFx0XHRcdH0gICBcclxuXHRcdFx0XHRcdGlmIChiKSBicmVhaztcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0aWYgKGIpIHtcclxuXHRcdFx0XHRcdHMxID0gc1xyXG5cdFx0XHRcdFx0Zm9yIChsZXQgYWN0aW9uIG9mIHNvdXJjZS5hY3Rpb25zKSB7XHJcblx0XHRcdFx0XHRcdHN3aXRjaChhY3Rpb24uYWN0aW9uKSB7XHJcblx0XHRcdFx0XHRcdFx0Y2FzZSBcInJlcGxhY2VSZWdFeFwiOiBcclxuXHRcdFx0XHRcdFx0XHRsZXQgcmVnID0gUmVnRXhwKGFjdGlvbi5mcm9tLCAnbWcnKVxyXG5cdFx0XHRcdFx0XHRcdHMxID0gczEucmVwbGFjZShyZWcsIGFjdGlvbi50bylcclxuXHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRjYXNlIFwicmVwbGFjZVwiOiBcclxuXHRcdFx0XHRcdFx0XHRzMSA9IHMxLnJlcGxhY2UoYWN0aW9uLmZyb20sIGFjdGlvbi50bylcclxuXHRcdFx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0OiBcclxuXHRcdFx0XHRcdFx0XHRhbGVydCAoJ1Vua25vd24gYWN0aW9uOiAnICsgYWN0aW9uLmFjdGlvbiArICcgZGVmaW5lZCBmb3Igc291cmNlOiAnICsgc291cmNlLm5hbWUpXHJcblx0XHRcdFx0XHRcdFx0czEgPSAnJ1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdGlmIChzMT09JycpIGJyZWFrXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRpZiAoczEhPT0nJykge1xyXG5cdFx0XHRcdFx0XHR0Yi5hZGRUb1N1bW1hcnkgPSAnQWRkZWQgJyArIHNvdXJjZS5kZXNjcmlwdGlvblxyXG5cdFx0XHRcdFx0XHRicmVha1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdC8vIEFkZGluZyBpbmxpbmUgY2l0YXRpb25cclxuXHRcdGlmIChzMSE9PScnKSB7XHJcblx0XHRcdGlmICh0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcuY2JJbmxpbmUnKVswXS5jaGVja2VkKSB7XHJcblx0XHRcdFx0czEgPSAnPHJlZj4nICsgczEgKyAnPC9yZWY+J1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdHMxID0gJyogJyArIHMxXHJcblx0XHRcdH0gXHJcblx0XHR9XHJcblx0XHR0Yi5lbERsZy5xdWVyeVNlbGVjdG9yQWxsKCcucmVzdWx0RmxkJylbMF0udmFsdWUgPSBzMVxyXG5cdH1cclxufVxyXG5cclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4vKiBNZW51IGV2ZW50cyAgICAgICAgICAgICovXHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbmZ1bmN0aW9uIHBvc1RvT2Zmc2V0ICh0eHQsIHBvcyl7XHJcbiAgY29uc3QgYXJyPXR4dC5zcGxpdChcIlxcblwiKTtcclxuICB2YXIgbGVuPTA7XHJcbiAgZm9yICh2YXIgaT0wO2k8cG9zLmxpbmU7aSsrKSBcclxuXHRsZW4rPSBsZW5ndGgoYXJyW2ldKSArIDEgO1xyXG4gIHJldHVybiBsZW4rcG9zLmNoIDtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB3dFBsdXMgKHBhcmFtcyl7XHJcblx0aWYgKHRiLmVsVGV4dC5zdHlsZS5kaXNwbGF5ID09IFwibm9uZVwiKSB7XHJcblx0XHRhbGVydCgnRW5oYW5jZWQgZWRpdG9yIGlzIG5vdCBzdXBwb3J0ZWQuXFxuXFxuVHVybmluZyBpdCBvZmYgdG8gdXNlIHRoZSBleHRlbnNpb24uJyk7XHJcblx0XHR0Yi5lbEVuaGFuY2VkLmNsaWNrKCk7XHJcblx0fVxyXG5cclxuXHQvL1NldHMgYWxsIGVkaXQgdmFyaWFibGVzXHJcblx0dGIuZWxFbmhhbmNlZEFjdGl2ZSA9ICh0Yi5lbFRleHQuc3R5bGUuZGlzcGxheSA9PSBcIm5vbmVcIik7XHJcblx0aWYgKHRiLmVsRW5oYW5jZWRBY3RpdmUpIHtcclxuXHRcdHRiLmVsRW5oYW5jZWQuY2xpY2soKTtcclxuXHRcdFx0XHJcblx0XHRcdFxyXG4vLyAgICAgICAgICAgIGFsZXJ0ICgnRW5oYW5jZWQgZWRpdG9yIGlzIG5vdCBzdXBwb3J0ZWQuPGJyPlR1cm4gaXQgb2ZmIHRvIHVzZSBXaWtpVHJlZSsgZXh0ZW5zaW9uLicpO1xyXG4vKlxyXG5cdFx0aWYgKHdpbmRvdy5jb2xvcmVkRWRpdG9yKSB7XHJcblx0XHRcdHRiLnRleHRBbGwgPSBjb2xvcmVkRWRpdG9yLmdldFZhbHVlKCkucmVwbGFjZSgvXFxyXFxufFxcblxccnxcXG58XFxyL2csICdcXG4nKVxyXG5cdFx0XHR0Yi5zZWxTdGFydCA9IHBvc1RvT2Zmc2V0ICh0Yi50ZXh0QWxsLCBjb2xvcmVkRWRpdG9yLmdldEN1cnNvcihcImZyb21cIikpXHJcblx0XHRcdHRiLnNlbEVuZCA9IHBvc1RvT2Zmc2V0ICh0Yi50ZXh0QWxsLCBjb2xvcmVkRWRpdG9yLmdldEN1cnNvcihcInRvXCIpKVxyXG4qL1xyXG5cdFx0fVxyXG5cclxuXHR0Yi5zZWxTdGFydCA9IHRiLmVsVGV4dC5zZWxlY3Rpb25TdGFydDtcclxuXHR0Yi5zZWxFbmQgPSB0Yi5lbFRleHQuc2VsZWN0aW9uRW5kO1xyXG5cdHRiLnRleHRBbGwgPSB0Yi5lbFRleHQudmFsdWU7XHJcblx0aWYgKHRiLmVsQmlydGhMb2NhdGlvbikge1xyXG5cdFx0dGIuYmlydGhMb2NhdGlvbiA9IHRiLmVsQmlydGhMb2NhdGlvbi52YWx1ZTtcclxuXHR9XHJcblx0aWYgKHRiLmVsRGVhdGhMb2NhdGlvbikge1xyXG5cdFx0dGIuZGVhdGhMb2NhdGlvbiA9IHRiLmVsRGVhdGhMb2NhdGlvbi52YWx1ZTtcclxuXHR9XHJcblx0aWYgKHRiLmVsRW5oYW5jZWRBY3RpdmUpIHtcclxuXHRcdHRiLmVsRW5oYW5jZWQuY2xpY2soKTtcclxuXHR9XHJcblxyXG5cdHRiLnRleHRCZWZvcmUgPSB0Yi50ZXh0QWxsLnN1YnN0cmluZygwLCAgdGIuc2VsU3RhcnQpO1xyXG5cdHRiLnRleHRTZWxlY3RlZCA9IHRiLnNlbEVuZCA9PSB0Yi5zZWxTdGFydCA/ICcnIDogdGIudGV4dEFsbC5zdWJzdHJpbmcodGIuc2VsU3RhcnQsIHRiLnNlbEVuZCk7XHJcblx0dGIudGV4dEFmdGVyID0gdGIudGV4dEFsbC5zdWJzdHJpbmcodGIuc2VsRW5kKTtcclxuXHR0Yi5jYXRlZ29yaWVzID0gdGIudGV4dEFsbC5tYXRjaCgvXFxbXFxbQ2F0ZWdvcnk6Lio/XFxdXFxdL21naSlcclxuXHRpZiAodGIuY2F0ZWdvcmllcyl7XHJcblx0XHR0Yi5jYXRlZ29yaWVzID0gdGIuY2F0ZWdvcmllcy5qb2luKCdcXG4nKS5yZXBsYWNlKC9cXFtcXFtDYXRlZ29yeTpcXHMqKC4qPylcXHMqXFxdXFxdL21naSwgJyQxJyk7XHJcblx0fSAgICAgICAgXHJcblx0dGIudGV4dFJlc3VsdCA9IHRiLnRleHRBbGw7IFxyXG5cclxuXHRpZiAocGFyYW1zLnRlbXBsYXRlKSB7XHJcblx0XHQvL0FkZCB0ZW1wbGF0ZSBcclxuXHRcdHBhcmFtc0NvcHkgKHBhcmFtcy50ZW1wbGF0ZSlcclxuXHRcdHBhcmFtc0luaXRpYWxWYWx1ZXMgKCk7XHJcblx0XHRlZGl0VGVtcGxhdGUgKFwiQWRkZWRcIik7XHJcblx0fSBlbHNlIHtcclxuXHRcdHN3aXRjaChwYXJhbXMuYWN0aW9uKSB7XHJcblx0XHRcdGNhc2UgXCJcIjogYnJlYWs7XHJcblx0XHRcdGNhc2UgXCJFZGl0VGVtcGxhdGVcIjogLy9FZGl0IHRlbXBsYXRlXHJcbi8vICAgICAgICAgICAgdmFyIGV4cHJlc3Npb24gPSAve3tbXFxzXFxTXSo/fX0vZ1xyXG5cdFx0dmFyIGV4cHJlc3Npb24gPSAvXFx7XFx7Lio/KFxcW1xcW1tee31bXFxdXSo/XFxdXFxdW157fVtcXF1dKj98XFxbW157fVtcXF1dKj9cXF1bXnt9W1xcXV0qP3xcXHtcXHtbXnt9W1xcXV0qP1xcfVxcfVtee31bXFxdXSo/KSo/W157fVtcXF1dKj9cXH1cXH0vZ21zXHJcblxyXG5cclxuXHRcdGlmICh0Yi5zZWxTdGFydCAhPSB0Yi5zZWxFbmQpIHtcclxuXHRcdFx0bGV0IHRlbSA9IHRiLnRleHRTZWxlY3RlZC5tYXRjaChleHByZXNzaW9uKTtcclxuXHRcdFx0aWYgKHRlbSAmJiAodGVtLmxlbmd0aCA9PSAxKSkge1xyXG5cdFx0XHRcdHZhciBzID0gdGIudGV4dFNlbGVjdGVkLnNwbGl0KGV4cHJlc3Npb24pO1xyXG5cdFx0XHRcdHRiLnRleHRCZWZvcmUgKz0gc1swXTtcclxuXHRcdFx0XHR0Yi50ZXh0U2VsZWN0ZWQgPSB0ZW1bMF07XHJcblx0XHRcdFx0dGIudGV4dEFmdGVyID0gc1syXSArIHRiLnRleHRBZnRlcjtcclxuXHRcdFx0XHR0Yi5zZWxTdGFydCA9IHRiLnRleHRCZWZvcmUubGVuZ3RoXHJcblx0XHRcdFx0dGIuc2VsRW5kID0gdGIuc2VsU3RhcnQgKyB0Yi50ZXh0U2VsZWN0ZWQubGVuZ3RoO1xyXG5cdFx0XHRcdHBhcmFtc0Zyb21TZWxlY3Rpb24oKTtcclxuXHRcdFx0XHRlZGl0VGVtcGxhdGUoXCJFZGl0ZWRcIik7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0YWxlcnQgKCdUaGVyZSBpcyBubyB0ZW1wbGF0ZSBpbiBzZWxlY3RlZCB0ZXh0Jyk7XHJcblx0XHRcdH0gICAgXHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRsZXQgdGVtID0gdGIudGV4dEFsbC5tYXRjaChleHByZXNzaW9uKTtcclxuXHRcdFx0aWYgKHRlbSkge1xyXG5cdFx0XHRcdGlmICh0ZW0ubGVuZ3RoID09IDEpIHtcclxuXHRcdFx0XHRcdHZhciBzID0gdGIudGV4dEFsbC5zcGxpdChleHByZXNzaW9uKTtcclxuXHRcdFx0XHRcdHRiLnRleHRCZWZvcmUgPSBzWzBdO1xyXG5cdFx0XHRcdFx0dGIudGV4dFNlbGVjdGVkID0gdGVtWzBdO1xyXG5cdFx0XHRcdFx0dGIudGV4dEFmdGVyICA9IHNbMl07XHJcblx0XHRcdFx0XHR0Yi5zZWxTdGFydCA9IHRiLnRleHRCZWZvcmUubGVuZ3RoXHJcblx0XHRcdFx0XHR0Yi5zZWxFbmQgPSB0Yi5zZWxTdGFydCArIHRiLnRleHRTZWxlY3RlZC5sZW5ndGg7XHJcblx0XHRcdFx0XHRwYXJhbXNGcm9tU2VsZWN0aW9uKCk7XHJcblx0XHRcdFx0XHRlZGl0VGVtcGxhdGUoXCJFZGl0ZWRcIik7XHJcblx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdGxldCBtYXRjaCA9ICcnXHJcblx0XHRcdFx0XHR3aGlsZSAobWF0Y2ggPSBleHByZXNzaW9uLmV4ZWModGIudGV4dEFsbCkpIHtcclxuXHRcdFx0XHRcdFx0aWYgKChtYXRjaC5pbmRleCA8IHRiLnNlbFN0YXJ0KSAmJiAoZXhwcmVzc2lvbi5sYXN0SW5kZXggPiB0Yi5zZWxTdGFydCkpIHtcclxuXHRcdFx0XHRcdFx0XHR0Yi50ZXh0QmVmb3JlID0gdGIudGV4dEFsbC5zdWJzdHJpbmcoMCwgIG1hdGNoLmluZGV4KTtcclxuXHRcdFx0XHRcdFx0XHR0Yi50ZXh0U2VsZWN0ZWQgPSBtYXRjaFswXTtcclxuXHRcdFx0XHRcdFx0XHR0Yi50ZXh0QWZ0ZXIgID0gdGIudGV4dEFsbC5zdWJzdHJpbmcoZXhwcmVzc2lvbi5sYXN0SW5kZXgpO1xyXG5cdFx0XHRcdFx0XHRcdHRiLnNlbFN0YXJ0ID0gdGIudGV4dEJlZm9yZS5sZW5ndGhcclxuXHRcdFx0XHRcdFx0XHR0Yi5zZWxFbmQgPSB0Yi5zZWxTdGFydCArIHRiLnRleHRTZWxlY3RlZC5sZW5ndGg7XHJcblx0XHRcdFx0XHRcdFx0cGFyYW1zRnJvbVNlbGVjdGlvbigpO1xyXG5cdFx0XHRcdFx0XHRcdGVkaXRUZW1wbGF0ZShcIkVkaXRlZFwiKTtcclxuXHRcdFx0XHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdFx0XHRcdH07XHJcblx0XHRcdFx0XHR9O1xyXG5cdFx0XHRcdFx0YWxlcnQgKCdUaGVyZSBpcyBubyB0ZW1wbGF0ZSBhdCBjdXJzb3IgcG9zaXRpb24uJylcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0YWxlcnQgKCdUaGVyZSBpcyBubyB0ZW1wbGF0ZSBvbiB0aGUgcGFnZS4nKVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHRicmVhaztcclxuXHJcblx0XHRjYXNlIFwiQXV0b0Zvcm1hdFwiOiAvL2F1dG9tYXRpYyBmb3JtdGluZ1xyXG5cdFx0dGIudGV4dFJlc3VsdCA9IHRiLnRleHRBbGwucmVwbGFjZSgvXiAqXFx8ICooW14gPXxdKikgKj0gKi9tZywgXCJ8JDE9IFwiKVxyXG5cdFx0dGIuYmlydGhMb2NhdGlvblJlc3VsdCA9ICcnO1xyXG5cdFx0dGIuZGVhdGhMb2NhdGlvblJlc3VsdCA9ICcnO1xyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gJydcclxuXHRcdHVwZGF0ZUVkaXQgKCk7XHJcblx0XHRicmVhaztcclxuXHJcblx0XHRjYXNlIFwiQXV0b1VwZGF0ZVwiOiAvL2F1dG9tYXRpYyBjb3JyZWN0aW9uc1xyXG5cdFx0QXV0b1VwZGF0ZSAoKTtcclxuXHRcdGJyZWFrOyAgIFxyXG5cclxuXHRcdGNhc2UgXCJFZGl0Qk9UQ29uZmlybVwiOiAvL0VkaXRCT1QgY29uZmlybWF0aW9uXHJcblx0XHR0Yi50ZXh0UmVzdWx0ID0gdGIudGV4dEFsbC5yZXBsYWNlKC9cXHwoUmV2aWV3fE1hbnVhbClcXH1cXH0vbWcsIFwifENvbmZpcm1lZH19XCIpXHJcblx0XHR0Yi50ZXh0UmVzdWx0ID0gdGIudGV4dFJlc3VsdC5yZXBsYWNlKC9cXHNcXHNcXH1cXH0vbWcsIFwiIFwiKVxyXG5cdFx0dGIuYmlydGhMb2NhdGlvblJlc3VsdCA9ICcnO1xyXG5cdFx0dGIuZGVhdGhMb2NhdGlvblJlc3VsdCA9ICcnO1xyXG5cdFx0dGIuYWRkVG9TdW1tYXJ5ID0gXCJDb25maXJtYXRpb24gZm9yIEVkaXRCT1RcIlxyXG5cdFx0dXBkYXRlRWRpdCAoKTtcclxuXHRcdGJyZWFrO1xyXG5cdFx0XHJcblx0XHRjYXNlIFwiQWRkVGVtcGxhdGVcIjogLy9hZGQgYW55IHRlbXBsYXRlXHJcblx0XHRzZWxlY3RUZW1wbGF0ZSAocGFyYW1zLmRhdGEpO1xyXG5cdFx0YnJlYWs7XHJcblxyXG5cdFx0Y2FzZSBcIlBhc3RlU291cmNlXCI6IC8vcGFzdGUgYSBzb3VyY2UgY2l0YXRpb25cclxuXHRcdHBhc3RlU291cmNlICgpO1xyXG5cdFx0YnJlYWs7XHJcblx0XHRcclxuXHJcblx0XHRkZWZhdWx0OiBhbGVydCAoXCJVbmtub3duIGV2ZW50IFwiICsgcGFyYW1zLmFjdGlvbilcclxuXHRcdH07XHJcblx0fTtcclxuXHRcclxufTtcclxuXHJcbi8qIENsYXNzZXMgKi9cclxuXHJcbmNvbnN0IGF0dGFjaENsYXNzID0gKHNlbGVjdG9yLCBjbGFzc05hbWUpID0+IHtcclxuXHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKS5mb3JFYWNoKGk9PmkuY2xhc3NMaXN0LmFkZChjbGFzc05hbWUpKVxyXG59XHJcblxyXG5jb25zdCByZW1vdmVDbGFzcyA9IChzZWxlY3RvciwgY2xhc3NOYW1lKSA9PiB7XHJcblx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcikuZm9yRWFjaChpPT5pLmNsYXNzTGlzdC5yZW1vdmUoY2xhc3NOYW1lKSlcclxufVxyXG5cclxuLyogRXZlbnRzICovXHJcblxyXG5jb25zdCBhdHRhY2hFdmVudHMgPSAoc2VsZWN0b3IsIGV2ZW50VHlwZSkgPT4ge1xyXG5cdGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3IpLmZvckVhY2goaT0+aS5hZGRFdmVudExpc3RlbmVyKGV2ZW50VHlwZSwgZXZlbnQ9Pm1haW5FdmVudExvb3AoZXZlbnQpKSlcclxufVxyXG5mdW5jdGlvbiBtYWluRXZlbnRMb29wIChldmVudCkge1xyXG5cclxuXHRpZiAodGIuZWxUZXh0LnN0eWxlLmRpc3BsYXkgPT0gXCJub25lXCIpIHtcclxuXHRcdGFsZXJ0ICgnRW5oYW5jZWQgZWRpdG9yIGlzIG5vdCBzdXBwb3J0ZWQuXFxuXFxuVHVybmluZyBpdCBvZmYgdG8gdXNlIHRoZSBleHRlbnNpb24uJyk7XHJcblx0XHR0Yi5lbEVuaGFuY2VkLmNsaWNrKCk7XHJcblx0fSAgIFxyXG5cclxuXHRsZXQgZWxlbWVudCA9IGV2ZW50LnNyY0VsZW1lbnRcclxuXHRpZiAoZWxlbWVudC50YWdOYW1lID09ICdURCcpIHtcclxuXHRcdGVsZW1lbnQgPSBlbGVtZW50LnBhcmVudEVsZW1lbnRcclxuXHR9XHJcblx0Y29uc3Qgb3AgPSBlbGVtZW50LmRhdGFzZXQub3BcclxuXHRjb25zdCBpZCA9IGVsZW1lbnQuZGF0YXNldC5pZFxyXG5cdGlmIChvcCA9PT0gJ3d0UGx1cycpICAgIHtldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXR1cm4gd3RQbHVzKGlkKX1cclxuXHRcclxuXHRpZiAob3AgPT09ICdvbkRsZ0VkaXRUZW1wbGF0ZUV4cENvbCcpIHtldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXR1cm4gb25EbGdFZGl0VGVtcGxhdGVFeHBDb2woaWQpfVxyXG5cdGlmIChvcCA9PT0gJ29uRGxnRWRpdFRlbXBsYXRlUmVzdG9yZScpICAgIHtldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXR1cm4gb25EbGdFZGl0VGVtcGxhdGVSZXN0b3JlKGlkKX1cclxuXHRpZiAob3AgPT09ICdvbkRsZ0VkaXRUZW1wbGF0ZUluaXRpYWwnKSAgICB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnRWRpdFRlbXBsYXRlSW5pdGlhbChpZCl9XHJcblx0aWYgKG9wID09PSAnb25EbGdFZGl0VGVtcGxhdGVGb2xsb3cnKSB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnRWRpdFRlbXBsYXRlRm9sbG93KGlkKX1cclxuXHRpZiAob3AgPT09ICdvbkRsZ0VkaXRUZW1wbGF0ZUJ0bicpICB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnRWRpdFRlbXBsYXRlQnRuKGlkKX1cclxuXHRpZiAob3AgPT09ICdvbkRsZ0VkaXRUZW1wbGF0ZVBhc3RlJykgIHJldHVybiBvbkRsZ0VkaXRUZW1wbGF0ZVBhc3RlKGlkLCBldmVudClcclxuXHJcblx0aWYgKG9wID09PSAnb25EbGdQYXN0ZVNvdXJjZVBhc3RlJykgIHJldHVybiBvbkRsZ1Bhc3RlU291cmNlUGFzdGUoaWQsIGV2ZW50KVxyXG5cdGlmIChvcCA9PT0gJ29uRGxnUGFzdGVTb3VyY2VDQicpICByZXR1cm4gb25EbGdQYXN0ZVNvdXJjZUNCKGlkLCBldmVudCkgICAgXHJcblx0aWYgKG9wID09PSAnb25EbGdQYXN0ZVNvdXJjZUJ0bicpIHtldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXR1cm4gb25EbGdQYXN0ZVNvdXJjZUJ0bihpZCl9XHJcblxyXG5cdGlmIChvcCA9PT0gJ29uRGxnUHJvZmlsZUNsZWFudXBCdG4nKSB7ZXZlbnQucHJldmVudERlZmF1bHQoKTsgcmV0dXJuIG9uRGxnUHJvZmlsZUNsZWFudXBCdG4oaWQpfVxyXG5cclxuXHRpZiAob3AgPT09ICdvbkRsZ1NlbGVjdFRlbXBsYXRlRmx0JykgcmV0dXJuIG9uRGxnU2VsZWN0VGVtcGxhdGVGbHQoKVxyXG5cdGlmIChvcCA9PT0gJ29uRGxnU2VsZWN0VGVtcGxhdGVUclNlbCcpIHJldHVybiBvbkRsZ1NlbGVjdFRlbXBsYXRlVHJTZWwoZWxlbWVudClcclxuXHRpZiAob3AgPT09ICdvbkRsZ1NlbGVjdFRlbXBsYXRlQnRuJykge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJldHVybiBvbkRsZ1NlbGVjdFRlbXBsYXRlQnRuKGlkKX1cclxuXHJcblx0aWYgKG9wID09PSAnb25EbGdOb25lJykge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJldHVybn1cclxuXHRcclxuXHRjb25zb2xlLmVycm9yICgnTWlzc2luZyBkYXRhLW9wIG9uICcsIGVsZW1lbnQpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzRWRpdFBhZ2UoKSB7XHJcblx0cmV0dXJuICh3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9U3BlY2lhbDpFZGl0UGVyc29uJi4qL2cpIHx8XHJcblx0ICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9LiomYWN0aW9uPWVkaXQuKi9nKSB8fFxyXG5cdFx0XHR3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvXFwvaW5kZXgucGhwXFw/dGl0bGU9LiomYWN0aW9uPXN1Ym1pdC4qL2cpKTtcclxufVxyXG5cclxuLyogSW5pdGlhbGl6YXRpb24gKi9cclxuY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoJ3d0cGx1cycsIChyZXN1bHQpID0+IHtcclxuXHRpZiAocmVzdWx0Lnd0cGx1cyAmJiBpc0VkaXRQYWdlKCkpIHtcclxuXHRcdHRiLm5hbWVTcGFjZSA9IChkb2N1bWVudC50aXRsZS5zdGFydHNXaXRoKCdFZGl0IFBlcnNvbiAnKSkgPyAnUHJvZmlsZScgOiAnJ1xyXG5cdFx0bGV0IHcgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdoMSA+IC5jb3B5V2lkZ2V0JylcclxuXHRcdGlmICh3KSB7XHJcblx0XHRcdHRiLndpa2l0cmVlSUQgPSB3LmdldEF0dHJpYnV0ZSgnZGF0YS1jb3B5LXRleHQnKTtcclxuXHRcdH1cclxuXHRcdHRiLmVsVGV4dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwid3BUZXh0Ym94MVwiKTtcclxuXHRcdHRiLmVsQmlydGhMb2NhdGlvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibUJpcnRoTG9jYXRpb25cIik7XHJcblx0XHR0Yi5lbERlYXRoTG9jYXRpb24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1EZWF0aExvY2F0aW9uXCIpO1xyXG5cclxuXHRcdHRiLmVsU3VtbWFyeSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwid3BTdW1tYXJ5XCIpO1xyXG5cdFx0dGIuZWxFbmhhbmNlZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidG9nZ2xlTWFya3VwQ29sb3JcIik7XHJcblxyXG5cdFx0ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0b29sYmFyXCIpLmluc2VydEFkamFjZW50SFRNTCgnYmVmb3JlZW5kJywgJzxkaWFsb2cgaWQ9XCJ3dFBsdXNEbGdcIj48L2RpYWxvZz4nKVxyXG5cdFx0dGIuZWxEbGcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInd0UGx1c0RsZ1wiKTtcclxuXHJcblx0XHQvLyBMb2FkaW5nIG9mIHRlbXBsYXRlIGRlZmluaXRpb24gRnJvbSBTdG9yYWdlXHJcblx0XHRjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydhbGx0ZW1wbGF0ZXMnXSwgZnVuY3Rpb24oYSl7XHJcblx0XHRcdGlmIChhLmFsbHRlbXBsYXRlcyAmJiBhLmFsbHRlbXBsYXRlcy52ZXJzaW9uKSB7XHJcblx0XHRcdFx0Ly8gSXMgaW4gc3RvcmFnZVxyXG5cdFx0XHRcdHRiLnRlbXBsYXRlcyA9IGEuYWxsdGVtcGxhdGVzLnRlbXBsYXRlcztcclxuXHRcdFx0XHR0Yi5jbGVhbnVwID0gYS5hbGx0ZW1wbGF0ZXMuY2xlYW51cDsgaWYgKCEodGIuY2xlYW51cCkpIHt0Yi5jbGVhbnVwID0gW119O1xyXG5cdFx0XHRcdHRiLmxvY2F0aW9ucyA9IGEuYWxsdGVtcGxhdGVzLmxvY2F0aW9uczsgaWYgKCEodGIubG9jYXRpb25zKSkge3RiLmxvY2F0aW9ucyA9IFtdfTtcclxuXHRcdFx0XHR0Yi5zb3VyY2VzID0gYS5hbGx0ZW1wbGF0ZXMuc291cmNlczsgaWYgKCEodGIuc291cmNlcykpIHt0Yi5zb3VyY2VzID0gW119O1xyXG5cdFx0XHRcdHRiLmRhdGFWZXJzaW9uID0gbmV3IERhdGUoYS5hbGx0ZW1wbGF0ZXMudmVyc2lvbik7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coJ1N0b3JhZ2U6ICcgKyB0Yi5kYXRhVmVyc2lvbiArICcsICcgKyAgdGIudGVtcGxhdGVzLmxlbmd0aCArICcgdGVtcGxhdGVzJyArICcsICcgKyAgdGIuY2xlYW51cC5sZW5ndGggKyAnIGNsZWFudXAnICsgJywgJyArIHRiLmxvY2F0aW9ucy5sZW5ndGggKyAnIGxvY2F0aW9ucycgKyAnLCAnICsgdGIuc291cmNlcy5sZW5ndGggKyAnIHNvdXJjZXMuJylcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQvLyBOb3QgaW4gc3RvcmFnZVxyXG5cdFx0XHRcdHRiLmRhdGFWZXJzaW9uID0gbmV3IERhdGUoXCIyMDAwLTAxLTAxVDAwOjAwOjAwKzAxOjAwXCIpO1xyXG5cdFx0XHR9IFxyXG5cdFx0XHQvLyBMb2FkaW5nIG9mIHRlbXBsYXRlIGRlZmluaXRpb24gRnJvbSBFeHRlbnNpb25cclxuXHRcdFx0ZmV0Y2goY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwiZmVhdHVyZXMvd3QrL3RlbXBsYXRlc0V4cC5qc29uXCIpKVxyXG5cdFx0XHQudGhlbigocmVzcCkgPT4gcmVzcC5qc29uKCkpXHJcblx0XHRcdC50aGVuKGpzb25EYXRhID0+IHtcclxuXHRcdFx0XHRjb25zdCBkID0gbmV3IERhdGUoanNvbkRhdGEudmVyc2lvbilcclxuXHRcdFx0XHRpZiAoZC5nZXRUaW1lICgpID4gdGIuZGF0YVZlcnNpb24uZ2V0VGltZSAoKSkge1xyXG5cdFx0XHRcdFx0Ly8gRXh0ZW5zaW9uIGRlZmluaXRpb24gaXMgbmV3ZXJcclxuXHRcdFx0XHRcdHRiLnRlbXBsYXRlcyA9IGpzb25EYXRhLnRlbXBsYXRlcztcclxuXHRcdFx0XHRcdHRiLmNsZWFudXAgPSBqc29uRGF0YS5jbGVhbnVwOyBpZiAoISh0Yi5jbGVhbnVwKSkge3RiLmNsZWFudXAgPSBbXX07XHJcblx0XHRcdFx0XHR0Yi5sb2NhdGlvbnMgPSBqc29uRGF0YS5sb2NhdGlvbnM7IGlmICghKHRiLmxvY2F0aW9ucykpIHt0Yi5sb2NhdGlvbnMgPSBbXX07XHJcblx0XHRcdFx0XHR0Yi5zb3VyY2VzID0ganNvbkRhdGEuc291cmNlczsgaWYgKCEodGIuc291cmNlcykpIHt0Yi5zb3VyY2VzID0gW119O1xyXG5cdFx0XHRcdFx0dGIuZGF0YVZlcnNpb24gPSBkO1xyXG5cdFx0XHRcdFx0Y29uc29sZS5sb2coJ0V4dGVuc2lvbjogJyArIHRiLmRhdGFWZXJzaW9uICsgJywgJyArICB0Yi50ZW1wbGF0ZXMubGVuZ3RoICsgJyB0ZW1wbGF0ZXMuJyArICcsICcgKyAgdGIuY2xlYW51cC5sZW5ndGggKyAnIGNsZWFudXAuJyArICcsICcgKyB0Yi5sb2NhdGlvbnMubGVuZ3RoICsgJyBsb2NhdGlvbnMnICsgJywgJyArIHRiLnNvdXJjZXMubGVuZ3RoICsgJyBzb3VyY2VzLicpXHJcblx0XHRcdFx0XHRjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1wiYWxsdGVtcGxhdGVzXCI6IGpzb25EYXRhfSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGlmICh0Yi5kYXRhVmVyc2lvbi5nZXRUaW1lICgpIDwgbmV3IERhdGUoKS5nZXRUaW1lICgpIC0gNiAqIDM2MDAgKiAxMDAwKSB7XHJcblx0XHRcdFx0XHQvLyBMb2FkaW5nIG9mIHRlbXBsYXRlIGRlZmluaXRpb24gRnJvbSBXZWJcclxuXHRcdFx0XHRcdGZldGNoKFwiaHR0cHM6Ly93aWtpdHJlZS5zZG1zLnNpL2Nocm9tZS90ZW1wbGF0ZXNFeHAuanNvblwiKVxyXG5cdFx0XHRcdFx0LnRoZW4oKHJlc3ApID0+IHJlc3AuanNvbigpKVxyXG5cdFx0XHRcdFx0LnRoZW4oanNvbkRhdGEgPT4ge1xyXG5cdFx0XHRcdFx0XHRjb25zdCBkID0gbmV3IERhdGUoanNvbkRhdGEudmVyc2lvbilcclxuXHRcdFx0XHRcdFx0aWYgKGQuZ2V0VGltZSAoKSA+IHRiLmRhdGFWZXJzaW9uLmdldFRpbWUgKCkpIHtcclxuXHRcdFx0XHRcdFx0XHQvLyBXZWIgZGVmaW5pdGlvbiBpcyBuZXdlclxyXG5cdFx0XHRcdFx0XHRcdHRiLnRlbXBsYXRlcyA9IGpzb25EYXRhLnRlbXBsYXRlcztcclxuXHRcdFx0XHRcdFx0XHR0Yi5jbGVhbnVwID0ganNvbkRhdGEuY2xlYW51cDsgaWYgKCEodGIuY2xlYW51cCkpIHt0Yi5jbGVhbnVwID0gW119O1xyXG5cdFx0XHRcdFx0XHRcdHRiLmxvY2F0aW9ucyA9IGpzb25EYXRhLmxvY2F0aW9uczsgaWYgKCEodGIubG9jYXRpb25zKSkge3RiLmxvY2F0aW9ucyA9IFtdfTtcclxuXHRcdFx0XHRcdFx0XHR0Yi5zb3VyY2VzID0ganNvbkRhdGEuc291cmNlczsgaWYgKCEodGIuc291cmNlcykpIHt0Yi5zb3VyY2VzID0gW119O1xyXG5cdFx0XHRcdFx0XHRcdHRiLmRhdGFWZXJzaW9uID0gZDtcclxuXHRcdFx0XHRcdFx0XHRjb25zb2xlLmxvZygnV2ViOiAnICsgdGIuZGF0YVZlcnNpb24gKyAnLCAnICsgIHRiLnRlbXBsYXRlcy5sZW5ndGggKyAnIHRlbXBsYXRlcy4nICsgJywgJyArICB0Yi5jbGVhbnVwLmxlbmd0aCArICcgY2xlYW51cC4nICsgJywgJyArIHRiLmxvY2F0aW9ucy5sZW5ndGggKyAnIGxvY2F0aW9ucycgKyAnLCAnICsgdGIuc291cmNlcy5sZW5ndGggKyAnIHNvdXJjZXMuJylcclxuXHRcdFx0XHRcdFx0XHRjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1wiYWxsdGVtcGxhdGVzXCI6IGpzb25EYXRhfSk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH0pXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9KVxyXG5cdFx0fSk7XHJcblx0fVxyXG59KTtcclxuXHJcbi8qXHJcblRvZG8uIEFkZCBzcGFjZXMgb24gZWRpdCBjb21tZW50LlxyXG4xLjAuNFxyXG4gICogQ29uZGVuc2VkIHRlbXBsYXRlIGluZm8gaW4gdGhlIGRpYWxvZyB0byBvY2N1cHkgbGVzcyBzcGFjZS5cclxuICAqIEFmdGVyIHN3aXRjaGluZyBvZmYgdGhlIGVuaGFuY2VkIGVkaXRvciB0aGUgc2VsZWN0ZWQgZnVuY3Rpb24gaXMgZXhlY3V0ZWQgaWYgcG9zc2libGUuXHJcbiAgKiBBdXRvQ29ycmVjdGlvbiBvZiBsb2NhdGlvbiBmaWVsZHMuXHJcbiAgKiBBZGRlZCBBdXRvQ29ycmVjdGlvbiB0byBjYXRlZ29yaWVzXHJcbiAgKiBJbXBsZW1lbnRlZCBjYXNlIGluc2Vuc2l0aXZlIGluIHRlbXBsYXRlIHBhcmFtZXRlciBuYW1lcyByZWNvZ25pdGlvblxyXG4qL1xyXG4iLCJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuJC5mbi5ob3ZlckRlbGF5ID0gZnVuY3Rpb24gKG4pIHtcclxuICB2YXIgZSA9IHsgZGVsYXlJbjogMzAwLCBkZWxheU91dDogMzAwLCBoYW5kbGVySW46IGZ1bmN0aW9uICgpIHt9LCBoYW5kbGVyT3V0OiBmdW5jdGlvbiAoKSB7fSB9O1xyXG4gIHJldHVybiAoXHJcbiAgICAobiA9ICQuZXh0ZW5kKGUsIG4pKSxcclxuICAgIHRoaXMuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgICAgIHZhciBlLFxyXG4gICAgICAgIHQsXHJcbiAgICAgICAgdSA9ICQodGhpcyk7XHJcbiAgICAgIHUuaG92ZXIoXHJcbiAgICAgICAgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgdCAmJiBjbGVhclRpbWVvdXQodCksXHJcbiAgICAgICAgICAgIChlID0gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgbi5oYW5kbGVySW4odSk7XHJcbiAgICAgICAgICAgIH0sIG4uZGVsYXlJbikpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgZSAmJiBjbGVhclRpbWVvdXQoZSksXHJcbiAgICAgICAgICAgICh0ID0gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgbi5oYW5kbGVyT3V0KHUpO1xyXG4gICAgICAgICAgICB9LCBuLmRlbGF5T3V0KSk7XHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgfSlcclxuICApO1xyXG59O1xyXG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdGlkOiBtb2R1bGVJZCxcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuLy8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbl9fd2VicGFja19yZXF1aXJlX18ubSA9IF9fd2VicGFja19tb2R1bGVzX187XG5cbiIsInZhciBkZWZlcnJlZCA9IFtdO1xuX193ZWJwYWNrX3JlcXVpcmVfXy5PID0gKHJlc3VsdCwgY2h1bmtJZHMsIGZuLCBwcmlvcml0eSkgPT4ge1xuXHRpZihjaHVua0lkcykge1xuXHRcdHByaW9yaXR5ID0gcHJpb3JpdHkgfHwgMDtcblx0XHRmb3IodmFyIGkgPSBkZWZlcnJlZC5sZW5ndGg7IGkgPiAwICYmIGRlZmVycmVkW2kgLSAxXVsyXSA+IHByaW9yaXR5OyBpLS0pIGRlZmVycmVkW2ldID0gZGVmZXJyZWRbaSAtIDFdO1xuXHRcdGRlZmVycmVkW2ldID0gW2NodW5rSWRzLCBmbiwgcHJpb3JpdHldO1xuXHRcdHJldHVybjtcblx0fVxuXHR2YXIgbm90RnVsZmlsbGVkID0gSW5maW5pdHk7XG5cdGZvciAodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWQubGVuZ3RoOyBpKyspIHtcblx0XHR2YXIgW2NodW5rSWRzLCBmbiwgcHJpb3JpdHldID0gZGVmZXJyZWRbaV07XG5cdFx0dmFyIGZ1bGZpbGxlZCA9IHRydWU7XG5cdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBjaHVua0lkcy5sZW5ndGg7IGorKykge1xuXHRcdFx0aWYgKChwcmlvcml0eSAmIDEgPT09IDAgfHwgbm90RnVsZmlsbGVkID49IHByaW9yaXR5KSAmJiBPYmplY3Qua2V5cyhfX3dlYnBhY2tfcmVxdWlyZV9fLk8pLmV2ZXJ5KChrZXkpID0+IChfX3dlYnBhY2tfcmVxdWlyZV9fLk9ba2V5XShjaHVua0lkc1tqXSkpKSkge1xuXHRcdFx0XHRjaHVua0lkcy5zcGxpY2Uoai0tLCAxKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGZ1bGZpbGxlZCA9IGZhbHNlO1xuXHRcdFx0XHRpZihwcmlvcml0eSA8IG5vdEZ1bGZpbGxlZCkgbm90RnVsZmlsbGVkID0gcHJpb3JpdHk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKGZ1bGZpbGxlZCkge1xuXHRcdFx0ZGVmZXJyZWQuc3BsaWNlKGktLSwgMSlcblx0XHRcdHZhciByID0gZm4oKTtcblx0XHRcdGlmIChyICE9PSB1bmRlZmluZWQpIHJlc3VsdCA9IHI7XG5cdFx0fVxuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59OyIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIi8vIG5vIGJhc2VVUklcblxuLy8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3Ncbi8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuLy8gW3Jlc29sdmUsIHJlamVjdCwgUHJvbWlzZV0gPSBjaHVuayBsb2FkaW5nLCAwID0gY2h1bmsgbG9hZGVkXG52YXIgaW5zdGFsbGVkQ2h1bmtzID0ge1xuXHRcImNvbnRlbnRcIjogMFxufTtcblxuLy8gbm8gY2h1bmsgb24gZGVtYW5kIGxvYWRpbmdcblxuLy8gbm8gcHJlZmV0Y2hpbmdcblxuLy8gbm8gcHJlbG9hZGVkXG5cbi8vIG5vIEhNUlxuXG4vLyBubyBITVIgbWFuaWZlc3RcblxuX193ZWJwYWNrX3JlcXVpcmVfXy5PLmogPSAoY2h1bmtJZCkgPT4gKGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9PT0gMCk7XG5cbi8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xudmFyIHdlYnBhY2tKc29ucENhbGxiYWNrID0gKHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uLCBkYXRhKSA9PiB7XG5cdHZhciBbY2h1bmtJZHMsIG1vcmVNb2R1bGVzLCBydW50aW1lXSA9IGRhdGE7XG5cdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuXHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcblx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMDtcblx0aWYoY2h1bmtJZHMuc29tZSgoaWQpID0+IChpbnN0YWxsZWRDaHVua3NbaWRdICE9PSAwKSkpIHtcblx0XHRmb3IobW9kdWxlSWQgaW4gbW9yZU1vZHVsZXMpIHtcblx0XHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhtb3JlTW9kdWxlcywgbW9kdWxlSWQpKSB7XG5cdFx0XHRcdF9fd2VicGFja19yZXF1aXJlX18ubVttb2R1bGVJZF0gPSBtb3JlTW9kdWxlc1ttb2R1bGVJZF07XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKHJ1bnRpbWUpIHZhciByZXN1bHQgPSBydW50aW1lKF9fd2VicGFja19yZXF1aXJlX18pO1xuXHR9XG5cdGlmKHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKSBwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbihkYXRhKTtcblx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcblx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGluc3RhbGxlZENodW5rcywgY2h1bmtJZCkgJiYgaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG5cdFx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF1bMF0oKTtcblx0XHR9XG5cdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID0gMDtcblx0fVxuXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXy5PKHJlc3VsdCk7XG59XG5cbnZhciBjaHVua0xvYWRpbmdHbG9iYWwgPSBzZWxmW1wid2VicGFja0NodW5rd2lraXRyZWVfYnJvd3Nlcl9leHRlbnNpb25cIl0gPSBzZWxmW1wid2VicGFja0NodW5rd2lraXRyZWVfYnJvd3Nlcl9leHRlbnNpb25cIl0gfHwgW107XG5jaHVua0xvYWRpbmdHbG9iYWwuZm9yRWFjaCh3ZWJwYWNrSnNvbnBDYWxsYmFjay5iaW5kKG51bGwsIDApKTtcbmNodW5rTG9hZGluZ0dsb2JhbC5wdXNoID0gd2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCBjaHVua0xvYWRpbmdHbG9iYWwucHVzaC5iaW5kKGNodW5rTG9hZGluZ0dsb2JhbCkpOyIsIl9fd2VicGFja19yZXF1aXJlX18ubmMgPSB1bmRlZmluZWQ7IiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBkZXBlbmRzIG9uIG90aGVyIGxvYWRlZCBjaHVua3MgYW5kIGV4ZWN1dGlvbiBuZWVkIHRvIGJlIGRlbGF5ZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKHVuZGVmaW5lZCwgW1widmVuZG9yXCJdLCAoKSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vc3JjL2NvbnRlbnQuanNcIikpKVxuX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18uTyhfX3dlYnBhY2tfZXhwb3J0c19fKTtcbiIsIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==