/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 766:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(755);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


// an array of information about features
const features = [
  {
    name: "Printer Friendly Bio",
    id: "printerFriendly",
    description: "Change the page to a printer-friendly one.",
    category: "Global",
  },
  {
    name: "Source Previews",
    id: "sPreviews",
    description: "Enable source previews on inline references.",
    category: "Global",
  },
  {
    name: "Space Page Previews",
    id: "spacePreviews",
    description: "Enable previews of Space Pages on hover.",
    category: "Global",
  },
  {
    name: "Apps Menu",
    id: "appsMenu",
    description: "Adds an apps submenu to the Find menu.",
    category: "Global",
  },
  {
    name: "WikiTree+ Edit Helper",
    id: "wtplus",
    description: "Adds multiple editing features.",
    category: "Editing",
  },
  {
    name: "Collapsible Descendants Tree",
    id: "collapsibleDescendantsTree",
    description: "Makes the descendants tree on profile pages collapsible.",
    category: "Profile",
  },
  {
    name: "AKA Name Links",
    id: "akaNameLinks",
    description:
      'Adds surname page links to the "aka" names on the profile page.',
    category: "Profile",
  },
  {
    name: "Family Timeline",
    id: "familyTimeline",
    description:
      "Displays a family timeline. A button is added to the profile submenu.",
    category: "Profile",
  },
  {
    name: "Draft List",
    id: "draftList",
    description:
      "Adds a button to the Find menu to show your uncommitted drafts.",
    category: "Global",
  },
  {
    name: "Random Profile",
    id: "randomProfile",
    description: "Adds a Random Profile link to the Find menu.",
    category: "Global",
  },
  {
    name: "Locations Helper",
    id: "locationsHelper",
    description:
      "Manipulates the suggested locations, highlighting likely correct locations," +
      " based on family members' locations, and demoting likely wrong locations, based on the dates.",
    category: "Editing",
  },
  {
    name: "Distance and Relationship",
    id: "distanceAndRelationship",
    description:
      "Adds the distance (degrees) between you and the profile person and any relationship between you.",
    category: "Profile",
  },
  {
    name: "Dark Mode",
    id: "darkMode",
    description: "Make WikiTree dark.",
    category: "Style",
  },
  {
    name: "Family Group",
    id: "familyGroup",
    description:
      "Display dates and locations of all family members. A button is added to the profile submenu.",
    category: "Profile",
  },
  {
    name: 'BioCheck',
    id: 'bioCheck',
    description: 'Check biography style and sources.',
    category: 'Editing',
  },
];

// Categories
const categories = ["Global", "Profile", "Editing", "Style"];

// saves options to chrome.storage
function save_options() {
  // for each feature, save if they are checked or not
  features.forEach((feature) => {
    const checked = jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#${feature.id} input`).prop("checked");
    chrome.storage.sync.set({
      [feature.id]: checked,
    });
  });
}

// restores state of options page
function restore_options() {
  chrome.storage.sync.get(null, (items) => {
    features.forEach((feature) => {
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#${feature.id} input`).prop("checked", items[`${feature.id}`]);
    });
  });
}

// when the options page loads, load status of options from storage
jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).ready(() => {
  restore_options();
});

// Sort features alphabetically
features.sort(function (a, b) {
  return a.name.localeCompare(b.name);
});

// add each feature to the options page
categories.forEach(function (category) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#features").append(`<h2 data-category="${category}">${category} 
  <div class="feature-toggle">
  <label class="switch">
  <input type="checkbox">
  <span class="slider round"></span>
  </label>
</div></h2>`);
  features.forEach((feature) => {
    if (feature.category == category) {
      addFeatureToOptionsPage(feature);
    }
  });
});

// Category switches
jquery__WEBPACK_IMPORTED_MODULE_0___default()("h2 input").change(function () {
  let oSwitch = true;
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).prop("checked") == false) {
    oSwitch = false;
  }
  let oClass = jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).closest("h2").data("category");
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("." + oClass)
    .find("input")
    .prop("checked", oSwitch);
});

// Switch at the top to toggle every switch
jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(`<div class="feature-toggle">
<label class="switch">
<input type="checkbox">
<span class="slider round"></span>
</label>
</div>`)
);

jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 input").change(function () {
  let oSwitch = true;
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).prop("checked") == false) {
    oSwitch = false;
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("input[type='checkbox']").prop("checked", oSwitch);
});

// Auto save the options on click (on 'change' would create lots of events when a big switch is clicked)
// The short delay is for the changes to happen after the click
jquery__WEBPACK_IMPORTED_MODULE_0___default()("#options .feature-toggle input[type='checkbox']").each(function () {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).click(function () {
    setTimeout(function () {
      save_options();
    }, 100);
  });
});

// adds feature HTML to the options page
function addFeatureToOptionsPage(featureData) {
  const featureHTML = `
        <div class="feature-information ${featureData.category}" id="${featureData.id}">
            <div class="feature-header">
                <div class="feature-toggle">
                    <label class="switch">
                    <input type="checkbox">
                    <span class="slider round"></span>
                    </label>
                </div>
                <div class="feature-name">
                ${featureData.name}
                </div>
            </div>
            <div class="feature-description">
                ${featureData.description}
            </div>
        </div>
    `;

  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#features").append(featureHTML);
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/runtimeId */
/******/ 	(() => {
/******/ 		__webpack_require__.j = 798;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			798: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwikitree_browser_extension"] = self["webpackChunkwikitree_browser_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [736], () => (__webpack_require__(766)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;