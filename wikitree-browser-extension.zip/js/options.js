/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


// an array of information about features
const features = [
  {
    name: "Printer Friendly Bio",
    id: "printerFriendly",
    description: "Change the page to a printer-friendly one.",
    category: "Global",
  },
  {
    name: "Source Previews",
    id: "sPreviews",
    description: "Enable source previews on inline references.",
    category: "Global",
  },
  {
    name: "Space Page Previews",
    id: "spacePreviews",
    description: "Enable previews of Space Pages on hover.",
    category: "Global",
  },
  {
    name: "Apps Menu",
    id: "appsMenu",
    description: "Adds an apps submenu to the Find menu.",
    category: "Global",
  },
  {
    name: "WikiTree+ Edit Helper",
    id: "wtplus",
    description: "Adds multiple editing features.",
    category: "Editing",
  },
  {
    name: "Collapsible Descendants Tree",
    id: "collapsibleDescendantsTree",
    description: "Makes the descendants tree on profile pages collapsible.",
    category: "Profile",
  },
  {
    name: "AKA Name Links",
    id: "akaNameLinks",
    description:
      'Adds surname page links to the "aka" names on the profile page.',
    category: "Profile",
  },
  {
    name: "Family Timeline",
    id: "familyTimeline",
    description:
      "Displays a family timeline. A button is added to the profile submenu.",
    category: "Profile",
  },
  {
    name: "Draft List",
    id: "draftList",
    description:
      "Adds a button to the Find menu to show your uncommitted drafts.",
    category: "Global",
  },
  {
    name: "Random Profile",
    id: "randomProfile",
    description: "Adds a Random Profile link to the Find menu.",
    category: "Global",
  },
  {
    name: "Locations Helper",
    id: "locationsHelper",
    description:
      "Manipulates the suggested locations, highlighting likely correct locations," +
      " based on family members' locations, and demoting likely wrong locations, based on the dates.",
    category: "Editing",
  },
  {
    name: "Distance and Relationship",
    id: "distanceAndRelationship",
    description:
      "Adds the distance (degrees) between you and the profile person and any relationship between you.",
    category: "Profile",
  },
  {
    name: "Dark Mode",
    id: "darkMode",
    description: "Make WikiTree dark.",
    category: "Style",
  },
  {
    name: "Family Group",
    id: "familyGroup",
    description:
      "Display dates and locations of all family members. A button is added to the profile submenu.",
    category: "Profile",
  },
  {
    name: 'BioCheck',
    id: 'bioCheck',
    description: 'Check biography style and sources.',
    category: 'Editing',
  },
];

// Categories
const categories = ["Global", "Profile", "Editing", "Style"];

// saves options to chrome.storage
function save_options() {
  // for each feature, save if they are checked or not
  features.forEach((feature) => {
    const checked = jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#${feature.id} input`).prop("checked");
    chrome.storage.sync.set({
      [feature.id]: checked,
    });
  });
}

// restores state of options page
function restore_options() {
  chrome.storage.sync.get(null, (items) => {
    features.forEach((feature) => {
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#${feature.id} input`).prop("checked", items[`${feature.id}`]);
    });
  });
}

// when the options page loads, load status of options from storage
jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).ready(() => {
  restore_options();
});

// Sort features alphabetically
features.sort(function (a, b) {
  return a.name.localeCompare(b.name);
});

// add each feature to the options page
categories.forEach(function (category) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#features").append(`<h2 data-category="${category}">${category} 
  <div class="feature-toggle">
  <label class="switch">
  <input type="checkbox">
  <span class="slider round"></span>
  </label>
</div></h2>`);
  features.forEach((feature) => {
    if (feature.category == category) {
      addFeatureToOptionsPage(feature);
    }
  });
});

// Category switches
jquery__WEBPACK_IMPORTED_MODULE_0___default()("h2 input").change(function () {
  let oSwitch = true;
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).prop("checked") == false) {
    oSwitch = false;
  }
  let oClass = jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).closest("h2").data("category");
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("." + oClass)
    .find("input")
    .prop("checked", oSwitch);
});

// Switch at the top to toggle every switch
jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(`<div class="feature-toggle">
<label class="switch">
<input type="checkbox">
<span class="slider round"></span>
</label>
</div>`)
);

jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 input").change(function () {
  let oSwitch = true;
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).prop("checked") == false) {
    oSwitch = false;
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("input[type='checkbox']").prop("checked", oSwitch);
});

// Auto save the options on click (on 'change' would create lots of events when a big switch is clicked)
// The short delay is for the changes to happen after the click
jquery__WEBPACK_IMPORTED_MODULE_0___default()("#options .feature-toggle input[type='checkbox']").each(function () {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).click(function () {
    setTimeout(function () {
      save_options();
    }, 100);
  });
});

// adds feature HTML to the options page
function addFeatureToOptionsPage(featureData) {
  const featureHTML = `
        <div class="feature-information ${featureData.category}" id="${featureData.id}">
            <div class="feature-header">
                <div class="feature-toggle">
                    <label class="switch">
                    <input type="checkbox">
                    <span class="slider round"></span>
                    </label>
                </div>
                <div class="feature-name">
                ${featureData.name}
                </div>
            </div>
            <div class="feature-description">
                ${featureData.description}
            </div>
        </div>
    `;

  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#features").append(featureHTML);
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"options": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwikitree_browser_extension"] = self["webpackChunkwikitree_browser_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/options.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9ucy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLDZDQUFDLEtBQUssWUFBWTtBQUN0QztBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLDZDQUFDLEtBQUssWUFBWSxpQ0FBaUMsV0FBVztBQUNwRSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLDZDQUFDO0FBQ0Q7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsRUFBRSw2Q0FBQywyQ0FBMkMsU0FBUyxJQUFJO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILENBQUM7QUFDRDtBQUNBO0FBQ0EsNkNBQUM7QUFDRDtBQUNBLE1BQU0sNkNBQUM7QUFDUDtBQUNBO0FBQ0EsZUFBZSw2Q0FBQztBQUNoQixFQUFFLDZDQUFDO0FBQ0g7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsNkNBQUM7QUFDRCxFQUFFLDZDQUFDO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2Q0FBQztBQUNEO0FBQ0EsTUFBTSw2Q0FBQztBQUNQO0FBQ0E7QUFDQSxFQUFFLDZDQUFDO0FBQ0gsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLDZDQUFDO0FBQ0QsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNILENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyxxQkFBcUIsUUFBUSxlQUFlO0FBQ3RGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSw2Q0FBQztBQUNIOzs7Ozs7O1VDdE5BO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7Ozs7V0N6QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQSwrQkFBK0Isd0NBQXdDO1dBQ3ZFO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUJBQWlCLHFCQUFxQjtXQUN0QztXQUNBO1dBQ0Esa0JBQWtCLHFCQUFxQjtXQUN2QztXQUNBO1dBQ0EsS0FBSztXQUNMO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7Ozs7V0MzQkE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlDQUFpQyxXQUFXO1dBQzVDO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQSx1REFBdUQsaUJBQWlCO1dBQ3hFO1dBQ0EsZ0RBQWdELGFBQWE7V0FDN0Q7Ozs7O1dDTkE7O1dBRUE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLE1BQU0scUJBQXFCO1dBQzNCO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7O1dBRUE7V0FDQTtXQUNBOzs7OztXQ2hEQTs7Ozs7VUVBQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vLi9zcmMvb3B0aW9ucy5qcyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2pzb25wIGNodW5rIGxvYWRpbmciLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL25vbmNlIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svYWZ0ZXItc3RhcnR1cCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5cclxuLy8gYW4gYXJyYXkgb2YgaW5mb3JtYXRpb24gYWJvdXQgZmVhdHVyZXNcclxuY29uc3QgZmVhdHVyZXMgPSBbXHJcbiAge1xyXG4gICAgbmFtZTogXCJQcmludGVyIEZyaWVuZGx5IEJpb1wiLFxyXG4gICAgaWQ6IFwicHJpbnRlckZyaWVuZGx5XCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJDaGFuZ2UgdGhlIHBhZ2UgdG8gYSBwcmludGVyLWZyaWVuZGx5IG9uZS5cIixcclxuICAgIGNhdGVnb3J5OiBcIkdsb2JhbFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJTb3VyY2UgUHJldmlld3NcIixcclxuICAgIGlkOiBcInNQcmV2aWV3c1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIHNvdXJjZSBwcmV2aWV3cyBvbiBpbmxpbmUgcmVmZXJlbmNlcy5cIixcclxuICAgIGNhdGVnb3J5OiBcIkdsb2JhbFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJTcGFjZSBQYWdlIFByZXZpZXdzXCIsXHJcbiAgICBpZDogXCJzcGFjZVByZXZpZXdzXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJFbmFibGUgcHJldmlld3Mgb2YgU3BhY2UgUGFnZXMgb24gaG92ZXIuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJHbG9iYWxcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiQXBwcyBNZW51XCIsXHJcbiAgICBpZDogXCJhcHBzTWVudVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiQWRkcyBhbiBhcHBzIHN1Ym1lbnUgdG8gdGhlIEZpbmQgbWVudS5cIixcclxuICAgIGNhdGVnb3J5OiBcIkdsb2JhbFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJXaWtpVHJlZSsgRWRpdCBIZWxwZXJcIixcclxuICAgIGlkOiBcInd0cGx1c1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiQWRkcyBtdWx0aXBsZSBlZGl0aW5nIGZlYXR1cmVzLlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiRWRpdGluZ1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJDb2xsYXBzaWJsZSBEZXNjZW5kYW50cyBUcmVlXCIsXHJcbiAgICBpZDogXCJjb2xsYXBzaWJsZURlc2NlbmRhbnRzVHJlZVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiTWFrZXMgdGhlIGRlc2NlbmRhbnRzIHRyZWUgb24gcHJvZmlsZSBwYWdlcyBjb2xsYXBzaWJsZS5cIixcclxuICAgIGNhdGVnb3J5OiBcIlByb2ZpbGVcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiQUtBIE5hbWUgTGlua3NcIixcclxuICAgIGlkOiBcImFrYU5hbWVMaW5rc1wiLFxyXG4gICAgZGVzY3JpcHRpb246XHJcbiAgICAgICdBZGRzIHN1cm5hbWUgcGFnZSBsaW5rcyB0byB0aGUgXCJha2FcIiBuYW1lcyBvbiB0aGUgcHJvZmlsZSBwYWdlLicsXHJcbiAgICBjYXRlZ29yeTogXCJQcm9maWxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkZhbWlseSBUaW1lbGluZVwiLFxyXG4gICAgaWQ6IFwiZmFtaWx5VGltZWxpbmVcIixcclxuICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICBcIkRpc3BsYXlzIGEgZmFtaWx5IHRpbWVsaW5lLiBBIGJ1dHRvbiBpcyBhZGRlZCB0byB0aGUgcHJvZmlsZSBzdWJtZW51LlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiUHJvZmlsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJEcmFmdCBMaXN0XCIsXHJcbiAgICBpZDogXCJkcmFmdExpc3RcIixcclxuICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICBcIkFkZHMgYSBidXR0b24gdG8gdGhlIEZpbmQgbWVudSB0byBzaG93IHlvdXIgdW5jb21taXR0ZWQgZHJhZnRzLlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiR2xvYmFsXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIlJhbmRvbSBQcm9maWxlXCIsXHJcbiAgICBpZDogXCJyYW5kb21Qcm9maWxlXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJBZGRzIGEgUmFuZG9tIFByb2ZpbGUgbGluayB0byB0aGUgRmluZCBtZW51LlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiR2xvYmFsXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkxvY2F0aW9ucyBIZWxwZXJcIixcclxuICAgIGlkOiBcImxvY2F0aW9uc0hlbHBlclwiLFxyXG4gICAgZGVzY3JpcHRpb246XHJcbiAgICAgIFwiTWFuaXB1bGF0ZXMgdGhlIHN1Z2dlc3RlZCBsb2NhdGlvbnMsIGhpZ2hsaWdodGluZyBsaWtlbHkgY29ycmVjdCBsb2NhdGlvbnMsXCIgK1xyXG4gICAgICBcIiBiYXNlZCBvbiBmYW1pbHkgbWVtYmVycycgbG9jYXRpb25zLCBhbmQgZGVtb3RpbmcgbGlrZWx5IHdyb25nIGxvY2F0aW9ucywgYmFzZWQgb24gdGhlIGRhdGVzLlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiRWRpdGluZ1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJEaXN0YW5jZSBhbmQgUmVsYXRpb25zaGlwXCIsXHJcbiAgICBpZDogXCJkaXN0YW5jZUFuZFJlbGF0aW9uc2hpcFwiLFxyXG4gICAgZGVzY3JpcHRpb246XHJcbiAgICAgIFwiQWRkcyB0aGUgZGlzdGFuY2UgKGRlZ3JlZXMpIGJldHdlZW4geW91IGFuZCB0aGUgcHJvZmlsZSBwZXJzb24gYW5kIGFueSByZWxhdGlvbnNoaXAgYmV0d2VlbiB5b3UuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJQcm9maWxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkRhcmsgTW9kZVwiLFxyXG4gICAgaWQ6IFwiZGFya01vZGVcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIk1ha2UgV2lraVRyZWUgZGFyay5cIixcclxuICAgIGNhdGVnb3J5OiBcIlN0eWxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkZhbWlseSBHcm91cFwiLFxyXG4gICAgaWQ6IFwiZmFtaWx5R3JvdXBcIixcclxuICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICBcIkRpc3BsYXkgZGF0ZXMgYW5kIGxvY2F0aW9ucyBvZiBhbGwgZmFtaWx5IG1lbWJlcnMuIEEgYnV0dG9uIGlzIGFkZGVkIHRvIHRoZSBwcm9maWxlIHN1Ym1lbnUuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJQcm9maWxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiAnQmlvQ2hlY2snLFxyXG4gICAgaWQ6ICdiaW9DaGVjaycsXHJcbiAgICBkZXNjcmlwdGlvbjogJ0NoZWNrIGJpb2dyYXBoeSBzdHlsZSBhbmQgc291cmNlcy4nLFxyXG4gICAgY2F0ZWdvcnk6ICdFZGl0aW5nJyxcclxuICB9LFxyXG5dO1xyXG5cclxuLy8gQ2F0ZWdvcmllc1xyXG5jb25zdCBjYXRlZ29yaWVzID0gW1wiR2xvYmFsXCIsIFwiUHJvZmlsZVwiLCBcIkVkaXRpbmdcIiwgXCJTdHlsZVwiXTtcclxuXHJcbi8vIHNhdmVzIG9wdGlvbnMgdG8gY2hyb21lLnN0b3JhZ2VcclxuZnVuY3Rpb24gc2F2ZV9vcHRpb25zKCkge1xyXG4gIC8vIGZvciBlYWNoIGZlYXR1cmUsIHNhdmUgaWYgdGhleSBhcmUgY2hlY2tlZCBvciBub3RcclxuICBmZWF0dXJlcy5mb3JFYWNoKChmZWF0dXJlKSA9PiB7XHJcbiAgICBjb25zdCBjaGVja2VkID0gJChgIyR7ZmVhdHVyZS5pZH0gaW5wdXRgKS5wcm9wKFwiY2hlY2tlZFwiKTtcclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHtcclxuICAgICAgW2ZlYXR1cmUuaWRdOiBjaGVja2VkLFxyXG4gICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbi8vIHJlc3RvcmVzIHN0YXRlIG9mIG9wdGlvbnMgcGFnZVxyXG5mdW5jdGlvbiByZXN0b3JlX29wdGlvbnMoKSB7XHJcbiAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQobnVsbCwgKGl0ZW1zKSA9PiB7XHJcbiAgICBmZWF0dXJlcy5mb3JFYWNoKChmZWF0dXJlKSA9PiB7XHJcbiAgICAgICQoYCMke2ZlYXR1cmUuaWR9IGlucHV0YCkucHJvcChcImNoZWNrZWRcIiwgaXRlbXNbYCR7ZmVhdHVyZS5pZH1gXSk7XHJcbiAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuLy8gd2hlbiB0aGUgb3B0aW9ucyBwYWdlIGxvYWRzLCBsb2FkIHN0YXR1cyBvZiBvcHRpb25zIGZyb20gc3RvcmFnZVxyXG4kKGRvY3VtZW50KS5yZWFkeSgoKSA9PiB7XHJcbiAgcmVzdG9yZV9vcHRpb25zKCk7XHJcbn0pO1xyXG5cclxuLy8gU29ydCBmZWF0dXJlcyBhbHBoYWJldGljYWxseVxyXG5mZWF0dXJlcy5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XHJcbiAgcmV0dXJuIGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSk7XHJcbn0pO1xyXG5cclxuLy8gYWRkIGVhY2ggZmVhdHVyZSB0byB0aGUgb3B0aW9ucyBwYWdlXHJcbmNhdGVnb3JpZXMuZm9yRWFjaChmdW5jdGlvbiAoY2F0ZWdvcnkpIHtcclxuICAkKFwiI2ZlYXR1cmVzXCIpLmFwcGVuZChgPGgyIGRhdGEtY2F0ZWdvcnk9XCIke2NhdGVnb3J5fVwiPiR7Y2F0ZWdvcnl9IFxyXG4gIDxkaXYgY2xhc3M9XCJmZWF0dXJlLXRvZ2dsZVwiPlxyXG4gIDxsYWJlbCBjbGFzcz1cInN3aXRjaFwiPlxyXG4gIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIj5cclxuICA8c3BhbiBjbGFzcz1cInNsaWRlciByb3VuZFwiPjwvc3Bhbj5cclxuICA8L2xhYmVsPlxyXG48L2Rpdj48L2gyPmApO1xyXG4gIGZlYXR1cmVzLmZvckVhY2goKGZlYXR1cmUpID0+IHtcclxuICAgIGlmIChmZWF0dXJlLmNhdGVnb3J5ID09IGNhdGVnb3J5KSB7XHJcbiAgICAgIGFkZEZlYXR1cmVUb09wdGlvbnNQYWdlKGZlYXR1cmUpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59KTtcclxuXHJcbi8vIENhdGVnb3J5IHN3aXRjaGVzXHJcbiQoXCJoMiBpbnB1dFwiKS5jaGFuZ2UoZnVuY3Rpb24gKCkge1xyXG4gIGxldCBvU3dpdGNoID0gdHJ1ZTtcclxuICBpZiAoJCh0aGlzKS5wcm9wKFwiY2hlY2tlZFwiKSA9PSBmYWxzZSkge1xyXG4gICAgb1N3aXRjaCA9IGZhbHNlO1xyXG4gIH1cclxuICBsZXQgb0NsYXNzID0gJCh0aGlzKS5jbG9zZXN0KFwiaDJcIikuZGF0YShcImNhdGVnb3J5XCIpO1xyXG4gICQoXCIuXCIgKyBvQ2xhc3MpXHJcbiAgICAuZmluZChcImlucHV0XCIpXHJcbiAgICAucHJvcChcImNoZWNrZWRcIiwgb1N3aXRjaCk7XHJcbn0pO1xyXG5cclxuLy8gU3dpdGNoIGF0IHRoZSB0b3AgdG8gdG9nZ2xlIGV2ZXJ5IHN3aXRjaFxyXG4kKFwiaDFcIikuYXBwZW5kKFxyXG4gICQoYDxkaXYgY2xhc3M9XCJmZWF0dXJlLXRvZ2dsZVwiPlxyXG48bGFiZWwgY2xhc3M9XCJzd2l0Y2hcIj5cclxuPGlucHV0IHR5cGU9XCJjaGVja2JveFwiPlxyXG48c3BhbiBjbGFzcz1cInNsaWRlciByb3VuZFwiPjwvc3Bhbj5cclxuPC9sYWJlbD5cclxuPC9kaXY+YClcclxuKTtcclxuXHJcbiQoXCJoMSBpbnB1dFwiKS5jaGFuZ2UoZnVuY3Rpb24gKCkge1xyXG4gIGxldCBvU3dpdGNoID0gdHJ1ZTtcclxuICBpZiAoJCh0aGlzKS5wcm9wKFwiY2hlY2tlZFwiKSA9PSBmYWxzZSkge1xyXG4gICAgb1N3aXRjaCA9IGZhbHNlO1xyXG4gIH1cclxuICAkKFwiaW5wdXRbdHlwZT0nY2hlY2tib3gnXVwiKS5wcm9wKFwiY2hlY2tlZFwiLCBvU3dpdGNoKTtcclxufSk7XHJcblxyXG4vLyBBdXRvIHNhdmUgdGhlIG9wdGlvbnMgb24gY2xpY2sgKG9uICdjaGFuZ2UnIHdvdWxkIGNyZWF0ZSBsb3RzIG9mIGV2ZW50cyB3aGVuIGEgYmlnIHN3aXRjaCBpcyBjbGlja2VkKVxyXG4vLyBUaGUgc2hvcnQgZGVsYXkgaXMgZm9yIHRoZSBjaGFuZ2VzIHRvIGhhcHBlbiBhZnRlciB0aGUgY2xpY2tcclxuJChcIiNvcHRpb25zIC5mZWF0dXJlLXRvZ2dsZSBpbnB1dFt0eXBlPSdjaGVja2JveCddXCIpLmVhY2goZnVuY3Rpb24gKCkge1xyXG4gICQodGhpcykuY2xpY2soZnVuY3Rpb24gKCkge1xyXG4gICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgIHNhdmVfb3B0aW9ucygpO1xyXG4gICAgfSwgMTAwKTtcclxuICB9KTtcclxufSk7XHJcblxyXG4vLyBhZGRzIGZlYXR1cmUgSFRNTCB0byB0aGUgb3B0aW9ucyBwYWdlXHJcbmZ1bmN0aW9uIGFkZEZlYXR1cmVUb09wdGlvbnNQYWdlKGZlYXR1cmVEYXRhKSB7XHJcbiAgY29uc3QgZmVhdHVyZUhUTUwgPSBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZlYXR1cmUtaW5mb3JtYXRpb24gJHtmZWF0dXJlRGF0YS5jYXRlZ29yeX1cIiBpZD1cIiR7ZmVhdHVyZURhdGEuaWR9XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmZWF0dXJlLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZlYXR1cmUtdG9nZ2xlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwic3dpdGNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2xpZGVyIHJvdW5kXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmZWF0dXJlLW5hbWVcIj5cclxuICAgICAgICAgICAgICAgICR7ZmVhdHVyZURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZlYXR1cmUtZGVzY3JpcHRpb25cIj5cclxuICAgICAgICAgICAgICAgICR7ZmVhdHVyZURhdGEuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYDtcclxuXHJcbiAgJChcIiNmZWF0dXJlc1wiKS5hcHBlbmQoZmVhdHVyZUhUTUwpO1xyXG59XHJcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4vLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuX193ZWJwYWNrX3JlcXVpcmVfXy5tID0gX193ZWJwYWNrX21vZHVsZXNfXztcblxuIiwidmFyIGRlZmVycmVkID0gW107XG5fX3dlYnBhY2tfcmVxdWlyZV9fLk8gPSAocmVzdWx0LCBjaHVua0lkcywgZm4sIHByaW9yaXR5KSA9PiB7XG5cdGlmKGNodW5rSWRzKSB7XG5cdFx0cHJpb3JpdHkgPSBwcmlvcml0eSB8fCAwO1xuXHRcdGZvcih2YXIgaSA9IGRlZmVycmVkLmxlbmd0aDsgaSA+IDAgJiYgZGVmZXJyZWRbaSAtIDFdWzJdID4gcHJpb3JpdHk7IGktLSkgZGVmZXJyZWRbaV0gPSBkZWZlcnJlZFtpIC0gMV07XG5cdFx0ZGVmZXJyZWRbaV0gPSBbY2h1bmtJZHMsIGZuLCBwcmlvcml0eV07XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHZhciBub3RGdWxmaWxsZWQgPSBJbmZpbml0eTtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBkZWZlcnJlZC5sZW5ndGg7IGkrKykge1xuXHRcdHZhciBbY2h1bmtJZHMsIGZuLCBwcmlvcml0eV0gPSBkZWZlcnJlZFtpXTtcblx0XHR2YXIgZnVsZmlsbGVkID0gdHJ1ZTtcblx0XHRmb3IgKHZhciBqID0gMDsgaiA8IGNodW5rSWRzLmxlbmd0aDsgaisrKSB7XG5cdFx0XHRpZiAoKHByaW9yaXR5ICYgMSA9PT0gMCB8fCBub3RGdWxmaWxsZWQgPj0gcHJpb3JpdHkpICYmIE9iamVjdC5rZXlzKF9fd2VicGFja19yZXF1aXJlX18uTykuZXZlcnkoKGtleSkgPT4gKF9fd2VicGFja19yZXF1aXJlX18uT1trZXldKGNodW5rSWRzW2pdKSkpKSB7XG5cdFx0XHRcdGNodW5rSWRzLnNwbGljZShqLS0sIDEpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0ZnVsZmlsbGVkID0gZmFsc2U7XG5cdFx0XHRcdGlmKHByaW9yaXR5IDwgbm90RnVsZmlsbGVkKSBub3RGdWxmaWxsZWQgPSBwcmlvcml0eTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYoZnVsZmlsbGVkKSB7XG5cdFx0XHRkZWZlcnJlZC5zcGxpY2UoaS0tLCAxKVxuXHRcdFx0dmFyIHIgPSBmbigpO1xuXHRcdFx0aWYgKHIgIT09IHVuZGVmaW5lZCkgcmVzdWx0ID0gcjtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn07IiwiLy8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbl9fd2VicGFja19yZXF1aXJlX18ubiA9IChtb2R1bGUpID0+IHtcblx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG5cdFx0KCkgPT4gKG1vZHVsZVsnZGVmYXVsdCddKSA6XG5cdFx0KCkgPT4gKG1vZHVsZSk7XG5cdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsIHsgYTogZ2V0dGVyIH0pO1xuXHRyZXR1cm4gZ2V0dGVyO1xufTsiLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiLy8gbm8gYmFzZVVSSVxuXG4vLyBvYmplY3QgdG8gc3RvcmUgbG9hZGVkIGFuZCBsb2FkaW5nIGNodW5rc1xuLy8gdW5kZWZpbmVkID0gY2h1bmsgbm90IGxvYWRlZCwgbnVsbCA9IGNodW5rIHByZWxvYWRlZC9wcmVmZXRjaGVkXG4vLyBbcmVzb2x2ZSwgcmVqZWN0LCBQcm9taXNlXSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbnZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG5cdFwib3B0aW9uc1wiOiAwXG59O1xuXG4vLyBubyBjaHVuayBvbiBkZW1hbmQgbG9hZGluZ1xuXG4vLyBubyBwcmVmZXRjaGluZ1xuXG4vLyBubyBwcmVsb2FkZWRcblxuLy8gbm8gSE1SXG5cbi8vIG5vIEhNUiBtYW5pZmVzdFxuXG5fX3dlYnBhY2tfcmVxdWlyZV9fLk8uaiA9IChjaHVua0lkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID09PSAwKTtcblxuLy8gaW5zdGFsbCBhIEpTT05QIGNhbGxiYWNrIGZvciBjaHVuayBsb2FkaW5nXG52YXIgd2VicGFja0pzb25wQ2FsbGJhY2sgPSAocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24sIGRhdGEpID0+IHtcblx0dmFyIFtjaHVua0lkcywgbW9yZU1vZHVsZXMsIHJ1bnRpbWVdID0gZGF0YTtcblx0Ly8gYWRkIFwibW9yZU1vZHVsZXNcIiB0byB0aGUgbW9kdWxlcyBvYmplY3QsXG5cdC8vIHRoZW4gZmxhZyBhbGwgXCJjaHVua0lkc1wiIGFzIGxvYWRlZCBhbmQgZmlyZSBjYWxsYmFja1xuXHR2YXIgbW9kdWxlSWQsIGNodW5rSWQsIGkgPSAwO1xuXHRpZihjaHVua0lkcy5zb21lKChpZCkgPT4gKGluc3RhbGxlZENodW5rc1tpZF0gIT09IDApKSkge1xuXHRcdGZvcihtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuXHRcdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcblx0XHRcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tW21vZHVsZUlkXSA9IG1vcmVNb2R1bGVzW21vZHVsZUlkXTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYocnVudGltZSkgdmFyIHJlc3VsdCA9IHJ1bnRpbWUoX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cdH1cblx0aWYocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24pIHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKGRhdGEpO1xuXHRmb3IoO2kgPCBjaHVua0lkcy5sZW5ndGg7IGkrKykge1xuXHRcdGNodW5rSWQgPSBjaHVua0lkc1tpXTtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oaW5zdGFsbGVkQ2h1bmtzLCBjaHVua0lkKSAmJiBpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0pIHtcblx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSgpO1xuXHRcdH1cblx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPSAwO1xuXHR9XG5cdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fLk8ocmVzdWx0KTtcbn1cblxudmFyIGNodW5rTG9hZGluZ0dsb2JhbCA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmt3aWtpdHJlZV9icm93c2VyX2V4dGVuc2lvblwiXSA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmt3aWtpdHJlZV9icm93c2VyX2V4dGVuc2lvblwiXSB8fCBbXTtcbmNodW5rTG9hZGluZ0dsb2JhbC5mb3JFYWNoKHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgMCkpO1xuY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2ggPSB3ZWJwYWNrSnNvbnBDYWxsYmFjay5iaW5kKG51bGwsIGNodW5rTG9hZGluZ0dsb2JhbC5wdXNoLmJpbmQoY2h1bmtMb2FkaW5nR2xvYmFsKSk7IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5uYyA9IHVuZGVmaW5lZDsiLCIiLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGRlcGVuZHMgb24gb3RoZXIgbG9hZGVkIGNodW5rcyBhbmQgZXhlY3V0aW9uIG5lZWQgdG8gYmUgZGVsYXllZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8odW5kZWZpbmVkLCBbXCJ2ZW5kb3JcIl0sICgpID0+IChfX3dlYnBhY2tfcmVxdWlyZV9fKFwiLi9zcmMvb3B0aW9ucy5qc1wiKSkpXG5fX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKF9fd2VicGFja19leHBvcnRzX18pO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9