/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);


// an array of information about features
const features = [
  {
    name: "Printer Friendly Bio",
    id: "printerFriendly",
    description: "Change the page to a printer-friendly one.",
    category: "Global",
  },
  {
    name: "Source Previews",
    id: "sPreviews",
    description: "Enable source previews on inline references.",
    category: "Global",
  },
  {
    name: "Space Page Previews",
    id: "spacePreviews",
    description: "Enable previews of Space Pages on hover.",
    category: "Global",
  },
  {
    name: "Apps Menu",
    id: "appsMenu",
    description: "Adds an apps submenu to the Find menu.",
    category: "Global",
  },
  {
    name: "WikiTree+ Edit Helper",
    id: "wtplus",
    description: "Adds multiple editing features.",
    category: "Editing",
  },
  {
    name: "Collapsible Descendants Tree",
    id: "collapsibleDescendantsTree",
    description: "Makes the descendants tree on profile pages collapsible.",
    category: "Profile",
  },
  {
    name: "AKA Name Links",
    id: "akaNameLinks",
    description:
      'Adds surname page links to the "aka" names on the profile page.',
    category: "Profile",
  },
  {
    name: "Family Timeline",
    id: "familyTimeline",
    description:
      "Displays a family timeline. A button is added to the profile submenu.",
    category: "Profile",
  },
  {
    name: "Draft List",
    id: "draftList",
    description:
      "Adds a button to the Find menu to show your uncommitted drafts.",
    category: "Global",
  },
  {
    name: "Random Profile",
    id: "randomProfile",
    description: "Adds a Random Profile link to the Find menu.",
    category: "Global",
  },
  {
    name: "Locations Helper",
    id: "locationsHelper",
    description:
      "Manipulates the suggested locations, highlighting likely correct locations," +
      " based on family members' locations, and demoting likely wrong locations, based on the dates.",
    category: "Editing",
  },
  {
    name: "Distance and Relationship",
    id: "distanceAndRelationship",
    description:
      "Adds the distance (degrees) between you and the profile person and any relationship between you.",
    category: "Profile",
  },
  {
    name: "Dark Mode",
    id: "darkMode",
    description: "Make WikiTree dark.",
    category: "Style",
  },
  {
    name: "Family Group",
    id: "familyGroup",
    description:
      "Display dates and locations of all family members. A button is added to the profile submenu.",
    category: "Profile",
  },
];

// Categories
const categories = ["Global", "Profile", "Editing", "Style"];

// saves options to chrome.storage
function save_options() {
  // for each feature, save if they are checked or not
  features.forEach((feature) => {
    const checked = jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#${feature.id} input`).prop("checked");
    chrome.storage.sync.set({
      [feature.id]: checked,
    });
  });
}

// restores state of options page
function restore_options() {
  chrome.storage.sync.get(null, (items) => {
    features.forEach((feature) => {
      jquery__WEBPACK_IMPORTED_MODULE_0___default()(`#${feature.id} input`).prop("checked", items[`${feature.id}`]);
    });
  });
}

// when the options page loads, load status of options from storage
jquery__WEBPACK_IMPORTED_MODULE_0___default()(document).ready(() => {
  restore_options();
});

// Sort features alphabetically
features.sort(function (a, b) {
  return a.name.localeCompare(b.name);
});

// add each feature to the options page
categories.forEach(function (category) {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#features").append(`<h2 data-category="${category}">${category} 
  <div class="feature-toggle">
  <label class="switch">
  <input type="checkbox">
  <span class="slider round"></span>
  </label>
</div></h2>`);
  features.forEach((feature) => {
    if (feature.category == category) {
      addFeatureToOptionsPage(feature);
    }
  });
});

// Category switches
jquery__WEBPACK_IMPORTED_MODULE_0___default()("h2 input").change(function () {
  let oSwitch = true;
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).prop("checked") == false) {
    oSwitch = false;
  }
  let oClass = jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).closest("h2").data("category");
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("." + oClass)
    .find("input")
    .prop("checked", oSwitch);
});

// Switch at the top to toggle every switch
jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1").append(
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(`<div class="feature-toggle">
<label class="switch">
<input type="checkbox">
<span class="slider round"></span>
</label>
</div>`)
);

jquery__WEBPACK_IMPORTED_MODULE_0___default()("h1 input").change(function () {
  let oSwitch = true;
  if (jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).prop("checked") == false) {
    oSwitch = false;
  }
  jquery__WEBPACK_IMPORTED_MODULE_0___default()("input[type='checkbox']").prop("checked", oSwitch);
});

// Auto save the options on click (on 'change' would create lots of events when a big switch is clicked)
// The short delay is for the changes to happen after the click
jquery__WEBPACK_IMPORTED_MODULE_0___default()("#options .feature-toggle input[type='checkbox']").each(function () {
  jquery__WEBPACK_IMPORTED_MODULE_0___default()(this).click(function () {
    setTimeout(function () {
      save_options();
    }, 100);
  });
});

// adds feature HTML to the options page
function addFeatureToOptionsPage(featureData) {
  const featureHTML = `
        <div class="feature-information ${featureData.category}" id="${featureData.id}">
            <div class="feature-header">
                <div class="feature-toggle">
                    <label class="switch">
                    <input type="checkbox">
                    <span class="slider round"></span>
                    </label>
                </div>
                <div class="feature-name">
                ${featureData.name}
                </div>
            </div>
            <div class="feature-description">
                ${featureData.description}
            </div>
        </div>
    `;

  jquery__WEBPACK_IMPORTED_MODULE_0___default()("#features").append(featureHTML);
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"options": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwikitree_browser_extension"] = self["webpackChunkwikitree_browser_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/options.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9ucy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiw2Q0FBQyxLQUFLLFlBQVk7QUFDdEM7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSw2Q0FBQyxLQUFLLFlBQVksaUNBQWlDLFdBQVc7QUFDcEUsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSw2Q0FBQztBQUNEO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUMsMkNBQTJDLFNBQVMsSUFBSTtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDO0FBQ0Q7QUFDQTtBQUNBLDZDQUFDO0FBQ0Q7QUFDQSxNQUFNLDZDQUFDO0FBQ1A7QUFDQTtBQUNBLGVBQWUsNkNBQUM7QUFDaEIsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLDZDQUFDO0FBQ0QsRUFBRSw2Q0FBQztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQUM7QUFDRDtBQUNBLE1BQU0sNkNBQUM7QUFDUDtBQUNBO0FBQ0EsRUFBRSw2Q0FBQztBQUNILENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSw2Q0FBQztBQUNELEVBQUUsNkNBQUM7QUFDSDtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMscUJBQXFCLFFBQVEsZUFBZTtBQUN0RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsNkNBQUM7QUFDSDs7Ozs7OztVQ2hOQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOztVQUVBO1VBQ0E7Ozs7O1dDekJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsK0JBQStCLHdDQUF3QztXQUN2RTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlCQUFpQixxQkFBcUI7V0FDdEM7V0FDQTtXQUNBLGtCQUFrQixxQkFBcUI7V0FDdkM7V0FDQTtXQUNBLEtBQUs7V0FDTDtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDM0JBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7OztXQ05BOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7V0NoREE7Ozs7O1VFQUE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uLy4vc3JjL29wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2NodW5rIGxvYWRlZCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vd2lraXRyZWUtYnJvd3Nlci1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9qc29ucCBjaHVuayBsb2FkaW5nIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9ub25jZSIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL3dpa2l0cmVlLWJyb3dzZXItZXh0ZW5zaW9uL3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly93aWtpdHJlZS1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuXHJcbi8vIGFuIGFycmF5IG9mIGluZm9ybWF0aW9uIGFib3V0IGZlYXR1cmVzXHJcbmNvbnN0IGZlYXR1cmVzID0gW1xyXG4gIHtcclxuICAgIG5hbWU6IFwiUHJpbnRlciBGcmllbmRseSBCaW9cIixcclxuICAgIGlkOiBcInByaW50ZXJGcmllbmRseVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiQ2hhbmdlIHRoZSBwYWdlIHRvIGEgcHJpbnRlci1mcmllbmRseSBvbmUuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJHbG9iYWxcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiU291cmNlIFByZXZpZXdzXCIsXHJcbiAgICBpZDogXCJzUHJldmlld3NcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBzb3VyY2UgcHJldmlld3Mgb24gaW5saW5lIHJlZmVyZW5jZXMuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJHbG9iYWxcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiU3BhY2UgUGFnZSBQcmV2aWV3c1wiLFxyXG4gICAgaWQ6IFwic3BhY2VQcmV2aWV3c1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIHByZXZpZXdzIG9mIFNwYWNlIFBhZ2VzIG9uIGhvdmVyLlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiR2xvYmFsXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkFwcHMgTWVudVwiLFxyXG4gICAgaWQ6IFwiYXBwc01lbnVcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIkFkZHMgYW4gYXBwcyBzdWJtZW51IHRvIHRoZSBGaW5kIG1lbnUuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJHbG9iYWxcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiV2lraVRyZWUrIEVkaXQgSGVscGVyXCIsXHJcbiAgICBpZDogXCJ3dHBsdXNcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIkFkZHMgbXVsdGlwbGUgZWRpdGluZyBmZWF0dXJlcy5cIixcclxuICAgIGNhdGVnb3J5OiBcIkVkaXRpbmdcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiQ29sbGFwc2libGUgRGVzY2VuZGFudHMgVHJlZVwiLFxyXG4gICAgaWQ6IFwiY29sbGFwc2libGVEZXNjZW5kYW50c1RyZWVcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIk1ha2VzIHRoZSBkZXNjZW5kYW50cyB0cmVlIG9uIHByb2ZpbGUgcGFnZXMgY29sbGFwc2libGUuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJQcm9maWxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkFLQSBOYW1lIExpbmtzXCIsXHJcbiAgICBpZDogXCJha2FOYW1lTGlua3NcIixcclxuICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICAnQWRkcyBzdXJuYW1lIHBhZ2UgbGlua3MgdG8gdGhlIFwiYWthXCIgbmFtZXMgb24gdGhlIHByb2ZpbGUgcGFnZS4nLFxyXG4gICAgY2F0ZWdvcnk6IFwiUHJvZmlsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJGYW1pbHkgVGltZWxpbmVcIixcclxuICAgIGlkOiBcImZhbWlseVRpbWVsaW5lXCIsXHJcbiAgICBkZXNjcmlwdGlvbjpcclxuICAgICAgXCJEaXNwbGF5cyBhIGZhbWlseSB0aW1lbGluZS4gQSBidXR0b24gaXMgYWRkZWQgdG8gdGhlIHByb2ZpbGUgc3VibWVudS5cIixcclxuICAgIGNhdGVnb3J5OiBcIlByb2ZpbGVcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiRHJhZnQgTGlzdFwiLFxyXG4gICAgaWQ6IFwiZHJhZnRMaXN0XCIsXHJcbiAgICBkZXNjcmlwdGlvbjpcclxuICAgICAgXCJBZGRzIGEgYnV0dG9uIHRvIHRoZSBGaW5kIG1lbnUgdG8gc2hvdyB5b3VyIHVuY29tbWl0dGVkIGRyYWZ0cy5cIixcclxuICAgIGNhdGVnb3J5OiBcIkdsb2JhbFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJSYW5kb20gUHJvZmlsZVwiLFxyXG4gICAgaWQ6IFwicmFuZG9tUHJvZmlsZVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiQWRkcyBhIFJhbmRvbSBQcm9maWxlIGxpbmsgdG8gdGhlIEZpbmQgbWVudS5cIixcclxuICAgIGNhdGVnb3J5OiBcIkdsb2JhbFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJMb2NhdGlvbnMgSGVscGVyXCIsXHJcbiAgICBpZDogXCJsb2NhdGlvbnNIZWxwZXJcIixcclxuICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICBcIk1hbmlwdWxhdGVzIHRoZSBzdWdnZXN0ZWQgbG9jYXRpb25zLCBoaWdobGlnaHRpbmcgbGlrZWx5IGNvcnJlY3QgbG9jYXRpb25zLFwiICtcclxuICAgICAgXCIgYmFzZWQgb24gZmFtaWx5IG1lbWJlcnMnIGxvY2F0aW9ucywgYW5kIGRlbW90aW5nIGxpa2VseSB3cm9uZyBsb2NhdGlvbnMsIGJhc2VkIG9uIHRoZSBkYXRlcy5cIixcclxuICAgIGNhdGVnb3J5OiBcIkVkaXRpbmdcIixcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiRGlzdGFuY2UgYW5kIFJlbGF0aW9uc2hpcFwiLFxyXG4gICAgaWQ6IFwiZGlzdGFuY2VBbmRSZWxhdGlvbnNoaXBcIixcclxuICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICBcIkFkZHMgdGhlIGRpc3RhbmNlIChkZWdyZWVzKSBiZXR3ZWVuIHlvdSBhbmQgdGhlIHByb2ZpbGUgcGVyc29uIGFuZCBhbnkgcmVsYXRpb25zaGlwIGJldHdlZW4geW91LlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiUHJvZmlsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJEYXJrIE1vZGVcIixcclxuICAgIGlkOiBcImRhcmtNb2RlXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJNYWtlIFdpa2lUcmVlIGRhcmsuXCIsXHJcbiAgICBjYXRlZ29yeTogXCJTdHlsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCJGYW1pbHkgR3JvdXBcIixcclxuICAgIGlkOiBcImZhbWlseUdyb3VwXCIsXHJcbiAgICBkZXNjcmlwdGlvbjpcclxuICAgICAgXCJEaXNwbGF5IGRhdGVzIGFuZCBsb2NhdGlvbnMgb2YgYWxsIGZhbWlseSBtZW1iZXJzLiBBIGJ1dHRvbiBpcyBhZGRlZCB0byB0aGUgcHJvZmlsZSBzdWJtZW51LlwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiUHJvZmlsZVwiLFxyXG4gIH0sXHJcbl07XHJcblxyXG4vLyBDYXRlZ29yaWVzXHJcbmNvbnN0IGNhdGVnb3JpZXMgPSBbXCJHbG9iYWxcIiwgXCJQcm9maWxlXCIsIFwiRWRpdGluZ1wiLCBcIlN0eWxlXCJdO1xyXG5cclxuLy8gc2F2ZXMgb3B0aW9ucyB0byBjaHJvbWUuc3RvcmFnZVxyXG5mdW5jdGlvbiBzYXZlX29wdGlvbnMoKSB7XHJcbiAgLy8gZm9yIGVhY2ggZmVhdHVyZSwgc2F2ZSBpZiB0aGV5IGFyZSBjaGVja2VkIG9yIG5vdFxyXG4gIGZlYXR1cmVzLmZvckVhY2goKGZlYXR1cmUpID0+IHtcclxuICAgIGNvbnN0IGNoZWNrZWQgPSAkKGAjJHtmZWF0dXJlLmlkfSBpbnB1dGApLnByb3AoXCJjaGVja2VkXCIpO1xyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoe1xyXG4gICAgICBbZmVhdHVyZS5pZF06IGNoZWNrZWQsXHJcbiAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuLy8gcmVzdG9yZXMgc3RhdGUgb2Ygb3B0aW9ucyBwYWdlXHJcbmZ1bmN0aW9uIHJlc3RvcmVfb3B0aW9ucygpIHtcclxuICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChudWxsLCAoaXRlbXMpID0+IHtcclxuICAgIGZlYXR1cmVzLmZvckVhY2goKGZlYXR1cmUpID0+IHtcclxuICAgICAgJChgIyR7ZmVhdHVyZS5pZH0gaW5wdXRgKS5wcm9wKFwiY2hlY2tlZFwiLCBpdGVtc1tgJHtmZWF0dXJlLmlkfWBdKTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vLyB3aGVuIHRoZSBvcHRpb25zIHBhZ2UgbG9hZHMsIGxvYWQgc3RhdHVzIG9mIG9wdGlvbnMgZnJvbSBzdG9yYWdlXHJcbiQoZG9jdW1lbnQpLnJlYWR5KCgpID0+IHtcclxuICByZXN0b3JlX29wdGlvbnMoKTtcclxufSk7XHJcblxyXG4vLyBTb3J0IGZlYXR1cmVzIGFscGhhYmV0aWNhbGx5XHJcbmZlYXR1cmVzLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHtcclxuICByZXR1cm4gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKTtcclxufSk7XHJcblxyXG4vLyBhZGQgZWFjaCBmZWF0dXJlIHRvIHRoZSBvcHRpb25zIHBhZ2VcclxuY2F0ZWdvcmllcy5mb3JFYWNoKGZ1bmN0aW9uIChjYXRlZ29yeSkge1xyXG4gICQoXCIjZmVhdHVyZXNcIikuYXBwZW5kKGA8aDIgZGF0YS1jYXRlZ29yeT1cIiR7Y2F0ZWdvcnl9XCI+JHtjYXRlZ29yeX0gXHJcbiAgPGRpdiBjbGFzcz1cImZlYXR1cmUtdG9nZ2xlXCI+XHJcbiAgPGxhYmVsIGNsYXNzPVwic3dpdGNoXCI+XHJcbiAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiPlxyXG4gIDxzcGFuIGNsYXNzPVwic2xpZGVyIHJvdW5kXCI+PC9zcGFuPlxyXG4gIDwvbGFiZWw+XHJcbjwvZGl2PjwvaDI+YCk7XHJcbiAgZmVhdHVyZXMuZm9yRWFjaCgoZmVhdHVyZSkgPT4ge1xyXG4gICAgaWYgKGZlYXR1cmUuY2F0ZWdvcnkgPT0gY2F0ZWdvcnkpIHtcclxuICAgICAgYWRkRmVhdHVyZVRvT3B0aW9uc1BhZ2UoZmVhdHVyZSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxuLy8gQ2F0ZWdvcnkgc3dpdGNoZXNcclxuJChcImgyIGlucHV0XCIpLmNoYW5nZShmdW5jdGlvbiAoKSB7XHJcbiAgbGV0IG9Td2l0Y2ggPSB0cnVlO1xyXG4gIGlmICgkKHRoaXMpLnByb3AoXCJjaGVja2VkXCIpID09IGZhbHNlKSB7XHJcbiAgICBvU3dpdGNoID0gZmFsc2U7XHJcbiAgfVxyXG4gIGxldCBvQ2xhc3MgPSAkKHRoaXMpLmNsb3Nlc3QoXCJoMlwiKS5kYXRhKFwiY2F0ZWdvcnlcIik7XHJcbiAgJChcIi5cIiArIG9DbGFzcylcclxuICAgIC5maW5kKFwiaW5wdXRcIilcclxuICAgIC5wcm9wKFwiY2hlY2tlZFwiLCBvU3dpdGNoKTtcclxufSk7XHJcblxyXG4vLyBTd2l0Y2ggYXQgdGhlIHRvcCB0byB0b2dnbGUgZXZlcnkgc3dpdGNoXHJcbiQoXCJoMVwiKS5hcHBlbmQoXHJcbiAgJChgPGRpdiBjbGFzcz1cImZlYXR1cmUtdG9nZ2xlXCI+XHJcbjxsYWJlbCBjbGFzcz1cInN3aXRjaFwiPlxyXG48aW5wdXQgdHlwZT1cImNoZWNrYm94XCI+XHJcbjxzcGFuIGNsYXNzPVwic2xpZGVyIHJvdW5kXCI+PC9zcGFuPlxyXG48L2xhYmVsPlxyXG48L2Rpdj5gKVxyXG4pO1xyXG5cclxuJChcImgxIGlucHV0XCIpLmNoYW5nZShmdW5jdGlvbiAoKSB7XHJcbiAgbGV0IG9Td2l0Y2ggPSB0cnVlO1xyXG4gIGlmICgkKHRoaXMpLnByb3AoXCJjaGVja2VkXCIpID09IGZhbHNlKSB7XHJcbiAgICBvU3dpdGNoID0gZmFsc2U7XHJcbiAgfVxyXG4gICQoXCJpbnB1dFt0eXBlPSdjaGVja2JveCddXCIpLnByb3AoXCJjaGVja2VkXCIsIG9Td2l0Y2gpO1xyXG59KTtcclxuXHJcbi8vIEF1dG8gc2F2ZSB0aGUgb3B0aW9ucyBvbiBjbGljayAob24gJ2NoYW5nZScgd291bGQgY3JlYXRlIGxvdHMgb2YgZXZlbnRzIHdoZW4gYSBiaWcgc3dpdGNoIGlzIGNsaWNrZWQpXHJcbi8vIFRoZSBzaG9ydCBkZWxheSBpcyBmb3IgdGhlIGNoYW5nZXMgdG8gaGFwcGVuIGFmdGVyIHRoZSBjbGlja1xyXG4kKFwiI29wdGlvbnMgLmZlYXR1cmUtdG9nZ2xlIGlucHV0W3R5cGU9J2NoZWNrYm94J11cIikuZWFjaChmdW5jdGlvbiAoKSB7XHJcbiAgJCh0aGlzKS5jbGljayhmdW5jdGlvbiAoKSB7XHJcbiAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgc2F2ZV9vcHRpb25zKCk7XHJcbiAgICB9LCAxMDApO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbi8vIGFkZHMgZmVhdHVyZSBIVE1MIHRvIHRoZSBvcHRpb25zIHBhZ2VcclxuZnVuY3Rpb24gYWRkRmVhdHVyZVRvT3B0aW9uc1BhZ2UoZmVhdHVyZURhdGEpIHtcclxuICBjb25zdCBmZWF0dXJlSFRNTCA9IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmVhdHVyZS1pbmZvcm1hdGlvbiAke2ZlYXR1cmVEYXRhLmNhdGVnb3J5fVwiIGlkPVwiJHtmZWF0dXJlRGF0YS5pZH1cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZlYXR1cmUtaGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmVhdHVyZS10b2dnbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJzd2l0Y2hcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzbGlkZXIgcm91bmRcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZlYXR1cmUtbmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgJHtmZWF0dXJlRGF0YS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmVhdHVyZS1kZXNjcmlwdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgJHtmZWF0dXJlRGF0YS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgO1xyXG5cclxuICAkKFwiI2ZlYXR1cmVzXCIpLmFwcGVuZChmZWF0dXJlSFRNTCk7XHJcbn1cclxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBfX3dlYnBhY2tfbW9kdWxlc19fO1xuXG4iLCJ2YXIgZGVmZXJyZWQgPSBbXTtcbl9fd2VicGFja19yZXF1aXJlX18uTyA9IChyZXN1bHQsIGNodW5rSWRzLCBmbiwgcHJpb3JpdHkpID0+IHtcblx0aWYoY2h1bmtJZHMpIHtcblx0XHRwcmlvcml0eSA9IHByaW9yaXR5IHx8IDA7XG5cdFx0Zm9yKHZhciBpID0gZGVmZXJyZWQubGVuZ3RoOyBpID4gMCAmJiBkZWZlcnJlZFtpIC0gMV1bMl0gPiBwcmlvcml0eTsgaS0tKSBkZWZlcnJlZFtpXSA9IGRlZmVycmVkW2kgLSAxXTtcblx0XHRkZWZlcnJlZFtpXSA9IFtjaHVua0lkcywgZm4sIHByaW9yaXR5XTtcblx0XHRyZXR1cm47XG5cdH1cblx0dmFyIG5vdEZ1bGZpbGxlZCA9IEluZmluaXR5O1xuXHRmb3IgKHZhciBpID0gMDsgaSA8IGRlZmVycmVkLmxlbmd0aDsgaSsrKSB7XG5cdFx0dmFyIFtjaHVua0lkcywgZm4sIHByaW9yaXR5XSA9IGRlZmVycmVkW2ldO1xuXHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuXHRcdGZvciAodmFyIGogPSAwOyBqIDwgY2h1bmtJZHMubGVuZ3RoOyBqKyspIHtcblx0XHRcdGlmICgocHJpb3JpdHkgJiAxID09PSAwIHx8IG5vdEZ1bGZpbGxlZCA+PSBwcmlvcml0eSkgJiYgT2JqZWN0LmtleXMoX193ZWJwYWNrX3JlcXVpcmVfXy5PKS5ldmVyeSgoa2V5KSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXy5PW2tleV0oY2h1bmtJZHNbal0pKSkpIHtcblx0XHRcdFx0Y2h1bmtJZHMuc3BsaWNlKGotLSwgMSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRmdWxmaWxsZWQgPSBmYWxzZTtcblx0XHRcdFx0aWYocHJpb3JpdHkgPCBub3RGdWxmaWxsZWQpIG5vdEZ1bGZpbGxlZCA9IHByaW9yaXR5O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihmdWxmaWxsZWQpIHtcblx0XHRcdGRlZmVycmVkLnNwbGljZShpLS0sIDEpXG5cdFx0XHR2YXIgciA9IGZuKCk7XG5cdFx0XHRpZiAociAhPT0gdW5kZWZpbmVkKSByZXN1bHQgPSByO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufTsiLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIvLyBubyBiYXNlVVJJXG5cbi8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4vLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbi8vIFtyZXNvbHZlLCByZWplY3QsIFByb21pc2VdID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxudmFyIGluc3RhbGxlZENodW5rcyA9IHtcblx0XCJvcHRpb25zXCI6IDBcbn07XG5cbi8vIG5vIGNodW5rIG9uIGRlbWFuZCBsb2FkaW5nXG5cbi8vIG5vIHByZWZldGNoaW5nXG5cbi8vIG5vIHByZWxvYWRlZFxuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0XG5cbl9fd2VicGFja19yZXF1aXJlX18uTy5qID0gKGNodW5rSWQpID0+IChpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPT09IDApO1xuXG4vLyBpbnN0YWxsIGEgSlNPTlAgY2FsbGJhY2sgZm9yIGNodW5rIGxvYWRpbmdcbnZhciB3ZWJwYWNrSnNvbnBDYWxsYmFjayA9IChwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbiwgZGF0YSkgPT4ge1xuXHR2YXIgW2NodW5rSWRzLCBtb3JlTW9kdWxlcywgcnVudGltZV0gPSBkYXRhO1xuXHQvLyBhZGQgXCJtb3JlTW9kdWxlc1wiIHRvIHRoZSBtb2R1bGVzIG9iamVjdCxcblx0Ly8gdGhlbiBmbGFnIGFsbCBcImNodW5rSWRzXCIgYXMgbG9hZGVkIGFuZCBmaXJlIGNhbGxiYWNrXG5cdHZhciBtb2R1bGVJZCwgY2h1bmtJZCwgaSA9IDA7XG5cdGlmKGNodW5rSWRzLnNvbWUoKGlkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2lkXSAhPT0gMCkpKSB7XG5cdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG5cdFx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8obW9yZU1vZHVsZXMsIG1vZHVsZUlkKSkge1xuXHRcdFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLm1bbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihydW50aW1lKSB2YXIgcmVzdWx0ID0gcnVudGltZShfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblx0fVxuXHRpZihwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbikgcGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24oZGF0YSk7XG5cdGZvcig7aSA8IGNodW5rSWRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y2h1bmtJZCA9IGNodW5rSWRzW2ldO1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhpbnN0YWxsZWRDaHVua3MsIGNodW5rSWQpICYmIGluc3RhbGxlZENodW5rc1tjaHVua0lkXSkge1xuXHRcdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdWzBdKCk7XG5cdFx0fVxuXHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG5cdH1cblx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18uTyhyZXN1bHQpO1xufVxuXG52YXIgY2h1bmtMb2FkaW5nR2xvYmFsID0gc2VsZltcIndlYnBhY2tDaHVua3dpa2l0cmVlX2Jyb3dzZXJfZXh0ZW5zaW9uXCJdID0gc2VsZltcIndlYnBhY2tDaHVua3dpa2l0cmVlX2Jyb3dzZXJfZXh0ZW5zaW9uXCJdIHx8IFtdO1xuY2h1bmtMb2FkaW5nR2xvYmFsLmZvckVhY2god2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCAwKSk7XG5jaHVua0xvYWRpbmdHbG9iYWwucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2guYmluZChjaHVua0xvYWRpbmdHbG9iYWwpKTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm5jID0gdW5kZWZpbmVkOyIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgZGVwZW5kcyBvbiBvdGhlciBsb2FkZWQgY2h1bmtzIGFuZCBleGVjdXRpb24gbmVlZCB0byBiZSBkZWxheWVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18uTyh1bmRlZmluZWQsIFtcInZlbmRvclwiXSwgKCkgPT4gKF9fd2VicGFja19yZXF1aXJlX18oXCIuL3NyYy9vcHRpb25zLmpzXCIpKSlcbl9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8oX193ZWJwYWNrX2V4cG9ydHNfXyk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=